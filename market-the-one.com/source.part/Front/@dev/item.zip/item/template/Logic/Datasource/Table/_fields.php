<?php

	 $fields = array ( 'id',  'market_product_id', 'payout', 'payout_type',  'clicks_in',  'conversions','clicks_in','clicks_out','url');

	
?>