-- phpMyAdmin SQL Dump
-- version 2.6.0-pl2
-- http://www.phpmyadmin.net
-- 
-- Хост: localhost
-- Время создания: Сен 12 2005 г., 00:45
-- Версия сервера: 4.1.12
-- Версия PHP: 5.0.4
-- 
-- БД: `bus`
-- 

-- --------------------------------------------------------

-- 
-- Структура таблицы `bus_tickets`
-- 

CREATE TABLE `bus_tickets` (
  `ticket_id` int(10) unsigned NOT NULL auto_increment,
  `bus_id` int(10) unsigned NOT NULL default '0',
  `ticket_status` enum('free','reserved','waiting') NOT NULL default 'free',
  `ticket_owner` enum('nobody','dealer','user','admin') NOT NULL default 'nobody',
  `ticket_owner_id` int(10) unsigned NOT NULL default '0',
  `ticket_place` int(11) NOT NULL default '0',
  `ticket_timedate` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `ticket_deleted` tinyint(1) NOT NULL default '0',
  `ticket_payed` tinyint(2) NOT NULL default '0',
  `dclient_id` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`ticket_id`),
  UNIQUE KEY `bus_ticket` (`ticket_place`,`bus_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Дамп данных таблицы `bus_tickets`
-- 

