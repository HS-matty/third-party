-- phpMyAdmin SQL Dump
-- version 3.5.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 18, 2014 at 07:47 AM
-- Server version: 5.5.32-log
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `_prj`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_users`
--

CREATE TABLE IF NOT EXISTS `auth_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(64) DEFAULT NULL,
  `company` varchar(128) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `phone_number` varchar(64) DEFAULT NULL,
  `login` varchar(64) NOT NULL,
  `sha_password` varchar(128) NOT NULL,
  `is_active` tinyint(4) DEFAULT '0',
  `type` enum('admin','client','manager') DEFAULT 'client',
  `is_payed` tinyint(4) NOT NULL DEFAULT '0',
  `balance` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `auth_users`
--

INSERT INTO `auth_users` (`id`, `group_id`, `first_name`, `last_name`, `company`, `email`, `phone_number`, `login`, `sha_password`, `is_active`, `type`, `is_payed`, `balance`) VALUES
(1, 1, 'Serj', 'Vol', 'none', 'byqdes@gmail.com', '2101664', 'descent', '7c4a8d09ca3762af61e59520943dc26494f8941b', 1, 'admin', 0, 3910),
(2, 1, 'name', 'last_name', 'company name', 'test@autopay', NULL, 'test-user', 'e10adc3949ba59abbe56e057f20f883e', 1, 'client', 0, 7178);

-- --------------------------------------------------------

--
-- Table structure for table `autopay_contractors`
--

CREATE TABLE IF NOT EXISTS `autopay_contractors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `autopay_contractors`
--

INSERT INTO `autopay_contractors` (`id`, `name`, `title`) VALUES
(1, 'MTS', 'MTS'),
(3, 'byfly', 'byfly'),
(4, 'Mgts', 'Mgts');

-- --------------------------------------------------------

--
-- Table structure for table `autopay_info`
--

CREATE TABLE IF NOT EXISTS `autopay_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` tinytext,
  `sum` float NOT NULL,
  `datetime` datetime NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `type_id` int(11) NOT NULL,
  `contractor_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `autopay_info`
--

INSERT INTO `autopay_info` (`id`, `name`, `title`, `description`, `sum`, `datetime`, `status`, `type_id`, `contractor_id`) VALUES
(1, 'Payment-1', 'Payment #1', 'Операция выполнена успешно', 100, '2014-05-17 00:00:00', 'Операция выполнена успешно', 1, 1),
(2, 'Payment-2', 'Payment #2', 'Операция выполнена успешно', 200, '2014-05-17 00:00:00', 'Операция выполнена успешно', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `autopay_payments`
--

CREATE TABLE IF NOT EXISTS `autopay_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` tinytext,
  `sum` float NOT NULL,
  `datetime` datetime NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `type_id` int(11) NOT NULL,
  `contractor_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `autopay_payments`
--

INSERT INTO `autopay_payments` (`id`, `name`, `title`, `description`, `sum`, `datetime`, `status`, `type_id`, `contractor_id`) VALUES
(1, 'Payment-1', 'Payment #1', 'Операция выполнена успешно', 100, '2014-05-17 00:00:00', 'Операция выполнена успешно', 1, 1),
(2, 'Payment-2', 'Payment #2', 'Операция выполнена успешно', 200, '2014-05-17 00:00:00', 'Операция выполнена успешно', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `autopay_schedule`
--

CREATE TABLE IF NOT EXISTS `autopay_schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` tinytext,
  `sum` float DEFAULT NULL,
  `date` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `types_contractors_id` int(11) NOT NULL,
  `period` enum('day','week','month') NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `types_contractors_id` (`types_contractors_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `autopay_schedule`
--

INSERT INTO `autopay_schedule` (`id`, `name`, `title`, `description`, `sum`, `date`, `status`, `types_contractors_id`, `period`) VALUES
(2, NULL, NULL, NULL, NULL, '2014-04-17', NULL, 1, 'month');

-- --------------------------------------------------------

--
-- Table structure for table `autopay_services`
--

CREATE TABLE IF NOT EXISTS `autopay_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone_number` varchar(255) NOT NULL,
  `type_contractor_id` int(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `balance` float NOT NULL DEFAULT '-50',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `autopay_services`
--

INSERT INTO `autopay_services` (`id`, `phone_number`, `type_contractor_id`, `password`, `balance`) VALUES
(1, '+375 2222', 4, '12345', 120),
(2, '2222', 4, '2222', 152),
(3, '+375 296 222', 4, '123456', 100),
(4, '+17 2222', 3, '2222', -50),
(5, '+375 297 22222', 3, '123456', -50);

-- --------------------------------------------------------

--
-- Table structure for table `autopay_types`
--

CREATE TABLE IF NOT EXISTS `autopay_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `title_ru` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `autopay_types`
--

INSERT INTO `autopay_types` (`id`, `name`, `title`, `title_ru`) VALUES
(1, 'Internet', 'Internet providers', 'Интернет провайдеры'),
(2, 'telecommunication', 'Telecommunication services', 'Услуги связи');

-- --------------------------------------------------------

--
-- Table structure for table `autopay_types_contractors`
--

CREATE TABLE IF NOT EXISTS `autopay_types_contractors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL,
  `contractor_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `autopay_types_contractors`
--

INSERT INTO `autopay_types_contractors` (`id`, `type_id`, `contractor_id`) VALUES
(1, 1, 1),
(2, 1, 3),
(3, 2, 1),
(4, 2, 4);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
