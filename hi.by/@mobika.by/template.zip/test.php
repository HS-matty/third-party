<?php
require 'template.php';

$tmpl = new cTemplate('tmpl/test.tmpl',array(
			'enable_eval_errors' => true,
			'disable_warnings' => 1
	));

$loop = array();
$loop[0]['ifl1'] = true;
$loop[0]['ifl2'] = true;
$loop[0]['loop_var'] = 'loop var 1';
$loop[1]['ifl1'] = true;
$loop[1]['ifl2'] = false;
$loop[1]['loop_var'] = 'loop var 2';
$loop[2]['ifl1'] = false;
$loop[2]['ifl2'] = true;
$loop[2]['loop_var'] = 'loop var 3';
$loop[3]['ifl1'] = false;
$loop[3]['ifl2'] = false;
$loop[3]['loop_var'] = 'loop var 4';

$tmpl->param['loop1'] = $loop;
$tmpl->param['if1'] = false;
$tmpl->param['if2'] = true;

$tmpl->param['var1'] = '<b>Test var</b>';
$tmpl->param['var2'] = 2;
$tmpl->param['var3'] = '2*2';

echo $tmpl->parse();

?>