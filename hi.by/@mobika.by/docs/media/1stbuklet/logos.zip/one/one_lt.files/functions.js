/*
	**********************************************************************
	Common JavaScript function library
	Author: Oleg M. Podolsky
	(c) ONE Ltd.
	**********************************************************************
*/
// keypress cuts the text in a textarea.
// Parameters - textarea object and max. text length

function keypress(textarea,maxlen)
{
	if(textarea.value.length > maxlen)
		textarea.value = textarea.value.substring(0,maxlen);
}


// Counts number of symbols in textarea and writes this number to textfield (full names)
function symbolcount(textarea, textfield, maxlen)
{
	n = maxlen - textarea.value.length;
	textfield.value = "" + n;
}



/*
	**********************************************************************
	Functions for form sumbmittion and window opening
	**********************************************************************
*/

// Checks whether string str starts with sub
function startsWith(str, sub)
{
	if (str.indexOf(sub, 0) == 0)
		return true;
	return false;
}

function transformButtonName(form, buttonname)
{
	var len = form.length;

	var eventsubmit_do = "eventsubmit_do";
	var _eventsubmit_doAction = "_" + buttonname.toLowerCase();

	for (i = 0; i < len; i++)
	{
		element = form.elements[i].name;
		if (startsWith(element.toLowerCase(), eventsubmit_do))
		{
			element = '_' + element;
			form.elements[i].name = element;
			form.elements[i].value = buttonname;
		}
		if (startsWith(element.toLowerCase(), _eventsubmit_doAction))
		{
//			alert(_eventsubmit_doAction.substring(1, _eventsubmit_doAction.length));
			form.elements[i].name = _eventsubmit_doAction.substring(1, _eventsubmit_doAction.length);
		}
	}
}

// submitForm sets the value hvalue for the form's hidden field hname,
// and submits the given form
function submitForm(form, hname)
{
	transformButtonName(form, hname);
	form.submit();
}



// windowForm opens a window with random name and given parameters
// and tells the given form to load results into it

function windowForm(form, buttonname, param)
{
	transformButtonName(form, buttonname);
	var date = new Date();
	var name = "" + date.getTime();
	var win = null;
	win = window.open("/portal/blank.html",name,param);

	form.target=name;
	form.submit();
//	form.target = "";
}

function windowFormCentered(form, buttonname, winwidth, winheight, param)
{
	transformButtonName(form, buttonname);
	var date = new Date();
	var name = "" + date.getTime();
	var win = null;
	win = openWinCentered(name, "/portal/blank.html", winheight, winwidth, param);

	form.target=name;
	form.submit();
//	form.target = "";
}

function windowFormShifted(form, buttonname, winwidth, winheight, offsetX, offsetY, param)
{
	transformButtonName(form, buttonname);
	var date = new Date();
	var name = "" + date.getTime();
	var win = null;
	win = openWinShifted(name,winheight,winwidth,"/portal/blank.html",offsetX,offsetY, param);

	form.target=name;
	form.submit();
//	form.target = "";
}

/**
* <p>
* Submits a form to the parent window of the current window. Also
* emulates the buttonclicking behaviour for Turbine, to determine which button
* was clicked.
* <p>
* Assumes that there exists a hidden tag with name <code>"_" + buttonname</code>.
* 
* @author <a href="mailto:neeme@one.lv">Neeme Praks</a>
* @version $Id: functions.js,v 1.2 2001/12/08 13:54:05 simon Exp $
* 
* @param form the form object to be submitted
* @param buttonname the name of the button that was clicked
*/

function windowFormToParent(form, buttonname)
{
	transformButtonName(form, buttonname);
	if (window.opener != null)
	{
		if (window.opener.name == "") window.opener.name="main";
		form.target=window.opener.name;
	}

	form.submit();
//	form.target = "";
}


// windowURL opens a window with random name and given parameters
// and loads a page with given URL into it

function windowURL(url,param)
{
	var date = new Date();
	var name = date.getTime();

	window.open(url,name,param);
}

function windowURLCentered(url, winwidth, winheight, param)
{
	var date = new Date();
	var name = date.getTime();

	var win = openWinCentered(name, url, winheight, winwidth, param);
//	window.open(url,name,param);
}



// cellclick loads a new page with given URL when clicking on a table cell
// (though, you can call this function when clicking on any object)
// URL must contain protocol name (http://..., ftp://..., etc.)

function cellclick(url)	
{
	window.location.href=url;
//	window.location.reload();
}



/*
	*******************************************************************
	Functions for selecting a distribution list of recipients from
	statically given set of folders
	*******************************************************************
*/

// Current folder index
var curFolder=0;

// Status array
var status = null;

// Array of selected items
var selected = null;
var selnum = 0;

// Checks if ch exists in array set
function existIn(ch, set)
{
	var i = 0;

	while(i < set.length)
		if(ch == set[i++]) return true;
	return false;
}

// Initialization: selected array and setting default folder
// Parameters: folder select-list and list for folder content (full names)
function init(folderList, sourceList, destList)
{
	status = new Array(folder.length);
	for(i=0; i < folder.length; i++)
	{
		status[i] = new Array(item[i].length);
		for(j=0; j < item[i].length; j++)
			if(existIn(itemID[i][j], preset)) status[i][j] = true;
			else status[i][j] = false;
	}

	selected = new Array( new Array(), new Array());
	findSelected();

	clearList(folderList);
	for(i = 0 ; i < folder.length ; i++)
		addItem(folderList, folder[i]);
	folderList.selectedIndex = 0;
	changeFolder(folderList, sourceList);
	showSelected(destList);
	unmarkAll(sourceList);
	unmarkAll(destList);
}

// Adds an item to select-list
// Parameters: select-list full name, text to write and element ID
function addItem(list, text, id)
{
	list.options[list.length] = new Option(text,""+id,false,false);
}

// Clears the select-list
function clearList(list)
{
	var listlen = list.length;

	for(i=0; i < listlen; i++)
		list.options[0] = null;
}

// Finds selected items in folders (status = true)
function findSelected()
{
	selnum = 0;

	for(i=0; i < folder.length; i++)
		for(j=0; j < item[i].length; j++)
			if(status[i][j] == true)
			{
				selected[0][selnum] = i;
				selected[1][selnum] = j;
				selnum++;
			}
}




// Adds selected items in sourceList to destList
function addSelected(sourceList, destList)	// From folder's list
{
	for(i=0; i < sourceList.length; i++)
		if(sourceList.options[i].selected)
			status[curFolder][i] = true;
	findSelected();
	showFolder(sourceList);
	showSelected(destList);

	unmarkAll(sourceList);
	unmarkAll(destList);
}

// Deletes selected items from sourceList to destList
function removeSelected(sourceList, destList)	// From selected items' list
{
	for(i=0; i < sourceList.length; i++)
		if(sourceList.options[i].selected)
			status [ selected[0][i] ] [ selected[1][i] ] = false;
	findSelected();
	showFolder(destList);
	showSelected(sourceList);

	unmarkAll(sourceList);
	unmarkAll(destList);
}

// Selects all items in sourceList and transfers them to destList
function addAll(sourceList, destList)
{
	for(i=0; i < item[curFolder].length; i++)
		status[curFolder][i] = true;
	findSelected();
	showFolder(sourceList);
	showSelected(destList);

	unmarkAll(sourceList);
	unmarkAll(destList);
}

// Removes all items from sourceList to destList
function removeAll(sourceList, destList)
{
	for(i=0; i < selnum; i++)
		status[selected[0][i]][selected[1][i]] = false;
			findSelected();
	showFolder(destList);
	showSelected(sourceList);

	unmarkAll(sourceList);
	unmarkAll(destList);
}

// Shows current folder in destList
function showFolder(destList)
{
	var destlen = item[curFolder].length;

	clearList(destList);
	for(i = 0 ; i < destlen; i++)
		if( status[curFolder][i] == false ) addItem(destList, item[curFolder][i], itemID[curFolder][i]);
		else addItem(destList, ">>> " + item[curFolder][i], itemID[curFolder][i]);

	unmarkAll(destList);
}

// Shows all selected items in destList
function showSelected(destList)
{
	clearList(destList);
	for(i=0; i < selnum; i++)
		addItem(destList, item[selected[0][i]][selected[1][i]] + " ("+folder[selected[0][i]]+")",
					itemID[selected[0][i]][selected[1][i]]);
}

// Changes to the folder that was selected in folderList and shows it destList
function changeFolder(folderList, destList)
{
	curFolder = folderList.selectedIndex;

	showFolder(destList);
}

// Marks all item in the given list
function markAll(list)
{
	for(i=0; i < list.length; i++)
		list.options[i].selected = true;
}

// Unmarks all item in the given list
function unmarkAll(list)
{
	for(i=0; i < list.length; i++)
		list.options[i].selected = false;
}


/*
	*******************************************************************
	 Other functions
	*******************************************************************
*/

function setDisabled(targetElement, isDisabled) {
//	alert(targetElement.name);
	targetElement.disabled = isDisabled;
}

function openWinCentered(winname, loc, heightt, widthh, params)
{  
	tp=Math.ceil((screen.height-heightt)/2);
	lf=Math.ceil((screen.width-widthh)/2);
	if (params.length > 0) params = "," + params;
	return window.open(loc,winname,"width="+widthh+",height="+heightt+",top="+tp+",left="+lf+params);
}

function openWinShifted(winname,heightt,widthh,loc,shiftx,shifty, params)
{
   naver=navigator.appVersion;
   
   if(navigator.appName=="Microsoft Internet Explorer" && 
      naver.substring(naver.indexOf("MSIE")+5,naver.lastIndexOf(';'))>'5.0')
   {
        tp=window.screenTop+shifty;
        lf=window.screenLeft+shiftx;
	if (params.length > 0) params = "," + params;
        window.open(loc,winname,"width="+widthh+" height="+heightt+" top="+tp+" left="+lf+params);
   }
   else if(navigator.appName=="Netscape" && naver.substring(0,naver.indexOf(' '))>'4.0')
   {            
        tp=window.screenY+shiftx;
        lf=window.screenX+shifty;
        tp+=window.outerHeight-window.innerHeight;
	if (params.length > 0) params = "," + params;
        window.open(loc,winname,'width='+widthh+',height='+heightt+',top='+tp+',left='+lf+params);
   }
   else window.open(loc,winname);
}

function openWinInMousePosition(heightt,widthh,loc,ex,ey, params)
{     
	tp=ey;
	lf=ex;                
	if (params.length > 0) params = "," + params;
	window.open(loc,"",'width='+widthh+',height='+heightt+',top='+tp+',left='+lf+params);
}

function selectAll(mainbox, boxname)
{
	var elems = mainbox.form.elements;
		var elemnum = elems.length;

	for(i=0; i < elemnum; i++)
		if(elems[i].name == boxname)
			elems[i].checked = mainbox.checked;
}

function appendQueryString(str)
{
	var date = new Date();
	var name = "" + date.getTime();

	if((str == null) || (str.length == 0))  str = '?';
	else
	{
		if(str.charAt(0) != '?')  str = '?' + str;
		if(str.length != 1)  str += '&';
	}
	str += name;

	return str;
}

// functions for symbol counting in Netscape
var timeoutt=1000;
var isrun=0;
var timID=0;

var textarr,textff,limitt;
function setviewer(textar,textf,limit)
{
	if(navigator.appName=='Netscape' && isrun==0)
	{
		isrun=1;
		textarr=textar;
		textff=textf;
		limitt=limit;
		timID=setTimeout("viewer()",timeoutt);
	}
	return true;
}

function viewer()
{
	if(isrun==1)
	{
		isrun=2;
		textff.focus();
		textarr.focus();  
		keypress(textarr,140); 
		symbolcount(textarr,textff,limitt);
		isrun=1;
		timID=setTimeout("viewer()",timeoutt);
	}     
}

function stoptimer()
{
	if(navigator.appName=='Netscape' && isrun==1)
	{
		clearTimeout(timID);
		isrun=0;
	}
	return true;
}


function markAutoContact(sourceList)
{
	for(i=0; i < sourceList.length; i++)
		if(sourceList.options[i].selected)
		{
			myValue = sourceList.options[i].text;
			myBool = myValue.substr(0,3) == ">>>";
			if(!myBool)
			{
				sourceList.options[i].text = ">>> " + myValue;
				sourceList.options[i].value = "!" + sourceList.options[i].value;
			}
			sourceList.options[i].selected = false;
		}
}
