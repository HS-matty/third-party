<?php
/***************************************************************************
                          page_header.php  -  description
                             -------------------
    begin                : Sat June 17 2000
    copyright            : (C) 2001 The phpBB Group
    email                : support@phpbb.com
 
    $Id: page_header.php,v 1.74 2001/06/27 19:09:13 bartvb Exp $ 

 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

$mtime = microtime();
$mtime = explode(" ",$mtime);
$mtime = $mtime[1] + $mtime[0];
$starttime = $mtime;



/* Who's Online Hack */
$IP=$REMOTE_ADDR;

if($pagetype == "index") {
	$users_online = get_whosonline($IP, $userdata[username], 0, $db);
}
if($pagetype == "viewforum" || $pagetype == "viewtopic") {
	$users_online = get_whosonline($IP, $userdata[username], $forum, $db);
}
if($pagetype == "admin") {
	$header_image = "../$header_image";
}


$login_logout_link = make_login_logout_link($user_logged_in, $url_phpbb);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<HTML>
<HEAD>
<TITLE><?php echo "$sitename $l_forums - $pagetitle" ?></TITLE>
<?php
if($l_special_meta) {
	echo $l_special_meta . "\n";
}
if($forward) {
	echo "<META HTTP-EQUIV=\"refresh\" content=\"3;URL=$url_phpbb/viewtopic.$phpEx?topic=$topic&forum=$forum&$total_topic\">";
} 
$meta = showmeta($db);
?>
<?php echo $meta?>
</HEAD>
<BODY BGCOLOR="<?php echo $bgcolor?>" TEXT="<?php echo $textcolor?>" LINK="<?php echo $linkcolor?>" VLINK="<?php echo $vlinkcolor?>">
<div align=center>
<font face="<?php echo $FontFace?>">
<?php

showheader($db);

//  Table layout (col and rowspans are marked with '*' and '-')
//  *one*   | two
//  *three* | four
//  -five-  | -six-

// cell one and three in the first TD with rowspan (logo)
?>
<?php
// Switch for cell two  (posts buttons)
switch($pagetype) {
	// 'index' is covered by default
	case 'newtopic':
?>

		<FONT FACE="<?php echo $FontFace?>" SIZE="<?php echo $FontSize2?>" COLOR="<?php echo $textcolor?>"><b>Post New Topic in:<BR>
		<a href="<?php echo $url_phpbb?>/viewforum.<?php echo $phpEx ?>?forum=<?php echo $forum?>"><?php echo $forum_name?></a></b>
		</font>

<?php
	break;
	case 'viewforum':
?>

		<a href="<?php echo $url_phpbb?>/newtopic.<?php echo $phpEx ?>?forum=<?php echo $forum?>"><IMG SRC="<?php echo $newtopic_image?>" BORDER="0"></a>
	</TD>
<?php
	break;
	case 'viewtopic':
?>

		<a href="<?php echo $url_phpbb?>/newtopic.<?php echo $phpEx ?>?forum=<?php echo $forum?>">
			<IMG SRC="<?php echo $newtopic_image?>" BORDER="0"></a>&nbsp;&nbsp;
<?php
	if($lock_state != 1) {
?>
		<a href="<?php echo $url_phpbb?>/reply.<?php echo $phpEx ?>?topic=<?php echo $topic?>&forum=<?php echo $forum?>">
			<IMG SRC="<?php echo $reply_image?>" BORDER="0"></a></TD>
<?php
	}
	else
			echo "<img src=\"$reply_locked_image\" BORDER=0>\n";
?>

<?php
	break;
	// 'Register' is covered by default
	case '':
?>
<?php
        default:
?>

		<FONT FACE="<?php echo $FontFace?>" SIZE="<?php echo $FontSize4?>" COLOR="<?php echo $textcolor?>"><?php echo "$sitename $l_forums"?></font>

<?php
	break;
}  // End for switch cell two
// Cell four (block with links)
?>
<table width="30%" border="0" align="right" cellpadding="0" cellspacing="0">

 <tr>
    <td> 

		<div align=center><FONT FACE="<?php echo $FontFace?>" SIZE="<?php echo $FontSize1?>" COLOR="<?php echo $textcolor?>">
		[<a href="<?php echo $url_phpbb?>/bb_register.<?php echo $phpEx ?>?mode=agreement"><?php echo $l_register?></a>]&nbsp;
		[<a href="<?php echo $url_phpbb?>/bb_profile.<?php echo $phpEx ?>?mode=edit"><?php echo $l_editprofile?></a>]&nbsp;
		[<a href="<?php echo $url_phpbb?>/prefs.<?php echo $phpEx ?>"><?php echo $l_editprefs?></a>]&nbsp;
		[<a href="<?php echo $url_phpbb?>/search.<?php echo $phpEx ?>"><?php echo $l_search?></a>]<br>
		
		[<a href="<?php echo $url_phpbb?>/viewpmsg.<?php echo $phpEx ?>"><?php echo $l_privmsgs?></a>]&nbsp;
		[<a href="<?php echo $url_phpbb?>/bb_memberlist.<?php echo $phpEx ?>"><?php echo $l_memberslist?></a>]&nbsp;
		[<a href="<?php echo $url_phpbb?>/<?php echo $faq_url ?>"><?php echo $l_faq?></a>]&nbsp;
		[<?php echo $login_logout_link?>]</div></font></td></tr><br>
	<tr><td>
<?php		
		if ($user_logged_in)
		{
			// do PM notification.
			$last_visit_date = date("Y-m-d h:i", $last_visit);
			
			$username = addslashes($userdata[username]);
			
			$sql = "SELECT count(*) AS count FROM priv_msgs WHERE msg_status = '0' and to_userid = '$userdata[user_id]'";	
			 
			if(!$result = mysql_query($sql, $db))
			{
				error_die("phpBB was unable to check private messages because " .mysql_error($db));
			}
		
			$row = @mysql_fetch_array($result);
			$new_message = $row[count];
			$word = ($new_message > 1) ? "messages" : "message";
			$privmsg_url = "$url_phpbb/viewpmsg.$phpEx";
			
			if ($new_message != 0)
			{
				eval($l_privnotify);
				print $privnotify;
			}
		}
?>		
		
		


<?php
//Third row with cell five and six (misc. information)
switch($pagetype) {
	case 'index':
	$total_posts = get_total_posts("0", $db, "all");
	$total_users = get_total_posts("0", $db, "users");
	$sql = "SELECT username, user_id FROM users WHERE user_level != -1 ORDER BY user_id DESC LIMIT 1";
	$res = mysql_query($sql, $db);
	$row = mysql_fetch_array($res);
	$newest_user = $row["username"];
	$newest_user_id = $row["user_id"];
	$profile_url = "$url_phpbb/bb_profile.$phpEx?mode=view&user=$newest_user_id";
	$online_url = "$url_phpbb/whosonline.$phpEx";

?>


		<FONT FACE="<?php echo $FontFace?>" SIZE="<?php echo $FontSize1?>" COLOR="<?php echo $textcolor?>">
		<?php 
			eval($l_statsblock);
			print $statsblock;
			print_login_status($user_logged_in, $userdata[username], $url_phpbb);
		?>
		</font> </TD>
    </TR>

  </TABLE></div><p>&nbsp;</p>

<?php
	break;
	case 'newforum':
	// No third row
	break;
	case 'viewforum':
?>
	<FONT FACE="<?php echo $FontFace?>" SIZE="<?php echo $FontSize2?>" COLOR="<?php echo $textcolor?>">
		<b><?php echo $forum_name?></b>
		<BR>
		<FONT FACE="<?php echo $FontFace?>" SIZE="<?php echo $FontSize1?>" COLOR="<?php echo $textcolor?>">
			<?php echo $l_moderatedby?>:
<?php
$count = 0;     
$forum_moderators = get_moderators($forum, $db);
   while(list($null, $mods) = each($forum_moderators)) {
      while(list($mod_id, $mod_name) = each($mods)) {
	 if($count > 0)
	   echo ", ";
	 echo "<a href=\"bb_profile.$phpEx?mode=view&user=$mod_id\">".trim($mod_name)."</a>";
	 $count++;
      }
   }
?></font>


<?php
	case 'viewtopic':
	$total_forum = get_total_posts($forum, $db, 'forum');
?>
	<FONT FACE="<?php echo $FontFace?>" SIZE="<?php echo $FontSize1?>" COLOR="<?php echo $textcolor?>">
		<a href="<?php echo $url_phpbb?>/index.<?php echo $phpEx ?>"><?php echo $sitename?> Forum Index</a>
		<b><?php echo $l_separator?></b>
		<a href="<?php echo "$url_phpbb/viewforum.$phpEx?forum=$forum&$total_forum"?>"><?php echo stripslashes($forum_name)?></a> 
<?php
        if($pagetype != "viewforum")
		echo "<b>$l_separator</b>";
?>
		<?php echo $topic_subject?>
<?php
	break;
	case 'privmsgs':
?>
	<FONT FACE="<?php echo $FontFace?>" SIZE="<?php echo $FontSize2?>" COLOR="<?php echo $textcolor?>">
		[<a href="<?php echo $url_phpbb?>/sendpmsg.<?php echo $phpEx ?>"><?php echo $l_sendpmsg?></a>]

<?php
	break;
}
?>

