<?php

require("./global.php");

if ($allowsearches==0) {
  echo standarderror($bbtitle,"Sorry. The search function has been disabled by the administrator.");

  exit;
}

if (isset($action)==0 or $action=="") {
  $action="intro";
}

if ($action=="intro") {

  $jumpforumbits="";
  $forums=$DB_site->query("SELECT forumid,title,displayorder FROM forum WHERE displayorder<>0 ORDER BY displayorder");
  while ($forum=$DB_site->fetch_array($forums)) {
    $jumpforumid=$forum[forumid];
    $jumpforumtitle="  $forum[title]";

    eval("\$jumpforumbits .= \"".gettemplate("jumpforumbit")."\";");
  }
  eval("echo dovars(\"".gettemplate("searchintro")."\");");
}

if (strstr($searchuser,"%")>0) {
  $searchuser=urldecode($searchuser);
}

if ($action=="simplesearch") {
  if ($query=="" and $searchuser=="" and $getdaily!="yes") {
    echo standarderror($bbtitle,gettemplate("error_searchspecifyterms",0));

    exit;
  }

  $query=urlencode($query);
  $searchuser=urlencode($searchuser);

  echo standardredirect($bbtitle,"Thank you for searching. Your search is in progress and you will be taken to the results in a moment. Thank you for your patience.","search.php?query=".addslashes($query)."&forumchoice=".addslashes($forumchoice)."&booleanand=".addslashes($booleanand)."&searchin=".addslashes($searchin)."&searchuser=".addslashes($searchuser)."&exactname=".addslashes($exactname)."&action=dosearch&pagenum=".intval($pagenum));

}

if ($action=="dosearch") {

  $query=wordsonly(urldecode($query));
  $searchuser=wordsonly(urldecode($searchuser));

  if ($query=="" and $searchuser=="") {
    echo standarderror($bbtitle,gettemplate("error_searchspecifyterms",0));

    exit;
  }

  $words=explode(" ",addslashes($query));

  $query=htmlspecialchars($query);

  if ($query!="") {
    if ($booleanand=="yes") {
      $joiner="AND";
    } else {
      $joiner="OR";
    }

    if ($searchin=="subject") {
      $searchfield="subjectindex";
    } else {
      $searchfield="threadindex";
    }

    $combinedwords="AND (INSTR($searchfield,'".implode($words,"')>0 $joiner INSTR($searchfield,'")."')>0)";

  } else {
    if ($searchuser=="" and $getdaily!="yes") {
      echo standarderror($bbtitle,gettemplate("error_searchspecifyterms",0));

      exit;
    }

    $combinedwords="";
    $subjectonly="";
  }

  if ($searchuser!="") {
    if ($exactname=="yes") {
      $checkuser="AND INSTR(userindex,' ".addslashes($searchuser)." ')>0";
    } else {
      $checkuser="AND INSTR(userindex,'".addslashes($searchuser)."')>0";
    }
  } else {
    $checkuser="";
  }

  if ($forumchoice!=-1 and isset($forumchoice)!=0 and $forumchoice!=0) {
    $checkforum="AND thread.forumid=$forumchoice";
  }

  $searchresults=$DB_site->query("SELECT DISTINCT
    threadid,
    lastpost
    FROM thread
    WHERE 1=1 $checkforum $subjectonly $checkuser $combinedwords
    ORDER BY lastpost DESC");

  $countmatches=$DB_site->num_rows($searchresults);

  makeforumjump();

  // set defaults
  if (isset($perpage)==0 or $perpage==0 or $perpage=="") {
    $perpage=20;
  }
  if (isset($pagenum)==0 or $pagenum==0 or $pagenum=="") {
    $pagenum=1;
  }

  if ($countmatches!=0) {
    $first=($pagenum-1)*$perpage;
    $lower=$first+1;
    $upper=$pagenum*$perpage;
    if ($upper>$countmatches) {
      $upper=$countmatches;
    }

    $DB_site->data_seek($first,$searchresults);

    $curres=0;

    while ($searchresult=$DB_site->fetch_array($searchresults) and $curres++<$perpage) {
      $threadinfo=$DB_site->query_first("SELECT title,postusername,dateline,postusername,replycount FROM thread WHERE threadid=$searchresult[threadid]");

      $foruminfo=$DB_site->query_first("SELECT forum.forumid,forum.title FROM thread,forum WHERE forum.forumid=thread.forumid and thread.threadid=$searchresult[threadid]");
      $forumtitle=htmlspecialchars($foruminfo[title]);
      $forumid=$foruminfo[forumid];

      $searchlink="showthread.php?threadid=$searchresult[threadid]";
      $postusername=$threadinfo[postusername];
      $dateline=@date($dateformat,$threadinfo[dateline]+($timeoffset*3600));
      $threadtitle=htmlspecialchars($threadinfo[title]);
      $poster=htmlspecialchars($threadinfo[postusername]);
      $lastpostdate=date($dateformat,$searchresult[lastpost]+($timeoffset*3600));

      eval ("\$searchresultbits .= \"".gettemplate("searchresultbit")."\";");
    }

    if ($upper<$countmatches) {
      $nextpagelink="<a href=\"search.php?query=".urlencode($query)."&getdaily=$getdaily&forumchoice=$forumchoice&searchin=$searchin&booleanand=$booleanand&searchuser=".urlencode($searchuser)."&exactname=$exactname&action=simplesearch&pagenum=".($pagenum+1)."\">[Next Page]</a>";
    } else {
      $nextpagelink="";
    }

  } else {

    echo standarderror($bbtitle,"Sorry - no matches. Please try some different terms.");

    exit;
  }

  eval("echo dovars(\"".gettemplate("searchresults")."\");");

}

?>