<?php

require ("./global.php");

function getprop ($text,$prop) {

  $prop.="=\"";

  $text=strtolower($text);
  $prop=strtolower($prop);

  if (strpos($text,$prop)>0) {
    $firstbit=substr($text,strpos($text,$prop)+strlen($prop));
    $retval=substr($firstbit,0,strpos($firstbit,"\""));
  } else {
    $retval="";
  }

  return $retval;

}

?>
<html>
<body>
<?php

if (isset($action)==0) {
  $action="options";
}

if ($action=="options") {

echo "<form action=\"options.php\" method=\"post\">
<input type=\"hidden\" name=\"action\" value=\"dooptions\">

<table border=0><tr><td colspan=2><hr></td></tr>
<tr>
<td><a name=\"bbactive\"></a><b>bbactive</b></td>
<td>Yes<input type=\"radio\" name=\"newoption[bbactive]\"  ".iif($bbactive==1,"checked","")." value=\"1\"> No <input type=\"radio\" name=\"newoption[bbactive]\" ".iif($bbactive==0,"checked","")." value=\"0\"></td>
</tr>
<tr><td colspan=2>From time to time, you may want to turn your bulletin board off to the public while you perform maintenance, update versions, etc. When you turn your BB off, visitors will receive a message that states that the bulletin board is temporarily unavailable.
<br>

<br>
Use this as a master switch for your board. You can set options for individual user groups in the User Permissions area.
</td></tr>
<tr>
<td><b>bbclosedreason</b></td>
<td><input type=\"text\" size=\"35\" name=\"newoption[bbclosedreason]\" value=\"$bbclosedreason\"></td>
</tr>
<tr><td colspan=2>The text that is presented when the BB is closed.<br></td></tr>

<tr><td colspan=2><hr></td></tr>
<tr>
<td><a name=\"general\"></a><b>bbtitle</b></td>
<td><input type=\"text\" size=\"35\" name=\"newoption[bbtitle]\" value=\"$bbtitle\"></td>
</tr>
<tr><td colspan=2>Title of board. Appears in the title of every page.<br></td></tr>
<tr>
<td><b>hometitle</b></td>
<td><input type=\"text\" size=\"35\" name=\"newoption[hometitle]\" value=\"$hometitle\"></td>
</tr>
<tr><td colspan=2>Name of your homepage. Appears at the bottom of every page.<br></td></tr>
<tr><td colspan=2>URL (with no final \"/\") of the BB.<br></td></tr>
<tr>
<td><b>homeurl</b></td>
<td><input type=\"text\" size=\"35\" name=\"newoption[homeurl]\" value=\"$homeurl\"></td>
</tr>
<tr><td colspan=2>URL of your home page. Appears at the bottom of every page.<br></td></tr>

<tr><td colspan=2><hr></td></tr>
<tr>
<td><a name=\"contact\"></a><b>contactuslink</b></td>
<td><input type=\"text\" size=\"35\" name=\"newoption[contactuslink]\" value=\"$contactuslink\"></td>
</tr>
<tr><td colspan=2>Link for contacting the site. Can just be mailto:webmaster@whereever.com or your own form. Appears at the bottom of every page.<br></td></tr>
<tr>
<td><b>webmasteremail</b></td>
<td><input type=\"text\" size=\"35\" name=\"newoption[webmasteremail]\" value=\"$webmasteremail\"></td>
</tr>
<tr><td colspan=2>Email address of the webmaster.<br></td></tr>
<tr>
<td><b>technicalemail</b></td>
<td><input type=\"text\" size=\"35\" name=\"newoption[technicalemail]\" value=\"$technicalemail\"></td>
</tr>
<tr><td colspan=2>Email address of the technical contact for the BB. This receives all database errors.<br></td></tr>

<tr><td colspan=2><hr></td></tr>

<tr>
<td><b>showforumdescriptions</b></td>
<td>Yes<input type=\"radio\" name=\"newoption[showforumdescriptions]\"  ".iif($showforumdescriptions==1,"checked","")." value=\"1\"> No <input type=\"radio\" name=\"newoption[showforumdescriptions]\" ".iif($showforumdescriptions==0,"checked","")." value=\"0\"></td>
</tr>
<tr><td colspan=2>Show forum desciptions on the homepage.
</td></tr>
<tr>
<td><a name=\"users\"></a><b>displayemails</b></td>
<td>Yes<input type=\"radio\" name=\"newoption[displayemails]\"  ".iif($displayemails==1,"checked","")." value=\"1\"> No <input type=\"radio\" name=\"newoption[displayemails]\" ".iif($displayemails==0,"checked","")." value=\"0\"></td>
</tr>
<tr><td colspan=2>Allow public viewing of email addresses.
</tr>
<tr>
<td><b>cookietimeout</b></td>
<td><input type=\"text\" size=\"35\" name=\"newoption[cookietimeout]\" value=\"$cookietimeout\"></td>
</tr>
<tr><td colspan=2>This is the time that a user must remain inactive before the unread posts are reset to read.<br></td></tr>
<tr>
<td><b>cookiepath</b></td>
<td><input type=\"text\" size=\"35\" name=\"newoption[cookiepath]\" value=\"$cookiepath\"></td>
</tr>
<tr><td colspan=2>The path that the cookie is saved to. If you run more than one board on the same domain, it will be neccessary to set this to the inidividual directories of the forums. Otherwise, just leave it as / .<br></td></tr>

<tr><td colspan=2><hr></td></tr>
<tr>
<td><b>maxthreads</b></td>
<td><input type=\"text\" size=\"35\" name=\"newoption[maxthreads]\" value=\"$maxthreads\"></td>
</tr>
<tr><td colspan=2>The number of threads to display on a forum page before splitting it over multiple pages.<br></td></tr>

<tr><td colspan=2><hr></td></tr>
<tr>
<td><a name=\"search\"></a><b>allowsearches</b></td>
<td>Yes<input type=\"radio\" name=\"newoption[allowsearches]\"  ".iif($allowsearches==1,"checked","")." value=\"1\"> No <input type=\"radio\" name=\"newoption[allowsearches]\" ".iif($allowsearches==0,"checked","")." value=\"0\"></td>
</tr>
<tr><td colspan=2>Allow searching for posts within the BB. This is quite a server intensive process so you may want to disable it.</td></tr>

<tr><td colspan=2><hr></td></tr>
<tr>
<td><a name=\"datetime\"></a><b>timeoffset</b></td>
<td><input type=\"text\" size=\"35\" name=\"newoption[timeoffset]\" value=\"$timeoffset\"></td>
</tr>
<tr><td colspan=2>Time (in hours) that you want displayed times to be offset from the default server time. Can be negative or positive.<br></td></tr>
<tr>
<td><b>timezone</b></td>
<td><input type=\"text\" size=\"35\" name=\"newoption[timezone]\" value=\"$timezone\"></td>
</tr>
<tr><td colspan=2>Text to describle what time zone the server is in.<br></td></tr>
<tr>
<td><b>dateformat</b></td>
<td><input type=\"text\" size=\"35\" name=\"newoption[dateformat]\" value=\"$dateformat\"></td>
</tr>
<tr><td colspan=2>Format that the date is presented in on the pages.
<br>

<br>
See: <a href=\"http://www.php.net/manual/function.date.php3\" target=_blank>http://www.php.net/manual/function.date.php3</a>
<br>

<br>
Examples:
<br>
US Format (e.g., 04-25-98) - m-d-y
<br>
Expanded US Format (e.g., April 25th, 1998) - F jS, Y
<br>
European Format (e.g., 25-04-98) - d-m-Y
<br>
Expanded European Format (e.g., 25th April 1998) - jS F Y<br></td></tr>
<tr>
<td><b>timeformat</b></td>
<td><input type=\"text\" size=\"35\" name=\"newoption[timeformat]\" value=\"$timeformat\"></td>
</tr>
<tr><td colspan=2>Format that the time is presented in on the pages.
<br>

<br>
See: <a href=\"http://www.php.net/manual/function.date.php3\" target=_blank>http://www.php.net/manual/function.date.php3</a>
<br>

<br>
Examples:
<br>
Use AM/PM Time Format (eg, 11:15 PM) - h:i A
<br>
User 24-Hour Format Time (eg, 23:15) - H:i<br></td></tr>

<tr>
<tr><td colspan=2><hr></td></tr>
<td><a name=\"styles\"></a><b>titleimage</b></td>
<td><input type=\"text\" size=\"35\" name=\"newoption[titleimage]\" value=\"$titleimage\"></td>
</tr>
<tr><td colspan=2>The image that is used globally as the title image.<br></td></tr>
</table>
<div align=\"center\"><center><table border=\"0\">
<tr>
<td><p align=\"center\"><input type=\"submit\" name=\"submit\" value=\"Submit\"></p></td>
<td><p align=\"center\"><input type=\"reset\" name=\"reset\" value=\"Reset\"></p></td>
</tr>
</table>
</center></div>
</form>";

}

// ###################### Start set options #######################
if ($action=="dooptions") {

  while (list($key,$val)=each($newoption)) {
    if (get_magic_quotes_gpc()==1) {
      $val=stripslashes($val);
    }
    $val=str_replace("\$","\\\$",$val);
    $val=str_replace("\"","\\\"",$val);
    $opttemp.="\$$key = \"$val\";\n";
  }

  $opttemp.="\$versionnumber = \"$versionnumber\";\n";

  $DB_site->query("UPDATE template SET template='".addslashes($opttemp)."' WHERE title='options'");

  echo "Thanks for updating the options.";

}

if ($action=="styles") {

  echo "<p>Leave a field blank to use the default. This styles area of the control panel provides a more friendly interface to the templates and replacements sections. If you find that you cannot do something through this area, go directly to the templates and replacements sections.</p>";

  echo doformheader("options","dostyles");
  echo "<table border=0>";

  $headerinsert=$DB_site->query_first("SELECT template FROM template WHERE title='cssinclude'");
  echo maketextareacode("Head Insert:<br>Code that is placed in &lt;head&gt; &lt;/head&gt; tags","cssinclude",$headerinsert[template],8,50);

  $header=$DB_site->query_first("SELECT template FROM template WHERE title='header'");
  echo maketextareacode("Header:","header",$header[template],8,50);

  $footer=$DB_site->query_first("SELECT template FROM template WHERE title='footer'");
  echo maketextareacode("footer:","footer",$footer[template],8,50);

  if ($body=$DB_site->query_first("SELECT replaceword FROM replacement WHERE findword='<body>'")) {
    echo makeinputcode("Body tag","body",$body[replaceword]);
  }

  if ($largefont=$DB_site->query_first("SELECT replaceword FROM replacement WHERE findword='<largefont'")) {
    echo makeinputcode("Large Font: face","largefontface",getprop($largefont[replaceword],"face"));
    echo makeinputcode("Large Font: size","largefontsize",getprop($largefont[replaceword],"size"));
    echo makeinputcode("Large Font: color","largefontcolor",getprop($largefont[replaceword],"color"));
  }
  if ($smallfont=$DB_site->query_first("SELECT replaceword FROM replacement WHERE findword='<smallfont'")) {
    echo makeinputcode("Small Font: face","smallfontface",getprop($smallfont[replaceword],"face"));
    echo makeinputcode("Small Font: size","smallfontsize",getprop($smallfont[replaceword],"size"));
    echo makeinputcode("Small Font: color","smallfontcolor",getprop($smallfont[replaceword],"color"));
  }
  if ($font=$DB_site->query_first("SELECT replaceword FROM replacement WHERE LEFT(findword,11)='<normalfont'")) {
    echo makeinputcode("Main Font: face","fontface",getprop($font[replaceword],"face"));
    echo makeinputcode("Main Font: size","fontsize",getprop($font[replaceword],"size"));
    echo makeinputcode("Main Font: color","fontcolor",getprop($font[replaceword],"color"));
  }

  $categorybackcolor=$DB_site->query_first("SELECT replaceword FROM replacement WHERE findword='{categorybackcolor}'");
  echo makeinputcode("Category Strip Background Color","categorybackcolor",$categorybackcolor[replaceword]);

  $categoryfontcolor=$DB_site->query_first("SELECT replaceword FROM replacement WHERE findword='{categoryfontcolor}'");
  echo makeinputcode("Category Strip font Color","categoryfontcolor",$categoryfontcolor[replaceword]);

  $tableheadbgcolor=$DB_site->query_first("SELECT replaceword FROM replacement WHERE findword='{tableheadbgcolor}'");
  echo makeinputcode("Table Heading Background Color","tableheadbgcolor",$tableheadbgcolor[replaceword]);

  $tableheadtextcolor=$DB_site->query_first("SELECT replaceword FROM replacement WHERE findword='{tableheadtextcolor}'");
  echo makeinputcode("Table Heading Text Color","tableheadtextcolor",$tableheadtextcolor[replaceword]);

  $linkcolor=$DB_site->query_first("SELECT replaceword FROM replacement WHERE findword='{linkcolor}'");
  echo makeinputcode("Link Color","linkcolor",$linkcolor[replaceword]);

  $hovercolor=$DB_site->query_first("SELECT replaceword FROM replacement WHERE findword='{hovercolor}'");
  echo makeinputcode("Hover Color for Links","hovercolor",$hovercolor[replaceword]);

  $timecolor=$DB_site->query_first("SELECT replaceword FROM replacement WHERE findword='{timecolor}'");
  echo makeinputcode("Time Color (This color is used for the time field on the main forum summary page and the forum pages)","timecolor",$timecolor[replaceword]);

  $firstaltcolor=$DB_site->query_first("SELECT replaceword FROM replacement WHERE findword='{firstaltcolor}'");
  echo makeinputcode("First Alternating Table Background Color","firstaltcolor",$firstaltcolor[replaceword]);

  $secondaltcolor=$DB_site->query_first("SELECT replaceword FROM replacement WHERE findword='{secondaltcolor}'");
  echo makeinputcode("Second Alternating Table Background Color","secondaltcolor",$secondaltcolor[replaceword]);

  echo "<tr><td colspan=2>These two 'alternating' colors are used alternately in long lists so that one row can easily be told from the next.</td></tr>";

  echo doformfooter();

}

if ($action=="dostyles") {

  $DB_site->query("UPDATE template SET template='".addslashes($cssinclude)."' WHERE title='cssinclude'");
  $DB_site->query("UPDATE template SET template='".addslashes($header)."' WHERE title='header'");
  $DB_site->query("UPDATE template SET template='".addslashes($footer)."' WHERE title='footer'");

  if ($body=="") {
    $body="<body>";
  }
  $DB_site->query("UPDATE replacement SET replaceword='".addslashes($body)."' WHERE findword='<body>'");

  $largefont="<b><FONT ";
  if ($largefontface!="") {
    $largefont.="face=\"$largefontface\" ";
  }
  if ($largefontsize!="") {
    $largefont.="size=\"$largefontsize\" ";
  }
  if ($largefontcolor!="") {
    $largefont.="color=\"$largefontcolor\" ";
  }
  $DB_site->query("UPDATE replacement SET replaceword='".addslashes($largefont)."' WHERE findword='<largefont'");

  $smallfont="<FONT ";
  if ($smallfontface!="") {
    $smallfont.="face=\"$smallfontface\" ";
  }
  if ($smallfontsize!="") {
    $smallfont.="size=\"$smallfontsize\" ";
  }
  if ($smallfontcolor!="") {
    $smallfont.="color=\"$smallfontcolor\" ";
  }
  $DB_site->query("UPDATE replacement SET replaceword='".addslashes($smallfont)."' WHERE findword='<smallfont'");

  $font="<FONT ";
  if ($fontface!="") {
    $font.="face=\"$fontface\" ";
  }
  if ($fontsize!="") {
    $font.="size=\"$fontsize\" ";
  }
  if ($fontcolor!="") {
    $font.="color=\"$fontcolor\" ";
  }
  $DB_site->query("UPDATE replacement SET replaceword='".addslashes($font)."' WHERE findword='<normalfont'");

  $DB_site->query("UPDATE replacement SET replaceword='".addslashes($categorybackcolor)."' WHERE findword='{categorybackcolor}'");
  $DB_site->query("UPDATE replacement SET replaceword='".addslashes($categoryfontcolor)."' WHERE findword='{categoryfontcolor}'");
  $DB_site->query("UPDATE replacement SET replaceword='".addslashes($tableheadbgcolor)."' WHERE findword='{tableheadbgcolor}'");
  $DB_site->query("UPDATE replacement SET replaceword='".addslashes($tableheadtextcolor)."' WHERE findword='{tableheadtextcolor}'");
  $DB_site->query("UPDATE replacement SET replaceword='".addslashes($linkcolor)."' WHERE findword='{linkcolor}'");
  $DB_site->query("UPDATE replacement SET replaceword='".addslashes($hovercolor)."' WHERE findword='{hovercolor}'");
  $DB_site->query("UPDATE replacement SET replaceword='".addslashes($timecolor)."' WHERE findword='{timecolor}'");
  $DB_site->query("UPDATE replacement SET replaceword='".addslashes($firstaltcolor)."' WHERE findword='{firstaltcolor}'");
  $DB_site->query("UPDATE replacement SET replaceword='".addslashes($secondaltcolor)."' WHERE findword='{secondaltcolor}'");

  echo "<p>Styles updated</p>";

}

?>
</body>
</html>
