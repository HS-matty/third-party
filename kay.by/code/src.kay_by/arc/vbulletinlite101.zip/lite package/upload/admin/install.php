<html>
<!--
<?php

// determine if php is running
if (1==0) {
  echo "-->You are not running PHP - Please contact your system administrator.<!--";
} else {
  echo "--".">";
}

$version="1.0.1 Lite";

if ($step=="") {

?><head><title>vBulletin Lite Install Wizard <?php echo $version; ?></title></head>
<body>

<p>Welcome to vBulletin Lite version <?php echo $version; ?>. Running this script will do a clean install of vBulletin onto your server.</p>
<p><a href="install.php?step=2">Click here to continue -></a></p>
<?php

}

if ($step==2) {

?><head><title>vBulletin Lite Install Wizard <?php echo $version; ?> - Check configuration of database</title></head>
<body><?php

  if (file_exists("config.php")==0) {
    ?>
<p>Cannot find config.php file.</p>

<p>Make sure that you have uploaded it and that it is in the admin directory. It should look something like this:</p>

<pre>
&lt;?
// only mysql is supported at the moment
$dbservertype="mysql";
// hostname or ip of server
$servername="localhost";
// username and password to log onto db server
$dbusername="root";
$dbpassword="";
// name of database
$dbname="freeforum";

//password for control panel
$cppassword="foy4wellesley";
?&gt;
</pre>
<?php

  } else {
    include("./config.php");

    if ($dbservertype=="") {

      ?>
<p>Make sure that you have filled in all the details in the config.php file. It should look something like this:

<pre>
&lt;?
// only mysql is supported at the moment
$dbservertype="mysql";
// hostname or ip of server
$servername="localhost";
// username and password to log onto db server
$dbusername="root";
$dbpassword="";
// name of database
$dbname="freeforum";

//password for control panel
$cppassword="foy4wellesley";
?&gt;
</pre>
    <?php
    } else {

      echo "<p>Please confirm the details below:</p>\n";
      echo "<p><b>Database server type:</b> $dbservertype</p>\n";
      echo "<p><b>Database server hostname / IP address:</b> $servername</p>\n";
      echo "<p><b>Database username:</b> $dbusername</p>\n";
      echo "<p><b>Database password:</b> $dbpassword</p>\n";
      echo "<p><b>Database name:</b> $dbname</p>\n";
      echo "<p>Only continue to the next step if those details are correct. If they are not, please edit your config.php file and reupload it. The next step will test database connectivity.</p>";
      echo "<p><a href=\"install.php?step=3\">Click here to continue -></a></p>";
    }
  }
}

if ($step>=3) {
  // step 3 and after, we are ok loading this file
  include("./config.php");
}

if ($step==3) {

?><head><title>vBulletin Lite Install Wizard <?php echo $version; ?> - Check database connectivity</title></head>
<body><p>Attempting to connect...</p><?php

  // connect to db
  // load db class
  $dbclassname="./db_$dbservertype.php";
  include($dbclassname);

  $DB_site=new DB_Sql_vb;

  // initialise vars
  $DB_site->appname="vBulletin Lite Installer";
  $DB_site->appshortname="vBulletin Lite (inst)";
  $DB_site->database=$dbname;
  $DB_site->server=$servername;
  $DB_site->user=$dbusername;
  $DB_site->password=$dbpassword;

  // allow this script to catch errors
  $DB_site->reporterror=0;

  $DB_site->connect();
  // end init db

  $errno=$DB_site->errno;

  if ($DB_site->link_id!=0) {

    if ($errno!=0) {
      if ($errno==1049) {
        echo "<p>You have specified a non existent database. Trying to create one now...</p>";
        $DB_site->query("CREATE DATABASE $dbname");
        echo "<p>Trying to connect again...</p>";
        $DB_site->select_db($dbname);

        $errno=$DB_site->geterrno();

        if ($errno==0) {
          echo "<p>Connect succeeded!</p>";
          echo "<p><a href=\"install.php?step=4\">Click here to continue -></a></p>";
        } else {
          echo "<p>Connect failed again! Please ensure that the database and server is correctly configured and try again.</p>";
          echo "<p>Click <a href=\"http://www.vbulletin.com/\"here</a> to go to the vBulletin website</p>";
        }
      } else {

        echo "<p>Connect failed: unexpected error from the database.</p>";
        echo "<p>Error number: ".$DB_site->errno."</p>";
        echo "<p>Error description: ".$DB_site->errdesc."</p>";
        echo "<p>Please ensure that the database and server is correctly configured and try again.</p>";
        echo "<p>Click <a href=\"http://www.vbulletin.com/\"here</a> to go to the vBulletin website</p>";

      }
    } else {
      // succeeded! yay!
      echo "<p>Connection succeeded! The database already exists.</p>";
      echo "<p><a href=\"install.php?step=4\">Click here to continue -></a></p>";
      echo "<p><a href=\"install.php?step=4&reset=1\">Click here to continue and reset the database to an empty one -></a></p>";

    }
  }
}

if ($step>=4) {

  // connect to db
  // load db class
  $dbclassname="./db_$dbservertype.php";
  include($dbclassname);

  $DB_site=new DB_Sql_vb;

  // initialise vars
  $DB_site->appname="vBulletin Lite Installer";
  $DB_site->appshortname="vBulletin Lite (inst)";
  $DB_site->database=$dbname;
  $DB_site->server=$servername;
  $DB_site->user=$dbusername;
  $DB_site->password=$dbpassword;

  // allow this script to catch errors
//  $DB_site->reporterror=0;

  $DB_site->connect();
  // end init db
}

if ($step==4) {

?><head><title>vBulletin Lite Install Wizard <?php echo $version; ?> - Set up tables</title></head>
<body><p>Setting up tables...</p><?php

  if ($reset==1) {
    echo "<p>Reseting database...";
    $DB_site->query("DROP DATABASE IF EXISTS $dbname");
    $DB_site->query("CREATE DATABASE $dbname");
    $DB_site->select_db($dbname);
    echo "succeeded</p>";
  }

  // Start generating tables and indicies
  // ###################### Start forum #######################
  $DB_site->query("CREATE TABLE forum (
   forumid SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
   title CHAR(100) NOT NULL,
   description CHAR(250) NOT NULL,
   active SMALLINT NOT NULL,
   displayorder SMALLINT NOT NULL,
   replycount INT UNSIGNED NOT NULL,
   lastpost INT NOT NULL,
   threadcount MEDIUMINT UNSIGNED NOT NULL,
   allowposting SMALLINT NOT NULL,
   PRIMARY KEY(forumid)
  )");

  // ###################### Start post #######################
  $DB_site->query("CREATE TABLE post (
   postid INT UNSIGNED NOT NULL AUTO_INCREMENT,
   threadid INT UNSIGNED NOT NULL,
   username CHAR(50) NOT NULL,
   email CHAR(50) NOT NULL,
   title CHAR(100) NOT NULL,
   dateline INT NOT NULL,
   pagetext MEDIUMTEXT,
   PRIMARY KEY(postid),
   INDEX idxdisp(threadid,dateline)
  )");

  // ###################### Start replacement #######################
  $DB_site->query("CREATE TABLE replacement (
   replacementid SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
   findword TEXT NOT NULL,
   replaceword TEXT NOT NULL,
   PRIMARY KEY(replacementid)
  )");

  // ###################### Start template #######################
  $DB_site->query("CREATE TABLE template (
   templateid SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
   title CHAR(100) NOT NULL,
   template MEDIUMTEXT NOT NULL,
   PRIMARY KEY(templateid)
  )");

  // ###################### Start thread #######################
  $DB_site->query("CREATE TABLE thread (
   threadid INT UNSIGNED NOT NULL AUTO_INCREMENT,
   title CHAR(100) NOT NULL,
   lastpost INT UNSIGNED NOT NULL,
   forumid SMALLINT UNSIGNED NOT NULL,
   replycount INT UNSIGNED NOT NULL,
   postusername CHAR(50) NOT NULL,
   dateline INT UNSIGNED NOT NULL,
   subjectindex CHAR(100) NOT NULL,
   threadindex MEDIUMTEXT NOT NULL,
   userindex MEDIUMTEXT NOT NULL,
   PRIMARY KEY(threadid)
  )");

  if ($DB_site->errno!=0) {
    echo "<p>The script reported errors in the installation of the tables. Only continue if you are sure that they are not serious.</p>";
    echo "<p>The errors were:</p>";
    echo "<p>Error number: ".$DB_site->errno."</p>";
    echo "<p>Error description: ".$DB_site->errdesc."</p>";
  } else {
    echo "<p>Tables set up successfully.</p>";
  }

  echo "<p><a href=\"install.php?step=5\">Click here to continue -></a></p>";

}

if ($step==5) {
?><head><title>vBulletin Lite Install Wizard <?php echo $version; ?> - Add default data to tables</title></head>
<body><p>Setting up tables...</p><?php

  // do bb codes
  echo "<p>Setting up demo forum...";
  $DB_site->query("INSERT INTO forum (forumid,title,description,active,displayorder,allowposting) VALUES (NULL,'Forum 1','Your description here',1,1,1)");
  echo "succeeded</p>";

  echo "<p>Setting up replacements...";
  $DB_site->query("INSERT INTO replacement VALUES (NULL,'<largefont','<b><FONT face=\"Arial, Helvetica\" color =\"#003399\" size=\"3\"')");
  $DB_site->query("INSERT INTO replacement VALUES (NULL,'</largefont>','</b></font>')");
  $DB_site->query("INSERT INTO replacement VALUES (NULL,'<body>','<body bgcolor=\"#ffffff\" text=\"#000000\" id=all>')");
  $DB_site->query("INSERT INTO replacement VALUES (NULL,'<normalfont','<FONT SIZE=\"2\" FACE=\"arial, helvetica\"')");
  $DB_site->query("INSERT INTO replacement VALUES (NULL,'</normalfont>','</font>')");
  $DB_site->query("INSERT INTO replacement VALUES (NULL,'{htmldoctype}','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\" \"http://www.w3.org/TR/REC-html40/loose.dtd\">')");
  $DB_site->query("INSERT INTO replacement VALUES (NULL,'<smallfont','<FONT SIZE=\"1\" FACE=\"verdana,arial,helvetica\"')");
  $DB_site->query("INSERT INTO replacement VALUES (NULL,'</smallfont>','</font>')");
  $DB_site->query("INSERT INTO replacement VALUES (NULL,'{firstaltcolor}','#C3C3EB')");
  $DB_site->query("INSERT INTO replacement VALUES (NULL,'{secondaltcolor}','#AAAAE6')");
  $DB_site->query("INSERT INTO replacement VALUES (NULL,'{tableheadtextcolor}','#FFFFFF')");
  $DB_site->query("INSERT INTO replacement VALUES (NULL,'{tableheadbgcolor}','#113274')");
  $DB_site->query("INSERT INTO replacement VALUES (NULL,'{timecolor}','#800080')");
  $DB_site->query("INSERT INTO replacement VALUES (NULL,'{categorybackcolor}','#CFD9FF')");
  $DB_site->query("INSERT INTO replacement VALUES (NULL,'{categoryfontcolor}','#000000')");
  $DB_site->query("INSERT INTO replacement VALUES (NULL,'{linkcolor}','#333399')");
  $DB_site->query("INSERT INTO replacement VALUES (NULL,'{hovercolor}','#ff0000')");
  echo "succeeded</p>";

  echo "<p>All tables successfully populated. The next step will set up the templates.";
  echo "<p><a href=\"install.php?step=6\">Click here to continue -></a></p>";
}

if ($step==6) {
  // do templates
?><head><title>vBulletin Lite Install Wizard <?php echo $version; ?> - Set up templates</title></head>
<body><p>Setting up templates...</p><?php

  $filename="./installtemplate.php";
  include($filename);

  echo "<p>Templates set up successfully. The next step will allow you to set up the options for this board.</p>";
  echo "<p><a href=\"install.php?step=7\">Click here to continue -></a></p>";

}

if ($step==7) {
?><head><title>vBulletin Lite Install Wizard <?php echo $version; ?> - Set options</title></head>
<body>

<form action="install.php" method="post">
<input type="hidden" name="step" value="8">

<table border=0>

<tr>
<td><b>BB Title</b></td>
<td><input type="text" size="35" name="bbtitle" value=""></td>
</tr>
<tr><td colspan=2>Title of board. Appears in the title of every page.<br></td></tr>

<tr>
<td><b>Home Title</b></td>
<td><input type="text" size="35" name="hometitle" value=""></td>
</tr>
<tr><td colspan=2>Name of your homepage. Appears at the bottom of every page.<br></td></tr>

<tr>
<td><b>BB URL</b></td>
<td><input type="text" size="35" name="bburl" value="http://yourhost.domain/forums"></td>
</tr>
<tr><td colspan=2>URL (with no final "/") of the BB.<br></td></tr>

<tr>
<td><b>Home URL</b></td>
<td><input type="text" size="35" name="homeurl" value="http://www.yourhost.domain/"></td>
</tr>
<tr><td colspan=2>URL of your home page. Appears at the bottom of every page.<br></td></tr>

<tr>
<td><b>Webmaster email address</b></td>
<td><input type="text" size="35" name="webmasteremail" value="webmaster@yourhost.domain"></td>
</tr>
<tr><td colspan=2>Email address of the webmaster.<br></td></tr>

<tr>
<td><b>Technical Email address</b></td>
<td><input type="text" size="35" name="technicalemail" value="tech@yourhost.domain"></td>
</tr>
<tr><td colspan=2>Email address of the technical contact for the BB. This receives all database errors.<br></td></tr>

</table>
<input type=submit value="Submit Options and Continue to next step">
</form>
<?php

}

if ($step==8) {
?><head><title>vBulletin Lite Install Wizard <?php echo $version; ?> - Complete</title></head>
<body><p>Setting up options...</p><?php

$DB_site->query("INSERT INTO template VALUES (NULL,'options','\$bbactive = \"1\";
\$bbclosedreason = \"Sorry. The administrator has disabled this bulletin board at the moment for maintenance.\";
\$bbtitle = \"".addslashes($bbtitle)."\";
\$hometitle = \"".addslashes($hometitle)."\";
\$bburl = \"".addslashes($bburl)."\";
\$homeurl = \"".addslashes($homeurl)."\";
\$copyrighttext = \"\";
\$privacyurl = \"\";
\$contactuslink = \"mailto:".addslashes($webmasteremail)."\";
\$webmasteremail = \"".addslashes($webmasteremail)."\";
\$technicalemail = \"".addslashes($technicalemail)."\";
\$faxnumber = \"\";
\$address = \"\";
\$companyname = \"\";
\$allowbbimagecode = \"0\";
\$allowbbcode = \"1\";
\$allowsmilies = \"1\";
\$allowhtml = \"0\";
\$maximages = \"10\";
\$usecategories = \"1\";
\$categoriesonly = \"0\";
\$showforumdescriptions = \"1\";
\$displayloggedin = \"1\";
\$hideprivateforums = \"0\";
\$displayemails = \"1\";
\$secureemail = \"1\";
\$allowsignatures = \"1\";
\$newuseremail = \"\";
\$requireuniqueemail = \"1\";
\$illegalusernames = \"\";
\$allowregistration = \"1\";
\$allowmultiregs = \"0\";
\$verifyemail = \"0\";
\$moderatenewmembers = \"0\";
\$usecoppa = \"1\";
\$cookietimeout = \"900\";
\$cookiepath = \"/\";
\$enablememberlist = \"1\";
\$usememberlistadvsearch = \"1\";
\$memberlistperpage = \"30\";
\$memberlisttopposters = \"10\";
\$postsorder = \"0\";
\$maxposts = \"15\";
\$pagenavpages = \"3\";
\$wordwrap = \"100\";
\$usehotthreads = \"1\";
\$hotnumber = \"15\";
\$linktopages = \"1\";
\$showicons = \"1\";
\$maxthreads = \"40\";
\$maxmultipage = \"6\";
\$allowsearches = \"1\";
\$enableemail = \"1\";
\$timeoffset = \"0\";
\$timezone = \"ET (US)\";
\$dateformat = \"m-d-Y\";
\$timeformat = \"h:i A\";
\$registereddateformat = \"M Y\";
\$enablecensor = \"0\";
\$censorwords = \"\";
\$censorchar = \"*\";
\$showeditedby = \"1\";
\$noeditedbytime = \"2\";
\$showeditedbyadmin = \"1\";
\$edittimelimit = \"0\";
\$logip = \"1\";
\$enablefloodcheck = \"0\";
\$floodchecktime = \"60\";
\$enablebanning = \"0\";
\$banip = \"\";
\$banemail = \"\";
\$titleimage = \"images/bbtitle.jpg\";
\$replyimage = \"images/reply.gif\";
\$newthreadimage = \"images/newthread.gif\";
\$closedthreadimage = \"images/threadclosed.gif\";
\$useadvheader = \"0\";
\$useadvfooter = \"0\";
\$ontext = \"ON\";
\$offtext = \"OFF\";
\$versionnumber = \"$version\";
')");

  echo "<p>Set up successfully!</p>";
  echo "<p>You have now completed the install of vBulletin Lite. Once you have deleted this install script you can proceed to the control panel.</p>";

  echo "<p>These are the files the you should delete: install.php installtemplate.php</p>";
  echo "<p>The control panel can be found <a href='index.php'>here</a></p>";
}

echo "</"."body>";
echo "<"."!--";
?>

-->
</html>