<?php

$DB_site->query("DELETE FROM template WHERE title<>'options'");
$DB_site->query("INSERT INTO template VALUES (NULL,'bbcode','<HTML>
<HEAD>
<TITLE>vB Codes Explained</TITLE>
\$cssinclude
</HEAD>

<body>

\$header

<table border=\"0\" width=\"100%\"><tr>
<td valign=\"top\" align=\"left\"><a href=\"index.php\"><img src=\"\$titleimage\" border=\"0\"></a></td>

<td valign=\"middle\" align=\"center\" nowrap>
\$fivelinks
</td></tr></table>

<normalfont>
<p><largefont>What are vB Codes?</largefont></p>

<P>vB Codes are a variation on the HTML tags you may already be familiar with.  They allow you to add functionality or style to your message that would normally require HTML, but without the problem of breaking the design of the pages that they are used on. You can use vB Codes even only if the administrator has specified that you can in the forum rules. You may want to use vB Codes as opposed to HTML, even if HTML is enabled for your forum, because there is less coding required and it is safer to use.

<P><largefont>Current vB Codes:</largefont></p>

<P><b>URL Hyperlinking</b></p>

<p>If you want to include the vB code, just encase the link as shown in the following example (vB Code is in <normalfont COLOR=\"red\">red</normalfont>).</p>

<P><blockquote><normalfont COLOR=\"red\">[url]</normalfont>www.vbulletin.com<normalfont COLOR=\"red\">[/url]</normalfont></blockquote></p>

<p>In the examples above, the vB Code automatically generates a hyperlink to the URL that is encased.  It will also ensure that the link is opened in a new window when the user clicks on it. Note that the \"http://\" part of the URL is optional if the address begins with www; if it does not, then you will need to include the full http:// part. In the second example above, the URL will hyperlink the text to whatever URL you provide after the equal sign. Also note that you DO need quotation marks inside the url tags.</p>

<p><b>Email Links</b></p>

<p>To add a hyperlinked email address within your message, just encase the email address as shown in the following example (vB Code is in <normalfont COLOR=\"red\">red</normalfont>).</p>

<P><blockquote><normalfont COLOR=\"red\">[email]</normalfont>john@vbulletin.com<normalfont COLOR=\"red\">[/email]</normalfont></blockquote></p>

<P>In the example above, the vB Code automatically generates a hyperlink to the email address that is encased.</p>

<b>Bold, Underline and Italics</b></p>

<p>You can make make text bold, underlined or italicized by encasing the applicable sections of your text with either the [b] , [/b] , [u] , [/u] or [i] , [/i] tags.</p>

<P><blockquote>Hello, <normalfont COLOR=\"red\">[b]</normalfont><B>James</B><normalfont COLOR=\"red\">[/b]</normalfont>, <normalfont COLOR=\"red\">[u]</normalfont><U>John</u><normalfont COLOR=\"red\">[/u] </normalfont> and <normalfont COLOR=\"red\">[i]</normalfont><I>Mary</I><normalfont COLOR=\"red\">[/i]</normalfont>.
</blockquote></p>

<p><b>Adding Images</b></p>

To add a graphic within your message, just encase the URL of the graphic image as shown in the following example (vB Code is in <normalfont COLOR=\"red\">red</normalfont>).

<P><blockquote>
<normalfont COLOR=\"red\">[img]</normalfont>http://www.vbulletin.com/images/vblogo.gif<normalfont COLOR=\"red\">[/img]</normalfont>
</blockquote></p>

<P>In the example above, the vB Code automatically makes the graphic visible in your message.  Note: the \"http://\" part of the URL is REQUIRED for the <normalfont COLOR=\"red\">[img]</normalfont> code.  Also note: some forums may disable the <normalfont COLOR=\"red\">[img]</normalfont> tag support to prevent objectionable images from being viewed. In that case, you will have to include a hyperlink to the image.</p>

<p><b>Quoting Other Messages</b></p>

<p>To reference something specific that someone has posted, just cut and paste the applicable verbiage and enclose it as shown below (vB Code is in <normalfont COLOR=\"red\">red</normalfont>).

<P><blockquote>
<normalfont COLOR=\"red\">[QUOTE]</normalfont>Ask not what your country can do for you....<BR>ask what you can do for your country.<normalfont COLOR=\"red\">[/QUOTE]</normalfont></blockquote></p>

<P>In the example above, the vB Code automatically indents the text you reference.</p>

<P><largefont>Incorrect vB Code Usage:</largefont></p>

<P><normalfont COLOR=\"red\">[url]</normalfont> www.vbulletin.com <normalfont COLOR=\"red\">[/url]</normalfont> - don\'t put spaces between the bracketed code and the text you are applying the code to.</p>

<P><normalfont COLOR=\"red\">[email]</normalfont>john@vbulletin.com<normalfont COLOR=\"red\">[email]</normalfont> - the end brackets must include a forward slash (<normalfont COLOR=\"red\">[/email]</normalfont>)</p>

<p><b>Note:</b> You should not use both HTML and vB Code to do the same function.  Also note that the vB Code is not case-sensitive (thus, you could use <normalfont COLOR=\"red\">[URL]</normalfont> or <normalfont COLOR=\"red\">[url]</normalfont>).<p>

\$footer

</body>
</html>')");
$DB_site->query("INSERT INTO template VALUES (NULL,'cssinclude','<STYLE type=text/css>
.thtcolor {
  COLOR: {tableheadtextcolor};
}
#all A:active {
  COLOR: {linkcolor} ;
}
#all A:visited {
  COLOR: {linkcolor} ;
}
#all A:hover {
  COLOR: {hovercolor};
}
#all A:link {
  COLOR: {linkcolor};
}

#cat A:active {
  COLOR:  {categoryfontcolor};
  text-decoration: none
}
#cat A:visited {
  COLOR: {categoryfontcolor} ;
  text-decoration: none
}
#cat A:hover {
  COLOR: {categoryfontcolor} ;
  text-decoration: underline
}
#cat A:link {
  COLOR: {categoryfontcolor} ;
  text-decoration: none
}

</STYLE>')");
$DB_site->query("INSERT INTO template VALUES (NULL,'error_forumclosed','Sorry! This forum is not available at the moment.')");
$DB_site->query("INSERT INTO template VALUES (NULL,'error_forumnoreply','Sorry! This forum is not open for new posts.')");
$DB_site->query("INSERT INTO template VALUES (NULL,'error_nosubject','Please complete both the subject and message fields. Press the back button, correct the problem and try again.')");
$DB_site->query("INSERT INTO template VALUES (NULL,'error_requiredfields','Please complete all the fields. Press the back button, correct the problem then try again.')");
$DB_site->query("INSERT INTO template VALUES (NULL,'error_searchspecifyterms','Please specify either some search words or a username to search by.')");
$DB_site->query("INSERT INTO template VALUES (NULL,'faq','<HTML>
<HEAD>
<TITLE>vBulletin Frequently Asked Questions</TITLE>
\$cssinclude
</HEAD>

<body>
\$header

<table border=\"0\" width=\"100%\"><tr>
<td valign=\"top\" align=\"left\"><a href=\"index.php\"><img src=\"\$titleimage\" border=\"0\"></a></td>

<td valign=\"middle\" align=\"center\" nowrap>
\$fivelinks
</td></tr></table>

<p><largefont>Frequently Asked Questions</largefont></p>

<normalfont>
<p>
<A HREF=\"#HTML\">Can I use HTML Code in posts?</A><BR>
<A HREF=\"#cookies\">Are cookies used?</A><BR>
<A HREF=\"#edit\">Can I edit my own posts?</A><BR>
<A HREF=\"#search\">How do I Search for Posts?</A><BR>

<HR ALIGN=\"CENTER\">
<P><A NAME=\"HTML\"><B>Can I use HTML Code in posts?</B></A>
<BR>
You may not use HTML in your posts for security reasons, and because you could easily break the design of the page. As an alternative to HTML code, you can use vB code. This provides a sub set of the functionality of HTML code, while maintaining security from malicious scripting and layout damage. More information about vB code can be found <A HREF=\"index.php?action=bbcode\">here</a>.</p>

<P><A NAME=\"cookies\"><B>Are cookies used?</B></A>
<BR>
vBulletin uses cookies to store the date and time that you last visited. These are used to track which posts are new since your last visit.</p>

<P><A NAME=\"edit\"><B>Can I edit my own posts?</B></A>
<BR>
No, you cannot edit your posts. If you want to change a post, please contact the administrator.</p>

<P>
<A NAME=\"search\"><B>How do I Search for Posts?</B></A>
<BR>
You can search for posts based on username, word(s) in the post or just in the subject, and only in particular forums. To access the search feature, click on the \"search\" link at the top of most pages. You can search any forum that you have permission to search - you will not be allowed to search through private forums unless the administrator has given your the necessary security rights to do so.</p>

</normalfont>

\$footer

</body>
</html>')");
$DB_site->query("INSERT INTO template VALUES (NULL,'fivelinks','<A HREF=\"index.php?action=faq\" target=_blank><img src=\"images/top_faq.gif\" alt=\"Frequently Asked Questions\" border=0></A> &nbsp;
<A HREF=\"search.php\"><img src=\"images/top_search.gif\" alt=\"Search\" border=0></A> &nbsp;
<A HREF=\"index.php\"><img src=\"images/top_home.gif\" alt=\"Home\" border=0></A>
')");
$DB_site->query("INSERT INTO template VALUES (NULL,'footer','<p align=\"center\"><normalfont><b>&lt; <a href=\"\$contactuslink\">Contact Us</a> - <a href=\"\$homeurl\">\$hometitle</a>&gt;</b></normalfont></p>
')");
$DB_site->query("INSERT INTO template VALUES (NULL,'forumdisplay','{htmldoctype}
<HTML>
<HEAD><TITLE>\$bbtitle - \$forumtitle</title>
\$cssinclude
</head>
<body>
\$header

<table border=\"0\" width=\"100%\"><tr>
<td valign=\"top\" align=\"left\"><a href=\"index.php\"><img src=\"\$titleimage\" border=\"0\"></a></td>

<td valign=\"middle\" align=\"center\" nowrap>
\$fivelinks
</td></tr></table>

<table border=\"0\" width=\"100%\" cellpadding=\"2\">
<form action=\"forumdisplay.php\" method=\"get\">
<tr><td width=\"100%\">

<normalfont><b><a href=\"index.php\">\$bbtitle</A> &gt; \$forumtitle</b></normalfont>
</td>
</tr></form>
</table>


<table border=0 cellpadding=4 border=0 cellspacing=1 width=\"100%\">
<tr bgcolor=\"{tableheadbgcolor}\">
<td colspan=2>
<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
<tr>
<td>
<A HREF=\"newthread.php?action=newthread&forumid=\$forumid\"><IMG SRC=\"images/newthread.gif\"  BORDER=0 ALT=\"Post New Thread\"></A>
</td>
<td width=\"100%\" align=\"center\">
<smallfont color=\"{tableheadtextcolor}\"><B>Thread</A></B></smallfont>
</td>
</tr></table>

</td>

<td align=center nowrap><smallfont color=\"{tableheadtextcolor}\"><B>Thread Starter</B></smallfont>
</td>
<td align=center><smallfont color=\"{tableheadtextcolor}\"><B>Replies</B></smallfont>
</td>
<td align=center nowrap>

<smallfont color=\"{tableheadtextcolor}\"><B>Last Post</A></B></smallfont>

</td></tr>

\$forumdisplaybits

<TR bgcolor=\"{tableheadbgcolor}\">
<TD valign=\"middle\" width=\"100%\" colspan=\"7\">

<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
<tr>

<td valign=\"middle\">
<A HREF=\"newthread.php?action=newthread&forumid=\$forumid\"><IMG SRC=\"images/newthread.gif\" BORDER=0 ALT=\"Post New Thread\"></A>
</td>

<td width=\"100%\" valign=\"middle\" align=\"right\">
<smallfont color=\"{tableheadtextcolor}\"><b>
All times are \$timezone. All dates are in Month-Day-Year format.</b></smallfont>
</td>

</tr></table>

</table>

<table border=\"0\" width=\"100%\" cellpadding=\"2\">
<tr><td nowrap valign=\"top\">

\$forumjump

</td><td valign=\"top\" align=\"right\">
<smallfont>\$pagenav</TD></tr></table>

<center><table border=0><tr>
<td><img src=\"images/newfolder.gif\" border=0 alt=\"New Posts\"></td>
<td><b><smallfont>New Posts</smallfont></b></td>
<td><img src=\"images/folder.gif\" border=0 alt=\"No New Posts\"></td>
<td><b><smallfont>No New Posts</smallfont></b></td>
</tr></table></center>

\$footer
</body>
</html>
')");
$DB_site->query("INSERT INTO template VALUES (NULL,'forumdisplaybit','<TR>
<TD align=center bgcolor=\"{firstaltcolor}\">
<IMG SRC=\"images/\$newoldhot.gif\" BORDER=0></td>

<td bgcolor=\"{firstaltcolor}\" width=\"100%\"><normalfont>
<A HREF=\"showthread.php?threadid=\$threadid\">\$threadtitle</a></normalfont>
</td>

<td align=center bgcolor=\"{secondaltcolor}\" nowrap>
<normalfont>\$firstposter</normalfont>
</td>

<td align=center bgcolor=\"{firstaltcolor}\">
<normalfont>\$replies</normalfont>
</td>

<td bgcolor=\"{firstaltcolor}\" nowrap>
<normalfont>\$lastreplydate <normalfont COLOR=\"{timecolor}\">\$lastreplytime</normalfont></normalfont>
</td></tr>
')");
$DB_site->query("INSERT INTO template VALUES (NULL,'forumhome','{htmldoctype}
<HTML>
<HEAD><TITLE>\$bbtitle - powered by vBulletin Lite</title>
\$cssinclude
</head>
<body>
\$header

<table border=\"0\" width=\"100%\"><tr>
<td valign=\"top\" align=\"left\"><a href=\"index.php\"><img src=\"\$titleimage\" border=\"0\"></a></td>

<td valign=\"middle\" align=\"center\" nowrap>
\$fivelinks
</td></tr></table>

<p><smallfont>You last visited: \$lastvisitdate.<br>The time now is \$timenow. \$newposts</smallfont></p>

<table cellpadding=4 cellspacing=1 border=0 width=\"100%\">
<tr bgcolor=\"{tableheadbgcolor}\">
<TD>&nbsp;</TD>
<td valign=bottom>
<smallfont COLOR=\"{tableheadtextcolor}\"><B>Forum</B></smallfont>
</td>
<td NOWRAP valign=bottom align=center>
<b><smallfont COLOR=\"{tableheadtextcolor}\">Posts</smallfont></B>
</td>
<td NOWRAP valign=bottom align=center>
<b><smallfont COLOR=\"{tableheadtextcolor}\">Threads</smallfont></B>
</td>
<td NOWRAP valign=bottom align=center>
<smallfont COLOR=\"{tableheadtextcolor}\"><B>Last Post</B></smallfont>
</td>
</tr>

\$forumbits

</tr></table>

<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">
<TR><TD valign=\"middle\" align=\"left\">
<smallfont>All times are \$timezone.</normalfont></td>
</tr></table>

<center><table border=0 cellpadding=2><tr>
<td><img src=\"images/on.gif\" border=0 alt=\"On\"></td>
<td><b><smallfont>New posts</smallfont></b></td>
<td><img src=\"images/off.gif\" border=0 alt=\"Off\"></td>
<td><b><smallfont>No new posts</smallfont></b></td>
<td><IMG SRC=\"images/lock.gif\" BORDER=0 ALT=\"Closed Forum\"></td>
<td><b><smallfont>A closed forum </b></smallfont></td>
</tr></table></center>

\$footer

</body>
</html>')");
$DB_site->query("INSERT INTO template VALUES (NULL,'forumhomebit','<TR>
<TD bgcolor=\"{firstaltcolor}\" align=center valign=top><IMG SRC=\"images/\$onoff.gif\" BORDER=0></td>
<TD bgcolor=\"{firstaltcolor}\" valign=top><normalfont><B>
<A HREF=\"forumdisplay.php?forumid=\$forumid\">\$forumtitle</A></B></normalfont><BR>
<smallfont>\$forumdescription</smallfont></td>
<td bgcolor=\"{secondaltcolor}\" align=center valign=top NOWRAP>
<normalfont>\$numberposts</normalfont></td>
<td bgcolor=\"{firstaltcolor}\" align=center valign=top NOWRAP>
<normalfont>\$numberthreads</normalfont></td>
<td bgcolor=\"{secondaltcolor}\" NOWRAP valign=top align=center>
<normalfont>\$lastpostdate <normalfont COLOR=\"{timecolor}\">\$lastposttime</normalfont></td>
</tr>

')");
$DB_site->query("INSERT INTO template VALUES (NULL,'forumjump','<normalfont><FORM ACTION=\"forumdisplay.php\" METHOD=\"GET\">
<B>Forum Jump: </B><SELECT NAME=\"forumid\">
<option \$defaultselected>Please select one:</option>
\$jumpforumbits
</SELECT>
<INPUT TYPE=\"SUBMIT\" VALUE=\"Go\"></FORM></normalfont>')");
$DB_site->query("INSERT INTO template VALUES (NULL,'header','')");
$DB_site->query("INSERT INTO template VALUES (NULL,'jumpforumbit','<OPTION value=\"\$jumpforumid\" \$optionselected>\$jumpforumtitle</option>')");
$DB_site->query("INSERT INTO template VALUES (NULL,'newreply','{htmldoctype}
<HTML><HEAD><TITLE>\$bbtitle - Reply to Topic</TITLE>
\$cssinclude
</HEAD>
<body>
\$header

<table border=\"0\" width=\"100%\"><tr>
<td valign=\"top\" align=\"left\"><a href=\"index.php\"><img src=\"\$titleimage\" border=\"0\"></a></td>

<td valign=\"middle\" align=\"center\" nowrap>
\$fivelinks
</td></tr></table>

<table border=\"0\" width=\"100%\" cellpadding=\"2\">
<tr><td width=\"100%\">

<normalfont><b><a href=\"index.php\">\$bbtitle</A> &gt; <a href=\"forumdisplay.php?forumid=\$forumid\">\$forumtitle</a> &gt; <a href=\"showthread.php?threadid=\$threadid\">\$threadtitle</a></b></normalfont>

</td></tr></table>

<FORM ACTION=\"newreply.php\" METHOD=\"POST\">
<table border=0 cellpadding=4 cellspacing=1 width=\"100%\">
<tr bgcolor=\"{tableheadbgcolor}\"><TD COLSPAN=2>
<normalfont color=\"{tableheadtextcolor}\" class=thtcolor><B>Post Reply</B></normalfont></td></tr>
<tr bgcolor=\"{firstaltcolor}\"><td valign=top>
<normalfont><B>Your Name:</B></normalfont></td>
<td valign=top>
<INPUT TYPE=\"TEXT\" NAME=\"username\" SIZE=25 MAXLENGTH=50>&nbsp;&nbsp;
</td>
</tr>
<tr bgcolor=\"{secondaltcolor}\">
<td valign=top>
<normalfont><B>Your Email address:</B></normalfont></td>
<td valign=top><INPUT TYPE=\"text\" NAME=\"email\" SIZE=25 MAXLENGTH=50>&nbsp;<smallfont>(Optional)</smallfont>
</td></tr>

<tr bgcolor=\"{firstaltcolor}\">
<td valign=top>
<normalfont><B>Post subject:</B></normalfont></td>
<td valign=top><INPUT TYPE=\"text\" NAME=\"title\" SIZE=40 MAXLENGTH=100>&nbsp;<smallfont>(Optional)</smallfont></td></tr>

<TR bgcolor=\"{secondaltcolor}\"><TD valign=top nowrap>
<normalfont><B>Your Reply:</B></normalfont>
</td>
<td>
<TEXTAREA NAME=\"message\" ROWS=20 COLS=60 WRAP=\"VIRTUAL\">\$message</TEXTAREA>
</td></tr>
</table>

<P align=\"center\">
<INPUT TYPE=\"HIDDEN\" NAME=\"action\" VALUE=\"postreply\">
<INPUT TYPE=\"HIDDEN\" NAME=\"threadid\" VALUE=\"\$threadid\">
<INPUT TYPE=\"Submit\" NAME=\"submit\" VALUE=\"Submit Reply\">
<INPUT TYPE=\"RESET\" NAME=\"RESET\" VALUE=\"Clear Fields\">
</p></form>

\$footer

</body>
</html>
')");
$DB_site->query("INSERT INTO template VALUES (NULL,'newthread','{htmldoctype}
<HTML>
<HEAD>
<TITLE>\$bbtitle - Post New Thread</TITLE>
\$cssinclude
</HEAD>
<body>
\$header

<table border=\"0\" width=\"100%\"><tr>
<td valign=\"top\" align=\"left\"><a href=\"index.php\"><img src=\"\$titleimage\" border=\"0\"></a></td>

<td valign=\"middle\" align=\"center\" nowrap>
\$fivelinks
</td></tr></table>

<table border=\"0\" width=\"100%\" cellpadding=\"2\">
<tr><td width=\"100%\">

<normalfont><b><a href=\"index.php\">\$bbtitle</A> &gt; <a href=\"forumdisplay.php?forumid=\$forumid\">\$forumtitle</a></b></normalfont>
</td></tr></table>

<FORM ACTION=\"newthread.php\" METHOD=\"POST\" NAME=\"postthread\">

<table border=0 cellpadding=4 cellspacing=1 width=100%>
<tr bgcolor=\"{tableheadbgcolor}\"><TD COLSPAN=2>
<normalfont color=\"{tableheadtextcolor}\" class=thtcolor><B>Post New Thread</B></normalfont></td></tr>
<tr bgcolor=\"{firstaltcolor}\">
<td><normalfont><B>Your Name:</B></normalfont></td>
<td><INPUT TYPE=\"TEXT\" NAME=\"username\" SIZE=25 MAXLENGTH=50></td>
</tr>

<tr bgcolor=\"{secondaltcolor}\">
<td><normalfont><B>Your Email Address:</B></normalfont></td>
<td><INPUT TYPE=\"email\" NAME=\"email\" SIZE=25 MAXLENGTH=50 value=\"\$password\">&nbsp;<smallfont>(Optional)</smallfont></td>

</tr><TR bgcolor=\"{firstaltcolor}\">

<td><normalfont><B>Subject:</B></normalfont></td>
<td><INPUT TYPE=\"TEXT\" NAME=\"subject\" SIZE=40 MAXLENGTH=100></td>

</tr>

\$posticons

<tr bgcolor=\"{secondaltcolor}\">
<td valign=top NOWRAP>

<normalfont><B>Message:</B></normalfont>
</td>
<td>
<TEXTAREA NAME=\"message\" ROWS=20 COLS=60 WRAP=\"VIRTUAL\">\$message</TEXTAREA></td></tr>

</table>

<P align=\"center\">
<INPUT TYPE=\"HIDDEN\" NAME=\"forumid\" VALUE=\"\$forumid\">
<INPUT TYPE=\"HIDDEN\" NAME=\"action\" VALUE=\"postthread\">
<INPUT TYPE=\"SUBMIT\" NAME=\"submit\" VALUE=\"Submit New Thread\">
<INPUT TYPE=\"RESET\" NAME=\"Reset\" VALUE=\"Clear Fields\">
</p>
</form>

\$footer

</body>
</html>')");
$DB_site->query("INSERT INTO template VALUES (NULL,'postbit','<tr bgcolor=\"\$backcolor\">
<TD width=\"175\" valign=\"top\" nowrap>

<p>\$foldericon <smallfont>\$postdate \$posttime</smallfont></p>

<p><normalfont><i>Posted by:</i><br>
<B>\$username</B></normalfont></p>

<p>\$useremail <a href=\"search.php?action=simplesearch&exactname=yes&searchuser=\$searchuser\"><img src=\"images/find.gif\" border=0 alt=\"Find more posts by \$username\"></a></p>

</td>
<td valign=\"top\" width=\"100%\">

<smallfont><B>\$postitle</b></smallfont>

<p><normalfont>\$message</normalfont></p>

</td></tr>
')");
$DB_site->query("INSERT INTO template VALUES (NULL,'searchintro','{htmldoctype}
<HTML>
<HEAD>
<TITLE>\$bbtitle Search Page</TITLE>
\$cssinclude
</HEAD>
<body>
\$header

<table border=\"0\" width=\"100%\"><tr>
<td valign=\"top\" align=\"left\"><a href=\"index.php\"><img src=\"\$titleimage\" border=\"0\"></a></td>

<td valign=\"middle\" align=\"center\" nowrap>
\$fivelinks
</td></tr></table>

<FORM ACTION=\"search.php\" METHOD=\"post\">

<table border=0 cellpadding=4 cellspacing=1 width=100%>
<tr bgcolor=\"{tableheadbgcolor}\"><TD COLSPAN=2>
<normalfont color=\"{tableheadtextcolor}\" class=thtcolor><B>\$bbtitle Search Engine</B></normalfont></td></tr>
<tr>

<td valign=\"top\" width=\"40%\" bgcolor=\"{firstaltcolor}\">
<p><smallfont><b>Search By Keyword:</b></smallfont><br>
<INPUT TYPE=\"TEXT\" NAME=\"query\" SIZE=20 MAXLENGTH=25><BR>
<smallfont><INPUT TYPE=\"RADIO\" NAME=\"booleanand\" VALUE=\"yes\" CHECKED> Match All <INPUT TYPE=\"RADIO\" NAME=\"booleanand\" VALUE=\"no\"> Match Any</p>
</td>

<td valign=\"top\" width=\"40%\" bgcolor=\"{firstaltcolor}\">
<p><smallfont><b>Search By Name:</b></smallfont><br>
<INPUT TYPE=\"TEXT\" NAME=\"searchuser\" SIZE=20 MAXLENGTH=25><BR>
<smallfont><INPUT TYPE=\"RADIO\" NAME=\"exactname\" VALUE=\"yes\" CHECKED> Match Exact <INPUT TYPE=\"RADIO\" NAME=\"exactname\" VALUE=\"no\"> Match Partial</p>
</td></tr>

<tr bgcolor=\"{tableheadbgcolor}\"><TD COLSPAN=2>
<normalfont color=\"{tableheadtextcolor}\" class=thtcolor><B>Search Options</B></normalfont></td></tr>

<tr>

<td valign=\"top\" width=\"50%\" bgcolor=\"{secondaltcolor}\">
<p><smallfont><b>Search Forum:</b></smallfont><br>
<SELECT NAME=\"forumchoice\">
<OPTION VALUE=\"-1\">Search All Open Forums</option>
\$jumpforumbits
</select>
</td>

<td valign=\"top\" width=\"25%\" bgcolor=\"{secondaltcolor}\">
<p><smallfont><b>Search In:</b></smallfont><br>
<SELECT NAME=\"searchin\">
  <OPTION VALUE=\"all\">Entire Message
  <OPTION VALUE=\"subject\">Subject Only
</SELECT>

</td>

</tr></table>

<p align=\"center\">
<INPUT TYPE=\"HIDDEN\" NAME=\"action\" VALUE=\"simplesearch\">
<INPUT TYPE=\"SUBMIT\" NAME=\"Submit\" VALUE=\"Perform Search\">
<INPUT TYPE=\"RESET\" NAME=\"Reset\" VALUE=\"Reset Fields\">
</p></form>

\$footer

</body>
</html>')");
$DB_site->query("INSERT INTO template VALUES (NULL,'searchresultbit','<TR>
<TD bgcolor=\"{firstaltcolor}\">
<normalfont><A HREF=\"\$searchlink\">\$threadtitle</A>
</normalfont>
</TD>
<TD bgcolor=\"{secondaltcolor}\">
<normalfont>\$poster</normalfont>
</TD>
<TD bgcolor=\"{firstaltcolor}\" NOWRAP>
<normalfont>\$lastpostdate</normalfont>
</TD>
<TD bgcolor=\"{secondaltcolor}\">
<normalfont><a href=\"forumdisplay.php?forumid=\$forumid\">\$forumtitle</a></normalfont>
</TD>
</tr>
')");
$DB_site->query("INSERT INTO template VALUES (NULL,'searchresults','{htmldoctype}
<HTML>
<HEAD>
<TITLE>\$bbtitle - Search Results</TITLE>
\$cssinclude
</HEAD>
<body>
\$header

<table border=\"0\" width=\"100%\"><tr>
<td valign=\"top\" align=\"left\"><a href=\"index.php\"><img src=\"\$titleimage\" border=\"0\"></a></td>

<td valign=\"middle\" align=\"center\" nowrap>
\$fivelinks
</td></tr></table>

<table border=\"0\" width=\"100%\" cellpadding=\"2\">
<tr><td width=\"100%\">

<normalfont><b><a href=\"index.php\">\$bbtitle</A> &gt; <a href=\"search.php\">Search</a></b></normalfont>

</td><td nowrap align=\"right\">
<smallfont>Displaying Topics \$lower to \$upper of \$countmatches &nbsp;&nbsp;&nbsp;&nbsp; \$nextpagelink</smallfont>
</td></tr></table>

<table border=0 cellspacing=1 cellpadding=4 width=100%>
<TR bgcolor=\"{tableheadbgcolor}\">
<TD>
<smallfont COLOR=\"{tableheadtextcolor}\"><B>Topic</B></smallfont>
</TD>
<TD>
<smallfont COLOR=\"{tableheadtextcolor}\"><B>Topic Starter</B></smallfont>
</TD>
<TD NOWRAP>
<smallfont COLOR=\"{tableheadtextcolor}\"><B>Last Post</B></smallfont>
</TD>
<TD>
<smallfont COLOR=\"{tableheadtextcolor}\"><B>Forum</B></smallfont>
</TD>
</tr>

\$searchresultbits

</table>

</CENTER>
<P><normalfont>
<p align=right>\$nextpagelink</p>

<table border=0 width=100%>
<tr><td align=left valign=top>
<smallfont>All times are \$timezone. All dates are in Month-Day-Year format.</smallfont></td>
<td align=right NOWRAP>

\$forumjump

</TD></tr></TABLE>

</normalfont>

\$footer
')");
$DB_site->query("INSERT INTO template VALUES (NULL,'showthread','{htmldoctype}
<HTML>
<HEAD><TITLE>\$bbtitle - \$threadtitle</title>
\$cssinclude
</head>
<body>
\$header


<table border=\"0\" width=\"100%\"><tr>
<td valign=\"top\" align=\"left\"><a href=\"index.php\"><img src=\"\$titleimage\" border=\"0\"></a></td>

<td valign=\"middle\" align=\"center\" nowrap>
\$fivelinks
</td></tr></table>

<table border=\"0\" width=\"100%\" cellpadding=\"2\">
<tr><td width=\"100%\">

<normalfont><b><a href=\"index.php\">\$bbtitle</A> &gt; <A HREF=\"forumdisplay.php?forumid=\$forumid\">\$forumtitle</a><br>\$threadtitle</b></normalfont>

</td>
<td valign=\"bottom\" align=\"right\" nowrap><smallfont>\$nextoldest \$nextnewest</smallfont></TD>
</tr></table>

<table width=100% border=0 cellspacing=1 cellpadding=4>
<TR bgcolor=\"{tableheadbgcolor}\">
<TD valign=\"middle\" width=\"175\" nowrap>
<smallfont color=\"{tableheadtextcolor}\" class=thtcolor><B>Author</B></smallfont>
</TD>
<TD valign=\"middle\" width=\"100%\">

<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
<tr><td width=\"100%\" valign=\"middle\">

<smallfont color=\"{tableheadtextcolor}\" class=thtcolor><B>Thread &nbsp;&nbsp; \$pagenav</B></smallfont>

</td><td valign=\"middle\">

<A HREF=\"newthread.php?action=newthread&forumid=\$forumid\"><IMG SRC=\"images/newthread.gif\"  BORDER=0 ALT=\"Post New Thread\"></A>

</td><td valign=\"middle\">
<normalfont>&nbsp;&nbsp;&nbsp;</normalfont>

</td><td valign=\"middle\">

<A HREF=\"newreply.php?action=newreply&threadid=\$threadid\"><IMG SRC=\"images/reply.gif\" BORDER=0 ALT=\"Post A Reply\"></A>

</td></tr></table>

\$postbits

<TR bgcolor=\"{tableheadbgcolor}\">
<TD valign=\"middle\" width=\"100%\" colspan=\"2\">

<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
<tr><td width=\"100%\" valign=\"middle\">

<smallfont color=\"{tableheadtextcolor}\"><b>
All times are \$timezone &nbsp;&nbsp; \$pagenav
</b></smallfont>

</td><td valign=\"middle\">

<A HREF=\"newthread.php?action=newthread&forumid=\$forumid\"><IMG SRC=\"images/newthread.gif\"  BORDER=0 ALT=\"Post New Thread\"></A>

</td><td valign=\"middle\">
<normalfont>&nbsp;&nbsp;&nbsp;</normalfont>

</td><td valign=\"middle\">

<A HREF=\"newreply.php?action=newreply&threadid=\$threadid\"><IMG SRC=\"images/reply.gif\" BORDER=0 ALT=\"Post A Reply\"></A>

</td></tr></table>

</table>

<table border=\"0\" width=\"100%\" cellpadding=\"2\">
<tr><td width=\"100%\" valign=\"top\">

\$forumjump

</td>
<td valign=\"top\" align=\"right\" nowrap><smallfont>\$nextoldest \$nextnewest</smallfont></TD>
</tr></table>

\$footer

</body>
</html>')");
$DB_site->query("INSERT INTO template VALUES (NULL,'standarderror','{htmldoctype}
<HTML>
<HEAD><TITLE>\$pagetitle</title>
\$cssinclude
\$headinsert
</head>
<body>
\$header


<table border=\"0\" width=\"100%\"><tr>
<td valign=\"top\" align=\"left\"><a href=\"index.php\"><img src=\"\$titleimage\" border=\"0\"></a></td>

<td valign=\"middle\" align=\"center\" nowrap>
\$fivelinks
</td></tr></table>

<table border=0 cellpadding=4 cellspacing=1 width=100%>
<tr bgcolor=\"{tableheadbgcolor}\"><TD width=\"100%\">

<normalfont color=\"{tableheadtextcolor}\" class=thtcolor><B>vBulletin Message</B></normalfont>

</td></tr>
<tr bgcolor=\"{firstaltcolor}\"><td width=\"100%\">
<normalfont>\$errormessage</normalfont>
</td></tr></table>

<p align=\"center\">\$forumjump</p>

\$footer

</body>
</html>')");
$DB_site->query("INSERT INTO template VALUES (NULL,'standardredirect','{htmldoctype}
<HTML>
<HEAD><TITLE>\$pagetitle</title>
\$cssinclude
<meta http-equiv=\"Refresh\" content=\"1; URL=\$url\">
</head>
<body bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#ffffff\" alink=\"#800000\" vlink=\"#666666\">
<br><br>
<ul><normalfont>

<B>\$errormessage</B>

<br><br></normalfont><smallfont>
<A HREF=\"\$url\">Click here if you do not want to wait any longer (or if your browser does not automatically forward you).</A>
</B>
</smallfont>
</ul>

</body>
</html>')");

?>
