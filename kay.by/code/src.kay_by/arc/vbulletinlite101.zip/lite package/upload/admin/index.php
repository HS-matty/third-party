<?php

require ("./global.php");

if (isset($action)==0) {
  $action="frames";
}

if ($action=="phpinfo") {
  phpinfo();
}

if ($action=="frames") {
?>
<html>
<head>
<title>vBulletin Lite Control Panel</title>
<frameset rows="30,*">
<frame src="index.php?action=head" name="head" scrolling="NO" >
<frameset cols="170,*">
<frame src="index.php?action=nav" name="nav" scrolling="AUTO">
<frame src="index.php?action=home" name="main" scrolling="AUTO">
</frameset>
</frameset>
</head>
</html>
<?php
}

if ($action=="head") {
?>
<html>
<body topmargin=2 bottomMargin=2>

<table border=0 width="80%">
<tr>
<td valign=top>
<b>vBulletin Lite Control Panel (Version <?php echo $versionnumber; ?>)</b>
</td>
<td valign=top>
<b><a href="../index.php" target="_top">Forums Home Page</a></b><br>
</td>
</tr>
</table>

</body>
</html>
<?php
}

if ($action=="home") {
?>
<html>
<body>
<p><b>Welcome to the Control Panel</b><br>
Software Developed by <a href="http://www.jelsoft.com/">Jelsoft Enterprises Limited</a></p>

<p>From here, you can control all aspects of you vBulletin Lite forums.
Please select what you need from the links down the left hand side of this page.<br>

<?php

?>

<p><b>Links</b><br>
<a href="http://www.vbulletin.com/">vBulletin Home Page</a><br>
<a href="http://www.vbulletin.com/forum/">vBulletin Support Forums</a><br>
<a href="http://www.vbulletin.com/manual/">vBulletin Online Manual</a><br>
<a href="http://www.php.net/">PHP 3 Home Page</a><br>
<a href="http://www.mysql.com/">MySQL Home Page</a><br>
</p>

<p><b>Developers and Contributors:</b><br>
Product Manager: James Limm<br>
Developer: John Percival</p>

<p>Graphics:<br>
General Graphics and Design: Menno<br>
Profile / Register / FAQ / Search Icons: Paul Young<br>
Alternative Logo: Philipp Esselbach<br>

</body>
</html>
<?php
}

if ($action=="nav") {
?>
<html>
<head><base target="main"></head>
<body>

<p><b>Forums</b><br>
<a href="forum.php?action=add">Add</a><br>
<a href="forum.php?action=modify">Modify</a><br>
<a href="forum.php?action=order">Order</a></p>

<p><b>Options</b><br>
<a href="options.php?action=options">Change options</a><br>
<a href="options.php?action=styles">Change styles</a></p>

<hr>

<p><b>Maintenance</b><br>
<a href="misc.php">Update counters...</a></p>

</body>
</html>
<?php
}

?>