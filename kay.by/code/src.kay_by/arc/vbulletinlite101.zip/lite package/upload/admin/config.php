<?php

/////////////////////////////////////////////////////////////
// Please note that if you get any errors when connecting, //
// that you will need to email your host as we cannot tell //
// you what your specific values are supposed to be        //
/////////////////////////////////////////////////////////////

// type of database running
// (only mysql is supported at the moment)
$dbservertype="mysql";

// hostname or ip of server
$servername="localhost";

// username and password to log onto db server
$dbusername="root";
$dbpassword="";

// name of database
$dbname="freewareforum";

//password needed to enter the control panel
$cppassword="foy4wellesley";

?>