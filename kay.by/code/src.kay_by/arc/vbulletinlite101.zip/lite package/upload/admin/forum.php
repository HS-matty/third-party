<?php

require ("./global.php");

?>
<html>
<body>
<?php

if (isset($action)==0) {
  $action="modify";
}

// ###################### Start add #######################
if ($action=="add") {

  echo doformheader("forum","insert");

  echo "<table border=0>";

  echo makeinputcode("Title","title");
  echo maketextareacode("Description<br>You may use HTML","description");
  echo makeyesnocode("Forum Enabled (i.e. can be viewed)<br>(To set permissions for individual users, go to the user permissions area)","active");
  echo makeyesnocode("Allow posting/editing","allowposting");
  echo makeinputcode("Display Order<br>0=do not display","displayorder",1);

  echo doformfooter();
}

// ###################### Start insert #######################
if ($action=="insert") {

  $DB_site->query("INSERT INTO forum (forumid,title,description,active,displayorder,allowposting) VALUES (NULL,'".addslashes($title)."','".addslashes($description)."',$active,$displayorder,$allowposting)");

  $action="modify";

  echo "<p>Record added</p>";

}

// ###################### Start edit #######################
if ($action=="edit") {

  $forum=$DB_site->query_first("SELECT title,description,active,displayorder,allowposting FROM forum WHERE forumid=$forumid");

  echo doformheader("forum","doupdate");
  echo makehiddencode("forumid","$forumid");

  echo "<table border=0>";

  echo makeinputcode("Title","title",$forum[title]);
  echo maketextareacode("Description<br>You may use HTML","description",$forum[description]);
  echo makeyesnocode("Forum Enabled (i.e. can be viewed)<br>(To set permissions for individual users, go to the user permissions area)","active",$forum[active]);
  echo makeyesnocode("Allow posting/editing","allowposting",$forum[allowposting]);
  echo makeinputcode("Display Order<br>0=do not display","displayorder",$forum[displayorder]);

  echo doformfooter();

}

// ###################### Start update #######################
if ($action=="doupdate") {

  $DB_site->query("UPDATE forum SET title='".addslashes($title)."',description='".addslashes($description)."',active=$active,displayorder=$displayorder,allowposting=$allowposting WHERE forumid=$forumid");

  echo "<p>Record updated!</p>";

  $action="modify";

}
// ###################### Start Remove forum #######################

if ($action=="remove") {

  echo "<p>Are you sure you want to delete the selected record - it will remove all the posts too!</p>\n";
  echo "<p><a href='forum.php?forumid=$forumid&action=kill'>Yes</a></p>";

}

// ###################### Start Kill #######################

if ($action=="kill") {

  $DB_site->query("DELETE FROM forum WHERE forumid=$forumid");

  $threads=$DB_site->query("SELECT threadid FROM thread WHERE forumid=$forumid");

  while ($thread=$DB_site->fetch_array($threads)) {
    $DB_site->query("DELETE FROM post WHERE threadid=$thread[threadid]");
  }

  $DB_site->query("DELETE FROM thread WHERE forumid=$forumid");

  $action="modfiy";

}

// ###################### Start order #######################
if ($action=="order") {

  echo doformheader("forum","doorder");

  echo "<ul>";

  $forums=$DB_site->query("SELECT forumid,title,displayorder FROM forum ORDER BY displayorder");

  while ($forum=$DB_site->fetch_array($forums)) {

    echo "<li>$forum[title] <input type=text name=\"order[$forum[forumid]]\" size=5 value=\"$forum[displayorder]\"></li>\n";
  }

  echo "</ul>";
  echo doformfooter();
}

// ###################### Start do order #######################
if ($action=="doorder") {

  while (list($key,$val)=each($order)) {

    $DB_site->query("UPDATE forum SET displayorder=$val WHERE forumid=$key");

  }

  echo "<p>Order updated!</p>";
  $action="modify";

}

// ###################### Start modify #######################
if ($action=="modify") {

  $forums=$DB_site->query("SELECT forumid,title,displayorder FROM forum ORDER BY displayorder");

  echo "<ul>";

  while ($forum=$DB_site->fetch_array($forums)) {

    echo "<li><b>$forum[title]</b> (Order: $forum[displayorder])  <a href='forum.php?action=edit&forumid=$forum[forumid]'>[edit]</a> <a href='forum.php?action=remove&forumid=$forum[forumid]'>[remove]</a></li>\n";

  }

  echo "</ul>";
}

?>
</body>
</html>