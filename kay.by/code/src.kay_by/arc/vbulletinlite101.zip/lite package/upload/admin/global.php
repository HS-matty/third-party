<?php
$noheader=1;

// get rid of slashes in get / post / cookie data
if (get_magic_quotes_gpc()==1 and is_array($GLOBALS)==1) {
  while(list($key,$val)=each($GLOBALS)) {
    if (is_string($val)==1) {
      $GLOBALS[$key]=stripslashes($val);
    }
  }
}
set_magic_quotes_runtime(0);

if (isset($noheader)==0 or $noheader==0) {
  // default headers
  header("HTTP/1.0 200 OK");
  header("HTTP/1.1 200 OK");
  header("Content-type: text/html");
}

if ($nocache==1) {
  // no caching
  header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");             // Date in the past
  header("Last-Modified: " . gmdate("D, d M Y H:i:s") . "GMT"); // always modified
  header("Cache-Control: no-cache, must-revalidate");           // HTTP/1.1
  header("Pragma: no-cache");                                   // HTTP/1.0
}


// ###################### Start init #######################
//load config
require("./config.php");

// init db **********************
// load db class
$dbclassname="./db_$dbservertype.php";
require($dbclassname);

$DB_site=new DB_Sql_vb;

$DB_site->appname="vBulletin Lite Control Panel";
$DB_site->appshortname="vBulletin Lite (cp)";
$DB_site->database=$dbname;
$DB_site->server=$servername;
$DB_site->user=$dbusername;
$DB_site->password=$dbpassword;

$DB_site->connect();
// end init db

// load options
$optionstemp=$DB_site->query_first("SELECT template FROM template WHERE title='options'");
eval($optionstemp[template]);

// ###################### Start iif #######################
function iif ($expression,$returntrue,$returnfalse) {

  if ($expression==0) {
    $areturn=$returnfalse;
  } else {
    $areturn=$returntrue;
  }
  return $areturn;

}

// ###################### Start makeinputcode #######################
function makeinputcode ($title,$name,$value="",$size=35) {
// makes code for an imput box: first column contains $title
// second column contains an input box of name, $name and value, $value. $value is "HTMLised"

  $htmlval=htmlspecialchars($value);
  $code="<tr>\n<td>$title</td>\n<td><input type=\"text\" size=\"$size\" name=\"$name\" value=\"$htmlval\"></td>\n</tr>\n";

  return $code;
}

// ###################### Start makehiddencode #######################
function makehiddencode ($name,$value="") {
// makes code for an imput box: first column contains $title
// second column contains an input box of name, $name and value, $value. $value is "HTMLised"

  $htmlval=htmlspecialchars($value);
  $code="<input type=\"hidden\" name=\"$name\" value=\"$htmlval\">\n";

  return $code;
}

// ###################### Start makepasswordcode #######################
function makepasswordcode ($title,$name,$value="",$size=35) {
// makes code for an imput box: first column contains $title
// second column contains an input box of name, $name and value, $value. $value is "HTMLised"

  $htmlval=htmlspecialchars($value);
  $code="<tr>\n<td>$title</td>\n<td><input type=\"password\" size=\"$size\" name=\"$name\" value=\"$htmlval\"></td>\n</tr>\n";

  return $code;
}

// ###################### Start makeyesnocode #######################
function makeyesnocode ($title,$name,$value=1) {
// Makes code for input buttons yes\no similar to makeinputcode

  if ($value==1) {
    $code="<tr>\n<td>$title</td>\n<td>Yes<input type=\"radio\" checked name=\"$name\" value=\"1\"> No <input type=\"radio\" name=\"$name\" value=\"0\"></td>\n</tr>";
  } else {
    $code="<tr>\n<td>$title</td>\n<td>Yes<input type=\"radio\" name=\"$name\" value=\"1\"> No <input type=\"radio\" checked name=\"$name\" value=\"0\"></td>\n</tr>";
  }

  return $code;
}

// ###################### Start maketextareacode #######################
function maketextareacode ($title,$name,$value="",$rows=4,$cols=40) {
// similar to makeinputcode, only for a text area

  $htmlval=htmlspecialchars($value);

  $code="<tr>\n<td>$title</td>\n<td><textarea name=\"$name\" rows=\"$rows\" cols=\"$cols\">$htmlval</textarea></td>\n</tr>\n";

  return $code;
}

// ###################### Start doformheader #######################
function doformheader ($phpscript,$action) {
// makes the standard form header, setting sctript to call and action to do

  $code="<form action=\"$phpscript.php\" method=\"post\">\n<input type=\"hidden\" name=\"action\" value=\"$action\">\n";
  return $code;
}

// ###################### Start doformfooter #######################
function doformfooter($submitname="Submit",$resetname="Reset") {
// closes the standard form table and makes a new one containing centred submit and reset buttons

  $code="</table>\n<div align=\"center\"><center><table border=\"0\">\n<tr>\n<td><p align=\"center\"><input type=\"submit\" name=\"submit\" value=\"$submitname\"></p></td>\n";
  if ($resetname!="") {
    $code.="<td><p align=\"center\"><input type=\"reset\" name=\"reset\" value=\"Reset\"></p></td>\n";
  }
  $code.="</tr>\n</table>\n</center></div>\n</form>\n";
  return $code;

}

// ###################### Start makechoosercode #######################
function makechoosercode ($title,$name,$tablename,$selvalue=-1,$extra="") {
// returns a combo box containing a list of titles in the $tablename table.
// allows specification of selected value in $selvalue
  global $DB_site;

  $code="<tr>\n<td>$title</td>\n<td><select name=\"$name\" size=\"1\">\n";
  $tableid=$tablename."id";

  $result=$DB_site->query("SELECT title,$tableid FROM $tablename ORDER BY title");
  while ($currow=$DB_site->fetch_array($result)) {

    if ($selvalue==$currow[$tableid]) {
      $code=$code."<option value=$currow[$tableid] SELECTED>$currow[title]</option>\n";
    } else {
      $code=$code."<option value=$currow[$tableid]>$currow[title]</option>\n";
    }
  } // for

  if ($extra!="") {
    if ($selvalue==-1) {
      $code=$code."<option value=-1 SELECTED>$extra</option>\n";
    } else {
      $code=$code."<option value=-1>$extra</option>\n";
    }
  }

  $code=$code."</select>\n</td>\n</tr>\n";

  return $code;

}

// ###################### Start cookies #######################
if ($cppassword!=$controlpassword) {

?><html>
<head><title>Forums admin</title></head>
<body>
<p>You are either not a valid administrator or have not logged in. Please log in now:</p>
<form action="index.php" method=post>
<input type="password" name="controlpassword">
<input type="submit" value="Submit">
</form>
</body>
</html>
<?php
  exit;
}

setcookie("controlpassword",$controlpassword,mktime(0,0,0,0,0,2020),"/");

?>