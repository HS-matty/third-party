<?

require("./global.php");

if (isset($action)==0 or $action=="") {
  $action="showforums";
}

if ($action=="bbcode") {

  eval("echo dovars(\"".gettemplate("bbcode")."\");");

}

if ($action=="faq") {

  eval("echo dovars(\"".gettemplate("faq")."\");");

}

if ($action=="showforums") {

  // if user is know, then welcome
  if ($bbusername!="") {
    $username=$bbusername;
    eval("\$welcometext = \"".gettemplate("welcometext")."\";");
  }

  // make the forum bits
  $forums=$DB_site->query("SELECT forumid,title,description,displayorder,lastpost,replycount,threadcount,allowposting FROM forum WHERE active=1 AND displayorder<>0 ORDER BY displayorder");
  while ($forum=$DB_site->fetch_array($forums)) {

    // do light bulb
    if ($lastvisitdate=="Never") {
      $onoff="on";
    } else {
      if ($bblastvisit<$forum[lastpost]) {
        $onoff="on";
      } else {
        $onoff="off";
      }
    }

    if ($forum[allowposting]==0) {
      $onoff.="lock";
    }

    // prepare template vars
    $forumid=$forum[forumid];
    $forumtitle=htmlspecialchars($forum[title]);

    if ($showforumdescriptions==1) {
      $forumdescription=$forum[description];
    }

    // post and thread counts
    $numberposts=$forum[replycount];
    $numberthreads=$forum[threadcount];

    // dates
    if ($forum[lastpost]>0) {
      $lastpostdate=date($dateformat,$forum[lastpost]+($timeoffset*3600));
      $lastposttime=date($timeformat,$forum[lastpost]+($timeoffset*3600));
    } else {
      $lastpostdate="Never";
      $lastposttime="";
    }

    eval("\$forumbits .= \"".gettemplate("forumhomebit")."\";");
  } // while forums

  eval("echo dovars(\"".gettemplate("forumhome")."\");");

}

?>