<?php

require("./global.php");

if (isset($action)==0 or $action=="") {
  $action="newreply";
}

// ############################### start new reply ###############################
if ($action=="newreply") {

  $threadid=verifyid("thread",$threadid);

  $threadinfo=$DB_site->query_first("SELECT title,forumid FROM thread WHERE threadid=$threadid");
  $threadtitle=htmlspecialchars($threadinfo[title]);
  $forumid=$threadinfo[forumid];

  $foruminfo=$DB_site->query_first("SELECT title,description,active,allowposting FROM forum WHERE forumid=$threadinfo[forumid]");
  $forumtitle=htmlspecialchars($foruminfo[title]);
  if ($foruminfo[active]==0) {
    echo standarderror($bbtitle,gettemplate("error_forumclosed",0));
    exit;
  }
  if ($foruminfo[allowposting]==0) {
    echo standarderror($bbtitle,gettemplate("error_forumnoreply",0));
    exit;
  }

  eval("echo dovars(\"".gettemplate("newreply")."\");");

}

// ############################### start post reply ###############################
if ($action=="postreply") {

  // check for subject and message
  if ($message=="") {
    echo standarderror($bbtitle,gettemplate("error_nosubject",0));
    exit;
  }

  //check valid name
  if ($username=="" or trim($username)=="") {
    echo standarderror($bbtitle,"Please enter your name in the 'Name' field.");
  }

  $threadid=verifyid("thread",$threadid);

  $threadinfo=$DB_site->query_first("SELECT title,forumid,replycount FROM thread WHERE threadid=$threadid");
  $threadtitle=$threadinfo[title];

  $foruminfo=$DB_site->query_first("SELECT forumid,title,active,allowposting FROM forum WHERE forumid=$threadinfo[forumid]");
  $forumid=$foruminfo[forumid];
  $forumtitle=$foruminfo[title];
  if ($foruminfo[active]==0) {
    echo standarderror($bbtitle,gettemplate("error_forumclosed",0));
    exit;
  }
  if ($foruminfo[allowposting]==0) {
    echo standarderror($bbtitle,gettemplate("error_forumnoreply",0));
    exit;
  }

  $DB_site->query("INSERT INTO post (postid,threadid,title,username,email,dateline,pagetext) VALUES (NULL,$threadid,'".addslashes($title)."','".addslashes($username)."','".addslashes($email)."',".time().",'".addslashes($message)."')");

  indexthread($threadid);

  if ($threadinfo[replycount]%50==0) {
    $replies=$DB_site->query_first("SELECT COUNT(postid)-1 AS replies FROM post WHERE threadid=$threadid");
    $DB_site->query("UPDATE thread SET lastpost=".time().",replycount=$replies[replies] WHERE threadid=$threadid");
  } else {
    $DB_site->query("UPDATE thread SET lastpost=".time().",replycount=replycount+1 WHERE threadid=$threadid");
  }

  // update forum stuff
  $DB_site->query("UPDATE forum SET replycount=replycount+1,lastpost=".time()." WHERE forumid=$threadinfo[forumid]");

  // redirect
  echo standardredirect($bbtitle,"Thank you for posting, $username. You will now be taken to your post.","showthread.php?threadid=".intval($threadid));
}


?>