<?php
$noheader=1;

// get rid of slashes in get / post / cookie data
if (get_magic_quotes_gpc()==1 and is_array($GLOBALS)==1) {
  while(list($key,$val)=each($GLOBALS)) {
    if (is_string($val)==1) {
      $GLOBALS[$key]=stripslashes($val);
    }
  }
}
set_magic_quotes_runtime(0);

unset($templatecache);

if (isset($noheader)==0 or $noheader==0) {
  // default headers
  header("HTTP/1.0 200 OK");
  header("HTTP/1.1 200 OK");
  header("Content-type: text/html");
}

if ($nocache==1) {
  // no caching
  header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");             // Date in the past
  header("Last-Modified: " . gmdate("D, d M Y H:i:s") . "GMT"); // always modified
  header("Cache-Control: no-cache, must-revalidate");           // HTTP/1.1
  header("Pragma: no-cache");                                   // HTTP/1.0
}

// ###################### Start init #######################
//load config
require("./admin/config.php");

// init db **********************
// load db class
$dbclassname="./admin/db_$dbservertype.php";
require($dbclassname);

$DB_site=new DB_Sql_vb;

$DB_site->appname="vBulletin Lite";
$DB_site->appshortname="vBulletin Lite (forum)";
$DB_site->database=$dbname;
$DB_site->server=$servername;
$DB_site->user=$dbusername;
$DB_site->password=$dbpassword;

$DB_site->connect();
// end init db

// load options
$optionstemp=$DB_site->query_first("SELECT template FROM template WHERE title='options'");
eval($optionstemp[template]);

// load vars
$vars=$DB_site->query("SELECT * FROM replacement ORDER BY replacementid DESC");

// ###################### Start dovars #######################
function dovars($vartext) {
  // parses replacement vars

  global $DB_site;
  global $vars;

  $newtext=$vartext;

  $DB_site->data_seek(0,$vars);
  while ($var=$DB_site->fetch_array($vars)) {
    $newtext=str_replace($var[findword],$var[replaceword],$newtext);
  }

  return $newtext;
}

// ###################### Start standarderror #######################
function standarderror($title="",$error="",$headinsert="") {
  // print standard error page
  global $header,$footer,$cssinclude,$fivelinks,$forumjump,$timezone,$bbtitle,$hometitle,$homeurl,$copyrighttext,$contactuslink,$webmasteremail,$technicalemail,$titleimage,$lastvisitdate,$timenow;

  makeforumjump();

  $pagetitle = "$title";
  $errormessage = $error;

  eval("\$returnval = dovars(\"".gettemplate("standarderror")."\");");

  return $returnval;
}

// ###################### Start standardredirect #######################
function standardredirect($title="",$message="",$redirectloc="") {
  // print standard redirect page

  global $header,$footer,$cssinclude,$fivelinks,$forumjump,$timezone,$bbtitle,$hometitle,$homeurl,$copyrighttext,$contactuslink,$webmasteremail,$technicalemail,$titleimage,$lastvisitdate,$timenow;

  makeforumjump();

  $pagetitle = "$title";
  $errormessage = $message;
  $url=$redirectloc;
  $url=str_replace("\"", "", $url);

  eval("\$returnval = dovars(\"".gettemplate("standardredirect")."\");");

  return $returnval;
}

// ###################### Start iif #######################
function iif ($expression,$returntrue,$returnfalse) {

  if ($expression==0) {
    $areturn=$returnfalse;
  } else {
    $areturn=$returntrue;
  }
  return $areturn;

}

// ###################### Start bbcodeparse #######################
function bbcodeparse($bbcode) {

  bbcodeparse2($bbcode,$forumid,$allowsmilie);

  global $bbcode2;

  return $bbcode2;
}

function bbcodeparse2($bbcode,$forumid=0,$allowsmilie=1) {
  // parses text for vB code, smilies and censoring

  global $DB_site,$bbcode2;

  // kill any rogue html code
  $bbcode=str_replace("&","&amp;",$bbcode);
  $bbcode=str_replace("<","&lt;",$bbcode);
  $bbcode=str_replace(">","&gt;",$bbcode);

  $bbcode=nl2br($bbcode);

  $bbcode=eregi_replace(quotemeta("[b]"),quotemeta("<b>"),$bbcode);
  $bbcode=eregi_replace(quotemeta("[/b]"),quotemeta("</b>"),$bbcode);
  $bbcode=eregi_replace(quotemeta("[i]"),quotemeta("<i>"),$bbcode);
  $bbcode=eregi_replace(quotemeta("[/i]"),quotemeta("</i>"),$bbcode);
  $bbcode=eregi_replace(quotemeta("[u]"),quotemeta("<u>"),$bbcode);
  $bbcode=eregi_replace(quotemeta("[/u]"),quotemeta("</u>"),$bbcode);

  // do [url]xxx[/url]
  $bbcode=eregi_replace("\\[url\\]www.([^\\[]*)\\[/url\\]","<a href=\"http://www.\\1\" target=_blank>\\1</a>",$bbcode);
  $bbcode=eregi_replace("\\[url\\]([^\\[]*)\\[/url\\]","<a href=\"\\1\" target=_blank>\\1</a>",$bbcode);

  // do [email]xxx[/email]
  $bbcode=eregi_replace("\\[email\\]([^\\[]*)\\[/email\\]","<a href=\"mailto:\\1\">\\1</a>",$bbcode);

  // do quotes
  $bbcode=eregi_replace("quote\\]","quote]",$bbcode);  // make lower case
  $bbcode=str_replace("[quote]\r\n","<blockquote><smallfont>quote:</smallfont><hr>",$bbcode);
  $bbcode=str_replace("[quote]","<blockquote><smallfont>quote:</smallfont><hr>",$bbcode);
  $bbcode=str_replace("[/quote]\r\n","<hr></blockquote>",$bbcode);
  $bbcode=str_replace("[/quote]","<hr></blockquote>",$bbcode);

  // do [img]xxx[/img]
  $bbcode=eregi_replace("\\[img\\]([^\"\\[]*)\\[/img\\]","<img src=\"\\1\" border=0>",$bbcode);
  $bbcode2=$bbcode;

  return 1;
}

// ###################### Start gettemplate #######################
function gettemplate($templatename,$escape=1) {
  // gets a template from the db or from the local cache
  global $templatecache,$DB_site;

  if ($templatecache[$templatename]!="") {
    $template=$templatecache[$templatename];
  } else {
    $gettemp=$DB_site->query_first("SELECT template FROM template WHERE title='".addslashes($templatename)."'");
    $template=$gettemp[template];
    $templatecache[$templatename]=$template;
  }

  if ($escape==1) {
    $template=str_replace("\"","\\\"",$template);
  }
  return $template;
}

// ###################### Start verifyid #######################
function verifyid($idname,$id) {
  // verifies an id number and returns a correct one if it can be found
  global $DB_site,$webmasteremail;

  if (isset($id)==0 or $id==0 or $id=="") {
    echo standarderror($bbtitle,"No $idname specified. If you followed a valid link, please notify the <a href=\"mailto:$webmasteremail\">webmaster</a>");

    exit;

  } else {
    $id=intval($id);
    if (!$check=$DB_site->query_first("SELECT $idname"."id FROM $idname WHERE $idname"."id=$id")) {
      echo standarderror($bbtitle,"Invalid $idname specified. If you followed a valid link, please notify the <a href=\"mailto:$webmasteremail\">webmaster</a>");

      exit;
    }
  }

  return $id;
}

// ###################### Start wordsonly #######################
function wordsonly ($text) {
  //for the searching - strips out unneccessary bits
  $text=strtolower($text);

  $text=ereg_replace("<pre>[^<]*</pre>"," ",$text);
  $text=ereg_replace("<[^>]*>"," ",$text); // remove HTML <> tags
  $text=ereg_replace("&[^;];"," ",$text); // remove HTML special chars
//  $text=ereg_replace("[^ 0-9a-z]"," ",$text); // keep only letters and numbers

  $counter=0;

  $words=explode(" ",$text);
  while (list($key,$val)=each($words)) {
    if (strlen($val)>2 and $val!="the" and $val!="this" and $val!="and" and $val!="but" and $val!="was" and $val!="that" and $val!="with" and $val!="its" and $val!="you" and $val!="they" and $val!="what" and $val!="why" and $val!="for" and $val!="are" and $val!="our" and $val!="then" and $val!="there" and $val!="which") {
      $counter++;
      $wordarray[$val]=1;
    }
  }

  if ($counter>0) {
    while (list($key,$val)=each($wordarray)) {
      $newwords[]=$key;
    }

    $newwords=implode($newwords," ");
  } else {
    $newwords="";
  }

  return $newwords;
}

// ###################### Start indexthread #######################
function indexthread($threadid) {
  //adds a thread into the search index
  global $DB_site;

  $thread=$DB_site->query_first("SELECT threadid,title FROM thread WHERE threadid=$threadid");

  $subject=$thread[title];

  $posts=$DB_site->query("SELECT username,pagetext FROM post WHERE threadid=$thread[threadid]");
  while ($post=$DB_site->fetch_array($posts)) {
    $usernames.=" $post[username] ";
    $pagetext.=" $post[pagetext] ";
  }

  $subject=wordsonly($subject);
  $pagetext=$subject." ".wordsonly($pagetext);
  $usernames=wordsonly($usernames);

  $DB_site->query("UPDATE thread SET subjectindex=' ".addslashes($subject)." ',threadindex=' ".addslashes($pagetext)." ',userindex=' ".addslashes($usernames)." ' WHERE threadid=$threadid");

  return 1;
}

// ###################### Start makeforumjump #######################
function makeforumjump() {
  // this generates the jump to box
  global $DB_site,$forumid,$optionselected,$usecategories,$jumpforumid,$jumpforumtitle,$jumpforumbits,$curforumid;
  global $defaultselected,$forumjump;

  $jumpforumbits="";

  if ($forumid!="") {
    $curforumid=$forumid;
  } else {
    if ($threadid!="") {
      $getforumid=$DB_site->query_first("SELECT forumid FROM thread WHERE threadid=$threadid");
      $curforumid=$getforumid[forumid];
    }
  }

  $forums=$DB_site->query("SELECT forumid,title,displayorder FROM forum WHERE displayorder<>0 AND active=1 ORDER BY displayorder");

  while ($forum=$DB_site->fetch_array($forums)) {
    $forumshown=1;

    $jumpforumid=$forum[forumid];
    $jumpforumtitle="  $forum[title]";

    if ($curforumid==$jumpforumid) {
      $optionselected="selected";
      $selectedone=1;
    } else {
      $optionselected="";
    }
    eval("\$jumpforumbits .= \"".gettemplate("jumpforumbit")."\";");
  } // end while

  if ($selectedone!=1) {
    $defaultselected="selected";
  }
  eval("\$forumjump = \"".gettemplate("forumjump")."\";");
}

if (isset($bblastvisit)!=0 and $bblastvisit!=0) {
  $bblastvisit=$bblastvisit;
  if (isset($bblastactivity)==0 or $bblastactivity==0) {
    $bblastactivity=time();
  }
  if (time()-$bblastactivity>$cookietimeout) {
    setcookie("bblastvisit",$bblastactivity,mktime(0,0,0,0,0,2020),$cookiepath);
    $bblastvisit=$bblastactivity;
  }
} else {
  setcookie("bblastvisit",time(),mktime(0,0,0,0,0,2020),$cookiepath);
  $bblastvisit=time();
}
setcookie("bblastactivity",time(),mktime(0,0,0,0,0,2020),$cookiepath);

$lastvisitdate=date($dateformat,$bblastvisit+($timeoffset*3600))." ".date($timeformat,$bblastvisit+($timeoffset*3600));

if (isset($bblastvisit)==0 or $bblastvisit==0) {
  $bblastvisit=time();
  $lastvisitdate="Never";
}

// ###################### Start templates #######################
//prepare default templates **********************
$temps=$DB_site->query("SELECT template,title FROM template WHERE title='cssinclude' OR title='header' OR title='footer' OR title='fivelinks' OR title='jumpforumbit' OR title='forumjump'");
while ($temp=$DB_site->fetch_array($temps)) {
  $templatecache["$temp[title]"]=$temp[template];
}

// parse css ################## not really needed!
eval("\$cssinclude = \"".gettemplate("cssinclude")."\";");

// parse header ##################
eval("\$header = \"".gettemplate("header")."\";");
eval("\$footer = \"".gettemplate("footer")."\";");

// DO NOT REMOVE OR EDIT THIS COPYRIGHT NOTICE
// IT IS REQUIRED FOR COMPLIANCE WITH THE LICENSE AGREEMENT
$footer.="<p align=\"center\"><smallfont>
Powered by: <a href=\"http://www.vbulletin.com\" target=\"_new\">vBulletin</a> Lite Version $versionnumber<BR>
Copyright &copy; Jelsoft Enterprises Limited 2000.<br>";
// DO NOT REMOVE

eval("\$fivelinks = \"".gettemplate("fivelinks")."\";");

if ($url=="") {
  $url=getenv("HTTP_REFERER");
}

$timezoneorig=$timezone;

if ($bbtimezoneoffset!=0) {
  if ($bbtimezoneoffset>0) {
    $timezone.="  hours";
  } else {
    $timezone.=" $bbtimezoneoffset hours";
  }
}

$timenow=date($timeformat,time()+($timeoffset*3600));
// end prepare default templates ********************

// check that board is active - if not admin, then display error
if ($bbactive==0) {
  echo standarderror($bbtitle,$bbclosedreason);
  exit;
}

?>