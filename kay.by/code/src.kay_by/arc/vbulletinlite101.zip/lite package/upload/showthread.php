<?php
require("./global.php");

$threadid = verifyid("thread",$threadid);

$threadinfo=$DB_site->query_first("SELECT title,forumid,lastpost,replycount+1 AS posts FROM thread WHERE threadid=$threadid");
$threadtitle=htmlspecialchars($threadinfo[title]);
$forumid=$threadinfo[forumid];

makeforumjump();

$foruminfo=$DB_site->query_first("SELECT title,description,active FROM forum WHERE forumid=$forumid");
$forumtitle=htmlspecialchars($foruminfo[title]);

if ($foruminfo[active]==0) {
  echo standarderror($bbtitle,gettemplate("error_forumclosed",0));
  exit;
}

$counter=0;
$posts=$DB_site->query("SELECT dateline,postid,pagetext,title,username,email FROM post WHERE threadid=$threadid ORDER BY dateline");
while ($post=$DB_site->fetch_array($posts)) {

  $counter++;

  $postid=$post[postid];

  if ($counter%2==0) {
    $backcolor="{firstaltcolor}";
  } else {
    $backcolor="{secondaltcolor}";
  }

  $postdate=date($dateformat,$post[dateline]+($timeoffset*3600));
  $posttime=date($timeformat,$post[dateline]+($timeoffset*3600));

  $postitle=htmlspecialchars($post[title]);

  if ($post[dateline]>$bblastvisit) {
    $foldericon="<IMG SRC=\"images/posticonnew.gif\" BORDER=0>";
  } else {
    $foldericon="<IMG SRC=\"images/posticon.gif\" BORDER=0>";
  }

  $username=htmlspecialchars($post[username]);

  if ($post[email]!="" and $displayemails==1) {
    $email=$post[email];
    $useremail = "<A HREF=\"mailto:$email\" target=_blank><IMG SRC=\"images/email.gif\" BORDER=0 ALT=\"Click Here to Email $username\"></A>&nbsp;&nbsp;";
  } else {
    $useremail="";
  }

  $message=bbcodeparse($post[pagetext]);

  $searchuser=urlencode($username);

  eval("\$postbits .= \"".gettemplate("postbit")."\";");

}

if ($getnextnewest=$DB_site->query_first("SELECT threadid FROM thread WHERE lastpost>$threadinfo[lastpost] AND forumid=$forumid ORDER BY lastpost LIMIT 1")) {
  $nextnewestthreadid=$getnextnewest[threadid];
  $nextnewest = "&nbsp; <a href=\"showthread.php?threadid=$nextnewestthreadid\">Next Thread &gt;</a>";
} else {
  $nextnewestthreadid=$threadid;
}

if ($getnextoldest=$DB_site->query_first("SELECT threadid FROM thread WHERE lastpost<$threadinfo[lastpost] AND forumid=$forumid ORDER BY lastpost DESC LIMIT 1")) {
  $nextoldestthreadid=$getnextoldest[threadid];
  $nextoldest = "<a href=\"showthread.php?threadid=$nextoldestthreadid\">&lt; Last Thread</a> &nbsp;";
} else {
  $nextoldestthreadid=$threadid;
}

eval("echo dovars(\"".gettemplate("showthread")."\");");

?>