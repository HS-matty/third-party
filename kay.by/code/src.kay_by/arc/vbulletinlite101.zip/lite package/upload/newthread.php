<?php

require("./global.php");

if (isset($action)==0 or $action=="") {
  $action="newthread";
}

// ############################### start new thread ###############################
if ($action=="newthread") {
  $forumid = verifyid("forum",$forumid);

  $foruminfo=$DB_site->query_first("SELECT title,description,active,allowposting FROM forum WHERE forumid=$forumid");
  $forumtitle=htmlspecialchars($foruminfo[title]);
  if ($foruminfo[active]==0) {
    echo standarderror($bbtitle,gettemplate("error_forumclosed",0));
    exit;
  }
  if ($foruminfo[allowposting]==0) {
    echo standarderror($bbtitle,gettemplate("error_forumnoreply",0));
    exit;
  }

  eval("echo dovars(\"".gettemplate("newthread")."\");");

}

// ############################### start post thread ###############################
if ($action=="postthread") {

  // check for subject and message
  if (trim($subject)=="" or trim($message)=="") {
    echo standarderror($bbtitle,gettemplate("error_nosubject",0));
    exit;
  }

  $forumid=verifyid("forum",$forumid);

  //check valid name
  if ($username=="" or trim($username)=="") {
    echo standarderror($bbtitle,"Please enter your name in the 'Name' field.");
  }

  $foruminfo=$DB_site->query_first("SELECT active,allowposting,title FROM forum WHERE forumid=$forumid");
  $forumtitle=$foruminfo[title];
  if ($foruminfo[active]==0) {
    echo standarderror($bbtitle,gettemplate("error_forumclosed",0));
    exit;
  }
  if ($foruminfo[allowposting]==0) {
    echo standarderror($bbtitle,gettemplate("error_forumnoreply",0));
    exit;
  }

  //create new thread
  $DB_site->query("INSERT INTO thread (threadid,title,lastpost,forumid,replycount,postusername,dateline) VALUES (NULL,'".addslashes($subject)."',".time().",$forumid,0,'".addslashes($username)."',".time().")");
  $threadid=$DB_site->insert_id();

  // create first post
  $DB_site->query("INSERT INTO post (postid,threadid,title,username,email,dateline,pagetext) VALUES (NULL,$threadid,'','".addslashes($username)."','".addslashes($email)."',".time().",'".addslashes($message)."')");

  indexthread($threadid);

  // update forum stuff
  $DB_site->query("UPDATE forum SET replycount=replycount+1,threadcount=threadcount+1,lastpost=".time()." WHERE forumid=$forumid");

  // redirect
  echo standardredirect($bbtitle,"Thank you for posting, $username. You will now be taken to your post.","showthread.php?threadid=".intval($threadid));
}

?>