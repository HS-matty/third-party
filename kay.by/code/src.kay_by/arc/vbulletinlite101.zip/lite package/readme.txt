Installation:

1) Edit the config.php file to match your MySQL settings. You will have to talk to your host to get these if you don't know them already! Also make a note of the control panel password.

2) Upload all the files onto your server

3) Call up this script in your browser:
http://yourhost.domain/vblite/admin/install.php

4) Follow the on screen instructions to complete the installation.