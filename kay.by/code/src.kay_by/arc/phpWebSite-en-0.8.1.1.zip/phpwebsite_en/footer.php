<?php
/**
 * This file defines the foot function used to print the page footer.
 *
 * If you want to customize the pages by means of a theme, you should
 * have a look at footer.php in one of the theme directories. This
 * file only determines the footer.php to include from one of
 * those. You should touch this file only to get rid of the
 * smalltextatbottom &quot;feature&quot;.
 *
 * @module footer
 * @modulegroup theme
 * @package phpWebSite
 */

/**
 * This function creates the "footer" of the web page.
 *
 * This function creates the "footer" of the web page dependent on the
 * theme being used by the user. If the user is not logged in, the
 * default theme footer is used.
 */
function foot() {
  /**
   * The global configuration file.
   */
  include("config.php");
  global $index, $storynum, $user, $cookie;

	if(isset($user))
	{
		if($cookie[9]=="") $cookie[9]="Default";
		/**
		 * The footer.php of the theme to be used. Contained
		 * in the user varibale cookie.
		 */
		$footer_exists = @fopen("themes/$cookie[9]/footer.php", "r");
		if($footer_exists)
			include("themes/$cookie[9]/footer.php");
		else
			include("themes/$default_theme/footer.php");
	}
	else
	/**
	 * The footer.php of the standard theme.
	 *
	 * This file is included if no user variable cookie is found.
	 */
	include("themes/$default_theme/footer.php");

	if($failed)
		include("themes/$default_theme/footer.php");

	echo "
	<div class=\"smalltextatbottom\" style=\"text-align : center\">
	$foot1<br />
	$foot2<br />
	$foot3<br />
	</div>
</body>
</html>
";
}

foot();

?>
