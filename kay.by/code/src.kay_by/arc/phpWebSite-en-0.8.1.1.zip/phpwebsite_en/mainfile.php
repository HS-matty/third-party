<?php

/**
 * This file contains the core function definitions for phpWebSite.
 *
 * The functions defined here are essential for the phpWebSite
 * system. This file gets included almost all the time, you should be
 * able to use the functions defined here everywhere in the code.
 *
 * @module mainfile
 * @modulegroup core
 * @package phpWebSite
 */

$mainfile = 1;

include("dbconnect.php");

/**
 * Checks for modules at given position and displays them.
 *
 * This function is used to check for modules registered an the
 * modules table. If a plugin for the given position is found, the
 * plugin code file gets included and the result is displayed using
 * the themeplugin function.
 *
 * @param int plugin block position
 */
function plug_check($position)
{
	global $admintest;
	$plug_mysql = mysql_query("select name, plug_dir, block_file, admin_only, user_only from modules where block_pos =  '$position'");

        if (mysql_num_rows($plug_mysql) > 0)
	{
                while ($row = mysql_fetch_array($plug_mysql))
		{
                        extract($row);
                        if (($admintest && !$user_only) || (!$admintest && !$admin_only))
			{
			  /**
			   * The plugin code file. Checks to see if plugin actually exists on server.
			   */
				if (file_exists("mod/$plug_dir/$block_file")) {
	                                include ("mod/$plug_dir/$block_file");
                                $box_title = $name;
                                themeplugin($box_title, $box_content);
				}
                      }
               }
        }
}


/**
 * Checks for given plugin name and displays it.
 *
 * This function is used to check for a given plugin name in the
 * modules table. If a plugin for the given name is found, the
 * plugin code file gets included and the result is displayed using
 * the themeplugin function.
 *
 * @param string plugin name
 */
function plug_get($plug_name)
{
	global $admintest;
	$plug_mysql = mysql_query ("select name, plug_dir, block_file, admin_only, user_only from modules where plug_dir='$plug_name'");

        if (mysql_num_rows($plug_mysql) > 0)
	{
                while ($row = mysql_fetch_array($plug_mysql))
		{
                        extract($row);
                        if (($admintest && !$user_only) || (!$admintest && !$admin_only))
			{
			  /**
			   * The plugin code file.
			   */
                                include ("mod/$plug_dir/$block_file");
                                echo $box_content;
                        }
                }
        }
}


/**
 * Outputs the given parameters somehow &quot;formatted&quot;
 *
 * The given parameters are checked for containing html breaks,
 * headings or paragraph tags. If no tags are found, newlines are
 * replaced by html break tags, otherwise the input is used as is.
 *
 * The input is then printed seperated by to html break tags if the
 * following variable is not empty.
 *
 * @param string The title of the part.
 * @param string The lead-in text.
 * @param string The optional main text.
 * @param string The optional notes text.
 */
function themepreview($title, $hometext, $bodytext="", $notes="")
{
	echo "<b>$title</b><br /><br />";

	if (!strstr ($hometext, '<p') && !strstr ($hometext, '<table') && !strstr ($hometext, '<br') && !strstr($hometext, '<h'))
	echo str_replace ("\n" , "<br />", $hometext);
	else
	echo "$hometext";

	if (strlen($bodytext))
	echo "<br /><br />";

	if (!strstr ($bodytext, '<p') && !strstr ($bodytext, '<table') && !strstr ($bodytext, '<br') && !strstr($bodytext, '<h'))
	echo str_replace ("\n" , "<br />", $bodytext);
	else
	echo "$bodytext";

	if (strlen($notes))
	echo "<br /><br />";

	if (!strstr ($notes, '<p') && !strstr ($notes, '<table') && !strstr ($notes, '<br') && !strstr($notes, '<h'))
	echo str_replace ("\n" , "<br />", $notes);
	else
	echo "$notes";
}


/**
 * Writes news headlines to a file for general purpose use
 *
 * The 10 most recent news headlines are fetched from the database and
 * stored in ultramode.txt in the web root. The file contains title,
 * URL, time, aid, text and imagename of each topic.
 */
function ultramode()
{
    $file = fopen("ultramode.txt", "w");
    fwrite($file, "General purpose self-explanatory file with news headlines\n");
    $rfile=mysql_query("select sid, aid, title, time, comments, topic from stories order by time DESC limit 0,10");

    while(list($sid, $aid, $title, $time, $comments, $topic) = mysql_fetch_row($rfile))
    {
	$rfile2=mysql_query("select topictext, topicimage from topics where topicid=$topic");
	list($topictext, $topicimage) = mysql_fetch_row($rfile2);
	$content = "%%\n$title\n/article.php?sid=$sid\n$time\n$aid\n$topictext\n$comments\n$topicimage\n";
	fwrite($file, $content);
    }
    fclose($file);
}

/**
 * Increments the totalhits counter in the vars table by one.
 */
function counter()
{
	mysql_query("UPDATE vars SET value=value+1 where name='totalhits'");
}

/**
 * base64_decodes the given string and returns the contents as an array.
 *
 * The given parameter is decoded using base64_decode and then
 * exploded at : (colon). The resulting array is returned.
 *
 * @param string user settings cookie data
 * @return array decoded user settings
 */
function cookiedecode($user)
{
	global $cookie;
	$user = base64_decode($user);
	$cookie = explode(":", $user);

	return $cookie;
}

function getusrinfo($user)
{
	include("config.php");
	global $userinfo;

	$user2 = base64_decode($user);
	$user3 = explode(":", $user2);
	if ($user_dblocation)
	{
		@mysql_select_db("$user_dbname") or die ("Unable to select database");
		$result = mysql_query("select uid, name, uname, email, femail, url, pass, storynum, umode, uorder, thold, noscore, bio, ublockon, ublock, theme, commentmax from users where uname='$user3[1]' and pass='$user3[2]'");
		@mysql_select_db("$dbname") or die ("Unable to select database");
	}
	else
	{
		$result = mysql_query("select uid, name, uname, email, femail, url, pass, storynum, umode, uorder, thold, noscore, bio, ublockon, ublock, theme, commentmax from users where uname='$user3[1]' and pass='$user3[2]'");		
	}

	if(mysql_num_rows($result)==1)
		$userinfo = mysql_fetch_array($result);
	else
		$userinfo = "";
	return $userinfo;
}

function FixQuotes ($what = "")
{
	$what = ereg_replace("'","''",$what);
	
	while (eregi("\\\\'", $what))
	{
		$what = ereg_replace("\\\\'","'",$what);
	}
	return $what;
}

/**
 * This is an attempt to clean up the referer function.
 *
 * @param string URL to insert into referer table
 * @author: Matt McNaney
 */
function new_url($url)
{
  /**
   * The global configuration file.
   */
  include ("config.php");

  $test_home = str_replace ("http://", "", $nuke_url);
  $test_url = str_replace ("http://", "", $url);
  if (eregi("^$test_home", "$test_url") || eregi("^www.$test_home", "$test_url")){
    return;
  }
  $sql_result = mysql_query ("select ref_id from new_referer where url LIKE '$url'");
  
  // Found match
  if (mysql_num_rows($sql_result)){
    list($ref_id)=mysql_fetch_row($sql_result);
    mysql_query("update new_referer set hit_total=hit_total+1, time='" . date("Y-m-d G:i:s") . "' where ref_id=$ref_id");
  }
  
  // Did not find match
  else{
    mysql_query("insert into new_referer (url, hit_total, time) values ('$url', '1','" . date("Y-m-d G:i:s") . "')");
  }
}



/**
 * Filters bad words from the given string.
 *
 * The given string is checked for bad words found in the CensorList
 * array defined in the global configuration file. According to the
 * CensorMode setting matches are found at the beginning of words, as
 * a fragment or as exact match.
 *
 * Any bad word that was found is replaced by the CensorReplace
 * variable.
 *
 * @param string the message to be filtered.
 * @return string the censored message.
 * @todo convert to using preg_replace. check whether including config.php is necessary.
 */
function check_words($Message)
{
  global $EditedMessage, $CensorList, $CensorMode, $CensorReplace;
  /**
   * The global configuration file.
   */
  include("config.php");
	
  $EditedMessage = $Message;

  if ($CensorMode != 0){
    if (is_array($CensorList)){
      $Replacement = $CensorReplace;
      
      if ($CensorMode == 1){ 	                                 // Exact match
	$RegExPrefix   = '([^[:alpha:]]|^)';
      $RegExSuffix   = '([^[:alpha:]]|$)';
      }
      elseif ($CensorMode == 2){    				// Word beginning
	$RegExPrefix   = '([^[:alpha:]]|^)';
	$RegExSuffix   = '[[:alpha:]]*([^[:alpha:]]|$)';
      }
      elseif ($CensorMode == 3){				// Word fragment
	$RegExPrefix   = '([^[:alpha:]]*)[[:alpha:]]*';
	$RegExSuffix   = '[[:alpha:]]*([^[:alpha:]]*)';
      }

      for ($i = 0; $i < count($CensorList) && $RegExPrefix != ''; $i++)
	{
	  $EditedMessage = eregi_replace("$CensorList[$i]","$Replacement",$EditedMessage);
	}
    }
  }
  return ($EditedMessage);
}

function check_html ($str, $strip="")
{
	include("config.php");

	if ($strip == "nohtml")
	$AllowableHTML=array('');

	$str = stripslashes($str);
	$str = eregi_replace("<[[:space:]]*([^>]*)[[:space:]]*>","<\\1>",$str);
	$tmp = "";

	while (eregi("<([^> ]*)([^>]*)>",$str,$reg))
	{
		$i = strpos($str,$reg[0]);
		$l = strlen($reg[0]);

		if ($reg[1][0] == "/") $tag = strtolower(substr($reg[1],1));
		else $tag = strtolower($reg[1]);
			
		if ($a = $AllowableHTML[$tag])
		{
			if ($reg[1][0] == "/") $tag = "</$tag>";
			elseif ($a == 1) $tag = "<$tag>";
			else $tag = "<$tag " . $reg[2] . ">";
		}
		else $tag = "";
		
		$tmp .= substr($str,0,$i) . $tag;
		$str = substr($str,$i+$l);
	}
	$str = $tmp . $str;

	// Squash PHP tags unconditionally
	$str = ereg_replace("<\?","",$str);
	$str = ereg_replace("\"","",$str); 

	return $str;
}

/**
 * Performs censoring and filtering of html on the given message.
 *
 * The given string is checked for bad words using the check_words
 * function. Afterwards it is cleaned from illegal html tags using
 * check_html.
 *
 * @param string The message to be filtered.
 * @param string Whether to strip HTML or not (&quot;&quot; or &quot;nohtml&quot;).
 * @return string The filtered message.
 * @see check_html(), check_words()
 * @todo CLEAN UP!
 */
function filter_text($Message, $strip="")
{
	global $EditedMessage;

	check_words($Message);
	$EditedMessage=check_html($EditedMessage, $strip);
	$EditedMessage=check_words($EditedMessage);
	return ($EditedMessage);
}

///////////////////////////////////////////////////////////////////////
// functions for formatting stories.
///////////////////////////////////////////////////////////////////////

/**
 * Formats a given timestamp according to locale configured in global configuration file.
 *
 * @param string Timestamp YYYY-MM-DD
 * @return string Natural language representation of input.
 * @todo convert to preg_match
 */
function formatTimestamp($time)
{
  /**
   * The global configuration file.
   */
  include ("config.php");
  global $datetime;

  setlocale ("LC_TIME", "$locale");

  ereg ("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2}) ([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2})", $time, $datetime);
  $datetime = strftime("%A %d %B @ %H:%M:%S", mktime($datetime[4],$datetime[5],$datetime[6],$datetime[2],$datetime[3],$datetime[1]));
  $datetime = ucfirst($datetime);

  return($datetime);
}

function oldNews($storynum)
{
  /**
   * The global configuration file.
   */
	include ("config.php");
	$boxstuff = "";
	$boxTitle = "Past Announcements";
	$result = mysql_query("select sid, title, time, comments from stories order by time desc limit $storynum, $oldnum");
	while(list($sid, $title, $time) = mysql_fetch_row($result))
	{
		if ($title != "") {
		$doitman = "yes";
		}
	
		$count1 = "0";
		setlocale ("LC_TIME", "$locale");
		ereg ("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2}) ([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2})", $time, $datetime2);
		$datetime2 = strftime("%B %d", mktime($datetime2[4],$datetime2[5],$datetime2[6],$datetime2[2],$datetime2[3],$datetime2[1]));
		$datetime2 = ucfirst($datetime2);
		if ($datetime2 != $time2){
		  $boxstuff .= "$datetime2<br />";
		}
			$boxstuff .= "<a href=\"article.php?sid=$sid\">$title";
			$boxstuff .= "</a><br /><br />";
			$time2 = $datetime2;
                         
		}
			if ($doitman == "yes") {
				themesidebox($boxTitle, $boxstuff);
					} 
}

function rightblocks()
{
	$result = mysql_query("select title, content from rblocks");
	
	while(list($title, $content) = mysql_fetch_array($result))
	{
		$content = str_replace("\n", "<br />", $content);
		themerightbox($title, $content);
	}
}

function leftblocks()
{
	$result = mysql_query("select title, content from lblocks");
	
	while(list($title, $content) = mysql_fetch_array($result))
	{
		$content = str_replace("\n", "<br />", $content);
		themesidebox($title, $content);
	}
}

function adminblock()
{
	$result = mysql_query("select title, content from adminblock");

	while(list($title, $content) = mysql_fetch_array($result))
	{
		$content = str_replace("\n", "<br />", $content);
		themesidebox($title, $content);
	}
}

function getTopics($s_sid)
{
    global $topicname, $topicimage, $topictext;
    
    $sid = $s_sid;
    $result=mysql_query("SELECT topic FROM stories where sid=$sid");
    list($topic) = mysql_fetch_row($result);
    $result=mysql_query("SELECT topicid, topicname, topicimage, topictext FROM topics where topicid=$topic");
    list($topicid, $topicname, $topicimage, $topictext) = mysql_fetch_row($result);
}

function date_select($month, $day, $year)
{
	$select_date = "";
	if (!$month){
		$month = date(m);
		$day = date(d);
		$year = date(Y);
		$oneweek = mktime(0,0,0,$month, $day + 7, $year); 
	}else
		$oneweek = mktime(0,0,0,$month, $day, $year); 

	$select_date .= "
	<select name=\"month\">\n";
	
	for($i=1; $i<13; $i++)
	{
		$select_date .= "<option value=\"".date(m, mktime(0,0,0,$i,1))."\"";
				if (date(m, mktime (0,0,0, $i,1)) == date(m, $oneweek))
					$select_date .= " selected=\"selected\"";

				$select_date .= ">".date("F", mktime(0,0,0,$i,1))."</option>\n";
	}
	
	$select_date .= "</select>
	<select name=\"day\">
	";

	for($i=1; $i<32; $i++)
	{
		$select_date .= "<option value=\"".date(d, mktime(0,0,0,1,$i))."\"";
				if (date(j, mktime(0,0,0,1,$i)) == date(j, $oneweek))
					$select_date .= " selected=\"selected\"";

				$select_date .= ">".date("d", mktime(0,0,0,1,$i))."</option>\n";
	}
	$select_date .= "</select>
	<select name=\"year\">
	";
	
	for($i=$year, $j=$year+5; $i < $j; $i++)
	{
		$select_date .= "<option value=\"".date(Y, mktime(0,0,0,1, 1, $i))."\"";
		if (date(Y, mktime(0,0,0,1,1,$i)) == date(Y, $oneweek))
			$select_date .= " selected=\"selected\"";

		$select_date .= ">".date("Y", mktime(0,0,0,1,1,$i))."</option>\n";
	}

	$select_date .= "</select>\n";
	
	return $select_date;
}

/**
 * Allows page to ignore cache and reload page after an amount of time
 *
 * Original idea from Michael T. Babcock (mbabcock@fibrespeed.net)
 *
 */
function CacheControl() 
{
	include("config.php");
	if ($limit_cache){

		header ("Pragma: no-cache"); 
		header ("Cache-Control: no-cache, must-revalidate, max_age=0");
		header ("Expires: 0"); 
	}
}


function help($name) { 
	$name = str_replace(" ", "%20", $name);
	$return_value = "
	<script type=\"text/javascript\">
		function launch() 
		{
			open('help.php?op=search&name=$name','help','resizable=yes,scrollbars=yes,toolbar=no,location=no,directories=no,status=no,menubar=no,width=500,height=300') 
		}
	</script>
	[ <a href=\"javascript:launch()\">Help</a> ]";

	return $return_value;  
}

function strip_php($string)
{
	if(substr_count($string, "<?") || substr_count($string, "?>"))
	{
		$string = str_replace("<?", "<NOPHP", $string);
		$string = str_replace("?>", "NOPHP>", $string);
	}
	return $string;
}
?>
