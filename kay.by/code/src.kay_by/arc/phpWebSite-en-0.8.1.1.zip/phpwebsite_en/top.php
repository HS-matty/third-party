<?php

if(!isset($mainfile)) { include("mainfile.php"); }
include("open_session.php");
include("auth.inc.php");
include("header.php");
include("config.php");


if($admintest) echo "<div style=\"text-align : center\"><a href=\"admin.php\">Back to Admin Menu</a></div><br />";


$box_title = "Welcome to the top $top page for $sitename !";

// Top 10 read Announcements

$result = mysql_query("select sid, title, time, counter from stories order by counter DESC limit 0,$top");

$box_stuff = "<br /><b>$top Most read announcements</b><br /><br />";
$lugar=1;
while(list($sid, $title, $time, $counter) = mysql_fetch_row($result)) {
    if($counter>0) {
	$box_stuff .= "<span class=\"onebiggerred\">&gt;&nbsp;</span>$lugar: <a href=\"article.php?sid=$sid\">$title</a> - (read: $counter times)<br />";
	$lugar++;
    }
}
mysql_free_result($result);
$box_stuff .= "<br /><br />";

// Top 10 commented announcements

$result = mysql_query("select sid, title, comments from stories order by comments DESC limit 0,$top");

$box_stuff .= "<b>Most commented announcements</b><br /><br />";
$lugar=1;
while(list($sid, $title, $comments) = mysql_fetch_row($result)) {
    if($comments>0) {
	$box_stuff .= "<span class=\"onebiggerred\">&gt;&nbsp;</span>$lugar: <a href=\"article.php?sid=$sid\">$title</a> - (comments: $comments)<br />";
	$lugar++;
    }
}
mysql_free_result($result);
$box_stuff .= "<br /><br />";

// Top 10 users submitters

if ($user_dblocation)
{
	@mysql_select_db("$user_dbname") or die ("Unable to select database");
	$result = mysql_query("select uname, counter from users order by counter DESC limit 0,$top");
	@mysql_select_db("$dbname") or die ("Unable to select database");
}
else
{
	$result = mysql_query("select uname, counter from users order by counter DESC limit 0,$top");	
}

$box_stuff .= "<b>$top Most active news submitters</b><br /><br />";
$lugar=1;
while(list($uname, $counter) = mysql_fetch_row($result)) {
    if($counter>0) {
	$box_stuff .= "<span class=\"onebiggerred\">&gt;&nbsp;</span>$lugar: <a href=\"user.php?op=userinfo&amp;uname=$uname\">$uname</a> - (sent news: $counter)<br />";
	$lugar++;
    }
}
mysql_free_result($result);
$box_stuff .= "<br /><br />";

// Top 10 Polls
include ("./mod/poll/poll.php");

$result = mysql_query("SELECT pid, data FROM mod_poll_data");
$box_stuff .= "<b>$top Most voted polls</b><br /><br />";

if(mysql_num_rows($result) != 0)
{
	$temp = new poll;
	$count = mysql_num_rows($result);

	for($i=0; $i<$count; $i++)
	{
		list($pid, $data) = mysql_fetch_row($result);

		$pid = $pid--;
		$temp = unserialize($data);
		$pid--;
		$votes[$pid] = $temp->total_votes;
		$titles[$pid] = $temp->title;
	}

	arsort($votes);
	reset($votes);

	if($count > $top)
		$count = $top;

	$lugar = 1;
	for($i=0; $i<$count; $i++)
	{
		list($pid, $vote) = each ($votes);
		$title = $titles[$pid]; 
		$pid++;
		$box_stuff .= "<span class=\"onebiggerred\">&gt;&nbsp;</span>$lugar: 
		<a href=\"mod.php?mod=poll&amp;op=results&amp;pid=$pid\">$title</a> - (votes: $vote)<br />";
		$lugar++;
	}

	mysql_free_result($result);
}

$box_stuff .= "<br /><br />";

// Top 10 authors

$result = mysql_query("select aid, counter from authors order by counter DESC limit 0,$top");

$box_stuff .= "<b>Most active authors</b><br /><br />";
$lugar=1;
while(list($aid, $counter) = mysql_fetch_row($result)) {
    if($counter>0) {
	$box_stuff .= "<span class=\"onebiggerred\">&gt;&nbsp;</span>$lugar: <a href=\"search.php?query=&amp;author=$aid\">$aid</a> - (news published: $counter)<br />";
	$lugar++;
    }
}
mysql_free_result($result);
themesidebox($box_title, $box_stuff);
include("footer.php");
?>
