<?php
include("open_session.php");

if (!isset($mainfile)) { include("mainfile.php"); }
include("auth.inc.php");
include("header.php");
include("config.php");

$dkn = mysql_query("select type, var, count from counter order by type desc");
if (!$dkn) { echo mysql_errno(). ": ".mysql_error(). "
<br />
";	exit(); }
while(list($type, $var, $count) = mysql_fetch_row($dkn)) {
if(($type == "total") && ($var == "hits")) {
$total = $count;
} elseif($type == "browser") {
if($var == "Netscape") {
$netscape[] = $count;
$netscape[] =  substr(100 * $count / $total, 0, 5);
} elseif($var == "MSIE") {
$msie[] = $count;
$msie[] =  substr(100 * $count / $total, 0, 5);
} elseif($var == "Konqueror") {
$konqueror[] = $count;
$konqueror[] =  substr(100 * $count / $total, 0, 5);
} elseif($var == "Opera") {
$opera[] = $count;
$opera[] =  substr(100 * $count / $total, 0, 5);
} elseif($var == "Lynx") {
$lynx[] = $count;
$lynx[] =  substr(100 * $count / $total, 0, 5);
} elseif($var == "WebTV") {
$webtv[] = $count;
$webtv[] =  substr(100 * $count / $total, 0, 5);
} elseif($var == "Bot") {
$bot[] = $count;
$bot[] =  substr(100 * $count / $total, 0, 5);
} elseif(($type == "browser") && ($var == "Other")) {
$b_other[] = $count;
$b_other[] =  substr(100 * $count / $total, 0, 5);
}
} elseif($type == "os") {
if($var == "Windows") {
$windows[] = $count;
$windows[] =  substr(100 * $count / $total, 0, 5);
} elseif($var == "Mac") {
$mac[] = $count;
$mac[] =  substr(100 * $count / $total, 0, 5);
} elseif($var == "Linux") {
$linux[] = $count;
$linux[] =  substr(100 * $count / $total, 0, 5);
} elseif($var == "FreeBSD") {
$freebsd[] = $count;
$freebsd[] =  substr(100 * $count / $total, 0, 5);
} elseif($var == "SunOS") {
$sunos[] = $count;
$sunos[] =  substr(100 * $count / $total, 0, 5);
} elseif($var == "IRIX") {
$irix[] = $count;
$irix[] =  substr(100 * $count / $total, 0, 5);
} elseif($var == "BeOS") {
$beos[] = $count;
$beos[] =  substr(100 * $count / $total, 0, 5);
} elseif($var == "OS/2") {
$os2[] = $count;
$os2[] =  substr(100 * $count / $total, 0, 5);
} elseif($var == "AIX") {
$aix[] = $count;
$aix[] =  substr(100 * $count / $total, 0, 5);
} elseif(($type == "os") && ($var == "Other")) {
$os_other[] = $count;
$os_other[] =  substr(100 * $count / $total, 0, 5);
}
}
}

if($admintest) echo "<div style=\"text-align : center\"><a href=\"admin.php\">Back to Admin Menu</a></div><br />";

echo "
<!--Big mamma block start-->
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">
	<tr>
		<td class=\"type0\">
			<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
				<tr>
					<td class=\"type4\">
						We received
						<span class=\"boldtext\">
							$total
						</span>
						visitors since $startdate
					</td>
				</tr>
				<tr>
					<td class=\"type5\">
						<!--Begin OS BLOCK-->
						<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\"><tr><td>&nbsp;</td></tr>

							<tr>
								<td class=\"type4\" colspan=\"2\">
									Operating Systems
								</td>
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									Windows
								</td>
								<td class=\"type5\">
									$windows[1] % ($windows[0])
								</td>
								
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									Linux
								</td>
								<td class=\"type5\">
									$linux[1] % ($linux[0])
								</td>
								
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									Mac/PPC
								</td>
								<td class=\"type5\">
									$mac[1] % ($mac[0])
								</td>
								
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									Free BSD
								</td>
								<td class=\"type5\">
									$freebsd[1] % ($freebsd[0])
								</td>
							</tr>
							
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									Sun OS
								</td>
								<td class=\"type5\">
									$sunos[1] % ($sunos[0])
								</td>
								
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									IRIX
								</td>
								<td class=\"type5\">
									$irix[1] % ($irix[0])
								</td>
								
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									BeOS
								</td>
								<td class=\"type5\">
									$beos[1] % ($beos[0])
								</td>
								
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									OS/2
								</td>
								<td class=\"type5\">
									$os2[1] % ($os2[0])
								</td>
								
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									AIX
								</td>
								<td class=\"type5\">
									$aix[1] % ($aix[0])
								</td>
								
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									Unknown
								</td>
								<td class=\"type5\">
									$os_other[1] % ($os_other[0])
								</td>
								
							</tr><tr><td>&nbsp;</td></tr>

							<tr>
								<td class=\"type4\" colspan=\"2\">
									Browsers
								</td>
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									Internet Explorer
								</td>
								<td class=\"type5\">
									$msie[1] % ($msie[0])
								</td>
								
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									Netscape
								</td>
								<td class=\"type5\">
									$netscape[1] % ($netscape[0])
								</td>
								
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									Opera
								</td>
								<td class=\"type5\">
									$opera[1] % ($opera[0])
								</td>
								
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									WebTV
								</td>
								<td class=\"type5\">
									$webtv[1] % ($webtv[0])
								</td>
								
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									Konqueror
								</td>
								<td class=\"type5\">
									$konqueror[1] % ($konqueror[0])
								</td>
								
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									Lynx
								</td>
								<td class=\"type5\">
									$lynx[1] % ($lynx[0])
								</td>
								
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									Robots / Spyders
								</td>
								<td class=\"type5\">
									$bot[1] % ($bot[0])
								</td>
								
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									Unknown
								</td>
								<td class=\"type5\">
									$b_other[1] % ($b_other[0])
								</td>
								
							</tr>
<tr><td>&nbsp;</td></tr>

							<tr>
								
								";
								if ($user_dblocation)
								{
									@mysql_select_db("$user_dbname") or die ("Unable to select database");
									$result = mysql_query("select * from users");
									@mysql_select_db("$dbname") or die ("Unable to select database");
								}
								else
								{
									$result = mysql_query("select * from users");
								}
								$unum = mysql_num_rows($result);
								$result = mysql_query("select * from authors");
								$anum = mysql_num_rows($result);
								$result = mysql_query("select * from stories");
								$snum = mysql_num_rows($result);
								$result = mysql_query("select * from comments");
								$cnum = mysql_num_rows($result);
								$result = mysql_query("select * from queue");
								$subnum = mysql_num_rows($result);
								$result = mysql_query("select * from topics");
								$tnum = mysql_num_rows($result);
								$result = mysql_query("select * from links_links");
								$links = mysql_num_rows($result);
								$result = mysql_query("select * from links_categories");
								$cat1 = mysql_num_rows($result);
								$result = mysql_query("select * from links_subcategories");
								$cat2 = mysql_num_rows($result);
								$cat = $cat1+$cat2;
								echo "
								<!--Misc Stats-->
								<td class=\"type4\" colspan=\"2\">
									Miscelaneous Stats
								</td>
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									Registered Users:
								</td>
								<td class=\"type5\">
									$unum
								</td>
								
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									Active Authors:
								</td>
								<td class=\"type5\">
									$anum
								</td>
								
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									Stories Published:
								</td>
								<td class=\"type5\">
									$snum
								</td>
								
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									Active Topics:
								</td>
								<td class=\"type5\">
									$tnum
								</td>
								
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									Comments Posted:
								</td>
								<td class=\"type5\">
									$cnum
								</td>
								
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									Links in Web Links:
								</td>
								<td class=\"type5\">
									$links
								</td>
								
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									Categories in Web Links:
								</td>
								<td class=\"type5\">
									$cat
								</td>
								
							</tr>
							<tr>
								
								<td class=\"type5\" width=\"50%\">
									News Waiting to be Published:
								</td>
								<td class=\"type5\">
									$subnum
								</td>
								
								
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	
</table>
<!--Big mamma block end-->
";





include("footer.php");

?>
