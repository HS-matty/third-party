<?

function back_to_admin()
{
	echo "<center><b><a href=\"./admin.php\">Back to Admin Menu</a></b></center><br />";
}

?>
