<?php

/**
 * The backbone of the admin side.
 *
 * This is the backbone of the admin side. It includes all files 
 * needed for the admin functions under the "Include Files" section 
 * and all operations are function driven by "The Switch" statement at 
 * the bottom. 
 *
 * @module admin
 * @modulegroup administration
 * @package phpWebSite
 */
$temp_admin = $current_admin;

// The Include Files
include("open_session.php");

/**
 * This file is currently used for an uploading feature on the topics
 * page but will soon be replaced with different code.
 */
//require("fileupload.class");

/**
 * Contains configuration variables for phpWebSite.
 */
include("config.php");

//IF mainfile has not been included THEN include it.
if (!IsSet($mainfile)) {
  /**
   * The core function definitions
   */
  include ("mainfile.php");
}

/**
 * Used to authorize the username and password of an incoming
 * administrator.
 */
include("auth.inc.php");
/**
 * Gives all page creation and editing functions for the main page.
 */
include("mainpage.php");
/**
 * Web Links functions for search engine.
 */
include("./admin/web_links.php");
/**
 * Referrer functions to see who is linking to the site.
 */
include("./admin/referer.php");
/**
 * Functions for creating and editing topics.
 */
include("./admin/topics_admin.php");
/**
 * Functions for editing LEFT, RIGHT, and ADMIN tables/blocks.
 */
include("./admin/blocks.php");
/**
 * Functions for creating and editing news/announcments and comments.
 */
include("./admin/news.php");
/**
 * Used for editing users and administrators for the web site.
 */
include("./admin/user_admin.php");
/**
/**
 * Used for editing menu items.
 */
include("./admin/menu_edit.php");
/**
 * Banner functions for administration of banners.
 */
include("./admin/banners_admin.php");
/**
 * Used for modification of help.
 */
include("./admin/help_admin.php");

/**
 * Generates the login form.
 *
 * This function takes in the admin username and password and passes
 * them back to admin.php for verification.
 *
 * @author unknown (a phpNuke developer)
 */
function login()
{
  /**
   * Generates the page header
   */
	include ("header.php");

    $box_title = "Administrative Login";
	$box_stuff = "<form action=\"admin.php\" method=\"post\">
	AdminID&nbsp;&nbsp;
	<input type=\"text\" name=\"current_admin\" size=\"20\" maxlength=\"20\" /><br />
	Password&nbsp;&nbsp;
	<input type=\"password\" name=\"pwd\" size=\"20\" maxlength=\"18\" />
	<input type=\"hidden\" name=\"op\" value=\"login\" /><br />
	<input type=\"submit\" value=\"Login\" /></form>
	";

	themesidebox($box_title, $box_stuff);
  /**
   * Generates the page footer
   */
	include ("footer.php");
}

/**
 * Displays the admin menu or a link to the admin based on the flag param.

 * @param boolean
 * @author unknown (a phpNuke developer)
 */
function GraphicAdmin($flag)
{
	include ("config.php");
	//Only show icons on MAIN admin page. (increases readability).
	if(!$flag)
	{
		echo "<div style=\"text-align : center\"><a href=\"admin.php\">Back to Admin Menu</a></div>";
		if(!$banners) echo "<br />";
		return;
	}

	$box_title = "Administration Home";
		$box_title .= help("admin");
	$notify_version = checkversion();
	$box_stuff = "$notify_version
<table cellspacing=\"4\" cellpadding=\"2\" border=\"0\" width=\"99%\">
<tr>
	<td class=\"type5\" valign=\"top\" width=\"33%\">
	<span class=\"onebiggerred\"><b>Blocks</b></span><br />
	<a href=\"admin.php?op=main_page_data\">Edit Main Page</a><br />\n";

	if($banners)
		$box_stuff .= "
	<a href=\"admin.php?op=BannersAdmin\">Banners Administration</a><br />
		";

	$box_stuff .= "
	<a href=\"admin.php?op=edit_menu\">Edit Main Menu</a><br />
	<a href=\"admin.php?op=lblocks\">Left Blocks</a><br />
	<a href=\"admin.php?op=rblocks\">Right Blocks</a><br /><br />
	</td>
	<td class=\"type5\" valign=\"top\" width=\"33%\">
	<span class=\"onebiggerred\"><b>Content</b></span><br />
	<a href=\"admin.php?op=adminStory\">New Announcement</a><br />
	<a href=\"admin.php?op=topicsmanager\">Topics Manager</a><br />
	<a href=\"mod.php?mod=userpage&amp;op=create_userpage\">New Web Page</a><br />
	<a href=\"mod.php?mod=userpage&amp;op=list_userpages\">Edit Web Page</a><br />
	<a href=\"admin.php?op=links\">Web Links</a><br />
	<a href=\"mod.php?mod=poll&amp;op=create_poll\">Surveys/Polls</a><br />
	</td>
	<td class=\"type5\" valign=\"top\" width=\"33%\">
	<span class=\"onebiggerred\"><b>Access / Stats</b></span><br />
	<a href=\"admin.php?op=mod_users\">Edit Users</a><br />
	<a href=\"admin.php?op=mod_authors\">Edit Admins</a><br />
	<a href=\"admin.php?op=logout\">Logout / Exit</a><br />
	<a href=\"admin.php?op=hreferer\">HTTP Referrers</a><br />
	<a href=\"top.php\">Top 10</a><br />
	<a href=\"stats.php\">Client Stats</a><br /><br />
	</td>
</tr>
</table>
	";
themesidebox($box_title, $box_stuff);

//BEGIN CODE FOR MODULE ADMIN
		
	$plug_mysql = mysql_query ("select * from modules");

	if (mysql_num_rows($plug_mysql) > 0)
	{
		$count=0;
		$box_title = "Plug-Ins";
		$box_content = "
<table cellspacing=\"4\" cellpadding=\"6\" border=\"0\">
<tr>
		";
		
		while ($row = mysql_fetch_array($plug_mysql))
		{
			if ($count > 4)
			{
				$box_content .= "</tr><tr>";
				$count = 0;
			}

			extract($row);

			$temp = explode(".", $source_file);

			if($temp[0] == "mod")
			{
				if($admin_inc) $temp_url = $source_file . "&amp;op=$admin_inc";
				else $temp_url = $source_file;
			}
			else $temp_url = "./$source_file?plug_id=$plug_id&amp;op=$admin_inc";

			$box_content .= "
	<td align=\"center\" valign=\"bottom\">
	<a href=\"$temp_url\">";
	$imagehw = GetImageSize("./mod/$plug_dir/$img");
	$image_size = $imagehw[3];
	$box_content .= "<img src=\"./mod/$plug_dir/$img\" $image_size alt=\"$about\"  border=\"0\" /></a><br />$name
	</td>";
			$count++;
		}
		if (mysql_num_rows($plug_mysql) > 5){
			while ($count < 5){
				$box_content .= "<td>&nbsp;</td>";
				$count++;
			}
		}
		$box_content .= "</tr></table>";
		themesidebox($box_title, $box_content);
	}
//END CODE FOR MODULE ADMIN

}

/**
 * Checks the version and displays if an update is avalable.
 *
 * @param string Reference to result string.
 * @author Jeremy Agee
 */
function checkversion()
{
    include("config.php");
    include("version.php");

	if($check_version)
	{
		$file = @fopen("http://phpwebsite.appstate.edu/downloads/current_version.php", "r");

		if (!$file)
		{
			$notify_version = "Unable to open the version file at phpwebsite.appstate.edu.";
		}
		else
		{
			while (!feof ($file))
			{
				$line = fgets ($file, 1024);
			}
			$remote_version = split("_", $line);
			$local_version = split("_", $phpwebsite_version);

			if ($local_version[2][1] == "-"  && $local_version[2][2] == "r" && $local_version[2][3] == "c")
			{
				
				$notify_version = "You are running release candidate $local_version[0].$local_version[1].$local_version[2]<br />The current stable version is $remote_version[0].$remote_version[1].$remote_version[2]<br />";
				return $notify_version;
			}

			
			if($local_version[0] <= $remote_version[0])
			{
				$notify_version = "";
				if($local_version[1] <= $remote_version[1])
				{
					$notify_version = "";
					if($local_version[2] < $remote_version[2])
						$notify_version = "
						<table cellspacing=\"4\" cellpadding=\"2\" border=\"0\" width=\"99%\">
						<tr>
       						<td class=\"type5\" valign=\"top\" colspan=\"3\">
        					<span class=\"onebiggerred\"><b>phpWebSite Update</b></span><br />
						You are running version $local_version[0].$local_version[1].$local_version[2]<br />
						The current version is $remote_version[0].$remote_version[1].$remote_version[2]<br />
        					<a href=\"http://phpwebsite.appstate.edu/content.php?menu=1300&page_id=10\">Download update</a><br />
        					</td>
						</tr>
						</table>";
				}
				else 
					$notify_version = "
					<table cellspacing=\"4\" cellpadding=\"2\" border=\"0\" width=\"99%\">
					<tr>
       					<td class=\"type5\" valign=\"top\" colspan=\"3\">
        				<span class=\"onebiggerred\"><b>phpWebSite Update</b></span><br />
					You are running version $local_version[0].$local_version[1].$local_version[2]<br />
					The current version is $remote_version[0].$remote_version[1].$remote_version[2]<br />
        				<a href=\"http://phpwebsite.appstate.edu/content.php?menu=1300&page_id=10\">Download update</a><br />
        				</td>
					</tr>
					</table>";
			}
			else
				$notify_version = "
					<table cellspacing=\"4\" cellpadding=\"2\" border=\"0\" width=\"99%\">
					<tr>
       					<td class=\"type5\" valign=\"top\" colspan=\"3\">
        				<span class=\"onebiggerred\"><b>phpWebSite Update</b></span><br />
					You are running version $local_version[0].$local_version[1].$local_version[2]<br />
					The current version is $remote_version[0].$remote_version[1].$remote_version[2]<br />
        				<a href=\"http://phpwebsite.appstate.edu/content.php?menu=1300&page_id=10\">Download update</a><br />
        				</td>
					</tr>
					</table>";
			
			fclose($file);
		}
	}
	return $notify_version;
}

/**
 * Displays the Announcement Administration on Main Admin Page.
 *
 * @author unknown (a phpNuke developer)
*/
function adminMain()
{
	global $admintest;
	include ("header.php");

	GraphicAdmin(1);
	
	$box_title = "Announcement Administration";
	$dummy = 0;
	$result = mysql_query("SELECT qid, subject, timestamp FROM queue order by timestamp");
	
	if(mysql_num_rows($result) < 1)
	$box_stuff = "<span class=\"onebiggerred\">&gt;</span>&nbsp;&nbsp;No New Submissions<br />";
	else
	{
		$box_stuff = "<span class=\"onebiggerred\">New Submissions!</span><br /><br />
<table cellspacing=\"1\" cellpadding=\"1\" border=\"0\" width=\"99%\">
		";

		while (list($qid, $subject, $timestamp) = mysql_fetch_row($result))
		{
			$subject = stripslashes($subject);
			$hour = "AM";
			ereg ("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2}) ([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2})", $timestamp, $datetime);
			
			if ($datetime[4] > 12)
			$datetime[4] = $datetime[4]-12; $hour = "PM";

			$datetime = date("%A, %B %d @ %T %Z", mktime($datetime[4],$datetime[5],$datetime[6],$datetime[2],$datetime[3],$datetime[1]));
			$box_stuff .= "
<tr>
	<td class=\"type5\"><b>$subject</b></td>
	<td class=\"type5\">$timestamp</td><td class=\"type5\" align=\"right\">
	<a href=\"admin.php?op=DisplayStory&amp;qid=$qid\">Read More...</a> | 
	<a href=\"admin.php?op=DeleteStory&amp;qid=$qid\">Delete</a></td>
</tr>
			";
		}
	}

	if(mysql_num_rows($result))
	$box_stuff .= "</table>";

	themesidebox($box_title, $box_stuff);
	mysql_free_result($result);

	$box_title = "$admart Last Announcements";
	$box_stuff = "<table cellspacing=\"1\" cellpadding=\"1\" border=\"0\" width=\"99%\">";

	$result=mysql_query("select sid, title, time, topic, informant, exp_date from stories order by time desc limit 0,$admart");

	if (mysql_num_rows($result) < 1)
	$box_stuff = "None Found";
	else
	{
		while(list($sid, $title, $time, $topic, $informant, $exp_date) = mysql_fetch_row($result))
		{
			$title = stripslashes($title);
			$ta = mysql_query("select topictext from topics where topicid='$topic'");
			list($topictext) = mysql_fetch_row($ta);
			
			if($exp_date == '2099-12-31 23:59:59') $exp_date = 'No Expiration';
			else $exp_date = substr($exp_date,0,10);

			formatTimestamp($time);
		
			$box_stuff .= "
<tr>
	<td class=\"type5\"><b>$title</b></td>
	<td class=\"type5\">$topictext</td>
	<td class=\"type5\">$exp_date</td>
	<td class=\"type5\" align=\"right\">
	<a href=\"admin.php?op=EditStory&amp;sid=$sid\">Edit</a> |
	<a href=\"admin.php?op=RemoveStory&amp;sid=$sid\">Delete</a>
	</td>
</tr>
			";
		}
	}

	if (mysql_num_rows ($result))
	$box_stuff .= "</table>";

	themesidebox($box_title, $box_stuff);
	mysql_free_result($result);

	include ("footer.php");
}

/**
 *  Function: The SWITCH (not REALLY a function)
 *  Author:   Started by phpNuke developers and edited by anyone who
 *            touched the admin side.
 *  Purpose:  This switch statement takes the arguement $op passed to the
 *            admin page and decides which functions to call based on
 *            that variable.
 */
//The session variable admintest is used to make sure an administrator has logged in. If NOT then it calls
//the login() function at the bottom of this switch statement.
if ($admintest == $security_hash)
{
	switch($op)
	{
		case "main_page_data":
		main_page_data();
		break;
      
		case "submit_main_page":
		test_data(1, $main_title, $main_text, $main_image, $main_alt);
		$main_alt = htmlentities($main_alt);
		if($main_image == "none" && $old_main_image)
		update_main_page($main_title, $main_text, $main_image, $main_alt, $old_main_image, $main_image_active, 'image/gif', '1', $active);
		else
		update_main_page($main_title, $main_text, $main_image, $main_alt, $main_image_name, $main_image_active, $main_image_type, $main_image_size, $active);
		save_new_page();
		break;
      
		case "update_page_menu":
		update_page_menu($menu_id, $menu_text);
		menu_saved();
		break;
      
		case "new_menu_item_post":
		$menu_id = menu_post($title, 'content.php');
		mysql_query("update menu set page_id='$page_id' where menu_id='$menu_id'");
		get_menu_text($menu_id);
		break;
    
		case "page_menu_post":
		page_menu_post($page_id);
		break;
      
		case "sub_page_menu_post":
		sub_page_menu_post($low_sub, $page_id);
		break;
      
		case "update_link_text":
		update_link_text($menu_id, $link);
		save_new_page();
		break;

		case "links":
		links();
		break;
      
		case "LinksDelNew":
		LinksDelNew($lid);
		break;
      
		case "LinksAddCat":
		LinksAddCat($title);
		break;
      
		case "LinksAddSubCat":
		LinksAddSubCat($cid, $title);
		break;
      
		case "LinksAddLink":
		LinksAddLink($new, $lid, $title, $url, $cat, $description, $name, $email);
		break;
      
		case "LinksDelCat":
		LinksDelCat($cid, $sid, $sub, $ok);
		break;
      
		case "LinksModCat":
		LinksModCat($cat);
		break;
      
		case "LinksModCatS":
		LinksModCatS($cid, $sid, $sub, $title);
		break;
      
		case "LinksModLink":
		LinksModLink($lid);
		break;
      
		case "LinksModLinkS":
		LinksModLinkS($lid, $title, $url, $description, $name, $email, $hits, $cat);
		break;
      
		case "LinksDelLink":
		LinksDelLink($lid);
		break;

		case "BannersAdmin":
		BannersAdmin();
		break;
      
		case "BannersAdd":
		BannersAdd($name, $cid, $imptotal, $imageurl, $clickurl);
		break;
      
		case "BannerAddClient":
		BannerAddClient($name, $contact, $email, $login, $passwd, $extrainfo);
		break;
     
		case "BannerFinishDelete":
		BannerFinishDelete($bid);
		break;
      
		case "BannerDelete":
		BannerDelete($bid, $ok);
		break;
      
		case "BannerEdit":
		BannerEdit($bid);
		break;
      
		case "BannerChange":
		BannerChange($bid, $cid, $imptotal, $impadded, $imageurl, $clickurl);
		break;
      
		case "BannerClientDelete":
		BannerClientDelete($cid, $ok);
		break;
      
		case "BannerClientEdit":
		BannerClientEdit($cid);
		break;
      
		case "BannerClientChange":
		BannerClientChange($cid, $name, $contact, $email, $extrainfo, $login, $passwd);
		break;

		case "GraphicsAdmin":
		GraphicAdmin();
		break;

		case "hreferer":
		hreferer($sortby, $filter);
		break;
      
		case "delreferer":
		delreferer($action);
		break;
      
		case "adminMain":
		adminMain();
		break;
      
		case "topicsmanager":
		topicsmanager();
		break;
      
		case "topicedit":
		topicedit($topicid);
		break;
      
		case "topicmake":
		topicmake($topicparent, $topicname, $topicimage, $topictext, $topiclongtext, $topicimage_name, $topicimage_type, $topicimage_size); 
		topicsmanager();
		break;
      
		case "topicdelete":
		topicdelete($topicid, $ok);
		break;
      
		case "topicchange":
		if($save)
		{
		    if($topicimage == 'none'){
		        if($blank_image==1)
		            topicchange($topicid, $topicparent, $topicname, $topicimage, $topictext, $topiclongtext, 'bl.gif', 'image/gif', 1, 0);
		        else
		            topicchange($topicid, $topicparent, $topicname, $topicimage, $topictext, $topiclongtext, $old_topicimage, 'image/gif', 1, 0);
		    }
		    else
		        topicchange($topicid, $topicparent, $topicname, $topicimage, $topictext, $topiclongtext, $topicimage_name, $topicimage_type, $topicimage_size, 1);
		}
		else if($delete)
		topicdelete($topicid, $ok);
		topicsmanager();
		break;
      
		case "sections":
		sections();
		break;
      
		case "sectionedit":
		sectionedit($secid);
		break;
      
		case "sectionmake":
		sectionmake($secname, $image);
		break;
      
		case "sectiondelete":
		sectiondelete($secid, $ok);
		break;
      
		case "sectionchange":
		sectionchange($secid, $secname, $image);
		break;
      
		case "secarticleadd":
		secarticleadd($secid, $title, $content);
		break;
      
		case "secartedit":
		secartedit($artid);
		break;
      
		case "secartchange":
		secartchange($artid, $secid, $title, $content);
		break;
      
		case "secartdelete":
		secartdelete($artid, $ok);
		break;
      
		case "blocks":
		blocks();
		break;
      
		case "makeblock":
		makeblock($title, $content);
		break;
      
		case "deleteblock":
		deleteblock($id);
		break;
    
		case "changeblock":
		changeblock($id, $title, $content);
		break;

		case "rblocks":
		rblocks();
		break;
      
		case "makerblock":
		makerblock($title, $content);
		break;
      
		case "deleterblock":
		deleterblock($id, $order_id);
		break;
      
		case "changerblock":
		changerblock($id, $title, $content);
		break;

		case "rblock_order":
		rblock_order($id, $action);
		break;

		case "lblocks":
		lblocks();
		break;
      
		case "makelblock":
		makelblock($title, $content);
		break;
      
		case "deletelblock":
		deletelblock($id, $order_id);
		break;
      
		case "changelblock":
		changelblock($id, $title, $content);
		break;

		case "lblock_order":
		lblock_order($id, $action);
		break;

		case "ablock":
		ablock();
		break;
      
		case "changeablock":
		changeablock($title, $content);
		break;
      
		case "DisplayStory":
		displayStory($qid);
		break;
      
		case "PreviewAgain":
		previewStory($qid, $uid, $author, $subject, $hometext, $bodytext, $topic, $month, $day, $year, $allow_expire);
		break;
      
		case "PostStory":
		postStory($qid, $uid, $author, $subject, $hometext, $bodytext, $topic, $notes, $month, $day, $year, $allow_expire);
		break;
      
		case "EditStory":
		editStory($sid);
		break;
      
		case "RemoveStory":
		removeStory($sid, $ok);
		break;
      
		case "RemoveComment":
		removeComment($tid, $sid);
		break;
      
		case "RemovePollComment":
		RemovePollComment($tid, $pollID);
		break;
      
		case "ChangeStory":
		changeStory($sid, $subject, $hometext, $bodytext, $topic, $notes, $month, $day, $year, $allow_expire, $informant);
		break;
      
		case "DeleteStory":
		deleteStory($qid);
		break;

		case "adminStory":
		adminStory($sid);
		break;
      
		case "PreviewAdminStory":
		previewAdminStory($subject, $hometext, $bodytext, $topic, $month, $day, $year, $allow_expire);
		break;
      
		case "PostAdminStory":
		postAdminStory($subject, $hometext, $bodytext, $topic, $month, $day, $year, $allow_expire);
		break;
      
		case "mod_authors":
		displayadmins();
		break;
      
		case "modifyadmin":
		modifyadmin($chng_aid);
		break;
      
		case "UpdateAuthor":
		updateadmin($chng_aid, $chng_name, $chng_email, $chng_url, $chng_pwd, $chng_pwd2);
		break;
      
		case "AddAuthor":
		if (!($add_aid && $add_name && $add_email && $add_pwd))
		{
			echo "You must complete all compulsory fields";
			return;
		}

		$crypt_pass = md5($add_pwd);
		$result = mysql_query("insert into authors values ('$add_aid','$add_name','$add_url','$add_email','$crypt_pass','0')");
      
		if (!$result)
		{
			echo mysql_errno(). ": ".mysql_error(). "<br />";
			return;
		}
		Header("Location: admin.php?op=adminMain");
		break;
      
		case "deladmin":
		include("header.php");
		$box_title = "<span class=\"type4bigger\">Delete Author</span>";
		$box_stuff = "Are you sure you want to delete $del_aid?<br />";
		$box_stuff .= "[ <a href=\"admin.php?op=deladminconf&amp;del_aid=$del_aid\">Yes</a>&nbsp;|&nbsp;<a href=\"admin.php?op=mod_authors\">No</a> ]";
		themesidebox($box_title, $box_stuff);
		include("footer.php");
		break;
    
		case "deladminconf":
		mysql_query("delete from authors where aid='$del_aid'");
		header("location:./admin.php?op=adminMain");
		echo mysql_error();
		break;
      
		case "mod_users":
		displayUsers();
		break;
      
		case "modifyUser":
		modifyUser($chng_uid);
		break;
      
		case "updateUser":
		updateUser($chng_uid, $chng_uname, $chng_name, $chng_url, $chng_email, $chng_femail, $chng_pass, $chng_pass2);
		break;
      
		case "delUser":
		include("header.php");
		$box_title = "<span class=\"type4bigger\">Delete User</span>";
		$box_stuff = "Are you sure you want to delete user $chng_uid?<br />";
		$box_stuff .= "[ <a href=\"admin.php?op=delUserConf&amp;del_uid=$chng_uid\">Yes</a> | <a href=\"admin.php?op=mod_users\">No</a> ]";
		themesidebox($box_title, $box_stuff);
		include("footer.php");
		break;
      
		case "delUserConf":
		if ($user_dblocation)
		{
			@mysql_select_db("$user_dbname") or die ("Unable to select database");
			mysql_query("delete from users where uid='$del_uid' or uname='$del_uid'");
			@mysql_select_db("$dbname") or die ("Unable to select database");
		}
		else
		{
			mysql_query("delete from users where uid='$del_uid' or uname='$del_uid'");		
		}
		Header("Location: admin.php?op=adminMain");
		echo mysql_error();
		break;
      
		case "addUser":
		$add_pwd = crypt($add_pass);
		$add_pwd = crypt($add_pass, substr($add_pwd,0,2));

		if (!($add_uname && $add_email && $add_pass))
		{
			echo "You must complete all compulsory fields";
			return;
		}

		$sql = "insert into users ";
		$sql .= "(name,uname,email,femail,url,pass) ";
		$sql .= "values ('$add_name','$add_uname','$add_email','$add_femail','$add_url','$add_pwd')";
		if ($user_dblocation)
		{
			@mysql_select_db("$user_dbname") or die ("Unable to select database");
			$result = mysql_query($sql);
			@mysql_select_db("$dbname") or die ("Unable to select database");
		}
		else
		{
			$result = mysql_query($sql);		
		}

		if (!$result)
		{
			echo mysql_errno(). ": ".mysql_error(). "<br />";
			return;
		}
		Header("Location: admin.php?op=mod_users");
		break;
      
		case "create":
		poll_createPoll($flip);
		break;
      
		case "createPosted":
		mysql_query("update flags set poll='1'");
		poll_createPosted();
		break;

		case "poll_active":
		if($active == 1)
		 mysql_query("update flags set poll='1'");
		else
		 mysql_query("update flags set poll='0'");
		poll_createPoll();
		break;
            
		case "poll_editPoll":
		poll_editPoll($pollID);
		break;
      
		case "ChangePoll":
		ChangePoll($pollID, $pollTitle, $optionText, $optionCount, $voteID);
		break;
      
		case "remove":
		poll_removePoll();
		break;
      
		case "removePosted":
		poll_removePosted();
		break;
      
		case "view": 
		poll_viewPoll();
		break;
      
		case "viewPosted":
		poll_viewPosted();
		break;
      
		case "logout":
		$admintest = "";
		$current_admin="";
		session_unregister("admintest");
		session_unregister("current_admin");
		$titlebar = "Logged out";
		include("header.php");
		themesidebox("You are now logged out", "<br /><a href=\"index.php\">Click here to go back to the main page</a>");
		include("footer.php");
		break;
      
      
		case "edit_menu":
		edit_menu();
		break;
      
		case "add_main_menu":
		add_main_menu();
		break;
      
		case "menu_post":
		menu_post($menu_text, $menu_url);
		edit_menu();
		break;
      
      
		case "add_sub_menu":
		add_sub_menu();
		break;
      
		case "sub_menu_post":
		sub_menu_post($low_sub, $menu_text, $menu_url);
		edit_menu();
		break;      

		case "menu_prompt_delete":
		menu_prompt_delete();
		break;
      
		case "menu_delete":
		menu_delete($menu_id);
		edit_menu();
		break;
      
		case "menu_active":
		menu_active($menu_id, $menu_active);
		edit_menu();
		break;
      
		case "edit_menu_item":
		edit_menu_item($menu_id);
		break;
      
		case "update_menu_item":
		update_menu_item($menu_id, $menu_text, $menu_url);
		edit_menu();
		break;

		case "order_menu":
		order_menu($menu_id);
		break;

		case "update_menu_order":
		update_menu_order($menu_id, $menu_order, $move);
		order_menu($menu_id);
		break;
      
		case "menu_error":
		menu_error();
		break;      

		default:
		adminMain();
		break;
	}
}
//IF NOT ADMIN FORCE USER TO LOG IN.
else
login();

?>
