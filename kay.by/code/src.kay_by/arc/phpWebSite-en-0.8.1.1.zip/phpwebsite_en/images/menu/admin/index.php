<?php
include("../../../config.php");
header("Location:$nuke_url");
?>
