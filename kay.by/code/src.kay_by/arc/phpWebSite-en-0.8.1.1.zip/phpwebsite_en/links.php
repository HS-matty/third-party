<?php
/**
 * Core file for the Web Links part.
 *
 * @module links
 * @modulegroup content_handling
 * @package phpWebSite
 */
include("open_session.php");

if (!isset($mainfile)) 
{
  /**
   * Defines core functions.
   */
  include("mainfile.php");
}

/**
 * Global configuration file.
 */
include("config.php");

function headblock()
{
	echo "<!--INDIVIDUAL BLOCKS-->
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">
<tr>
	<td class=\"type0\">
<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
<tr>
	<td class=\"type4\">Web Links</td>
</tr>
<tr>
	<td class=\"type5\">
	";
}

function tailblock()
{
	SearchForm();

	echo "<br />";

	$mainlink = 69;
	menu($mainlink);
	
	echo "</td></tr></table></td></tr></table>";
	include("footer.php");
}

function menu($mainlink)
{
	echo "<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
	<tr>";

	if ($mainlink>0) echo "<td class=\"type4\" colspan=\"4\">Navigation</td>\n";
	else echo "<td class=\"type4\" colspan=\"3\">Navigation</td>\n";

	echo "</tr>
	<tr>"; 

	if ($mainlink>0)
		echo "<td class=\"type5\"><a href=\"links.php\">Links Main</a></td>";
	
 	echo "
	<td class=\"type5\"><a href=\"links.php?op=AddLink\">Add Link</a></td>
	<td class=\"type5\"><a href=\"links.php?op=NewLinks\">New Links</a></td>
	<td class=\"type5\"><a href=\"links.php?op=TheBest\">The Best</a></td>
	</tr>
	</table>";
}

function SearchForm()
{
	echo "
<form action=\"links.php?op=search&amp;query=$query\" method=\"post\">
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">
<tr>
	<td class=\"type5\">
	<input type=\"text\" size=\"30\" maxlength=\"200\" name=\"query\" />
	<input type=\"submit\" value=\"Search\" /><br />
	";

	$result=mysql_query("select * from links_links");
	$numrows = mysql_num_rows($result);

	echo "There are $numrows Links in our Database";
	echo "
	</td>
</tr>
</table>
</form>
	";
}

function index()
{
	include("header.php");

	echo "
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">
<tr>
	<td class=\"type0\">
<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
<tr>
	<td class=\"type4\" colspan=\"3\">Web Links" . 
help("Web Links") . "</td>
</tr>
<tr>
	";

	$result=mysql_query("select cid, title from links_categories order by title");
	$count = 0;

	while(list($cid, $title) = mysql_fetch_row($result))
	{
		if ($count == "3")
		{
			echo "
</tr>
<tr>";
			$count = 0;
		}

		$result2 = mysql_query("select sid, title from links_subcategories where cid=$cid order by title");

		echo "
	<td class=\"type5\" valign=\"top\" width=\"33%\">
	<a href=\"links.php?op=viewlink&amp;cid=$cid\">$title</a><br />";

		while(list($sid, $stitle) = mysql_fetch_row($result2))
		echo "
	<b>&gt;</b>&nbsp;<a href=\"links.php?op=viewslink&amp;sid=$sid\">$stitle</a><br />";

		echo "
	</td>";
		$count++;
	}

	while($count < 3)
	{
		echo "
	<td class=\"type5\" valign=\"top\" width=\"33%\">&nbsp;</td>";
		$count++;
	}
	
	$result=mysql_query("select * from links_links");
	$numrows = mysql_num_rows($result);
	
	echo "
</tr></table>
</td></tr></table>
<br />
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">
<tr>
	<td class=\"type0\">
<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
<tr>
	<td class=\"type4\" colspan=\"3\">Search Web Links</td>
</tr>
<tr>
<td class=\"type5\" colspan=\"3\"><br />
";

	SearchForm();
	echo "</td></tr></table>";

	echo "</td></tr></table><br />";
	$mainlink = 0;
	menu($mainlink);
	include("footer.php");
}


function AddLink() {
    include("header.php");
echo"<!--INDIVIDUAL BLOCKS-->
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">
<tr>
	<td class=\"type0\">
		<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
			<tr>
				<td class=\"type4\">
				Add Link
				</td>
			</tr>
			<tr>
				<td class=\"type5\"><form method=\"post\" action=\"links.php?op=Add\">
    Page Title: <input type=\"text\" name=\"title\" size=\"50\" maxlength=\"100\" /><br />
    Page URL: <input type=\"text\" name=\"url\" size=\"50\" maxlength=\"100\" value=\"http://\" /><br />
    Description: (255 characters max) <br /><textarea name=\"description\" cols=\"60\" rows=\"5\" wrap=\"virtual\"></textarea><br /><br />
    Your Name: <input type=\"text\" name=\"name\" size=\"30\" maxlength=\"60\" /><br />
    Your Email: <input type=\"text\" name=\"email\" size=\"30\" maxlength=\"60\" /><br />
    <input type=\"hidden\" name=\"op\" value=\"Add\" />
    <center><input type=\"submit\" value=\"Submit\" /></center><br /><br />
    </form></td></tr></table></td></tr></table><br />";
    $mainlink = 1;
    menu($mainlink);
    include("footer.php");
}

function Add($title, $url, $name, $cat, $description, $name, $email)
{
	$result = mysql_query("select url from links_links where url='$url'");
	$numrows = mysql_num_rows($result);

	if ($numrows > 0)
	{
		include("header.php");
		headblock();
		echo "<span class=\"onebiggerred\">ERROR: This URL is already listed in the Database!</span><br />";
		tailblock();
		exit();
	}
	else
	{
		// Check if Title exist
		if ($title=="")
		{
			include("header.php");
			headblock();
			echo "<span class=\"onebiggerred\">ERROR: Add Failed. Please enter a title.</span><br />";
			tailblock();
			exit();
		}

		// Check if URL exist
		if ($url==""|| $url=="http://")
		{
			include("header.php");
			headblock();
			echo "<span class=\"onebiggerred\">ERROR: Add Failed. Please enter a URL.</span><br />";
			tailblock();
			exit();
		}

		// Check if Description exist
		if ($description=="")
		{
			include("header.php");
			headblock();
			echo "<span class=\"onebiggerred\">ERROR: Add Failed. Please enter a description</span><br />";
			tailblock();
			exit();
		}

		$cat = explode("-", $cat);
		if ($cat[1]=="") $cat[1] = 0;

		$title = stripslashes(FixQuotes($title));
		$url = stripslashes(FixQuotes($url));
		$description = stripslashes(FixQuotes($description));
		$name = stripslashes(FixQuotes($name));
		$email = stripslashes(FixQuotes($email));

		mysql_query("insert into links_newlink values (NULL, '$cat[0]', '$cat[1]', '$title', '$url', '$description', '$name', '$email')");

		include("header.php");
		headblock();
		echo "<h3>We received your Link submission. Thanks!<br />
		You'll receive an E-mail when it's approved.</h3><br /><br />";
		tailblock();
	}
}

function NewLinks() {
    global $admintest;
    include("header.php");
    include("config.php");
      echo "<!--INDIVIDUAL BLOCKS-->
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">
<tr>
	<td class=\"type0\">
		<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
			<tr>
				<td class=\"type4\">
				$newlinks Last Links Added to Database
				</td>
			</tr>
			<tr>
				<td class=\"type5\">";

    $result=mysql_query("select lid, cid, sid, title, description, date, hits from links_links order by date DESC limit 0,$newlinks");
    while(list($lid, $cid, $sid, $title, $description, $time, $hits)=mysql_fetch_row($result)) {

	if ($admintest) {
	    echo"<a href=\"links.php?op=visit&amp;lid=$lid\" target=\"blank\">$title</a>&nbsp;";
    	    echo "[ <a href=\"admin.php?op=LinksModLink&amp;lid=$lid\">Edit</a> ]<br />";
	} else {
	    echo "<a href=\"links.php?op=visit&amp;lid=$lid\" target=\"blank\">$title</a><br />";
	}

	echo "<span class=\"searchprops\">Description: </span>$description<br />";
	
	setlocale ("LC_TIME", "$locale");
	ereg ("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2}) ([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2})", $time, $datetime);
	$datetime = strftime("%d-%b-%Y", mktime($datetime[4],$datetime[5],$datetime[6],$datetime[2],$datetime[3],$datetime[1]));
	$datetime = ucfirst($datetime);
	
	echo "<span class=\"searchprops\">Added on: </span>$datetime Hits: $hits<br />";
	$result2=mysql_query("select title from links_categories where cid=$cid");
	list($ctitle) = mysql_fetch_row($result2);
	echo "<span class=\"searchprops\">Category: </span>$ctitle";
	$result3=mysql_query("select title from links_subcategories where sid=$sid");
	while(list($stitle) = mysql_fetch_row($result3)) {
	    echo " / $stitle";
	}
	echo "<br /><br />";
    }
    echo "</td></tr></table>";    

    echo "</td></tr></table><br />";
	$mainlink = 1;
    menu($mainlink);


    
    include("footer.php");
}

function TheBest() {
    global $admintest;
    include("header.php");
    include("config.php");
echo "<!--INDIVIDUAL BLOCKS-->
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">
<tr>
	<td class=\"type0\">
		<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
			<tr>
				<td class=\"type4\">
				 $toplinks Most Visited Links
				</td>
			</tr>
			<tr>
				<td class=\"type5\">";
    $result=mysql_query("select lid, cid, sid, title, description, date, hits from links_links order by hits DESC limit 0,$toplinks");
    while(list($lid, $cid, $sid, $title, $description, $time, $hits)=mysql_fetch_row($result)) {
	if ($hits>0) {

	if ($admintest) {
	    echo"<a href=\"links.php?op=visit&amp;lid=$lid\" target=\"blank\">$title</a>&nbsp;";
	    echo "[ <a href=\"admin.php?op=LinksModLink&amp;lid=$lid\">Edit</a> ]<br />";
	} else {
	    echo "<a href=\"links.php?op=visit&amp;lid=$lid\" target=\"blank\">$title</a><br />";
	}
	
	echo "<span class=\"searchprops\">Description: </span>$description<br />";
	
	setlocale ("LC_TIME", "$locale");
	ereg ("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2}) ([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2})", $time, $datetime);
	$datetime = strftime("%d-%b-%Y", mktime($datetime[4],$datetime[5],$datetime[6],$datetime[2],$datetime[3],$datetime[1]));
	$datetime = ucfirst($datetime);
	
	echo "<span class=\"searchprops\">Added on: </span>$datetime Hits: $hits<br />";
	$result2=mysql_query("select title from links_categories where cid=$cid");
	list($ctitle) = mysql_fetch_row($result2);
	echo "<span class=\"searchprops\">Category: </span>$ctitle";
	$result3=mysql_query("select title from links_subcategories where sid=$sid");
	while(list($stitle) = mysql_fetch_row($result3)) {
	    echo " / $stitle";
	}
	echo "<br /><br />";
    }
    }
    echo "</td></tr></table>";
    echo "</td></tr></table><br />";	
$mainlink = 1;
    menu($mainlink);
    include("footer.php");
}

function viewlink($cid, $min) 
{
	include("config.php");
	include("header.php");
	global $admintest;

	if (!isset($min)) $min=0;
	if (!isset($max)) $max=$min+$perpage;
	$countcat = 0;
	$countsub = 0;
	echo "<!--INDIVIDUAL BLOCKS-->
	
	<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
	<tr>
		<td class=\"type4\">Web Links</td>
	</tr>
	<tr>
		<td align=\"center\" class=\"type4small\">";
		$result=mysql_query("select title from links_categories where cid=$cid");
    		list($title) = mysql_fetch_row($result);
	        echo "<!--INDIVIDUAL BLOCKS-->
		<a href=\"links.php\">Main</a>
		/ <a href=\"links.php?op=viewlink&amp;cid=$cid\">$title</a></td>
	</tr>	
	<tr>
		<td class=\"type5\">";
		$result=mysql_query("select lid, title, description, date, hits from links_links where cid=$cid 
		AND sid=0 limit $min,$perpage");
		$x=0;
		while(list($lid, $title, $description, $time, $hits)=mysql_fetch_row($result)) 
		{
			if ($admintest) 
			{
				echo"<a href=\"links.php?op=visit&amp;lid=$lid\" target=\"blank\">$title</a>&nbsp;
    	    			[ <a href=\"admin.php?op=LinksModLink&amp;lid=$lid\">Edit</a> ]<br />";
			} 
			else 
			    echo "<a href=\"links.php?op=visit&amp;lid=$lid\" target=\"blank\">$title</a><br />";

			echo "<span class=\"searchprops\">Description: </span>$description<br />";
			setlocale ("LC_TIME", "$locale");
			ereg ("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2}) ([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2})", $time, $datetime);
			$datetime = strftime("%d-%b-%Y", mktime($datetime[4],$datetime[5],$datetime[6],$datetime[2],$datetime[3],$datetime[1]));
			$datetime = ucfirst($datetime);
			echo "<span class=\"searchprops\">Added on: </span>$datetime Hits: $hits<br /><br />";
			$x++;
		}
		echo "<br />
	</td></tr></table>";
    		
	echo "<!--INDIVIDUAL BLOCKS-->
	<table border=\"0\" cellspacing=\"1\" cellpadding=\"3\" width=\"100%\">	
	<tr>
		<td class=\"type4\">Sub-Categories</td>
	</tr>
	<tr>
		<td class=\"type5\">";
    	$result=mysql_query("select sid, title from links_subcategories where cid=$cid");
    	while(list($sid, $title) = mysql_fetch_row($result)) 
	{
		$countsub++;
		$result2 = mysql_query("select * from links_links where sid=$sid");
		$numrows = Mysql_num_rows($result2);
		if ($numrows > 0) 
			echo "<a href=\"links.php?op=viewslink&amp;sid=$sid\">$title</a> ($numrows) <br />";
		else 
			echo "$title<br />"; 
    	}

	if ($countsub == "") 
		echo "No Sub-Categories Available";
	echo "</td></tr></table><br />";

	$prev=$min-$perpage;
	if ($prev>=0) 
	{
		print "<a href=\"links.php?op=viewlink&amp;cid=$cid&amp;min=$prev\">";
		print "<br /><br />Previous Page</a>";
    	}

	$next=$min+$perpage;
	if ($x>=$perpage) 
	{
		print "<a href=\"links.php?op=viewlink&amp;cid=$cid&amp;min=$max\">";
		print "<br /><br />Next Page</a>";
	}
	
	$mainlink = 1;
	menu($mainlink);
	include("footer.php");
}


function viewslink($sid, $min) {
    global $admintest;
    include("header.php");
    include("config.php");
    if (!isset($min)) $min=0;
    if (!isset($max)) $max=$min+$perpage;
    headblock();
    $result = mysql_query("select cid, title from links_subcategories where sid=$sid");
    list($cid, $stitle) = mysql_fetch_row($result);
    
    $result2 = mysql_query("select cid, title from links_categories where cid=$cid");
    list($cid, $title) = mysql_fetch_row($result2);

    echo "<!--INDIVIDUAL BLOCKS-->
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">
<tr>
	<td class=\"type0\">
		<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
			<tr>
				<td align=\"center\" class=\"type4small\"><a href=\"links.php\">Main</a>
	 / <a href=\"links.php?op=viewlink&amp;cid=$cid\">$title</a> / $stitle
				</td>
			</tr>
			<tr>
				<td class=\"type5\">";

    $result=mysql_query("select lid, url, title, description, date, hits from links_links where sid=$sid limit $min,$perpage");
    $x=0;
    while(list($lid, $url, $title, $description, $time, $hits)=mysql_fetch_row($result)) {
		if ($admintest) {
	    echo"<a href=\"links.php?op=visit&amp;lid=$lid\" target=\"blank\">$title</a>&nbsp;";
    	    echo "[ <a href=\"admin.php?op=LinksModLink&amp;lid=$lid\">Edit</a> ]<br />";
	} else {
	    echo "<a href=\"links.php?op=visit&amp;lid=$lid\" target=\"blank\">$title</a><br />";
	}
	echo "<span class=\"searchprops\">Description: </span>$description<br />";
	setlocale ("LC_TIME", "$locale");
	ereg ("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2}) ([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2})", $time, $datetime);
	$datetime = strftime("%d-%b-%Y", mktime($datetime[4],$datetime[5],$datetime[6],$datetime[2],$datetime[3],$datetime[1]));
	$datetime = ucfirst($datetime);
	echo "<span class=\"searchprops\">Added on: </span>$datetime Hits: $hits<br /><br />";
	$x++;
    }
	if ($x == "") {
	echo "No Links Available<br /><br /><br /><br /><br /><br /><br />";
}
    echo "</td></tr></table>";
    
    $prev=$min-$perpage;
    if ($prev>=0) {
	print "<a href=\"links.php?op=viewslink&amp;sid=$sid&amp;min=$prev\">";
	print "<br /><br /><center>Previous Page</center></a>";
    }

    $next=$min+$perpage;
    if ($x>=$perpage) {
	print "<a href=\"links.php?op=viewslink&amp;sid=$sid&amp;min=$max\">";
	print "<br /><br /><center>Next Page</center></a>";
    }

    echo "\n</td></tr></table></td></tr></table>\n";
    echo "</td></tr></table><br />\n";

    $mainlink = 1;
    menu($mainlink);
    include("footer.php");
}

function visit($lid) {
    dbconnect();
    mysql_query("update links_links set hits=hits+1 where lid=$lid");
    $result = mysql_query("select url from links_links where lid=$lid");
    list($url) = mysql_fetch_row($result);
    Header("Location: $url");
}

function search($query, $min) {

    include("config.php");
    global $admintest;
    if (!isset($min)) $min=0;
    if (!isset($max)) $max=$min+$linksresults;

	if (strlen($query) > 0) {
		$query = stripslashes($query);
		$result = mysql_query("select lid, cid, sid, title, url, description, date, hits from links_links where title LIKE '%$query%' OR description LIKE '%$query%' ORDER BY title DESC LIMIT $min,$linksresults");
	$nrows  = mysql_num_rows($result);
	$resultx = mysql_query("select * from links_subcategories where title LIKE '%$query%' ORDER BY title DESC");
	$nrowsx  = mysql_num_rows($resultx);
	} else
		$nrows = 0;

    $x=0;

    include("header.php");
    $mainlink = 0;
    menu($mainlink);
    echo "<table class=\"type0\" width=\"100%\" cellspacing=\"0\" cellspacing=\"1\" border=\"0\"><tr><td colspan=\"2\">
    <table width=\"100%\" cellspacing=\"0\" cellpadding=\"8\" border=\"0\"><tr><td class=\"type5\"><br /><center>";
    SearchForm();
	echo"</center>";
    if ($nrows>0 || $nrowsx>0) {
	
	$result2 = mysql_query("select cid, sid, title from links_subcategories where title LIKE '%$query%' ORDER BY title DESC");
	echo "<center>Search Results for: <span class=\"onebiggerrd\">$query</span></center><br /><br />";
	echo "<table width=\"100%\"><td class=\"type2\">Sub-Categories</td></tr></table>";
	while(list($cid, $sid, $stitle) = mysql_fetch_row($result2)) {
	    $cate = mysql_query("select title from links_categories where cid=$cid");
	    list($ctitle) = mysql_fetch_row($cate);
	    $res = mysql_query("select * from links_links where sid=$sid");
	    $numrows = mysql_num_rows($res);
	    $ctitle = str_replace($query, "<b>$query</b>", $ctitle);
	    $stitle = str_replace($query, "<b>$query</b>", $stitle);
	    echo "	<a href=\"links.php?op=viewslink&amp;sid=$sid\">$ctitle / $stitle</a> ($numrows)<br />";
	}
	echo "<br /><table width=\"100%\"><tr><td class=\"type2\">Links</td></tr></table>";
        while(list($lid, $cid, $sid, $title, $url, $description, $time, $hits) = mysql_fetch_row($result)) {
	    $title = str_replace($query, "<b>$query</b>", $title);

	    	if ($admintest) {
	    echo"<a href=\"links.php?op=visit&amp;lid=$lid\">$title</a>&nbsp;";
    	    echo "[ <a href=\"admin.php?op=LinksModLink&amp;lid=$lid\">Edit</a> ]<br />";
	} else {
	    echo "<a href=\"links.php?op=visit&amp;lid=$lid\">$title</a><br />";
	}
	    $description = str_replace($query, "<b>$query</b>", $description);
	    echo "<span class=\"searchprops\">Description: </span>$description<br />";
	    setlocale ("LC_TIME", "$locale");
	    ereg ("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2}) ([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2})", $time, $datetime);
	    $datetime = strftime("%d-%b-%Y", mktime($datetime[4],$datetime[5],$datetime[6],$datetime[2],$datetime[3],$datetime[1]));
	    $datetime = ucfirst($datetime);
	    echo "<span class=\"searchprops\">Added on: </span><b>$datetime</b> Hits: $hits<br />";
	    $result3 = mysql_query("select title from links_categories where cid=$cid");
	    $result4 = mysql_query("select title from links_subcategories where sid=$sid");
	    list($ctitle) = mysql_fetch_row($result3);
	    list($stitle) = mysql_fetch_row($result4);
	    if ($stitle=="") {
		$slash = "";
	    } else {
		$slash = "/";
	    }
	    echo "<span class=\"searchprops\">Category: </span>$ctitle $slash $stitle<br /><br />";
	    $x++;
        }
                
    } else {
        echo "<center><span class=\"onebiggerred\">No matches found to your query</span></center><br /><br />";
    }

    $prev=$min-$linksresults;
    if ($prev>=0) {
	print "<a href=\"links.php?op=search&amp;query=$query&amp;min=$prev\">";
	print "<br /><br /><center>Previous Page</center></a>";
    }

    $next=$min+$linksresults;
    $tmp = $linksresults-1;
    if ($x>=$tmp) {
	print "<a href=\"links.php?op=search&amp;query=$query&amp;min=$max\">";
	print "<br /><br /><center>Next Page</center></a>";
    }

    echo "<br /><br /><center>
    Try to search \"$query\" in others Search Engines<br />
    <a target=\"_blank\" href=\"http://www.altavista.com/cgi-bin/query?pg=q&amp;sc=on&amp;hl=on&amp;act=2006&amp;par=0&amp;q=$query&amp;kl=XX&amp;stype=stext\">Altavista</a> | 
    <a target=\"_blank\" href=\"http://www.google.com/search?q=$query\">Google</a> | 
    <a target=\"_blank\" href=\"http://www.hotbot.com/?MT=$query&amp;DU=days&amp;SW=web\">HotBot</a> | 
    <a target=\"_blank\" href=\"http://www.infoseek.com/Titles?qt=$query\">Infoseek</a> | 
    <a target=\"_blank\" href=\"http://www.dejanews.com/dnquery.xp?QRY=$query\">Deja News</a> | 
    <a target=\"_blank\" href=\"http://www.lycos.com/cgi-bin/pursuit?query=$query&amp;maxhits=20\">Lycos</a> |  
    <a target=\"_blank\" href=\"http://search.yahoo.com/bin/search?p=$query\">Yahoo</a>
    <br />
    <a target=\"_blank\" href=\"http://es.linuxstart.com/cgi-bin/sqlsearch.cgi?pos=1&amp;query=$query&amp;language=&amp;advanced=&amp;urlonly=&amp;withid=\">LinuxStart</a> |  
    <a target=\"_blank\" href=\"http://search.1stlinuxsearch.com/compass?scope=$query&amp;ui=sr\">1stLinuxSearch</a> | 
    <a target=\"_blank\" href=\"http://www.linuxlinks.com/cgi-bin/search.cgi?query=$query&amp;engine=Links\">LinuxLinks</a> | 
    <a target=\"_blank\" href=\"http://www.freshmeat.net/search.php?query=$query\">Freshmeat</a> | 
    <a target=\"_blank\" href=\"http://www.justlinux.com/bin/search.pl?key=$query\">JustLinux</a>";

    echo "</td></tr></table></td></tr></table>\n";
    echo "</td></tr></table></td></tr></table>\n";
    
    include("footer.php");

}

switch($op) {

    case "menu":
	menu($mainlink);
	break;

    case "AddLink":
	AddLink();
	break;

    case "NewLinks":
	NewLinks();
	break;

    case "TheBest":
	TheBest();
	break;

    case "viewlink":
	viewlink($cid, $min);
	break;

    case "viewslink":
	viewslink($sid, $min);
	break;

    case "visit":
	visit($lid);
	break;

    case "Add":
	Add($title, $url, $name, $cat, $description, $name, $email);
	break;

    case "search":
	search($query, $min);
	break;

    default:
	index();
	break;
    
}

?>
