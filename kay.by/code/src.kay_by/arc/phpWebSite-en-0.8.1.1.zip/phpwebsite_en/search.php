<?php
include("open_session.php");

if(!isset($mainfile)) { include("mainfile.php"); }

switch($op) {

        case "comments":
                break;

        default:
                $offset=30;
                if (!isset($min)) $min=0;
                if (!isset($max)) $max=$min+$offset;

     		    $query = stripslashes($query);

                include("header.php");

		if ($topic > 0)
		{
			$result = mysql_query("select topicimage, topictext from topics where topicid=$topic");
			list($topicimage, $topictext) = mysql_fetch_row($result);
		}
		else
		{
			$topictext = "All Topics";
			$topicimage = "alltopics.gif";
		}

$box_title = "Search in $topictext";
$box_stuff = "
	<img src=\"$tipath$topicimage\" align=\"right\" border=\"0\" alt=\"$topictext\" />
        <form action=\"search.php\" method=\"get\">
        <input size=\"25\" type=\"text\" name=\"query\" value=\"$query\" />
	<input type=\"submit\" value=\"Search\" /><br />";
		$toplist = mysql_query("select topicid, topictext from topics order by topictext");

		$box_stuff .= "<select name=\"topic\">
	<option value=\"\">All Topics</option>
		";

                while(list($topicid, $topics) = mysql_fetch_row($toplist))
		{
                	if ($topicid == $topic)
			$sel = "selected=\"selected\" ";

               		$box_stuff .= "<option $sel value=\"$topicid\">$topics</option>\n";
			$sel = "";
                }

		$box_stuff .= "</select>";

		// Authors Selection -->
                $thing = mysql_query("select aid from authors order by aid");

                $box_stuff .= "<select name=\"author\"><option value=\"\">All Authors</option>\n";

                while(list($authors) = mysql_fetch_row($thing))
		{
                	if ($authors == $author)
			$sel = "selected=\"selected\" ";

			$box_stuff .= "<option value=\"$authors\" $sel>$authors</option>\n";
			$sel = "";
                }
		$sel = "selected=\"selected\" ";
                $box_stuff .= "</select>
                <!-- Date Selection -->
                <select name=\"days\">
                        <option value=\"0\"";
				if ($days == "0") $box_stuff .= $sel;
			$box_stuff .= ">All dates</option>
                        <option value=\"7\"";
				if ($days == "7") $box_stuff .= $sel;
			$box_stuff .= ">1 week</option>
                        <option value=\"14\"";
				if ($days == "14") $box_stuff .= $sel;
			$box_stuff .= ">2 weeks</option>
                        <option value=\"31\"";
				if ($days == "31") $box_stuff .= $sel;
			$box_stuff .= ">1 month</option>
			<option value=\"62\"";
				if ($days == "62") $box_stuff .= $sel;
			$box_stuff .=">2 months</option>
                        <option value=\"93\"";
				if ($days == "93") $box_stuff .= $sel;
			$box_stuff .=">3 months</option>
                </select></form><br />";

		if($url_to_email)
		$q = "select s.sid, s.aid, s.title, s.time, a.email, s.comments, s.topic from stories s, authors a where s.aid=a.aid ";
		else
                $q = "select s.sid, s.aid, s.title, s.time, a.url, s.comments, s.topic from stories s, authors a where s.aid=a.aid ";

                if (isset($query)){
					$query = addslashes($query);
					$q .= "AND (s.title LIKE '%$query%' OR s.hometext LIKE '%$query%' OR s.bodytext LIKE '%$query%') ";
				}
                if ($author != "") $q .= "AND s.aid='$author' ";
                if ($topic != "") $q .= "AND s.topic='$topic' ";
                if ($days != "" && $days!=0) $q .= "AND TO_DAYS(NOW()) - TO_DAYS(time) <= $days ";

                $q .= " ORDER BY s.time DESC LIMIT $min,$offset";
		$t = $topic;
                $result = mysql_query($q);
                $nrows  = mysql_num_rows($result);
                $x=0;

                $box_stuff .= "<br />Announcements matching your query are:<br /><hr />";

		if ($nrows>0)
		{
                        while(list($sid, $aid, $title, $time, $url, $comments, $topic) = mysql_fetch_row($result))
			{
				$result2=mysql_query("select topictext from topics where topicid='$topic'");
				list($topictext) = mysql_fetch_row($result2);

				if($url_to_email) $url = 'mailto:' . $url;
			        $furl = "article.php?sid=$sid";
                                formatTimestamp($time);
				$box_stuff .= "<a href=\"$furl\">$title</a> by: <a href=\"$url\">$aid</a>";
				$box_stuff .= " on: $datetime (<span class=\"boldtext\">$comments</span>)<br /><br />\n";
                                $x++;
                        }
                
		}
		else
		{
                        $box_stuff .= "<br /><span class=\"onebiggerred\">No matches found to your query</span><br /><br />";
                }

                $prev=$min-$offset;
                if ($prev>=0) {
                        $box_stuff .= "<a href=\"search.php?author=$author&amp;topic=$t&amp;min=$prev&amp;query=$query\">";
                        $box_stuff .= "<br /><br />$min previous matches</a>";
                }

                $next=$min+$offset;
		if ($x>=29) {
                        $box_stuff .= "<a href=\"search.php?author=$author&amp;topic=$t&amp;min=$max&amp;query=$query";
                        $box_stuff .= "&amp;section=$section\"><br /><br /><center><b>next matches</b></a>";
                }
		
		if($query)
		{
			$box_stuff .= "<br /><br />Pages matching your query are:<br /><hr />";
			$query = addslashes($query);
		
			$page_result = mysql_query("SELECT id, title FROM mod_userpage_data WHERE data LIKE '%$query%' OR title LIKE '%$query%'");
			$page_rows = mysql_num_rows($page_result);

			if($page_rows)
			{
				$box_stuff .= "<ul>";
				while(list($page_id, $page_title) = mysql_fetch_row($page_result))
				{
					$menu_result = mysql_query("select menu_id from menu where page_id='$page_id'");
					list($menu_id) = mysql_fetch_row($menu_result);

					$box_stuff .= "<li><a href=\"./mod.php?mod=userpage&amp;page_id=$page_id&amp;menu=$menu_id\">$page_title</a></li>";
				}
				$box_stuff .= "</ul><br />";
			}
			else
			{
				$box_stuff .= "<span class=\"onebiggerred\">No matches found to your query</span><br /><br />";
			}
		}

		themesidebox($box_title, $box_stuff);
		include("footer.php");
                break;
}
?>
<!-- search.php end -->
