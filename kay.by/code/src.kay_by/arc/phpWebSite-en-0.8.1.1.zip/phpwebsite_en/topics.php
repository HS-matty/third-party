<?php

/**
 * Displays all active topics.
 *
 * This file allows to display all the active topics on one page.
 * It is also used to display a topic with it long description, its subtopics
 * and its associated stories on one page.
 *
 * @module
 * @modulegroup
 * @package phpWebSite
 */

include("open_session.php");

if(!isset($mainfile))
{
  /* Defines core functions. */
  include("mainfile.php");
}

/* Global configuration data */
include("config.php");

/* Generates page header */
include ("header.php");

switch($op)
{
	case "viewtopic":
	viewtopic($topic);
	break;
	
	default:
	listtopics();
	break;
}

/**
 * Displays all the active topics on one page (image + topictext).
 *
 * @author unknown
 */
function listtopics()
{
	global $tipath;
	$result = mysql_query("select topicid, topicname, topicimage, topictext, topiclongtext, topicparent from topics where 
	topicparent = '0' order by topictext");
  
	$box_title = "Current Active Topics";
  
	if (mysql_num_rows($result)==0)
	      $box_stuff = "None Found";
  	else
	{
		$box_stuff = "Click to list all announcements in this topic<br />
		<table border=\"0\" width=\"100%\" align=\"center\" cellpadding=\"2\" summary=\"Data for Article Topic\"><tr>";
      
		while(list($topicid, $topicname, $topicimage, $topictext, $topiclongtext, $topicparent) = mysql_fetch_array($result))
		{ 
	  		$box_stuff .= "<td class=\"type5\" align=\"left\">
			<a href=\"topics.php?op=viewtopic&amp;topic=$topicid\">$topictext</a><br />
			$topiclongtext</td><td>
			<a href=\"topics.php?op=viewtopic&amp;topic=$topicid\">
			<img src=\"$tipath$topicimage\" border=\"0\" alt=\"$topictext\" /></a><br />
			<br /></td></tr>";

			$topicid_hold = $topicid;
		   	  
			$result2 = mysql_query("select topicid, topicparent, topictext, topiclongtext, topicimage from topics 
				WHERE topicparent = $topicid_hold");

			if(mysql_num_rows($result2))
			{	  
				while( list($subtopicid, $subtopicparent, $subtopictext, $subtopiclongtext, $subtopicimage) 
					= mysql_fetch_row($result2))
	    			{
					$box_stuff .="<td class=\"type5\" align=\"left\"><ul>
					<a href=\"topics.php?op=viewtopic&amp;topic=$subtopicid\">$subtopictext</a><br />
					$subtopiclongtext</ul></td><td>
					<a href=\"topics.php?op=viewtopic&amp;topic=$subtopicid\">
					<img src=\"$tipath$subtopicimage\" border=\"0\" alt=\"$subtopictext\" /></a><br />
					<br /></td></tr>";
	    	    
	    				$topicid_hold2 = $subtopicid;
	    
					$result3 = mysql_query("select topicid, topicparent, topictext, topiclongtext, topicimage 
						from topics WHERE topicparent = $topicid_hold2");
	    	
	    				if(mysql_num_rows($result3))
					{	
						while(list($subsubtopicid, $subsubtopicparent, $subsubtopictext, $subsubtopiclongtext, 
							$subsubtopicimage) = mysql_fetch_row($result3))
						{
							$box_stuff .="<tr><td class=\"type5\" align=\"left\"><ul><ul>
						<a href=\"topics.php?op=viewtopic&amp;topic=$subsubtopicid\">$subsubtopictext</a><br />
						$subsubtopiclongtext</ul></ul></td><td>
						<a href=\"topics.php?op=viewtopic&amp;topic=$subsubtopicid\">
						<img src=\"$tipath$subsubtopicimage\" border=\"0\" alt=\"$subsubtopictext\" /></a><br />
						<br /></td></tr>";
						}
						$box_stuff .= "</td></tr>";
		    			}
				}
			}
	  	}
	
		$box_stuff .= "</table>";
	}
	  
	  themesidebox($box_title, $box_stuff);
  	  include("footer.php");
}


/**
 * Displays all the active topics on one page (image + topictext).
 *
 * @author Nicolas De Rycke - nderycke@c4ifr.com
 */
function viewtopic($topic)
{
  global $tipath, $topicname, $topicimage, $topictext, $datetime;
  
  $result = mysql_query("select topicparent, topictext, topiclongtext, topicimage from topics WHERE topicid = $topic");
  if(mysql_num_rows($result))
    {
      list($topicparent, $topictext, $topiclongtext, $topicimage) = mysql_fetch_row($result);
      $tmptopicparent = $topicparent;
      
      while ($tmptopicparent != 0)
	{
	  $result2 = mysql_query("select topicid, topicparent, topictext, topicimage from topics WHERE topicid = $tmptopicparent");
	  list($tmptopic, $tmptopicparent, $tmptopictext, $tmptopicimage) = mysql_fetch_row($result2);
	  $topictext = "<a href=\"topics.php?op=viewtopic&amp;topic=$tmptopic\">$tmptopictext</a> > $topictext";
	}
      
      $topictext = "<a href=\"topics.php\">Topics</a> > $topictext";
      $topiclongtext = stripslashes(str_replace ("\n", "<br />" , $topiclongtext));
      $topiclongtext .= "<img src=\"$tipath$topicimage\" border=\"0\" alt=\"$tmptopictext\" align=\"right\" />";
      
      thememainbox($topictext, $topiclongtext);
    }
  
  $result = mysql_query("select topicid, topicname, topicimage, topictext from topics WHERE topicparent = $topic");
  if(mysql_num_rows($result))
    {
      $box_stuff = "
Click to view the subtopic<br />
<table border=\"0\" width=\"100%\" align=\"center\" cellpadding=\"2\" summary=\"List of the SubTopics\"><tr>
		";
      
      while(list($topicid, $topicname, $topicimage, $topictext) = mysql_fetch_array($result))
	{

  $box_stuff .= "
<td class=\"type5\" align=\"center\">
<a href=\"topics.php?op=viewtopic&amp;topic=$topicid\">
<img src=\"$tipath$topicimage\" border=\"0\" alt=\"$topictext\" /><br />
$topictext</a></td>
			";

	  
	  $count++;
	  if ($count == 5)
	    {
	      $box_stuff .= "</tr><tr>";
	      $count = 0;
	    }
	}
      
      $box_stuff .= "</tr></table>";
      themesidebox("List of the SubTopics", $box_stuff);
    }
  
  
  $result = mysql_query("SELECT sid, aid, title, time, hometext, bodytext, comments, counter, topic, informant, notes FROM stories WHERE topic = $topic ORDER BY sid DESC");
  while(list($s_sid, $aid, $title, $time, $hometext, $bodytext, $comments, $counter, $topic, $informant, $notes) = mysql_fetch_row($result))
    {
      getTopics($s_sid);
      formatTimestamp($time);
      
      $subject = stripslashes($subject);
      $hometext = stripslashes(str_replace ("\n", "<br />" , $hometext));
      $notes = stripslashes(str_replace ("\n", "<br />" , $notes));
      $introcount = strlen(str_replace ("\n", "<br />" , $hometext));
      $fullcount = strlen(str_replace ("\n", "<br />" , $bodytext));
      $totalcount = $introcount + $fullcount;
      $morelink = "";
      
      if ($fullcount > 1)
	{
	  $morelink .= "<a href=\"article.php?sid=$s_sid";
	  if (isset($cookie[4])){
	    $morelink .= "&amp;mode=$cookie[4]";
	  }
	  else{
	    $morelink .= "&amp;mode=threaded";
	  }
	  
	  if(isset($cookie[5])){
	    $morelink .= "&amp;order=$cookie[5]";
	  }
	  else{
	    $morelink .= "&amp;order=0";
	  }
	  
	  $morelink .= "\">Read More...</a> | $totalcount bytes more";
	}
      
      if($show_comments)
	{
	  
	  $count = $comments;
	  
	  $morelink .= "| <a href=\"article.php?sid=$s_sid";
	  
	  if (isset($cookie[4])){
	    $morelink .= "&amp;mode=$cookie[4]";
	  }
	  else{
	    $morelink .= "&amp;mode=threaded";
	  }
	  
	  if (isset($cookie[5])){
	    $morelink .= "&amp;order=$cookie[5]";
	  }
	  else{
	    $morelink .= "&amp;order=0";
	  }
	  
	  if (isset($cookie[6])){
	    $morelink .= "&amp;thold=$cookie[6]";
	  }
	  else{
	    $morelink .= "&amp;thold=0";
	  }
	  
	  $morelink2 = "| <a href=\"article.php?sid=$s_sid";
	  
	  if (isset($cookie[4])){
	    $morelink2 .= "&amp;mode=$cookie[4]";
	  }
	  else{
	    $morelink2 .= "&amp;mode=threaded";
	  }
	  
	  if (isset($cookie[5])){
	    $morelink2 .= "&amp;order=$cookie[5]";
	  }
	  else{
	    $morelink2 .= "&amp;order=0";
	  }
	  
	  if (isset($cookie[6])){
	    $morelink2 .= "&amp;thold=$cookie[6]";
	  }
	  else{
	    $morelink2 .= "&amp;thold=0";
	  }
	  if(($count==0))
	    {
	      $morelink .= "\">comments?</a>";
	    }
	  else
	    {
	      if (($fullcount<1))
		{
		  if(($count==1))
		    {
		      $morelink .= "\">Read More...</a> | $morelink2\">$count comment</a>";
		    }
		  else
		    {
		      $morelink .= "\">Read More...</a> | $morelink2\">$count comments</a>";
		    }
		}
	      else
		{
		  if(($count==1))
		    {
		      $morelink .= "\">$count comment</a>";
		    }
		  else
		    {
		      $morelink .= "\">$count comments</a>";
		    }
		}
	    }
	}
      
      $sid = $s_sid;
      $morelink .= "&nbsp;|&nbsp;<a href=\"friend.php?op=FriendSend&amp;sid=$sid\">
      <img src=\"images/friend.gif\" border=\"0\" align=\"middle\" alt=\"Send this announcement to a friend\" 
/></a>&nbsp;|&nbsp;
      <a href=\"article.php?op=Print&amp;sid=$sid\">
      <img src=\"images/print.gif\" border=\"0\" align=\"middle\" alt=\"Printable Version\" /></a>";
      themeindex($aid, $informant, $datetime, $title, $counter, $topic, $hometext, $notes, $morelink, $topicname, $topicimage, $topictext);
    }
  
  mysql_free_result($result);
  include("footer.php");
}

?>
