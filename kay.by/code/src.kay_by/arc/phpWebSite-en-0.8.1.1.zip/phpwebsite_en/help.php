<?
include ("mainfile.php");
include ("config.php");

include("open_session.php");

function help_top() {
echo "
<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"DTD/xhtml1-strict.dtd\">
  <html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\"> <head>"; 
include("config.php"); 
echo "<title>Welcome to $sitename</title>";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\" />
<meta name=\"description\" content=\"$sitename Help System\" />"; 
global $user, $hr, $theme, $cookie; if(isset($user)) {
   $user2 = base64_decode($user);
   $cookie = explode(":", $user2);
   if($cookie[9]=="") $cookie[9]="$default_theme";
   if(isset($theme)) $cookie[9]=$theme;
   $css = "themes/$cookie[9]/style.css";
include ("themes/$cookie[9]/theme.php");
  }else{
   $css = "themes/$default_theme/style.css";
include ("themes/$default_theme/theme.php"); 
	} 
echo "\n<link rel=\"stylesheet\" href=\"$css\" type=\"text/css\" />";
echo "</head> <body>";
}

function help_main($one, $two, $three, $four, $five, $six, $toc) {
help_top();
$title = show_nav($one, $two, $three, $four, $five, $six);
if (!$toc) {
$stuff .= show_help_level($one, $two, $three, $four, $five, $six);
}else{
$stuff .= show_toc();
}
$stuff .= lower_nav();
themesidebox("$title", "$stuff");
echo "</body> </html>";
}

function lower_nav(){
return "<p style=\"text-align : center\">[ <a href=\"help.php\">Main</a> | 
	<a href=\"help.php?op=TOC\">Table of Contents</a> | 
<a href=\"help.php?op=manual_search\">Search</a> ]</p>";
}

function search_form() {

return "<form action=\"help.php?op=search\" method=\"post\">\n
	<input type=\"text\" size=\"50\" maxlength=\"50\" name=\"name\" />
	<input type=\"submit\" value=\"Search\" /><br />";
}

switch($op)
{
	case "manual_search":
	   help_top();
	$searchf = search_form() . lower_nav();
	themesidebox("Search Help System", "$searchf");
	echo "</body></html>";	
	break;

	case "":
		help_main($one, $two, $three, $four, $five, $six, "");
	break;

	Default:
		help_main($one, $two, $three, $four, $five, $six, "");
	break;
	
	case "printable_version":
		printable_version();
	break;
	
	case "TOC":
		help_main("", "", "", "", "", "", 1);	
	break;

	case "search":
		if(strtolower($name) == "admin" && $admintest){
		 //If the name is called admin, that designates that it is the admin search
		 $result = mysql_query("SELECT * FROM help WHERE admin='1' ORDER BY one, two, three, four, five, six");
		 $row = mysql_fetch_array($result);
		 	if(!$row["one"]){
			   help_top();
		           themesidebox("Search", "None found:<br />
			   <a href=\"help.php\">Help System</a>");
			   echo "</body></html>";
			break;
			}else{
			   help_main($row["one"], $row["two"], $row["three"], $row["four"], $row["five"], $row["six"], "");
			   break;
			}
		}elseif($admintest && (strtolower($name) != "admin")){
		 $result = mysql_query("SELECT * FROM help WHERE name LIKE '%$name%'");
		 while ($row = mysql_fetch_array($result))
		 {
			$name_found = $row["name"];
			$one = $row["one"];
			$two = $row["two"];
			$three = $row["three"];
			$four = $row["four"];
			$five = $row["five"];
			$six = $row["six"];
			$count++;
			$multiple .= "<li>" . show_nav($one, $two, $three, $four, $five, $six) . "</li>";
		 }
		}elseif(!$admintest){
		$result = mysql_query("SELECT * FROM help WHERE name LIKE '%$name%' AND admin = '0'");
		while ($row = mysql_fetch_array($result))
		{
			$name_fount = $row["name"];
			$one = $row["one"];
			$two = $row["two"];
			$three = $row["three"];
			$four = $row["four"];
			$five = $row["five"];
			$six = $row["six"];
			$count++;
			$multiple .= "<li>" . show_nav($one, $two, $three, $four, $five, $six) . "</li>";
		}
	}
		
	if ($count == 1){
		//if there is only one exact match, do this...
		help_main($one, $two, $three, $four, $five, $six, "");
	}elseif($count > 1) {
		//if there are multiple results, do this...
		help_top();
	$nav = lower_nav();
		themesidebox("<a href=\"help.php\">Help System</a>", "<h3>Multiple Matches</h3>Select the best match:<br 
/><ul>$multiple</ul>$nav</body></html>");
	}else{
	//If no items match your search or inline argument, do this...
		help_top();
		$nav = lower_nav();	
	$searchf = search_form();
	themesidebox("<a href=\"help.php\">Help System</a>", "<h3>No matches found to your query \"$name\".</h3>$searchf $nav");
		echo "</body></html>";

	}
	break;

}

function show_help_level($one, $two, $three, $four, $five, $six) {

if (!$one) {
	$return_value .= "<h3>Welcome to Help System</h3>
		<a href=\"help.php?op=printable_version\">Printable Version</a><ul>";
	$result = mysql_query("SELECT * FROM help WHERE one > '0' AND two = '0' ORDER BY name ASC");
	while ($row = mysql_fetch_array($result)) {
		$name = $row["name"];
		$one = $row["one"];
		$admin_level = $row["admin"];
	if (!$admintest && $admin_level) {}else
	    {
	$return_value .= "<li><a href=\"help.php?one=$one\">$name</a></li>";
	     }
	}
	$return_value .= "</ul>";
}elseif(!$two) {
	$result = mysql_query("SELECT name, description FROM help WHERE one = '$one' AND two = '0'");
	$row = mysql_fetch_array($result);
	$name = $row["name"];
	$description = $row["description"];
		$return_value .= "<h3>$name</h3><p>$description</p>";
		$return_value .= "<ul>";
	$result = mysql_query("SELECT * FROM help WHERE one = '$one' AND two > '0' AND three = '0' ORDER BY name ASC");
	while ($row = mysql_fetch_array($result)) {
		$name = $row["name"];
		$two = $row["two"];
		$admin_level = $row["admin"];
	if(!$admintest && $admin_level){
	}else{
	$return_value .= "<li><a href=\"help.php?one=$one&amp;two=$two\">$name</a></li>";
	}
	}
	$return_value .= "</ul>";
}elseif(!$three) {
	$result = mysql_query("SELECT name, description FROM help WHERE one = '$one' AND two = '$two' AND three = '0'");
	$row = mysql_fetch_array($result);
	$name = $row["name"];
	$description = $row["description"];
	$return_value .= "<h3>$name</h3><p>$description</p>";
	$return_value .= "<ul>";
	$result = mysql_query("SELECT * FROM help WHERE one = '$one' AND two = '$two' AND three > '0' AND four = '0' ORDER BY name ASC");
	while ($row = mysql_fetch_array($result)) {
		$name = $row["name"];
		$three = $row["three"];
		$admin_level = $row["admin"];
	if(!$admintest && $admin_level){
	}else{
	$return_value .= "<li><a href=\"help.php?one=$one&amp;two=$two&amp;three=$three\">$name</a></li>";
	}
	}
	$return_value .= "</ul>";
}elseif(!$four) {
	$result = mysql_query("SELECT name, description FROM help WHERE one = '$one' AND two = '$two' AND three = '$three' AND four = '0'");
	$row = mysql_fetch_array($result);
	$name = $row["name"];
	$description = $row["description"];
	$return_value .= "<h3>$name</h3><p>$description</p>";
	$return_value .= "<ul>";
	$result = mysql_query("SELECT * FROM help WHERE one = '$one' AND two = '$two' AND three = '$three' AND four > '0' AND five = '0' ORDER BY name ASC");
	while ($row = mysql_fetch_array($result)) {
		$name = $row["name"];
		$four = $row["four"];
		$admin_level = $row["admin"];
	if(!$admintest && $admin_level) {
	}else{
	$return_value .= "<li><a href=\"help.php?one=$one&amp;two=$two&amp;three=$three&amp;four=$four\">$name</a></li>";
	}
	}
	$return_value .= "</ul>";
}elseif(!$five) {
	$result = mysql_query("SELECT name, description FROM help WHERE one = '$one' AND two = '$two' AND three = '$three' AND four = '$four' AND five = '0'");
	$row = mysql_fetch_array($result);
		$name = $row["name"];
		$description = $row["description"];
	$return_value .= "<h3>$name</h3><p>$description</p>";
	$return_value .= "<ul>";
	$result = mysql_query("SELECT * FROM help WHERE one = '$one' AND two = '$two' AND three = '$three' AND four = '$four' and five > '0' AND six = '0' ORDER BY name ASC");
	while ($row = mysql_fetch_array($result)) {
		$name = $row["name"];
		$five = $row["five"];
		$admin_level = $row["admin"];
	if(!$admintest && $admin_level) {
	}else{
	$return_value .= "<li><a href=\"help.php?one=$one&amp;two=$two&amp;three=$three&amp;four=$four&amp;five=$five\">$name</a></li>";
	}
	}
	$return_value .= "</ul>";
}elseif(!$six) {
	$result = mysql_query("SELECT name, description FROM help WHERE one = '$one' AND two = '$two' AND three = '$three' AND four = '$four' AND five = '$five' AND six = '0'");
	$row = mysql_fetch_array($result);
		$name = $row["name"];
		$description = $row["description"];
	$return_value .= "<h3>$name</h3><p>$description</p>";
	$return_value .= "<ul>";
	$result = mysql_query("SELECT * FROM help WHERE one = '$one' AND two = '$two' AND three = '$three' AND four = '$four' AND five = '$five' and six > '0' ORDER BY name ASC");
	while ($row = mysql_fetch_array($result)) {
		$name = $row["name"];
		$six = $row["six"];
		$admin_level = $row["admin"];
	if(!$admintest && $admin_level) {
	}else{
	$return_value .= "<li><a href=\"help.php?one=$one&amp;two=$two&amp;three=$three&amp;four=$four&amp;five=$five&amp;six=$six\">$name</a></li>";
	}
	}
	$return_value .= "</ul>";
}elseif($six){
	$result = mysql_query("SELECT name, description FROM help WHERE one = '$one' AND two = '$two' AND three = '$three' AND four = '$four' AND five = '$five' AND six = '$six'");
	$row = mysql_fetch_array($result);
		$name = $row["name"];
		$description = $row["description"];
		$admin_level = $row["admin"];
	if(!$admintest && $admin_level){
	}else{
	$return_value .= "<h3>$name</h3><p>$description</p>";
	}
}else{
$return_value .= "ERROR";
}
return $return_value;
}

function show_nav($one, $two, $three, $four, $five, $six) {
	$return_value .= "<a href=\"help.php\">Help Main</a>&nbsp;";

if($one) {
	$return_value .= "&gt;&nbsp;";
	$result = mysql_query("SELECT name FROM help WHERE one = '$one' AND two = '0'");
		$row = mysql_fetch_array($result);
			$name = $row["name"];
		$return_value .= "<a href=\"help.php?one=$one\">$name</a>&nbsp;";
}

if($two) {
	$return_value .= "&gt;&nbsp;";
	$result = mysql_query("SELECT name FROM help WHERE one = '$one' AND two = '$two' AND three = '0'");
		$row = mysql_fetch_array($result);
			$name = $row["name"];
		$return_value .= "<a href=\"help.php?one=$one&amp;two=$two\">$name</a>&nbsp;";
}

if($three) {
	$return_value .= "&gt;&nbsp;";
	$result = mysql_query("SELECT name FROM help WHERE one = '$one' AND two = '$two' AND three = '$three' AND four = '0'");
		$row = mysql_fetch_array($result);
			$name = $row["name"];
		$return_value .= "<a href=\"help.php?one=$one&amp;two=$two&amp;three=$three\">$name</a>&nbsp;";
}

if($four) {
	$return_value .= "&gt;&nbsp;";
	$result = mysql_query("SELECT name FROM help WHERE one = '$one' AND two = '$two' AND three = '$three' AND four = '$four' AND five = '0'");
		$row = mysql_fetch_array($result);
			$name = $row["name"];
		$return_value .= "<a href=\"help.php?one=$one&amp;two=$two&amp;three=$three&amp;four=$four\">$name</a>&nbsp;";
}

if($five) {
	$return_value .= "&gt;&nbsp;";
	$result = mysql_query("SELECT name FROM help WHERE one = '$one' AND two = '$two' AND three = '$three' AND four = '$four' AND five = '$five' AND 
six = '0'");
		$row = mysql_fetch_array($result);
			$name = $row["name"];
		$return_value .= "<a href=\"help.php?one=$one&amp;two=$two&amp;three=$three&amp;four=$four&amp;five=$five\">$name</a>&nbsp;";
}

if($six) {
	$return_value .= "&gt;&nbsp;";
	$result = mysql_query("SELECT name FROM help WHERE one = '$one' AND two = '$two' AND three = '$three' AND four = '$four' AND five = '$five' AND 
six = '$six'");
		$row = mysql_fetch_array($result);
			$name = $row["name"];
		$return_value .= "$name";
}

return $return_value;
}

function show_toc() {
//Shows all database items in a nested fashion

$result = mysql_query("SELECT * FROM help ORDER BY one, two, three, four, five, six");
while ($row = mysql_fetch_array($result)) {
	$name = $row["name"];
	$one = $row["one"];
	$two = $row["two"];
	$three = $row["three"];
	$four = $row["four"];
	$five = $row["five"];
	$six = $row["six"];
	$admin_level = $row["admin"];
//this isn't a modify link, it is to view the item.
if(!$admintest && $admin_level && $first_admin)
{
	$go_print = 0;
}
if(!$admintest && $admin_level && !$first_admin)
{
	$modify_link = "$name - Can only be viewed by an Administrator";
	$first_admin = 1;
	$go_print = 1;
}
if($admintest && $admin_level)
{
$modify_link = "<a href=\"help.php?one=$one&amp;two=$two&amp;three=$three&amp;four=$four&amp;five=$five&amp;six=$six\">$name</a>";
$go_print = 1;
}
if(!$admin_level)
{
$modify_link = "<a href=\"help.php?one=$one&amp;two=$two&amp;three=$three&amp;four=$four&amp;five=$five&amp;six=$six\">$name</a>";
$go_print = 1;
}
if ($go_print) {
if($one && !$two) {
$list .= "<div style=\"text-indent : 0em\">$one. $modify_link</div>"; 
}elseif ($two && !$three) {
$list .= "<div style=\"text-indent : 1em\">$one.$two $modify_link</div>"; 
}elseif ($three && !$four) {
$list .= "<div style=\"text-indent : 2em\">$one.$two.$three $modify_link</div>";
}elseif ($four && !$five) {
$list .= "<div style=\"text-indent : 3em\">$one.$two.$three.$four $modify_link</div>";
}elseif ($five && !$six) {
$list .= "<div style=\"text-indent : 4em\">$one.$two.$three.$four.$five $modify_link</div>";
}elseif ($six) {
$list .= "<div style=\"text-indent : 5em\">$one.$two.$three.$four.$five.$six $modify_link</div>";
}else{
$list .= "ERROR";
}
	}
}
return $list;
}

function printable_version()
{
include("config.php");

$top_print = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"DTD/xhtml1-transitional.dtd\">
  <html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\"> <head>
<title>Welcome to $sitename</title>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\" />
<meta name=\"description\" content=\"$sitename Help System\" /></head><body>";

$indent_start = "<div style=\"text-indent : 2em\">";
///////////////////////////////////
$result = mysql_query("SELECT * FROM help ORDER BY one, two, three, four, five, six");
while ($row = mysql_fetch_array($result)) {
	$name = $row["name"];
	$one = $row["one"];
	$two = $row["two"];
	$three = $row["three"];
	$four = $row["four"];
	$five = $row["five"];
	$six = $row["six"];
	$admin_level = $row["admin"];
//this isn't a modify link, it is to view the item.
if(!$admintest && $admin_level && $first_admin)
{
	$go_print = 0;
}
if(!$admintest && $admin_level && !$first_admin)
{
	$modify_link = "$name - Can only be viewed by an Administrator";
	$first_admin = 1;
	$go_print = 1;
}
if($admintest && $admin_level)
{
$modify_link = "<a href=\"#$one$two$three$four$five$six\">$name</a>";
$go_print = 1;
}
if(!$admin_level)
{
$modify_link = "<a href=\"#$one$two$three$four$five$six\">$name</a>";
$go_print = 1;
}
if ($go_print) {
if($one && !$two) {
$list .= "<div style=\"text-indent : 0em\">$one. $modify_link</div>"; 
}elseif ($two && !$three) {
$list .= "<div style=\"text-indent : 1em\">$one.$two $modify_link</div>"; 
}elseif ($three && !$four) {
$list .= "<div style=\"text-indent : 2em\">$one.$two.$three $modify_link</div>";
}elseif ($four && !$five) {
$list .= "<div style=\"text-indent : 3em\">$one.$two.$three.$four $modify_link</div>";
}elseif ($five && !$six) {
$list .= "<div style=\"text-indent : 4em\">$one.$two.$three.$four.$five $modify_link</div>";
}elseif ($six) {
$list .= "<div style=\"text-indent : 5em\">$one.$two.$three.$four.$five.$six $modify_link</div>";
}else{
$list .= "ERROR";
	}//If go print is enabled
	}
}
$list .= lower_nav() . "<hr />";
//////////////////after TOC /////////////////////////////////////
$result = mysql_query("SELECT * FROM help ORDER BY one, two, three, four, five, six");
while ($row = mysql_fetch_array($result)) {
	$name = $row["name"];
	$one = $row["one"];
	$two = $row["two"];
	$three = $row["three"];
	$four = $row["four"];
	$five = $row["five"];
	$six = $row["six"];
	$admin_level = $row["admin"];
	$description = $row["description"];
if(!$description) {
	$description = "None found";
}
//this isn't a modify link, it is to view the item.
if(!$admintest && $admin_level && $first_admin)
{
	$go_print = 0;
}
if(!$admintest && $admin_level && !$first_admin)
{
	$modify_link = "$name - Can only be viewed by an Administrator";
	$first_admin = 1;
	$go_print = 1;
}
if($admintest && $admin_level)
{
$modify_link = "<a name=\"$one$two$three$four$five$six\"></a>$name";
$go_print = 1;
}
if(!$admin_level)
{
$modify_link = "<a name=\"$one$two$three$four$five$six\"></a>$name";
$go_print = 1;
}
$desc_begin = "$indent_start $description [ <a href=\"#top\">Back</a> ]</div>";
$description = "$desc_begin";
if ($go_print) {
if($one && !$two) {
$list .= "<h2>$one. $modify_link </h2>$description"; 
}elseif ($two && !$three) {
$list .= "<h2>$one.$two $modify_link </h2>$description "; 
}elseif ($three && !$four) {
$list .= "<h2>$one.$two.$three $modify_link </h2> $description";
}elseif ($four && !$five) {
$list .= "<h2>$one.$two.$three.$four $modify_link </h2>$description";
}elseif ($five && !$six) {
$list .= "<h2>$one.$two.$three.$four.$five $modify_link </h2> $description";
}elseif ($six) {
$list .= "<h2>$one.$two.$three.$four.$five.$six $modify_link </h2> $description";
}else{
$list .= "ERROR";
	}//If go print is enabled
	}
}
///////////////////////////////////
$th = "<a name=\"top\"></a>Table of Contents<hr /> $list";
$end = "</body>\n</html>";
echo "$top_print<a name=\"top\"></a>$sitename Help $th $end";
}

?>
