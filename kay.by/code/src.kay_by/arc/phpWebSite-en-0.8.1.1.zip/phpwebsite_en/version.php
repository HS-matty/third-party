<?php
/**
 * Version number varibale file. 
 *
 * This varuable is for outputing what version in the admin section. 
 * It is also used for the up to date check.
 *
 * @author Jeremy Agee
 * @module version
 * @modulegroup administration
 * @package phpWebSite
 */

/* If you are changin this to a release candidate.  Use -rc after the version.  Ex. 0_8_0-rc4 */
$phpwebsite_version = "0_8_1_1";  /* Do not change this! */

?>
