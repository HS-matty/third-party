<?php
/**
 * Displays an article and associated comments.
 *
 * This file pulls the data associated with article sid from the mysql 
 * database and builds the "box" containing this data. It also shows 
 * the comments if any exist and if the site admin even wants them to 
 * be shown.
 *
 * @module article
 * @modulegroup content_handling
 * @package phpWebSite
 */

include("open_session.php");

session_register("cmode");
session_register("cthold");
session_register("corder");

global $cmode, $cthold, $corder;

if($refresh)
{
	if(isset($new_mode))
		$cmode=$new_mode;
	if(isset($new_thold))
		$cthold=$new_thold;
	if(isset($new_order))
		$corder=$new_order;
}

if(!isset($mainfile))
{
	/* Defines core functions. */
	include("mainfile.php");
}

/* Bail out if called incorrectly */
if(!isset($sid) && !isset($tid)) exit();

/* Global configuration data */
include("config.php");

if ($op == "Print")
{
	$result = mysql_query("select aid, time, title, hometext, bodytext, topic, informant, notes FROM stories where sid=$sid");
	list($aid, $time, $title, $hometext, $bodytext, $topic, $informant, $notes) = mysql_fetch_row($result);
	mysql_query("UPDATE stories SET counter=counter+1 where sid=$sid");

	formatTimestamp($time);
	
        if (!strstr ($hometext, '<p') && !strstr ($hometext, '<table') && !strstr ($hometext, '<br') && !strstr($hometext, '<h'))
	    $hometext = stripslashes(str_replace ("\n", "<br />", $hometext));
        if (!strstr ($bodytext, '<p') && !strstr ($bodytext, '<table') && !strstr ($bodytext, '<br') && !strstr($bodytext, '<h'))
	    $bodytext = stripslashes(str_replace ("\n", "<br />", $bodytext));

	echo "
<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" 
\"DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\">
<head>
<title>$sitename - $titletag</title>
</head>
<body>
<table width=\"640\" border=\"1\" cellSpacing=\"0\" cellPadding=\"20\" bgColor=\"#ffffff\" bordercolorlight=\"#000000\" bordercolor=\"#000000\" bordercolordark=\"#000000\">
<tr><td>
	<p align=\"right\"><font face=\"Arial\" size=\"2\">$sitename</font></p>
	<center><font face=\"Arial\" size=\"+3\"><b>$title</b></font><br />
	<font face=\"Arial\" size=\"1\">By $aid - Date: $time</font></center>
	<br /><br />
	<font face=\"Arial\" size=\"2\"><p align=\"justify\">$hometext</p>
	<p align=\"justify\">$bodytext</p>
	<hr noshade><br /><center>
	 $sitename<br />
	<a href=\"$nuke_url\">$nuke_url</a></br /><br />
	The URL for this announcement is:<br />
	<a href=\"$nuke_url/article.php?sid=$sid\">$nuke_url/article.php?sid=$sid</a></br /><br />
	</center></font>
</td></tr>
</table>
</body>
</html>
	";

}
else
{
	/* Generates page header */
	include ("header.php");

	if($save)
	{
		cookiedecode($user);
		if ($user_dblocation)
		{
			@mysql_select_db("$user_dbname") or die ("Unable to select database");
			mysql_query("update users set umode='$cmode', uorder='$order', thold='$thold' where uid='$cookie[0]'");
			@mysql_select_db("$dbname") or die ("Unable to select database");
		}
		else
		{
			mysql_query("update users set umode='$cmode', uorder='$corder', thold='$cthold' where uid='$cookie[0]'");
		}
		getusrinfo($user);
		$info = base64_encode("$userinfo[uid]:$userinfo[uname]:$userinfo[pass]:$userinfo[storynum]:$userinfo[umode]:$userinfo[uorder]:$userinfo[thold]:$userinfo[noscore]");
		setcookie("user","$info",time()+$cookieusrtime);
	}
	
	if($op == "Reply") Header("Location: comments.php?op=Reply&pid=0&sid=$sid&mode=$cmode&order=$order&thold=$thold");
	
	$result = mysql_query("select aid, time, title, hometext, bodytext, topic, informant, notes FROM stories where sid=$sid");
	list($aid, $time, $title, $hometext, $bodytext, $topic, $informant, $notes) = mysql_fetch_row($result);
	mysql_query("UPDATE stories SET counter=counter+1 where sid=$sid");
	
	
	formatTimestamp($time);
	
        if (!strstr ($hometext, '<p') && !strstr ($hometext, '<table') && !strstr ($hometext, '<br') && !strstr($hometext, '<h'))
	    $hometext = stripslashes(str_replace ("\n", "<br />", $hometext));
        if (!strstr ($bodytext, '<p') && !strstr ($bodytext, '<table') && !strstr ($bodytext, '<br') && !strstr($bodytext, '<h'))
	    $bodytext = stripslashes(str_replace ("\n", "<br />", $bodytext));
	$notes = stripslashes($notes);
	$title = stripslashes($title);

	if($bodytext == "") $bodytext = "$hometext";
	else $bodytext = "<i>$hometext</i> <br /><br />$bodytext";
	
	if($informant == "") $informant = $anonymous;
	
	getTopics($sid);
	themearticle($aid, $informant, $datetime, $title, $bodytext, $topic, $topicname, $topicimage, $topictext);
	
	if($show_comments)
	{
		echo "<div align=\"center\"><a href=\"comments.php?op=Reply&amp;pid=0&amp;sid=$sid\">Send Your Comment</a></div><br />\n";
		navbar($sid, $title);
	}
	
	cookiedecode($user);
	
	if($cmode != "nocomments" && $show_comments)
	{
	  /* Handles comments corresponding to article */
	  include("comments.php");
	}
	
	/* Generates page footer */
	include ("footer.php");
}

##########################################################################
#  Function: navbar()                                                    #
#  Author:   phpNuke developers                                          #
#  Purpose:  Creates the navigation bar allowing users to sort and       #
#            refresh comments for an article.                            #
##########################################################################
function navbar($sid, $title)
{
	global $user, $cmode, $cthold, $corder;

	$query = mysql_query("select sid FROM comments where sid=$sid");
	if(!$query) $count = 0; else $count = mysql_num_rows($query);
	if(!isset($cthold)) $cthold=0;
	
	echo "
<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"2\">
	";

	if($title)
	{
		echo "<tr><td class=\"type6\" align=\"center\">\"$title\" | ";
		if($user)
		echo "<a href=\"user.php\">Configure</a>";
		else
		echo "<a href=\"user.php\">Login/Create Account</a>";
		echo " | $count comments</td></tr>";
	}
	
	?>
<tr>
	<td class="type4" align="center">
	<form method="post" action="article.php">
	Threshold<select name="new_thold">
	<option value="-1" <?PHP if ($cthold == -1) { echo "selected=\"selected\" "; } ?>>-1</option>
	<option value="0" <?PHP if ($cthold == 0) { echo "selected=\"selected\" "; } ?>>0</option>
	<option value="1" <?PHP if ($cthold == 1) { echo "selected=\"selected\" "; } ?>>1</option>
	<option value="2" <?PHP if ($cthold == 2) { echo "selected=\"selected\" "; } ?>>2</option>
	<option value="3" <?PHP if ($cthold == 3) { echo "selected=\"selected\" "; } ?>>3</option>
	<option value="4" <?PHP if ($cthold == 4) { echo "selected=\"selected\" "; } ?>>4</option>
	<option value="5" <?PHP if ($cthold == 5) { echo "selected=\"selected\" "; } ?>>5</option>
	</select>

	<select name="new_mode">
	<option value="nocomments" <?PHP if ($cmode == 'nocomments') { echo "selected=\"selected\" "; } ?>>No Comments</option>
	<option value="nested" <?php if($cmode == 'nested') echo "selected=\"selected\" "; ?>>Nested</option>
	<option value="flat" <?PHP if ($cmode == 'flat') { echo "selected=\"selected\" "; } ?>>Flat</option>
	<option value="threaded" <?PHP if(!isset($cmode) || $cmode=='threaded' || $cmode == '') echo "selected=\"selected\" ";  ?>>Threaded</option>
	</select>

	<select name="new_order">
	<option value="0" <?PHP if (!$corder) { echo "selected=\"selected\" "; } ?>>Oldest First</option>
	<option value="1" <?PHP if ($corder==1) { echo "selected=\"selected\" "; } ?>>Newest First</option>
	<option value="2" <?PHP if ($corder==2) { echo "selected=\"selected\" "; } ?>>Highest Scores First</option>
	</select>

	<input type="hidden" name="refresh" value="1" />
	<input type="hidden" name="sid" value="<?PHP echo "$sid"; ?>" />
	<input type="submit" value="Refresh" />
	</form></td>
</tr>
<tr>
	<td class="type6" align="center">
	The comments are owned by the poster. We are not responsible for its content.
	</td>
</tr>
</table>
<br /><br />
<?php
}
?>

