<?php
/**
 * Displays page identified by page_id according to selected layout.
 *
 * The layout to be used is fetched from the user_pages table in the 
 * database.
 *
 * @module layout
 * @modulegroup theme
 * @package phpWebSite
 * @todo CLEAN UP!
 */

/**
 * Global configuration file.
 */
include("config.php");

//Grab the layout for the current page: $page_id
$result_layout = mysql_query("select layout from user_pages where page_id='$page_id'");

list($layout) = mysql_fetch_row($result_layout);

switch($layout) {

 case (1):
   template1($page_id);
   break;

 case (2):
   template2($page_id);
   break;

 case (3):
   template3($page_id);
   break; 

 case (4):
   template4($page_id);
   break;

 case (5):
   template5($page_id);
   break;

 case (6):
   template6($page_id);
   break;
		
}

/**
 * Template 1
 *
 * @param int ID of page to be displayed.
 */
function template1($page_id) {
include("config.php");

  $getnum_sec = mysql_query("select num_sections, title from user_pages where page_id=$page_id");

  list($num_sections, $title) = mysql_fetch_row($getnum_sec);
  $title = stripslashes($title);

  echo"<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr><td class=\"type0\">
       <table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"8\">
       <tr>
          <td class=\"type4bigger\">
          $title
          </td>
       </tr>
       <tr>
	  <td class=\"type5\">
          <table width=\"100%\">";

  for($i=0; $i < $num_sections; $i++)
    {
      $j = $i+1;


      $result = mysql_query("select subtitle, text, image, alt, sub_active, text_active, image_active from page_content  where page_id=$page_id and level=$j");

      list($subtitle, $text, $image, $alt, $sub_active, $text_active, $image_active ) = mysql_fetch_row($result);

	$subtitle = stripslashes($subtitle);
	$text = stripslashes($text);
	
        if (!strstr ($text, '<p') && !strstr ($text, '<table') && !strstr ($text, '<br') && !strstr($text, '<h'))
	 	$text = str_replace ("\n" , "<br />", $text);

      if ($sub_active==0 and $text_active==0 and $image_active==0)
      {
      }
      else
      {
         echo "<tr>  
               <td class=\"type5\" width=\"90%\" valign=\"top\">";
         if ($sub_active==1)
         {
	      echo "<span class=\"boldtext\">$subtitle</span>";
         }
         if ($text_active==1)
         {
	      echo "<br />$text";
         }
         if ($image_active==1)
         {
            echo "</td><td class=\"type5\" valign=\"top\" align=\"center\"><img src=\"$user_images_webdir$image\" alt=\"$alt\" />";
         }
         echo "</td></tr>";
      }
    }
  echo "   </table>
            </td>
          </tr>
          </table>
          </td>
        </tr>
        </table>";
  }


/**
 * Template 2
 *
 * @param int ID of page to be displayed.
 */
function template2($page_id) {
include("config.php");

    $getnum_sec = mysql_query("select num_sections, title from user_pages where page_id=$page_id");

  list($num_sections, $title) = mysql_fetch_row($getnum_sec);
  $title = stripslashes($title);

  echo"<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr><td class=\"type0\">
       <table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"8\">
       <tr>
          <td class=\"type4bigger\">
          $title
          </td>
       </tr>
       <tr>
	  <td class=\"type5\">
          <table width=\"100%\">";

  for($i=0; $i < $num_sections; $i++)
    {
      $j = $i+1;


      $result = mysql_query("select subtitle, text, image, alt, sub_active, text_active, image_active from page_content  where page_id=$page_id and level=$j");

      list($subtitle, $text, $image, $alt, $sub_active, $text_active, $image_active ) = mysql_fetch_row($result);
      
      $subtitle = stripslashes($subtitle);
	$text = stripslashes($text);
	
        if (!strstr ($text, '<p') && !strstr ($text, '<table') && !strstr ($text, '<br') && !strstr($text, '<h'))
	 	$text = str_replace ("\n" , "<br />", $text);

      if ($sub_active==0 and $text_active==0 and $image_active==0){
      }
      else{
	

 echo "<tr><td class=\"type5\" width=\"10%\" valign=\"top\" align=\"center\">";
      if ($image_active==1){
	echo "<img src=\"$user_images_webdir$image\" alt=\"$alt\" />";
      }

      if ($sub_active==1 and $text_active==1){
	echo "</td><td class=\"type5\" valign=\"top\"><span class=\"boldtext\">$subtitle</span>
              <p>$text</p>";
      }
      if ($sub_active==0 and $text_active==1){
	echo "</td><td class=\"type5\" valign=\"top\"><p>$text</p>";
      }
      if ($sub_active==1 and $text_active==0){
	echo "</td><td class=\"type5\" valign=\"top\"><span class=\"boldtext\">$subtitle</span>";
      }
      echo "</td></tr>";
      }
    }
  echo "     </table>
            </td>
          </tr>
          </table>
          </td>
        </tr>
        </table>";

  }


/**
 * Template 3
 *
 * @param int ID of page to be displayed.
 */
function template3($page_id) {
include("config.php");

    $getnum_sec = mysql_query("select num_sections, title from user_pages where page_id=$page_id");

  list($num_sections, $title) = mysql_fetch_row($getnum_sec);
  $title = stripslashes($title);

  echo"<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr><td class=\"type0\">
       <table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"8\">
       <tr>
          <td class=\"type4bigger\">
          $title
          </td>
       </tr>
       <tr>
	  <td class=\"type5\">
          <table width=\"100%\">";
  for($i=0; $i < $num_sections; $i++)
    {
      $j = $i+1;


      $result = mysql_query("select subtitle, text, image, alt, sub_active, text_active, image_active from page_content  where page_id=$page_id and level=$j");

      list($subtitle, $text, $image, $alt, $sub_active, $text_active, $image_active ) = mysql_fetch_row($result);
      
      $subtitle = stripslashes($subtitle);
	$text = stripslashes($text);
	
        if (!strstr ($text, '<p') && !strstr ($text, '<table') && !strstr ($text, '<br') && !strstr($text, '<h'))
	 	$text = str_replace ("\n" , "<br />", $text);

      if ($sub_active==0 and $text_active==0 and $image_active==0){
      }
      else{
	
	echo "<tr>";

      if ($image_active==1){
	echo "<td class=\"type5\" width=\"10%\" valign=\"top\" align=\"center\">
              <img src=\"$user_images_webdir$image\" alt=\"$alt\" />";

      if ($sub_active==1 and $text_active==1){
	echo "</td><td class=\"type5\" valign=\"top\"><span class=\"boldtext\">$subtitle</span>
              <p>$text</p>";
      }
      if ($sub_active==0 and $text_active==1){
	echo "</td><td class=\"type5\" valign=\"top\"><p>$text</p>";
      }
      if ($sub_active==1 and $text_active==0){
	echo "</td><td class=\"type5\" valign=\"top\"><span class=\"boldtext\">$subtitle</span>";
      }
     }

      if ($image_active==0){
        if ($sub_active==1 and $text_active==1){
	echo "<td class=\"type5\" colspan=\"2\" valign=\"top\"><span class=\"boldtext\">$subtitle</span>
              <p>$text</p>";
      }
      if ($sub_active==0 and $text_active==1){
	echo "<td class=\"type5\" valign=\"top\" colspan=\"2\"><p>$text</p>";
      }
      if ($sub_active==1 and $text_active==0){
	echo "<td class=\"type5\" valign=\"top\" colspan=\"2\"><span class=\"boldtext\">$subtitle</span>";
      }
     }
      echo "</td></tr>";
    }
   }
  echo "     </table>
            </td>
          </tr>
          </table>
          </td>
        </tr>
        </table>";
  }


/**
 * Template 4
 *
 * @param int ID of page to be displayed.
 */
function template4($page_id) {
include("config.php");

    $getnum_sec = mysql_query("select num_sections, title from user_pages where page_id=$page_id");

  list($num_sections, $title) = mysql_fetch_row($getnum_sec);
  $title = stripslashes($title);

  echo"<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr><td class=\"type0\">
       <table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"8\">
       <tr>
          <td class=\"type4bigger\">
          $title
          </td>
       </tr>
       <tr>
	  <td class=\"type5\">
          <table width=\"100%\">";
  for($i=0; $i < $num_sections; $i++)
    {
      $j = $i+1;


      $result = mysql_query("select subtitle, text, image, alt, sub_active, text_active, image_active from page_content  where page_id=$page_id and level=$j");

      list($subtitle, $text, $image, $alt, $sub_active, $text_active, $image_active ) = mysql_fetch_row($result);
      
      $subtitle = stripslashes($subtitle);
	$text = stripslashes($text);
	
        if (!strstr ($text, '<p') && !strstr ($text, '<table') && !strstr ($text, '<br') && !strstr($text, '<h'))
	 	$text = str_replace ("\n" , "<br />", $text);

      if ($sub_active==0 and $text_active==0 and $image_active==0){
      }
      else{
	echo "<tr>";

      if ($image_active==1){

      if ($sub_active==1 and $text_active==1){
	echo "<td class=\"type5\" valign=\"top\"><span class=\"boldtext\">$subtitle</span>
              <p>$text</p>";
      }
      if ($sub_active==0 and $text_active==1){
	echo "<td class=\"type5\" valign=\"top\"><p>$text</p>";
      }
      if ($sub_active==1 and $text_active==0){
	echo "<td class=\"type5\" valign=\"top\"><span class=\"boldtext\">$subtitle</span>";
      }

        echo "</td><td class=\"type5\" width=\"10%\" valign=\"top\" align=\"center\">
              <img src=\"$user_images_webdir$image\" alt=\"$alt\" />";
      }

      if ($image_active==0)
      {

        if ($sub_active==1 and $text_active==1)
        {
          echo "<td class=\"type5\" colspan=\"2\" valign=\"top\"><span class=\"boldtext\">$subtitle</span>
                <p>$text</p>";
        }
        if ($sub_active==0 and $text_active==1)
        {
	    echo "<td class=\"type5\" valign=\"top\" colspan=\"2\"><p>$text</p>";
        }
        if ($sub_active==1 and $text_active==0)
        {
	    echo "<td class=\"type5\" valign=\"top\" colspan=\"2\"><span class=\"boldtext\">$subtitle</span>";
        }
      }
      echo "</td></tr>";
    }
   }
  echo "     </table>
            </td>
          </tr>
          </table>
          </td>
        </tr>
        </table>";
  }

/**
 * Template 5
 *
 * @param int ID of page to be displayed.
 */
function template5($page_id) {
include("config.php");

  $getnum_sec = mysql_query("select num_sections, title from user_pages where page_id=$page_id");

  list($num_sections, $title) = mysql_fetch_row($getnum_sec);
  $title = stripslashes($title);

  echo"<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr><td class=\"type0\">
       <table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"8\">
       <tr>
          <td class=\"type4bigger\">
          $title
          </td>
       </tr>
       <tr>
	  <td class=\"type5\">
          <table width=\"100%\">";

  $m=0;

  for($i=0; $i < $num_sections; $i++)
  {
     $j = $i+1;

     $result = mysql_query("select subtitle, text, image, alt, sub_active, text_active, image_active from page_content  where page_id=$page_id and level=$j");

     list($subtitle, $text, $image, $alt, $sub_active, $text_active, $image_active ) = mysql_fetch_row($result);
     
     $subtitle = stripslashes($subtitle);
	$text = stripslashes($text);
	
     if (!strstr ($text, '<p') && !strstr ($text, '<table') && !strstr ($text, '<br') && !strstr($text, '<h'))
	 	$text = str_replace ("\n" , "<br />", $text);

     if ($sub_active==0 and $text_active==0 and $image_active==0){
     } // start if A
     else
     { // start else A

         $even_odd = $m % 2;

         echo "<tr>";
	
         if ($even_odd==0)
         {
            if ($image_active==1)
            {
	         $m++;

               echo "<td class=\"type5\" colspan=\"2\">
                     <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\"><tr>
                     <td class=\"type5\" valign=\"top\">";
	
               if ($sub_active==1 and $text_active==1)
               {
                  echo "<td class=\"type5\" valign=\"top\"><span class=\"boldtext\">$subtitle</span>
                        <p>$text</p>";
               }

               if ($sub_active==0 and $text_active==1)
               {
                  echo "<tr><td class=\"type5\" valign=\"top\"><p>$text</p>";
               }

               if ($sub_active==1 and $text_active==0)
               {
                  echo "<tr><td class=\"type5\" valign=\"top\"><span class=\"boldtext\">$subtitle</span>";
               }

               echo "</td><td class=\"type5\" width=\"10%\" valign=\"top\">
                     <img src=\"$user_images_webdir$image\" alt=\"$alt\" />
                     </td></tr></table>";
            }// end if image active
         } //end even odd if

         else
         { // start even odd if else
            if ($image_active==1)
            {
               $m++;
               echo "<td class=\"type5\" colspan=\"2\">
                     <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\"><tr>
                     <td class=\"type5\" width=\"10%\" valign=\"top\" align=\"center\">
                     <img src=\"$user_images_webdir$image\" alt=\"$alt\" />";	
               if ($sub_active==1 and $text_active==1)
               {
	            echo "
                     </td>
                     <td class=\"type5\" valign=\"top\" width=\"90%\">
                     <span class=\"boldtext\">$subtitle</span>
                     <p>$text</p>
                     </td></tr></table>";
               }
               if ($sub_active==0 and $text_active==1)
               {
                  echo "
                     </td>
                     <td class=\"type5\" valign=\"top\">
                     <p>$text</p>
                     </td></tr></table>";
               }

            } //end image active if

            if ($sub_active==1 and $text_active==0)
            {
	        echo "</td>
                    <td class=\"type5\" valign=\"top\"><span class=\"boldtext\">$subtitle</span>
                    </td></tr></table>";
            }
         } // end even odd if else 

         if ($image_active==0)
         {
           if ($sub_active==1 and $text_active==1)
           {
	       echo "
              <td class=\"type5\" colspan=\"2\" valign=\"top\">
              <span class=\"boldtext\">$subtitle</span>
              <p>$text</p>";
           }
           if ($sub_active==0 and $text_active==1)
           {
	       echo "<td class=\"type5\" valign=\"top\" colspan=\"2\"><p>$text</p>";
           }
           if ($sub_active==1 and $text_active==0)
           {
	       echo "<td class=\"type5\" valign=\"top\" colspan=\"2\">
                   <span class=\"boldtext\">$subtitle</span>";
           }
         }
         echo "</td></tr>";

      } //end else A

  } // end for loop


  echo "     </table>
            </td>
          </tr>
          </table>
          </td>
        </tr>
        </table>";
}

/**
 * Template 6
 *
 * @param int ID of page to be displayed.
 */
function template6($page_id) {
include("config.php");

  $getnum_sec = mysql_query("select num_sections, title from user_pages where page_id=$page_id");

  list($num_sections, $title) = mysql_fetch_row($getnum_sec);
  $title = stripslashes($title);

  echo"<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr><td class=\"type0\">
       <table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"8\">
       <tr>
          <td class=\"type4bigger\">
          $title
          </td>
       </tr>
       <tr>
	  <td class=\"type5\">
          <table width=\"100%\">";

  $m=0;

  for($i=0; $i < $num_sections; $i++)
  {
    $j = $i+1;

    $result = mysql_query("select subtitle, text, image, alt, sub_active, text_active, image_active from page_content  where page_id=$page_id and level=$j");

    list($subtitle, $text, $image, $alt, $sub_active, $text_active, $image_active ) = mysql_fetch_row($result);
    
    $subtitle = stripslashes($subtitle);
	$text = stripslashes($text);
	
    if (!strstr ($text, '<p') && !strstr ($text, '<table') && !strstr ($text, '<br') && !strstr($text, '<h'))
	 	$text = str_replace ("\n" , "<br />", $text);

    if ($sub_active==0 and $text_active==0 and $image_active==0)
    {
    } //start if A
    else
    { //start else if A

      $even_odd = $m % 2;

      echo "<tr>";
	
      if ($even_odd==1)
      { 
        if ($image_active==1)
        { 
	    $m++;
          echo "<td class=\"type5\" colspan=\"2\">
                <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\">
                <tr>
                <td class=\"type5\" valign=\"top\">";
	
        if ($sub_active==1 and $text_active==1)
        {
	    echo "<tr>
                <td class=\"type5\" valign=\"top\">
                <span class=\"boldtext\">$subtitle</span>
                <p>$text</p>";
        }

        if ($sub_active==0 and $text_active==1)
        {
	    echo "<tr><td class=\"type5\" valign=\"top\"><p>$text</p>";
        }

        if ($sub_active==1 and $text_active==0)
        {
	    echo "<tr>
                <td class=\"type5\" valign=\"top\">
                <span class=\"boldtext\">$subtitle</span>";
        }

        echo "</td><td class=\"type5\" width=\"10%\" valign=\"top\" align=\"center\">
              <img src=\"$user_images_webdir$image\" alt=\"$alt\" />
              </td></tr></table>";
	} //end image active if

    } //end even odd if

    else
    { //start even odd else if

      if ($image_active==1)
      {
        $m++;

        echo "<td class=\"type5\" colspan=\"2\">
              <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\"><tr>
              <td class=\"type5\" width=\"10%\" valign=\"top\" align=\"center\">
              <img src=\"$user_images_webdir$image\" alt=\"$alt\" />";	

        if ($sub_active==1 and $text_active==1)
        {
	    echo "</td><td class=\"type5\" valign=\"top\" width=\"90%\">
                <span class=\"boldtext\">$subtitle</span>
                <p>$text</p>
                </td></tr></table>";
        }

        if ($sub_active==0 and $text_active==1)
        {
	    echo "</td><td class=\"type5\" valign=\"top\"><p>$text</p>
                </td></tr></table>";
        }
      } // end image active if

      if ($sub_active==1 and $text_active==0)
      {
	  echo "</td><td class=\"type5\" valign=\"top\">
              <span class=\"boldtext\">$subtitle</span>
              </td></tr></table>";
      }

    } // end even odd else if

    if ($image_active==0)
    {
      if ($sub_active==1 and $text_active==1)
      {
        echo "<td class=\"type5\" colspan=\"2\" valign=\"top\">
              <span class=\"boldtext\">$subtitle</span>
              <p>$text</p>";
      }
      if ($sub_active==0 and $text_active==1)
      {
        echo "<td class=\"type5\" valign=\"top\" colspan=\"2\"><p>$text</p>";
      }
      if ($sub_active==1 and $text_active==0)
      {
	  echo "<td class=\"type5\" valign=\"top\" colspan=\"2\">
              <span class=\"boldtext\">$subtitle</span>";
      }
    }
    echo "</td></tr>";
  }
 } // end for loop

  echo "     </table>
            </td>
          </tr>
          </table>
          </td>
        </tr>
        </table>";
}

?>
