<?php
/**
 * Display user created pages.
 *
 * This file is used to display pages created by the user. To see the
 * "real" HTML creating the page, take a look at layout.php.
 *
 * @module content
 * @modulegroup content_handling
 * @package phpWebSite
 */

session_start();
if (!$PHPSESSID){
	session_register("admintest");
	session_register("current_admin");
}else if ((!$admintest) || (!$current_admin)){
	session_register("admintest");
	session_register("current_admin");
}
global $admintest, $current_admin;

if(!isset($mainfile))
{
  /**
   * Defines core functions.
   */
  include("mainfile.php");
}

/**
 * Generates page header.
 */
include ("header.php");

if ($admintest)
{
	echo"<span class=\"onebiggerred\">&gt;</span>&nbsp;
	<a href=\"admin.php?op=edit_page&amp;page_id=$page_id\">Edit This Page</a>";
}

/**
 * Actual layout engine.
 */
include ("layout.php");

/**
 * Generates page footer.
 */
include ("footer.php");
?>
