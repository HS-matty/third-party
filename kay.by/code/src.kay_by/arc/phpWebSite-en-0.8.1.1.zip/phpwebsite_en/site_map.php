<?php

if(!isset($mainfile))
{
  include("mainfile.php");
}
include("open_session.php");

include ('header.php');
$box_title = "Site Map";

$result = mysql_query("select menu_id, menu_text, menu_url, menu_order, page_id from menu where menu_level = 1 && menu_active = 1 order by menu_order");

      
  
	while(list($menu_id, $menu_text, $menu_url, $menu_order, $page_id) = mysql_fetch_row($result))
	{
		$temp = explode(":", $menu_url);
		if($temp[0] == "http")
		{
		        $box_stuff .= "$menu_bullet" . "<a href=\"$menu_url\" target=\"_blank\">$menu_text</a><br />\n";
		}
		else if($page_id)
		{
			if($menu_url == 'mod.php?mod=userpage')
			$box_stuff .= "$menu_bullet<a href=\"$menu_url&amp;menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
			else
			$box_stuff .= "$menu_bullet<a href=\"$menu_url?menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
		}
		else $box_stuff .= "$menu_bullet<a href=\"$menu_url\">$menu_text</a><br />";
      
		$low_sub = $menu_id * 100;
		$high_sub = $low_sub + 99;

		$result_sub = mysql_query("select menu_id, menu_text, menu_url, menu_order, page_id from menu where menu_level = 2 && menu_active = 1 && menu_id >=  $low_sub && menu_id <=  $high_sub order by menu_order");
      
		while(list($menu_id, $menu_text, $menu_url, $menu_order, $page_id) = mysql_fetch_row($result_sub))
		{
			$temp = explode(":", $menu_url);
			if($temp[0] == "http")
			{
				$box_stuff .= "&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url\" target=\"_blank\">$menu_text</a><br />\n";
			}
			else if($page_id)
			{
				if($menu_url == 'mod.php?mod=userpage')
				$box_stuff .= "&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url&amp;menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
				else
				$box_stuff .= "&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url?menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
			}
			else $box_stuff .= "&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url\">$menu_text</a><br />";
			
			$low_sub = $menu_id * 100;
			$high_sub = $low_sub + 99;
	  
			$result_sub2 = mysql_query("select menu_id, menu_text, menu_url, menu_order, page_id from menu where menu_level = 3 && menu_active = 1 && menu_id >=  $low_sub && menu_id <=  $high_sub order by menu_order");
	  
			while(list($menu_id, $menu_text, $menu_url, $menu_order, $page_id) = mysql_fetch_row($result_sub2))
			{
				$temp = explode(":", $menu_url);
				if($temp[0] == "http")
				{
					$box_stuff .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url\" target=\"_blank\">$menu_text</a><br />\n";
				}
				else if($page_id)
				{
					if($menu_url == 'mod.php?mod=userpage')
					$box_stuff .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url&amp;menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
					else
					$box_stuff .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url?menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
				}
				else $box_stuff .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url\">$menu_text</a><br />";
			}
		}
	}

themesidebox($box_title, $box_stuff);
include ('footer.php');

?>
