<?php

function themeplugin($title, $content)
{
	include("config.php");
	echo "
<!-- Start themeplugin -->
	<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"4\">
	<tr>
		<td class=\"boxtop\" width=\"100%\">$title</td>
	</tr>
	<tr>
		<td>$content</td>
	</tr>
	</table>
	<br />";
}

function themeindex ($aid, $informant, $time, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext){
	include("config.php");
	if ($url_to_email){
		$format_aid = mysql_query("SELECT email FROM authors where aid='$aid'");
		list($email) = mysql_fetch_row($format_aid);
		if ($email)
			$new_aid = "<a href=\"mailto:$email\">$aid</a>";
		else
			$new_aid = "<a href=\"mailto:$adminmail\">$aid</a>";
	} else {
		$format_aid = mysql_query("SELECT url FROM authors where aid='$aid'");
		list($url) = mysql_fetch_row($format_aid);
		if ($url){
			if (!strstr($url, "http://"))
				$url = "http://".$url;
			$new_aid = "<a href=\"$url\" target=\"_blank\">$aid</a>";
		} else
			$new_aid = "<a href=\"$nuke_url\" target=\"_blank\">$aid</a>";

	}

	if ("$aid" == "$informant") {
		$article_title = "$title<br />
<span class=\"smalltype\">Posted by $new_aid on: $time $timezone (read: $counter times)</span>";

		$content = "<a href=\"topics.php?op=viewtopic&amp;topic=$topic\">";

		if($topicimage){
			$imagehw =GetImageSize("$tipath$topicimage");
			$image_size = $imagehw[3];	
			$content .= "<img src=\"$tipath$topicimage\" border=\"0\" $image_size alt=\"$topictext\" align=\"right\" hspace=\"4\" />";
		}else{
			$imagehw =GetImageSize("$tipath$default_topic_image");
			$image_size = $imagehw[3];
			$content .= "<img src=\"$tipath$default_topic_image\" $image_size border=\"0\" alt=\"$topictext\" align=\"right\" hspace=\"4\" />";
		}

		$content .= "
		</a>$thetext<br /><br />
	</td>
</tr>
<tr>
<td align=\"right\">";

		$content .= $morelink;
		thememainbox($article_title, $content);
	} else {
		if($informant != "")
			$boxstuff = "<a href=\"user.php?op=userinfo&amp;uname=$informant\">$informant</a>";
		else
			$boxstuff = "$anonymous";

		$boxstuff .= " writes:<i>\"$thetext\"</i>$notes";

		$format_aid = mysql_query("SELECT url FROM authors where aid='$aid'");
		list($url) = mysql_fetch_row($format_aid);
		if ($url)
			$aid = "<a href=\"$url\" target=\"_blank\">$aid</a>";

		$article_title = "$title<br /><span class=\"smalltype\">Posted by $aid on: $time $timezone (read: $counter times)</span>";
	
		$content = "<a href=\"topics.php?op=viewtopic&amp;topic=$topic\">";

		if($topicimage){
			$imagehw =GetImageSize("$tipath$topicimage");
			$image_size = $imagehw[3];
			$content .= "<img src=\"$tipath$topicimage\" border=\"0\" $image_size alt=\"$topictext\" align=\"right\" hspace=\"4\" />";
		}else{
			$imagehw =GetImageSize("$tipath$default_topic_image");
			$image_size =$imagehw[3];
			$content .= "<img src=\"$tipath$default_topic_image\" border=\"0\" $image_size alt=\"$topictext\" align=\"right\" hspace=\"4\" />";
		}

		$content .= "</a>$boxstuff<br /><br />
	</td>
</tr>
<tr>
	<td align=\"right\">";

		$content .= $morelink;
		thememainbox($article_title, $content);
#### Never put a break here again ####
	}
}

function themearticle ($aid, $informant, $datetime, $title, $thetext, $topic, $topicname, $topicimage, $topictext){

	global $admin, $sid;
	include("config.php");

	if ("$aid" == "$informant") {
		$article_title = "$title<br /><span class=\"smalltype\">Posted on $datetime | <a href=\"friend.php?op=FriendSend&amp;sid=$sid\"><img src=\"images/friend.gif\" border=\"0\" align=\"middle\" alt=\"Send this story to a friend\" /></a></span>";

		if ($admin) {
			$article_title .= "&nbsp;&nbsp;</span>[<a href=\"admin.php?op=EditStory&amp;sid=$sid\">Edit</a>|<a href=\"admin.php?op=RemoveStory&amp;sid=$sid\">Delete</a>]";
		}

		$content = "<a href=\"topics.php?op=viewtopic&amp;topic=$topic\">";

		if($topicimage){
			$image_hw =GetImageSize("$tipath$topicimage");
			$image_size = $image_hw[3];
			$content .= "<img src=\"$tipath$topicimage\" border=\"0\" $image_size alt=\"$topictext\" align=\"right\" hspace=\"4\" />";
		}else{
			$imagehw =GetImageSize("$tipath$default_topic_image");
			$image_size =$imagehw[3];
			$content .= "<img src=\"$tipath$default_topic_image\" $image_size border=\"0\" alt=\"$topictext\" align=\"right\" hspace=\"4\" />";
		}

		$content .= "</a>$thetext";

		themearticlebox($article_title, $content);
		echo "<br />";
	} else {
		if($informant != "")
			$informant = "<a href=\"user.php?op=userinfo&amp;uname=$informant\">$informant</a>";
		else
			$boxstuff = "$anonymous";

		$boxstuff .= " writes:<br /><i>\"$thetext\"</i>$notes";

		$article_title = "$title<br />Contributed by $informant on: $datetime";

		global $admin, $sid;

		if ($admin){
			$article_title .= "&nbsp;&nbsp;[<a href=\"admin.php?op=EditStory&amp;sid=$sid\">Edit</a>|<a href=\"admin.php?op=RemoveStory&amp;sid=$sid\">Delete</a>]";
		}

		$content = "<a href=\"topics.php?op=viewtopic&amp;topic=$topic\">";

		if($topicimage){
			$imagehw =GetImageSize("$tipath$topicimage");
			$image_size = $imagehw[3];
			$content .= "<img src=\"$tipath$topicimage\" $image_size border=\"0\" alt=\"$topictext\" align=\"right\" hspace=\"4\" />";
		}else{
			$imagehw =GetImageSize("$tipath$default_topic_image");
			$image_size =$imagehw[3];
			$content .= "<img src=\"$tipath$default_topic_image\" $image_size border=\"0\" alt=\"$topictext\" align=\"right\" hspace=\"4\" />";
		}

		$content .= "</a>$thetext";

		themearticlebox($article_title, $content);
		echo "<br />";
	}
}

function themepollbox($title, $content)
{
	include("config.php");
	global $pollTitle;
	echo "
<!-- Start themeplugin -->
	<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"4\">
	<tr>
		<td class=\"boxtop\" width=\"100%\">$title</td>
	</tr>
	<tr>
		<td>$content</td>
	</tr>
	</table>
	<br />";
}


function themesidebox($title, $content)
{
	include("config.php");
	echo "
<!-- Start themeplugin -->
	<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"4\">
	<tr>
		<td class=\"article-top\" style=\"background-color : #e0e0e0\" width=\"100%\">$title</td>
	</tr>
	<tr>
		<td>$content</td>
	</tr>
	</table>
	<br />";
}

function themeleftbox($title, $content)
{
	include("config.php");
	echo "
<!-- Start themeplugin -->
	<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"4\">
	<tr>
		<td class=\"boxtop\" width=\"100%\">$title</td>
	</tr>
	<tr>
		<td>$content</td>
	</tr>
	</table>
	<br />";
}

function thememainbox($title, $content)
{
	include("config.php");
	echo "
	<table width=\"100%\" border=\"0\" cellspacing=\"2\" cellpadding=\"4\">
	<tr>
		<td class=\"article-top\" style=\"background-color : #e0e0e0\">$title</td>
	</tr>
	<tr>
	<td class=\"white\">$content</td>
	</tr>
	</table><br />";
}

function themearticlebox($title, $content)
{
	include("config.php");
	echo "
	<table width=\"100%\" border=\"0\" cellspacing=\"5\" cellpadding=\"4\">
	<tr>
		<td width=\"99%\" class=\"article-top\" style=\"background-color : #e0e0e0\">$title</td>
	</tr>
	<tr>
		<td>$content</td>
	</tr>
	</table><br />";
}

?>
