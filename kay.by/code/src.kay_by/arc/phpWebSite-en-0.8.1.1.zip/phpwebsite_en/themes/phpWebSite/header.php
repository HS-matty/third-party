<?php
###################################################
# Theme design:
# Matthew McNaney, Brian Brown
# Appalachian State University
#
###################################################

include("config.php");
$LeftBlocks = mysql_query("select title, content from lblocks order by order_id");

echo "<!-- BEGIN: File: /themes/phpWebSite/header.php -->";
?>
<head>
	<title>
		<?php include("config.php"); echo $sitename; if($titletag) echo" - $titletag"; ?>
	</title>
	<link rel="stylesheet" href="./themes/phpWebSite/style.css" type="text/css" />
	<meta http-equiv="Content-Type" content="text/html;charset=ISO-8859-1" />
</head>
<body>
<table border="0" cellpadding="0" cellspacing="0" width="100%" summary="Layout table" class="white">
<tr>
	<td class="leftside" width="9%" valign="top" align="center">
		<table cellpadding="0" cellspacing="0" width="100%" border="0">
		<tr>
			<td>
				<br />
				<div align="center">
				<a href="http://www.appstate.edu"><img src="themes/phpWebSite/img/ASULogo.gif" width="150" height="48" alt="Appalachian State University" border="0" /></a>
				</div>
				<br />
				<br />
				<table width="100%" border="0" cellspacing="1" cellpadding="3">
				<tr>
					<td class="boxtop" width="100%" >
						Main Menu
					</td>
				</tr>
				<tr>
					<td class="menu">
						<?php include ('menu.php'); ?>
	<form action="search.php" method="post">
	Search:
	<input type="text" size="18" name="query" />
	</form>
					</td>
				</tr>
				</table>
				<br />
<?php 
global $admintest;

if ($admintest)
{
	$AdminBlock = mysql_query("select title, content from adminblock");
	list($title, $content) = mysql_fetch_row($AdminBlock);
	themeleftbox($title, $content);
}
plug_check (1);

if(!$user && $login_switch) { 

	//This is the Career theme so the USER LOGIN BLOCK is being printed.

$title = "$sitename  Login";
$content = "
				<form action=\"user.php\" method=\"post\">
					Nickname:
					<input type=\"text\" name=\"uname\" size=\"12\" maxlength=\"25\" />
					<br />
					Password:
					<input type=\"password\" name=\"pass\" size=\"12\" maxlength=\"20\" />
					<br />
					<div align=\"center\">
						<input type=\"submit\" name=\"op\" value=\"login\" />
					</div>
				</form>
				If you do not have an account yet <a href=\"user.php\">Create One</a>.

<!-- As registered user you have some advantages like theme manager, comments configuration and post comments with your name.-->";

themeleftbox($title, $content);
}
?>
<!--Start Event Code -->
<!-- Show Left Blocks -->

<?php
$LeftBlocks = mysql_query("select title, content from lblocks ORDER BY order_id");
while(list($title, $content) = mysql_fetch_row($LeftBlocks)){
	$content = str_replace("\n", "<br />", $content);
	themeleftbox($title, $content); 
}
?>
			</td>
		</tr>
		</table>
	</td>
	<td class="leftshade" width="1%" valign="bottom">
<!-- <img src="themes/career/img/btmleft.gif" width="19" height="19" alt="." border="0">-->
&nbsp;
</td>
	<td valign="top" width="80%">
		<table cellpadding="0" cellspacing="0" width="100%" border="0">
		<tr>
			<td colspan="2" valign="top">
				<table border="0" cellspacing="0" cellpadding="6" width="100%" summary="Data for Introduction">
				<tr>
					<td><img src="themes/phpWebSite/img/trans.gif" width="1" height="50" alt="." border="0" /></td>
					<td valign="top" width="99%" class="titlebox-left" align="right">
					<img src="themes/phpWebSite/img/phpwblogo.gif" border="0" align="top" alt="phpWebSite - Open Source, Community-Driven WebWare" /></td></tr>
				<tr>
					<td>&nbsp;</td>
					<td align="right"><b>| <a href="http://phpwebsite.appstate.edu/">Core</a> | <a href="http://phpwsthemes.sourceforge.net/">Themes</a> | <a href="http://phpwsplugins.sourceforge.net/">Plug-Ins</a> |</b>
					</td>
				</tr>
				</table>
				<hr />
			</td>
		</tr>
		<tr>
			<td valign="top">
				<table border="0" cellspacing="4" cellpadding="6" width="100%" summary="Data for Introduction">
				<tr>
					<td>

<!-- End of header.php file -->
