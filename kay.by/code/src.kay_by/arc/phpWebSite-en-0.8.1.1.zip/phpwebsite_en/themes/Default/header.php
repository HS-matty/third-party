<head>
<title><?php echo $sitename; if($titletag) echo" - $titletag"; ?></title>
<link rel="stylesheet" href="themes/Default/style.css" type="text/css" />
<meta http-equiv="Content-Type" content="text/html;charset=ISO-8859-1" />
</head>
<body>

<table border="0" cellpadding="1" cellspacing="8" width="100%" align="center" summary="Border for WebSite">
<tr>
	<td class="type0">
<table border="0" cellspacing="0" cellpadding="0" width="100%" summary="Border for Introduction">
<tr>
	<td class="type1">
<table border="0" cellspacing="0" cellpadding="3" width="100%" summary="Data for Introduction">
<tr>
	<td class="type1">
<?php
	$size = GetImageSize ("themes/Default/deflogo.gif");
?>
	<a href="/"><img src="themes/Default/deflogo.gif" 
alt="Welcome to <?php echo "$sitename"; ?>" <?php 
echo $size[3]; ?> border="0" /></a>
	</td>

	<td class="type1small" align="right">
	<form action="search.php" method="post">
	Search:
	<input type="text" name="query" />
	</form>
	</td>
</tr>
<tr>
	<td class="type2" colspan="2">
	<?php echo "$titlebar" ?>
	</td>
</tr>
</table>
	</td>
</tr>
</table>
	</td>
</tr>
<tr>
	<td class="type3" valign="top">
<table border="0" cellspacing="0" cellpadding="2" width="100%" summary="Data for Website">
<tr>
	<td class="type3" valign="top" width="<?php echo "$block_percent"; ?>%">
<?php

echo "
<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" summary=\"Border for Main Menu\">
<tr>
	<td class=\"type0\">
<table width=\"100%\" cellpadding=\"5\" cellspacing=\"1\" border=\"0\" summary=\"Data for Main Menu\">
<tr>
	<td class=\"type4\">Main Menu</td>
</tr>
<tr>
	<td class=\"type5\">";

include ('menu.php');

echo "</td></tr></table></td></tr></table><br />";
	if ($admintest == $security_hash)
	{
		$AdminBlock = mysql_query("select title, content from adminblock");
		list($title, $content) = mysql_fetch_row($AdminBlock);
		themesidebox($title, $content);
	}

plug_check(1);
?>

<?php if(!$user && $login_switch) {
	//This is the Default theme so the USER LOGIN BLOCK is being printed.
	$title = "$sitename  Login";
	$content = "<form action=\"user.php\" method=\"post\">
	Nickname: <input type=\"text\" name=\"uname\" size=\"12\" maxlength=\"25\" /><br />
	Password: <input type=\"password\" name=\"pass\" size=\"12\" maxlength=\"20\" /><br />
	<div align=\"center\">
	<input type=\"submit\" name=\"op\" value=\"login\" />
	</div></form>
	If you do not have an account yet 
	<a href=\"user.php\">Create One</a>. 
<!-- As registered user you have some advantages like theme manager, comments configuration and post comments with your name.-->";
	themesidebox($title, $content);
}

	$LeftBlocks = mysql_query("select title, content from lblocks order by order_id");
	while(list($title, $content) = mysql_fetch_row($LeftBlocks))
	{
		$content = str_replace("\n", "<br />", $content);
		themesidebox($title, $content); 
	}

?>
</td>
<td class="type3" valign="top" align="left">
