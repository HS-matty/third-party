<?php
echo "\n<!-- BEGIN: File: themes/foo/footer.php -->\n";

	include('config.php');

	if ($index == 1)
	{
		$col_begin = "</td><td class=\"type3\" valign=\"top\" width=\"$block_percent%\">";
		$flag_begin = "0";

		//Survey Block
		$result = mysql_query("select flag from mod_poll_flag");
		list($active) = mysql_fetch_row($result);
		
		if($active)
		{
			include("./mod/poll/poll_functions.php");

			echo "$col_begin";
			$flag_begin = "1";
			poll_show();
		}

		//User Block
		if($cookie[8])
		{
			if ($user_dblocation)
			{
				@mysql_select_db("$user_dbname") or die ("Unable to select database");
				$getblock = mysql_query("select ublock from users where uid='$cookie[0]'");
				@mysql_select_db("$dbname") or die ("Unable to select database");
			}
			else
			{
				$getblock = mysql_query("select ublock from users where uid='$cookie[0]'");	
			}
			$title = "Menu for $cookie[1]";
			list($ublock) = mysql_fetch_row($getblock);
			
			if($flag_begin == "0")
			{
				echo "$col_begin";
				$flag_begin = "1";
			}
			themesidebox($title, $ublock);
    		}
		
		//Added Right Blocks
		plug_check(3);
		$result = mysql_query("select title, content from rblocks order by order_id");

		while(list($title, $content) = mysql_fetch_array($result))
		{
			if ($flag_begin == "0")
			{
				echo "$col_begin";
				$flag_begin = "1";
			}
			$content = str_replace("\n", "<br />", $content);
			themesidebox($title, $content);
		}

		//Old News Block
		$boxstuff = "";
		$boxTitle = "Past Articles";
		$result = mysql_query("select sid, title, time, comments from stories order by time desc limit $storynum, $oldnum");
		while(list($sid, $title, $time) = mysql_fetch_row($result))
		{
			if ($title != "")
				$doitman = "yes";

			$count1 = "0";
			setlocale ("LC_TIME", "$locale");
			ereg ("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2}) ([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2})", $time, $datetime2);
			$datetime2 = strftime("%B %d", mktime($datetime2[4],$datetime2[5],$datetime2[6],$datetime2[2],$datetime2[3],$datetime2[1]));
			$datetime2 = ucfirst($datetime2);

			if ($datetime2 != $time2)
				  $boxstuff .= "$datetime2<br />";

			$boxstuff .= "<a href=\"article.php?sid=$sid\">$title";
			$boxstuff .= "</a><br /><br />";
			$time2 = $datetime2;
		}

		if ($doitman == "yes") {
			if ($flag_begin == "0"){
				echo "$col_begin";
				$flag_begin = "1";
			}
			themesidebox($boxTitle, $boxstuff);
		}
}
?>
</td>
</tr>
</table>
</td>
</tr>
</table>
