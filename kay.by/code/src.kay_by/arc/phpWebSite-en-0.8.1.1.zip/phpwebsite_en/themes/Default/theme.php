<?php

function themeplugin($title, $content)
{
	include("config.php");
	echo "
<!-- Start themeplugin -->
<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" summary=\"Border for Generic Block\">
<tr>
	<td class=\"type0\">
<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\" summary=\"Data for Generic Block\">
<tr>
	<td class=\"type4\">
	$title
	</td>
</tr>
<tr>
	<td class=\"type5\">
	$content
	</td>
</tr>
</table>
	</td>
</tr>
</table>
<br />
";
}


function themeindex ($aid, $informant, $time, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
	include("config.php");

	if ($url_to_email){
		$format_aid = mysql_query("SELECT email FROM authors where aid='$aid'");
		list($email) = mysql_fetch_row($format_aid);
		if ($email)
			$new_aid = "<a href=\"mailto:$email\">$aid</a>";
		else
			$new_aid = "<a href=\"mailto:$adminmail\">$aid</a>";
	} else {
		$format_aid = mysql_query("SELECT url FROM authors where aid='$aid'");
		list($url) = mysql_fetch_row($format_aid);
		if ($url){
			if (!strstr($url, "http://"))
				$url = "http://".$url;
			$new_aid = "<a href=\"$url\" target=\"_blank\">$aid</a>";
		} else
			$new_aid = "<a href=\"$nuke_url\" target=\"_blank\">$aid</a>";

	}

	if ("$aid" == "$informant") {
	$article_title = "<span class=\"boldtext\"> $title </span><br />
	Posted by $new_aid on: $time $timezone (read: $counter times)";

	$content = "<a href=\"topics.php?op=viewtopic&amp;topic=$topic\">";
		if($topicimage)
		$content .= "<img src=\"$tipath$topicimage\" border=\"0\" alt=\"$topictext\" align=\"right\" hspace=\"4\" />";
		else
		$content .= "<img src=\"$tipath$default_topic_image\" border=\"0\" alt=\"$topictext\" align=\"right\" hspace=\"4\" />";
	$content .= "</a>$thetext<br /><br /></td></tr><tr><td class=\"type4\" align=\"right\">";
	$content .= $morelink;
	themesidebox($article_title, $content);


	} else {
	if($informant != "") $boxstuff = "<a href=\"user.php?op=userinfo&amp;uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "writes: <i>\"$thetext\"</i> $notes";

	$article_title = "<span class=\"type4bigger\">$title</span><br />
	Posted by $new_aid on: $time $timezone (read: $counter times)";

	$content = "<a href=\"topics.php?op=viewtopic&amp;topic=$topic\">";
		if($topicimage)
		$content .= "<img src=\"$tipath$topicimage\" border=\"0\" alt=\"$topictext\" align=\"right\" hspace=\"4\" />";
		else
		$content .= "<img src=\"$tipath$default_topic_image\" border=\"0\" alt=\"$topictext\" align=\"right\" hspace=\"4\" />";
	$content .= "</a>$boxstuff<br /><br /></td></tr><tr><td class=\"type4\" align=\"right\">";
	$content .= $morelink;
	themesidebox($article_title, $content);
#### Never put a break here again ####
	}
    }

function themearticle ($aid, $informant, $datetime, $title, $thetext, $topic, $topicname, $topicimage, $topictext) {
	global $admintest, $sid;
	include("config.php");

	if ("$aid" == "$informant") {
		$article_title = "<span class=\"boldtext\">$title</span><br />
	Posted on $datetime | <a href=\"friend.php?op=FriendSend&sid=$sid\"><img src=\"images/friend.gif\" border=\"0\" align=\"middle\" alt=\"Send this story to a friend\"></a>&nbsp;|&nbsp;<a href=\"article.php?op=Print&sid=$sid\"><img src=\"images/print.gif\" border=\"0\" align=\"middle\" alt=\"Printable Version\"></a>";
	if ($admintest) {
		$article_title .= "&nbsp;&nbsp;[ <a href=\"admin.php?op=EditStory&amp;sid=$sid\">Edit </a> | <a href=\"admin.php?op=RemoveStory&amp;sid=$sid\">Delete</a> ]</span>";
		}
	$content = "<a href=\"topics.php?op=viewtopic&amp;topic=$topic\">";
	if($topicimage)
	$content .= "<img src=\"$tipath$topicimage\" border=\"0\" alt=\"$topictext\" align=\"right\" hspace=\"4\" />";
	else
	$content .= "<img src=\"$tipath$default_topic_image\" border=\"0\" alt=\"$topictext\" align=\"right\" hspace=\"4\" />";

	$content .= "</a>$thetext";
	themesidebox($article_title, $content);
	echo "<br />";

	} else {
		if($informant != "") $informant = "<a href=\"user.php?op=userinfo&amp;uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "writes:<br /> <i>\"$thetext\"</i> $notes";

	$article_title = "<span class=\"type4bigger\">$title</span><br />
	Contributed by $informant on: $datetime | <a href=\"friend.php?op=FriendSend&sid=$sid\"><img src=\"images/friend.gif\" border=\"0\" align=\"middle\" alt=\"Send this story to a friend\"></a>&nbsp;|&nbsp;<a href=\"article.php?op=Print&sid=$sid\"><img src=\"images/print.gif\" border=\"0\" align=\"middle\" alt=\"Printable Version\"></a>";

global $admintest, $sid;
if ($admintest) {
    $article_title .= "&nbsp;&nbsp;[ <a href=\"admin.php?op=EditStory&amp;sid=$sid\">Edit</a> | <a
href=\"admin.php?op=RemoveStory&amp;sid=$sid\">Delete</a> ]";
}
	$content = "<a href=\"topics.php?op=viewtopic&amp;topic=$topic\">";
	if($topicimage)
	$content .= "<img src=\"$tipath$topicimage\" border=\"0\" alt=\"$topictext\" align=\"right\" hspace=\"4\" />";
	else
	$content .= "<img src=\"$tipath$default_topic_image\" border=\"0\" alt=\"$topictext\" align=\"right\" hspace=\"4\" />";

	$content .= "</a>$thetext";
	themesidebox($article_title, $content);
	echo "<br />";
 }
}

function themepollbox($title, $content)
{

	include("config.php");
	global $pollTitle;
?>
<!-- Entering themepollbox -->
<table width="100%" border="0" cellspacing="0" cellpadding="0" summary="Border for Generic Block">
<tr>
	<td class="type0">
<table width="100%" border="0" cellspacing="1" cellpadding="3" summary="Data for Generic Block">
<tr>
	<td class="type4">
	<?php echo $title; ?>
	</td>
</tr>
<tr>
	<td class="type5">
	<?php echo $content; ?>
	</td>
</tr>
</table>
	</td>
</tr>
</table>
<br />
<?php
}

function themesidebox($title, $content)
{

	include("config.php");
?>
<!-- Entering themesidebox -->
<table width="100%" border="0" cellspacing="0" cellpadding="0" summary="Border for Generic Block">
<tr>
	<td class="type0">
<table width="100%" border="0" cellspacing="1" cellpadding="3" summary="Data for Generic Block">
<tr>
	<td class="type4">
	<?php echo $title; ?>
	</td>
</tr>
<tr>
	<td class="type5">
	<?php echo $content; ?>
	</td>
</tr>
</table>
	</td>
</tr>
</table>
<br />
<?php
}

function themeboxtop($title)
{
	include("config.php");
?>
<!-- Entering themeboxtop -->
<table width="100%" border="0" cellspacing="0" cellpadding="0" summary="Border for Generic Top Block">
<tr><td class="type0">
<table width="100%" border="0" cellspacing="1" cellpadding="3" summary="Data for Generic Top Block">
<tr><td class="type4">
<?php echo "$title"; ?></td></tr>
<?php
}

function thememainbox($title, $content)
{
	include("config.php");
?>
<!-- entering thememainbox -->
<table width="100%" border="0" cellspacing="0" cellpadding="0" summary="Border for Generic Block">
<tr>
	<td class="type0">
<table width="100%" border="0" cellspacing="1" cellpadding="3" summary="Data for Generic Block">
<tr>
	<td class="type4">
	<?php echo $title; ?>
	</td>
</tr>
<tr>
	<td class="type5">
	<?php echo $content; ?>
	</td>
</tr>
</table>
	</td>
</tr>
</table>
<br />
<?php
}

function thememiddlebox($title, $content)
{
	include("config.php");
?>
<!-- entering middlebox -->
<table width="100%" border="0" cellpadding="0" cellspacing="0" summary="Border for Generic Block">
<tr>
	<td class="type0">
<table width="100%" border="0" cellpadding="5" cellspacing="1" summary="Data for Generic Block">
<tr>
	<td class="type4"><?php echo $title; ?></td></tr>
<tr>
	<td class="type5">
	<?php echo $content; ?>
	</td>
</tr>
</table>
	</td>
</tr>
</table>
<br />
<?php
}
?>
