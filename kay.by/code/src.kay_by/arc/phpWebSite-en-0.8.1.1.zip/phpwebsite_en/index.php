<?PHP

include("open_session.php");

session_register("cmode");
session_register("cthold");
session_register("corder");

if(!isset($mainfile)) include("mainfile.php");
include("config.php");


$index = 1;

if (isset($cookie[3]))
$storynum = $cookie[3];
else 
$storynum = $top;

include("header.php");
plug_check(2);

$todays_date = date('Y-m-d H:i:s');
$result = mysql_query("SELECT sid, aid, title, time, hometext, bodytext, comments, counter, topic, informant, notes FROM stories WHERE exp_date > '$todays_date' ORDER BY sid DESC limit $storynum");

if(!$result)
{
	echo mysql_errno() . ": ".mysql_error() . "<br />";
	exit();
}

$main_result = mysql_query("select main_title, main_text, main_image, main_image_active, alt, active from main_page_content");

if(mysql_num_rows($main_result))
{
	list($main_title, $main_text, $main_image, $main_image_active, $main_alt, $active) = mysql_fetch_row($main_result);

        $main_title = stripslashes($main_title);
        $main_text = stripslashes($main_text);
        $main_alt = stripslashes($main_alt);

	if($active)
	{
		if (!strstr ($main_title, '<p') && !strstr ($main_title, '<table') && !strstr ($main_title, '<br'))
        	$main_title = str_replace ("\n" , "<br />", $main_title). "<br />";

		if (!strstr ($main_text, '<p') && !strstr ($main_text, '<table') && !strstr ($main_text, '<br'))
        	$main_text = str_replace ("\n" , "<br />", $main_text). "<br />";

		if($main_image_active == 1)
		{
		  $size = GetImageSize ("$main_images_webdir$main_image");
		  //The image is wide, therefore it will be placed above the information.
		  if ($size[0] >250)
		    $content = "<center><img src=\"$main_images_webdir$main_image\" border=\"0\" alt=\"$main_alt\" /></center><br /><br />$main_text<br />";
		  else
		    $content = "<img src=\"$main_images_webdir$main_image\" border=\"0\" alt=\"$main_alt\" align=\"right\" hspace=\"5\" vspace=\"5\" />$main_text<br />";
		}
		else
		{
		  $content = "$main_text<br />";
		}

		thememainbox($main_title, $content);
	}
}

while(list($s_sid, $aid, $title, $time, $hometext, $bodytext, $comments, $counter, $topic, $informant, $notes) = mysql_fetch_row($result))
{
	getTopics($s_sid);
	formatTimestamp($time);

	$title = stripslashes($title);
	$hometext = stripslashes(str_replace ("\n", "<br />" , $hometext));
	$notes = stripslashes(str_replace ("\n", "<br />" , $notes));
	$introcount = strlen(str_replace ("\n", "<br />" , $hometext));
	$fullcount = strlen(str_replace ("\n", "<br />" , $bodytext));
	$totalcount = $introcount + $fullcount;
	$morelink = "";

	if ($fullcount > 1)
	{
		$morelink .= "<a href=\"article.php?sid=$s_sid";

		if (isset($cookie[4]))$morelink .= "&amp;mode=$cookie[4]";
		else $morelink .= "&amp;mode=nested";
		
		if(isset($cookie[5])) $morelink .= "&amp;order=$cookie[5]";
		else $morelink .= "&amp;order=0";
		
		$morelink .= "\">Read More...</a> | $totalcount bytes more";
	}

	if($show_comments)
	{
		$new_result = mysql_query("SELECT COUNT(tid) FROM comments WHERE sid='$s_sid'");
		list($count) = mysql_fetch_row($new_result);

		$morelink .= " | <a href=\"article.php?sid=$s_sid";
	
		if (isset($cookie[4])) $morelink .= "&amp;cmode=$cookie[4]";
		else $morelink .= "&amp;mode=threaded";
	
		if (isset($cookie[5])) $morelink .= "&amp;corder=$cookie[5]";
		else $morelink .= "&amp;order=0";
	
		if (isset($cookie[6])) $morelink .= "&amp;cthold=$cookie[6]";
		else $morelink .= "&amp;thold=0";
	
		$morelink2 = " | <a href=\"article.php?sid=$s_sid";
	
		if (isset($cookie[4])) $morelink2 .= "&amp;cmode=$cookie[4]";
		else $morelink2 .= "&amp;mode=threaded";
	
		if (isset($cookie[5])) $morelink2 .= "&amp;corder=$cookie[5]";
		else $morelink2 .= "&amp;order=0";
	
		if (isset($cookie[6])) $morelink2 .= "&amp;cthold=$cookie[6]";
		else $morelink2 .= "&amp;thold=0";

		if($count == 0) $morelink .= "\">comments?</a>";
		else
		{
			if ($count < 1)
			{
				if($count == 1) $morelink .= "\">Read More...</a> | $morelink2\">$count comment</a>";
				else $morelink .= "\">Read More...</a> | $morelink2\">$count comments</a>";
			}
			else
			{
				if($count == 1) $morelink .= "\">$count comment</a>";
				else $morelink .= "\">$count comments</a>";
			}
		}
	}

	if(isset($cookie[5])) $morelink2 .= "&amp;order=$cookie[5]";
	else $morelink2 .= "&amp;order=0";
	
	if (isset($cookie[6])) $morelink2 .= "&amp;thold=$cookie[6]";
	else $morelink2 .= "&amp;thold=0";


	$morelink .= "&nbsp;|&nbsp;
	<a href=\"friend.php?op=FriendSend&amp;sid=$s_sid\">
	<img src=\"images/friend.gif\" border=\"0\" align=\"middle\" alt=\"Send this announcement to a friend\" /></a>
	&nbsp;|&nbsp;
	<a href=\"article.php?op=Print&amp;sid=$s_sid\">
	<img src=\"images/print.gif\" border=\"0\" align=\"middle\" alt=\"Printable Version\" /></a>";

	themeindex($aid, $informant, $datetime, $title, $counter, $topic, $hometext, $notes, $morelink, $topicname, $topicimage, $topictext);
}

mysql_free_result($result);

include("footer.php");

##########################################
#   Gets referrer information            #
##########################################

if ($httpref>0){
        $ref = (phpversion() >= "4.1.0") ? $_SERVER[HTTP_REFERER] : $HTTP_SERVER_VARS[HTTP_REFERER];

        if($ref != "" && $ref != unknown)
        {
                $fixed_ref=str_replace("&", "&amp;", $ref);
                new_url($fixed_ref);
        }
}

?>



<!-- END || File: "index.php" - Directory: "./" || END -->
