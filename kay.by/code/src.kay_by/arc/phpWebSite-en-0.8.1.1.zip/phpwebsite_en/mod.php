<?php

include("./mod/$mod/index.php");

?>

