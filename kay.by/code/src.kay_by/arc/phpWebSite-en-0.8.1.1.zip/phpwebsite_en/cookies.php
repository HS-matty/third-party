<?php
/**
 * This file is just an error message assisting users with cookie problems or cookies turned off.
 *
 * Not sure what effect session variables will have on this file. One to watch 6.11.01
 * 
 * @module cookies
 * @modulegroup misc
 * @package phpWebSite
 */

if (!isset($mainfile))
{
  /**
   * Defines core functions.
   */
  include("mainfile.php");
}

/**
 * Generates page header.
 */
include("header.php");
$box_stuff = "

On this site we use cookies to be able to offer customized services.

<br /><br />

Of this form it is possible that, with your user account, you can select special characteristics of this page, such as the number of news items that you want to display on the top page, the appearance of users' comments, the total appearance of the site through themes, and much more.  This customized information is stored locally in your browser's cookies file.

<br /><br />

If you are one of those people who do not wish to accept cookies, you can still use this site.  However, if you create an account, you will need to log in each time you visit this site in order to load all your desired settings.

<br /><br />

If you are paranoid about cookies, or you are worried that another rogue site could remove them from your machine and obtain your personal data, you should be aware that our cookies are stored encrypted in your cookies file.  If some other site managed to actually remove them, they would probably not be able to recover the information since it will appear as gibberish.
";
themesidebox(strtoupper("cookies") , $box_stuff);
/**
 * Generates page footer.
 */
include("footer.php");
?>
