<?PHP

include("open_session.php");

if(!isset($mainfile)) { include("mainfile.php"); }

function nav() {
	include("config.php");
	$box_stuff = "[ 
	<a href=\"user.php?op=edituser\">Edit Your Info</a> | 
	<a href=\"user.php?op=edithome\">Edit The Homepage</a> | 
	<a href=\"user.php?op=editcomm\">Comment Options</a> | ";
	if ($disable_themes){ 
	$box_stuff .= "<a href=\"user.php?op=chgtheme\">Change the Theme</a> | ";
	}
	$box_stuff .= "<a href=\"user.php?op=logout\">Logout</a> ]";
	themesidebox("Navigation", $box_stuff);

}

function userCheck ($uname, $email) {
	
	global $stop;
	include("config.php");
	if ((!$email) || ($email=="") || (!eregi("^[_\.0-9a-z-]+@([0-9a-z][0-9a-z-]+\.)+[a-z]{2,3}$",$email))) $stop = "ERROR: Invalid email<br />";
	if (strrpos($email,' ') > 0) $stop = "ERROR: Email addresses do not contain spaces";
	if ((!$uname) || ($uname=="") || (ereg("[^a-zA-Z0-9_-]",$uname))) $stop = "ERROR: Invalid Nickname<br />";
	if (strlen($uname) > 25) $stop = "Nickname is too long. It must be less than 25 characters";
	if (eregi("^((root)|(adm)|(linux)|(webmaster)|(admin)|(god)|(administrator)|(administrateur)|(nobody)|(anonymous)|(anonyme)|(operator)|(op�rateur))$",$uname)) $stop = "ERROR: Name is reserved<br />";
	if (strrpos($uname,' ') > 0) $stop = "There cannot be any spaces in the Nickname.";
	if ($user_dblocation)
	{
		@mysql_select_db("$user_dbname") or die ("Unable to select database");
		if (mysql_num_rows(mysql_query("select uname from users where uname='$uname'")) > 0) $stop = "ERROR: Nickname taken<br />";
		if (mysql_num_rows(mysql_query("select email from users where email='$email'")) > 0) $stop = "ERROR: Email address already registered<br />";
		@mysql_select_db("$dbname") or die ("Unable to select database");
	}
	else
	{
		if (mysql_num_rows(mysql_query("select uname from users where uname='$uname'")) > 0) $stop = "ERROR: Nickname taken<br />";
		if (mysql_num_rows(mysql_query("select email from users where email='$email'")) > 0) $stop = "ERROR: Email address already registered<br />";
	}
	return($stop);
}

function makePass () {
	$makepass="";
	$syllables="er,in,tia,wol,fe,pre,vet,jo,nes,al,len,son,cha,ir,ler,bo,ok,tio,nar,sim,ple,bla,ten,toe,cho,co,lat,spe,ak,er,po,co,lor,pen,cil,li,ght,wh,at,the,he,ck,is,mam,bo,no,fi,ve,any,way,pol,iti,cs,ra,dio,sou,rce,sea,rch,pa,per,com,bo,sp,eak,st,fi,rst,gr,oup,boy,ea,gle,tr,ail,bi,ble,brb,pri,dee,kay,en,be,se";
	$syllable_array=explode(",", $syllables);
	srand((double)microtime()*1000000);
	for ($count=1;$count<=4;$count++) {
		if (rand()%10 == 1) {
			$makepass .= sprintf("%0.0f",(rand()%50)+1);
		} else {
			$makepass .= sprintf("%s",$syllable_array[rand()%62]);
		}
	}
	return($makepass);
}

function confirmNewUser($uname, $email) {
	global $stop, $EditedMessage;
	include("header.php");
	filter_text($uname);
	$uname = $EditedMessage;
	userCheck($uname, $email);
	if (!$stop) {
		$box_title = "Password will be sent to the email address you enter.";
		$box_stuff = "Username: $uname<br />
		    Email: $email<br />
		<form action=\"user.php\" method=\"post\">
		<input type=\"hidden\" name=\"uname\" value=\"$uname\" />
		<input type=\"hidden\" name=\"email\" value=\"$email\" />
		<br /><br /><input type=\"hidden\" name=\"op\" value=\"finish\" />
		<input type=\"submit\" value=\"Finish\" /></form>";
	} else {
		$box_title = "<span class=\"type4bigger\">$stop</span>";
		$box_stuff = "<span class=\"onebiggerred\">$stop</span>";
	}
	themesidebox($box_title, $box_stuff);
	include("footer.php");
}

function finishNewUser($uname, $email) {
	global $stop, $makepass, $EditedMessage;
	include("header.php");
	include("config.php");
	userCheck($uname, $email);
	if (!isset($stop)) {
		$makepass=makepass();
		
		if(!$system) {
			$cryptpass=crypt($makepass);
			$cryptpass=crypt($makepass, substr($cryptpass,0,2));
			}
		else	
			$cryptpass=$makepass;

		if ($user_dblocation)
		{
			@mysql_select_db("$user_dbname") or die ("Unable to select database");
			$result = mysql_query("insert into users values (NULL,'','$uname','$email','','','$cryptpass',10,'',0,0,0,'',0,'','','$commentlimit', '0')");
			@mysql_select_db("$dbname") or die ("Unable to select database");
		}
		else
		{
			$result = mysql_query("insert into users values (NULL,'','$uname','$email','','','$cryptpass',10,'',0,0,0,'',0,'','','$commentlimit', '0')");
		}
		if(!$result) {
			echo mysql_errno(). ": ".mysql_error(). "<br />";
		} else {
			$message = "Welcome to $sitename !\n\n You or someone else has used your email ($email) to create an account at $sitename.
			The following is the member information: \n\n -Nickname:  $uname\n -Password:  $makepass\n\n $nuke_url";
			$subject="User Password for $uname";
			$from="$adminmail";
			if ($system == 1) {
				echo "Your password is: <span class=\"boldtext\">$makepass</span><br />";
				echo "<a href=\"user.php?op=login&amp;uname=$uname&amp;pass=$makepass\">Please login</a> to change your info";
			} else {
				mail($email, $subject, $message, "From: $from\nX-Mailer: PHP/" . phpversion());
				echo "You are now registered. You should receive your password at the email account you provided.";
			}
		}
	} else {
		echo "$stop";
	}
	include("footer.php");
}

function userinfo($uname, $bypass=0) {
	global $user, $cookie;
	include("config.php");
	if ($user_dblocation)
	{
		@mysql_select_db("$user_dbname") or die ("Unable to select database");
		$result = mysql_query("select femail, url, bio from users where uname='$uname'");
		@mysql_select_db("$dbname") or die ("Unable to select database");
	}
	else
	{
		$result = mysql_query("select femail, url, bio from users where uname='$uname'");		
	}
	$userinfo = mysql_fetch_array($result);
	if(!$bypass) cookiedecode($user);
	include("header.php");
	if($uname == $cookie[1]) {
		$box_title = "<span class=\"type4bigger\">" . htmlspecialchars($uname);
		$box_title .= ", Welcome to $sitename ! </span>";
		$box_title .= help("user");
	}else{ 
		$box_title = "<span class=\"type4bigger\">" . htmlspecialchars($uname) . "</span>" . help("User");
		}
	if((mysql_num_rows($result)==1) && ($userinfo[url] || $userinfo[femail] || $userinfo[bio])) {
		if ($userinfo[url]) {
			if (!strstr($userinfo[url], "http://"))
				$userinfo[url] = "http://".$userinfo[url];
			$box_stuff .= "My HomePage: <a href=\"$userinfo[url]\">$userinfo[url]</a><br />\n";
		}
		if ($userinfo[femail]) { $box_stuff .= "My E-Mail: <a 
href=\"mailto:$userinfo[femail]\">$userinfo[femail]</a><br />\n"; }
		if ($userinfo[bio]) { $box_stuff .= "Extra Info: $userinfo[bio]<br />\n"; }
	} else {
		$box_stuff .= "There is no available info for " . htmlspecialchars($uname);
	}	
	$box_stuff .= "<br /><br />This web site uses <a href=\"cookies.php\">cookies</a>";
	themesidebox($box_title, $box_stuff);
	if($uname == $cookie[1]){ echo nav(); }
	include("footer.php");
}

function main($user) {
	global $stop;

	if(!isset($user) || (isset($user) && empty($user)))
	{
		include("config.php");
		include("header.php");

		if ($stop)
			echo "<center><span class=\"onebiggerred\">Incorrect Login!</span></center>";

		if (!empty($user)) {
		$box_title = "User Login";
		$box_stuff = "<form action=\"user.php\" method=\"post\">
		Nickname: <input type=\"text\" name=\"uname\" size=\"21\" maxlength=\"25\" /><br />
		Password: <input type=\"password\" name=\"pass\" size=\"21\" maxlength=\"20\" /><br />
		<input type=\"hidden\" name=\"op\" value=\"login\" />
		<input type=\"submit\" value=\"Login\" /></form>";
		themesidebox($box_title, $box_stuff);	
	 	}

		$box_title = "New User:";
		$box_stuff = "<form action=\"user.php\" method=\"post\">
		Nickname: <input type=\"text\" name=\"uname\" size=\"26\" maxlength=\"25\" /><br />
		E-Mail: <input type=\"text\" name=\"email\" size=\"25\" maxlength=\"60\" /><br />
		<input type=\"hidden\" name=\"op\" value=\"new user\" />
		<input type=\"submit\" value=\"Submit\" /></form>
		(Password will be sent to the email address you enter.)<br />
		Notice: Account preferences are cookie based. <a href=\"cookies.php\">more info...</a><br />
		<h3>As a registered user you can:</h3>
		<ul>
		<li>Post comments with your name</li>
		<li>Send news with your name</li>
		<li>Have a personal box in the Home</li>
		<li>Select how many news stories you want on the Homepage</li>
		<li>Customize the comments</li>
		<li>Select different themes</li>
		<li>and much more...</li>
		</ul>
		<a name=\"confcode\"></a>";
		themesidebox($box_title, $box_stuff);
	
		$box_title = "Lost your Password?";
		$box_stuff = "No problem. Just type your Nickname and click on send button.<br />
		A Confirmation Code will be sent to you via E-Mail after you enter your Nickname,
		once you get it enter your Nickname again along with your Confirmation Code.<br />
		<form action=\"user.php\" method=\"post\">
		Nickname: <input type=\"text\" name=\"uname\" size=\"26\" maxlength=\"25\" />&nbsp;&nbsp;
		Confirmation Code: <input type=\"text\" name=\"code\" size=\"5\" maxlength=\"6\" /><br />
		<input type=\"hidden\" name=\"op\" value=\"mailpasswd\" />
		<input type=\"submit\" value=\"Send\" />
		</form>";
		themesidebox($box_title, $box_stuff);
		include("footer.php");
	} else {
		global $cookie;
		cookiedecode($user);
		userinfo($cookie[1]);
	}
}

function logout() {
	$agent = (phpversion() > "4.1.0") ? $_SERVER[HTTP_USER_AGENT] : $HTTP_SERVER_VARS[HTTP_USER_AGENT];

 	// it seems like M$ Internet Explorer 5.x and 6.x requires this to
        // successfully logout users
        if (stristr($HTTP_USER_AGENT, 'msie'))
        if (stristr($agent, 'msie'))
 		setcookie("user","",time()-15552000,'/',"");

	// Netscape/Mozilla requires this instead
	setcookie("user");
	include("header.php");
	$title = "You are now logged out";
	$boxy = "<br /><a href=\"index.php\">Click here to go back to the main page</a><br />";
	themesidebox($title, $boxy);
	include("footer.php");
}

function mail_password($uname, $code) {
	
	include("config.php");
	if ($user_dblocation)
	{
		@mysql_select_db("$user_dbname") or die ("Unable to select database");
		$result = mysql_query("select email, pass from users where (uname='$uname')");
		@mysql_select_db("$dbname") or die ("Unable to select database");
	}
	else
	{
		$result = mysql_query("select email, pass from users where (uname='$uname')");	
	}
 {
		$host_name = getenv("REMOTE_ADDR");
		list($email, $pass) = mysql_fetch_row($result);

		$areyou = substr($pass, 0, 5);
		if ($areyou==$code) {
		
		$newpass=makepass();
		$message = "The user account \"$uname\" at $nuke_url has this email associated with it. A web user from $host_name has just requested that password be sent.\n\n Your New Password is: $newpass\n\n You can change it after you login at $nuke_url/user.php\n\n 
		If you didn't ask for this, don't worry. You are seeing this message, not him/her. If this was an error just login with your new password.";
		$subject="User Password for $uname";
		mail($email, $subject, $message, "From: $adminmail\nX-Mailer: PHP/" . phpversion());

	// Next step: add the new password to the database
	
		if(!$system) {
		    $cryptpass=crypt($newpass);
		    $cryptpass=crypt($newpass,substr($cryptpass,0,2));
		} else {
		    $cryptpass=$newpass;
		}
		$query="update users set pass='$cryptpass' where uname='$uname'";
		if ($user_dblocation)
		{
			@mysql_select_db("$user_dbname") or die ("Unable to select database");
			if(!mysql_query($query)) {
			echo "mail_password: could not update user entry. Contact the Administrator";
			}
			@mysql_select_db("$dbname") or die ("Unable to select database");
		}
		else
		{
			if(!mysql_query($query)) {
			echo "mail_password: could not update user entry. Contact the Administrator";
			}
		}	
	
		$titlebar = "User password sent";
		include ("header.php");
		if($uname ==""){
			echo "<center>Why didn't you put in a name? Go back...</center>";
		}
		if($uname != ""){
			echo "<center>Password for $uname sent by email.<br /> <a href=\"user.php\">
						Click here to log in as usual once you get your password.</a></center>";
		}	
		include ("footer.php");

	// If no Code, send it

		} else {

    		if ($user_dblocation)
		{
			@mysql_select_db("$user_dbname") or die ("Unable to select database");
			$result = mysql_query("select email, pass from users where (uname='$uname')");
			@mysql_select_db("$dbname") or die ("Unable to select database");
		}
		else
		{
			$result = mysql_query("select email, pass from users where (uname='$uname')");		
		}
		if(!$result) {
		    echo "<center>Sorry, no corresponding user info was found</center>";
		} else {
		    $host_name = getenv("REMOTE_ADDR");
		    list($email, $pass) = mysql_fetch_row($result);
		    $areyou = substr($pass, 0, 5);

		$message = "The user account '$uname' at $nuke_url has this email associated with it. A web user from $host_name has just requested a Confirmation Code to change the password.\n\n Your Confirmation Code is: $areyou \n\n With this code you can now assign a new password at $nuke_url/user.php\n If you didn't ask for this, don't worry. Just delete this Email.";
		$subject="Confirmation Code for $uname";
		mail($email, $subject, $message, "From: $adminmail\nX-Mailer: PHP/" . phpversion());

		include ("header.php");
		echo "Confirmation Code for $uname sent by email.";
		echo "Check your mail and get the Confirmation Code.<br /> <a href=\"user.php\">
		Click here once you're gotten the code. Enter both your nickname and confirmation code this time.</a>";
		include ("footer.php");
		exit;
    	    }		
	}
    }
}

function docookie($setuid, $setuname, $setpass, $setstorynum, $setumode, $setuorder, $setthold, $setnoscore, $setublockon, $settheme, $setcommentmax) {
	$info = base64_encode("$setuid:$setuname:$setpass:$setstorynum:$setumode:$setuorder:$setthold:$setnoscore:$setublockon:$settheme:$setcommentmax");
	setcookie("user","$info",time()+15552000); // 6 mo is 15552000
}

function login($uname, $pass)
{
	global $setinfo,$system;
	include("config.php");
	if ($user_dblocation)
	{
		@mysql_select_db("$user_dbname") or die ("Unable to select database");
		$result = mysql_query("select pass, uid, storynum, umode, uorder, thold, noscore, ublockon, theme, commentmax from users where uname='$uname'");
		@mysql_select_db("$dbname") or die ("Unable to select database");
	}
	else
	{
		$result = mysql_query("select pass, uid, storynum, umode, uorder, thold, noscore, ublockon, theme, commentmax from users where uname='$uname'");	
	}

	if(mysql_num_rows($result)==1)
	{
		$setinfo = mysql_fetch_array($result);
		
		$dbpass = $setinfo[pass];
		
		if(!$system)
	  	   $pass = crypt($pass, substr($dbpass,0,2));

		if (strcmp($dbpass, $pass))
		{
                        Header("Location: user.php?stop=1");
                        return;
                }

		docookie($setinfo[uid], $uname, $pass, $setinfo[storynum], $setinfo[umode], $setinfo[uorder], $setinfo[thold], $setinfo[noscore], $setinfo[ublockon], $setinfo[theme], $setinfo[commentmax]);
		Header("Location: user.php?op=userinfo&bypass=1&uname=$uname");
	}
	else Header("Location: user.php?stop=1");
}

function infoCheck($uid, $email, $url) {
	global $stop;
	include("config.php");
	if ((!$email) || ($email=="") || (!ereg("[@]",$email)) || (!ereg("[.]",$email)) || (strlen($email) < 7) || (ereg("[^a-zA-Z0-9@.]",$email))) { $stop = "Invalid email<br />"; }
	if (($url) && ($url!="http://") && ((!ereg("[http://]",$url)) || (!ereg("[.]",$url)) || (strlen($url) < 12) || (ereg("[^a-zA-Z0-9~.:/]",$url)))) { $stop = "Invalid URL<br />"; }
	if ($user_dblocation)
	{
		@mysql_select_db("$user_dbname") or die ("Unable to select database");
		list($test) = mysql_fetch_row(mysql_query("select email from users where (email='$email' and uid!=$uid)"));
		@mysql_select_db("$dbname") or die ("Unable to select database");
	}
	else
	{
		list($test) = mysql_fetch_row(mysql_query("select email from users where (email='$email' and uid!=$uid)"));		
	}
	if ("$test"=="$email") $stop = "ERROR: Email address already registered";
	return($stop);
}

function edituser() {
	global $user, $userinfo;
	include("header.php");
	getusrinfo($user);
	if ($userinfo){
	$box_title = "Edit Your Info";
		$box_title .= help("USER", "");
	$box_stuff = "<form action=\"user.php\" method=\"post\">
	<span class=\"boldtext\">Real Name</span> (optional)<br />
	<input type=\"text\" name=\"name\" value=\"$userinfo[name]\" size=\"30\" maxlength=\"60\" /><br />
	<span class=\"boldtext\">Real Email</span> (required)<br />
	(This Email will not be public but is required, will be used to send your password if you lost it)<br />
	<input type=\"text\" name=\"email\" value=\"$userinfo[email]\" size=\"30\" maxlength=\"60\" /><br />
	<span class=\"boldtext\">Fake Email</span> (optional)<br />
	(This Email will be public. Just type what you want, Spam proof)<br />
	<input type=\"text\" name=\"femail\" value=\"$userinfo[femail]\" size=\"30\" maxlength=\"60\" /><br />
	<span class=\"boldtext\">Your HomePage</span> (optional)<br />
	<input type=\"text\" name=\"url\" value=\"$userinfo[url]\" size=\"30\" maxlength=\"100\" /><br />
	<span class=\"boldtext\">Information about yourself...</span> (optional)<br />
	(255 characters max. Type what others can know about yourself)<br />
	<textarea cols=\"50\" rows=\"5\" name=\"bio\" wrap=\"virtual\">$userinfo[bio]</textarea>
	<br /><br />
	<span class=\"boldtext\">Password</span> (type a new password twice to change it)<br />
	<input type=\"password\" name=\"pass\" size=\"10\" maxlength=\"20\" />
	<input type=\"password\" name=\"vpass\" size=\"10\" maxlength=\"20\" />
	<br /><br />
	<input type=\"hidden\" name=\"uname\" value=\"$userinfo[uname]\" />
	<input type=\"hidden\" name=\"uid\" value=\"$userinfo[uid]\" />
	<input type=\"hidden\" name=\"op\" value=\"saveuser\" />
	<input type=\"submit\" value=\"Save Changes\" />";
	} else {
		$box_title = "Edit Your Info";
		$box_stuff = "A problem occurred: Your account is not registered. Please logout to delete your cookie";
	}
	themesidebox($box_title, $box_stuff);
	nav();
	include("footer.php");
}

function saveuser($uid, $name, $uname, $email, $femail, $url, $pass, $vpass, $bio) {
	global $user, $cookie, $userinfo, $EditedMessage,$system;
	include("config.php");
	if ((isset($pass)) && ("$pass" != "$vpass")) {
		echo "Both passwords are different. They need to be identical.";
	} elseif (($pass != "") && (strlen($pass) < $minpass)) {
		echo "Sorry, your password must be at least <span class=\"boldtext\">$minpass</span> characters long";
	} else {
		if ($bio) { filter_text($bio); $bio = $EditedMessage; $bio = FixQuotes($bio); }
		if ($pass != "") {
			cookiedecode($user);
			if ($user_dblocation)
			{
				@mysql_select_db("$user_dbname") or die ("Unable to select database");
				mysql_query("LOCK TABLES users WRITE");
				@mysql_select_db("$dbname") or die ("Unable to select database");
			}
			else
			{
				mysql_query("LOCK TABLES users WRITE");		
			}
	
			if(!$system) {
				$cpass=crypt($pass);
				$pass=crypt($pass,substr($cpass,0,2));
				}

			if ($user_dblocation)
			{
				@mysql_select_db("$user_dbname") or die ("Unable to select database");
				mysql_query("update users set name='$name', email='$email', femail='$femail', url='$url', pass='$pass', bio='$bio' where uid='$uid'");
				$result = mysql_query("select uid, uname, pass, storynum, umode, uorder, thold, noscore, ublockon, theme from users where uname='$uname' and pass='$pass'");
				@mysql_select_db("$dbname") or die ("Unable to select database");
			}
			else
			{
				mysql_query("update users set name='$name', email='$email', femail='$femail', url='$url', pass='$pass', bio='$bio' where uid='$uid'");
				$result = mysql_query("select uid, uname, pass, storynum, umode, uorder, thold, noscore, ublockon, theme from users where uname='$uname' and pass='$pass'");
			}
			
			if(mysql_num_rows($result)==1) {
				$userinfo = mysql_fetch_array($result);
				docookie($userinfo[uid],$userinfo[uname],$userinfo[pass],$userinfo[storynum],$userinfo[umode],$userinfo[uorder],$userinfo[thold],$userinfo[noscore],$userinfo[ublockon],$userinfo[theme],$userinfo[commentmax]);
			} else {
				echo "Something screwed up... don't you hate that?<br />";
			}
			mysql_query("UNLOCK TABLES");
		} else {
			if ($user_dblocation)
			{
				@mysql_select_db("$user_dbname") or die ("Unable to select database");
				mysql_query("update users set name='$name', email='$email', femail='$femail', url='$url', bio='$bio' where uid=$uid");
				@mysql_select_db("$dbname") or die ("Unable to select database");
			}
			else
			{
				mysql_query("update users set name='$name', email='$email', femail='$femail', url='$url', bio='$bio' where uid=$uid");
			}
		}
		Header("Location: user.php?"); 
	}
}

function edithome() {
	global $user, $userinfo;
	include ("config.php");
	include ("header.php");
	getusrinfo($user);
	if ($userinfo){
		$box_title = "Edit The Homepage";
		$box_title .= help("USER", "");
		if($userinfo[theme]=="") $userinfo[theme] = $default_theme;
		$box_stuff = "
	<form action=\"user.php\" method=\"post\">
	<span class=\"boldtext\">News number in the Home</span> (max: 127)
	<input type=\"text\" name=\"storynum\" size=\"3\" maxlength=\"3\" value=\"$userinfo[storynum]\" />
	<br /><br />
	<span class=\"boldtext\">Activate Personal Menu</span> <input type=\"checkbox\" name=\"ublockon\" ";

		if ($userinfo[ublockon]==1)
			$box_stuff .= "checked=\"checked\" ";
	$block_stuff = str_replace("<br />", "\n", $userinfo[ublock]);

		$box_stuff .= " />
	<br />(Check this option and the following text will appear in the Home)
	<br />(You can use HTML code to put links, for example)<br />
	<textarea cols=\"50\" rows=\"20\" name=\"ublock\" wrap=\"virtual\">$block_stuff</textarea>
	<br /><br />
	<input type=\"hidden\" name=\"theme\" value=\"$userinfo[theme]\" />
	<input type=\"hidden\" name=\"uname\" value=\"$userinfo[uname]\" />
	<input type=\"hidden\" name=\"uid\" value=\"$userinfo[uid]\" />
	<input type=\"hidden\" name=\"op\" value=\"savehome\" />
	<input type=\"submit\" value=\"Save Changes\" />
	</form>";
	} else {
		$box_title = "Edit The Homepage";
		$box_stuff = "A problem occurred: Your account is not registered. Please logout to delete your cookie";
	}

	themesidebox($box_title, $box_stuff);
	nav();
	include ("footer.php");
}

function chgtheme() {
	global $user, $userinfo;
	include ("header.php");
	getusrinfo($user);
	if ($userinfo){
		$box_title = "Change the Theme";
		$box_title .= help("USER", "");
		$box_stuff = "<form action=\"user.php\" method=\"post\">
	<b>Select One Theme</b><br />
	<select name=\"theme\">";
		include("themes/list.php");
		$themelist = explode(" ", $themelist);
		for ($i=0; $i < sizeof($themelist); $i++) {
			if($themelist[$i]!="") {
				$box_stuff .= "<option value=\"$themelist[$i]\" ";
				if((($userinfo[theme]=="") && ($themelist[$i]=="Default")) || ($userinfo[theme]==$themelist[$i])) $box_stuff .= "selected=\"selected\"";
				$box_stuff .= ">$themelist[$i]\n";
			}
		}
		if($userinfo[theme]=="") $userinfo[theme] = "Default";
		$box_stuff .= "</select><br />
	This option will change the look for the whole site.<br />
	The changes will be valid only to you.<br />
	Each user can view the site with different theme.<br />
	<br /><input type=\"hidden\" name=\"storynum\" value=\"$userinfo[storynum]\" />
	<input type=\"hidden\" name=\"ublockon\" value=\"$userinfo[ublockon]\" />
	<input type=\"hidden\" name=\"uname\" value=\"$userinfo[uname]\" />
	<input type=\"hidden\" name=\"uid\" value=\"$userinfo[uid]\" />
	<input type=\"hidden\" name=\"op\" value=\"savetheme\" />
	<input type=\"submit\" value=\"Save Changes\" />
	</form>";
	} else {
		$box_title = "Change the Theme";
		$box_stuff = "A problem occurred: Your account is not registered. Please logout to delete your cookie";
	}
	themesidebox($box_title, $box_stuff);
	nav();
	include ("footer.php");
}


function savehome($uid, $uname, $theme, $storynum, $ublockon, $ublock)
{
	global $user, $userinfo;
	include("config.php");
	if(isset($ublockon)) $ublockon=1; else $ublockon=0;	
	$ublock = FixQuotes($ublock);
        $ublock = str_replace("\n", "<br />", $ublock);

	if ($user_dblocation)
	{
		@mysql_select_db("$user_dbname") or die ("Unable to select database");
		mysql_query("LOCK TABLES users WRITE");
		mysql_query("update users set storynum='$storynum', ublockon='$ublockon', ublock='$ublock' where uid=$uid");
		@mysql_select_db("$dbname") or die ("Unable to select database");
	}
	else
	{
		mysql_query("LOCK TABLES users WRITE");
		mysql_query("update users set storynum='$storynum', ublockon='$ublockon', ublock='$ublock' where uid=$uid");

	}
	getusrinfo($user);
	if ($userinfo){
		mysql_query("UNLOCK TABLES");
		docookie($userinfo[uid],$userinfo[uname],$userinfo[pass],$userinfo[storynum],$userinfo[umode],$userinfo[uorder],$userinfo[thold],$userinfo[noscore],$userinfo[ublockon],$userinfo[theme],$userinfo[commentmax]);
		Header("Location: user.php?theme=$theme");
	} else {
		echo "A problem occurred: Your account is not registered. Please logout to delete your cookie";
		exit;
	}

}

function savetheme($uid, $theme) {
	global $user, $userinfo;
	include("config.php");
	if ($user_dblocation)
	{
		@mysql_select_db("$user_dbname") or die ("Unable to select database");
		mysql_query("update users set theme='$theme' where uid=$uid");
		@mysql_select_db("$dbname") or die ("Unable to select database");
	}
	else
	{
		mysql_query("update users set theme='$theme' where uid=$uid");
	}
	getusrinfo($user);
	if ($userinfo){
		docookie($userinfo[uid],$userinfo[uname],$userinfo[pass],$userinfo[storynum],$userinfo[umode],$userinfo[uorder],$userinfo[thold],$userinfo[noscore],$userinfo[ublockon],$userinfo[theme],$userinfo[commentmax]);
		Header("Location: user.php?theme=$theme");
	} else {
		echo "A problem occurred: Your account is not registered. Please logout to delete your cookie";
		exit;
	}
}

function editcomm()
{
	include("config.php");
	include ("header.php");	
	global $user, $userinfo;

	getusrinfo($user);

	if ($userinfo){
		$box_title = "Comment Options" . help("USER", "");

		$box_stuff = "mode = $userinfo[umode]
	<form action=\"user.php\" method=\"post\">
	<span class=\"boldtext\">Display Mode</span>
	
	<select class=\"textbox\" name=\"umode\">
		<option value=\"nocomments\" ";

			if ($userinfo[umode] == 'nocomments')
				$box_stuff .= "selected=\"selected\" ";

		$box_stuff .= ">No Comments</option>
		<option value=\"nested\" ";

			if ($userinfo[umode] == 'nested')
				$box_stuff .= "selected=\"selected\" ";

			$box_stuff .= ">Nested</option>
	<option value=\"threaded\" "; 

		if ($userinfo[umode] == 'threaded') { $box_stuff .= "selected=\"selected\" "; } 

		$box_stuff .= ">Threaded</option>
	<option value=\"flat\" ";
		if ($userinfo[umode] == 'flat') { $box_stuf .= "selected=\"selected\" "; } 

		$box_stuff .= ">Flat</option>
	</select><br /><br />
	<span class=\"boldtext\">Sort Order</span>
	<select class=\"textbox\" name=\"uorder\">
		<option value=\"0\""; 
			if ($userinfo[uorder]==0) 
			 	$box_stuff .= "selected=\"selected\" ";  

			$box_stuff .= ">Oldest First</option>
		<option value=\"1\""; 
			if ($userinfo[uorder]==1) 
				$box_stuff .= "selected=\"selected\" ";  

		$box_stuff .= ">Newest First</option>

		<option value=\"2\""; 
			if ($userinfo[uorder]==2) 
				$box_stuff .= "selected=\"selected\" ";  

		$box_stuff .= ">Highest Scores First</option>
	</select><br /><br />

	<span class=\"boldtext\">Threshold</span>
	<select class=\"textbox\" name=\"uthold\">
		<option value=\"-1\"";
		if ($userinfo[thold]==-1) 
			$box_stuff .= "selected=\"selected\" ";  
		$box_stuff .= ">-1: Uncut and Raw</option>
	<option value=\"0\""; 
		if ($userinfo[thold]==0) { $box_stuff .= "selected=\"selected\""; } 
		$box_stuff .= ">0: Almost Everything</option>
	<option value=\"1\"";
		if ($userinfo[thold]==1) { $box_stuff .= "selected=\"selected\""; } 
		$box_stuff .= ">1: Filter Most Anon</option>
	<option value=\"2\""; 
	if ($userinfo[thold]==2) { $box_stuff .= "selected=\"selected\""; } 
		$box_stuff .= ">2: Score +2</option>
	<option value=\"3\""; 
		if ($userinfo[thold]==3) { $box_stuff .= "selected=\"selected\""; } 
		$box_stuff .= ">3: Score +3</option>
	<option value=\"4\""; 
		if ($userinfo[thold]==4) { $box_stuff .= "selected=\"selected\""; } 
		$box_stuff .= ">4: Score +4</option>
	<option value=\"5\""; 
		if ($userinfo[thold]==5) { $box_stuff .= "selected=\"selected\""; } 
		$box_stuff .= ">5: Score +5</option>
	</select><br />
	Comments scored less than this setting will be ignored.<br />
	Anonymous posts start at 0, logged in posts start at 1. Moderators add and subtract points.
	<br /><br />
	<input type=\"checkbox\" name=\"noscore\"";
	if ($userinfo[noscore]) 
		$box_stuff .= "checked=\"checked\"";
	$box_stuff .="/><span class=\"boldtext\">Do Not Display Scores</span><br /> 
	(Hides score: They still apply, you just don't see them.)
	<br /><br />
	<span class=\"boldtext\">Max Comment Length</span>
	<br />
	<input type=\"text\" name=\"commentmax\" value=\"$userinfo[commentmax]\" size=\"11\" maxlength=\"11\" /> b (1024 b = 1K)
	<br />
	(Truncates long comments, and adds a Read More link. Set really big to disable)
	<br /><br />
	<input type=\"hidden\" name=\"uname\" value=\"$userinfo[uname]\" />
	<input type=\"hidden\" name=\"uid\" value=\"$userinfo[uid]\" />
	<input type=\"hidden\" name=\"op\" value=\"savecomm\" />
	<input type=\"submit\" value=\"Save Changes\" />
	</form>";
	} else {
		$box_title = "Comment Options";
		$box_stuff = "A problem occurred: Your account is not registered. Please logout to delete your cookie";
	}

	themesidebox($box_title, $box_stuff);
	nav();
	include ("footer.php");
}

function savecomm($uid, $uname, $umode, $uorder, $thold, $noscore, $commentmax) {
	include("config.php");

	global $user, $userinfo;
	
	if(isset($noscore)) 
		$noscore=1; 
	else 
		$noscore=0;
	
	if ($user_dblocation)
	{
		@mysql_select_db("$user_dbname") or die ("Unable to select database");
		mysql_query("LOCK TABLES users WRITE");
		mysql_query("update users set umode='$umode', uorder='$uorder', thold='$thold', noscore='$noscore', commentmax='$commentmax' where uid=$uid");
		@mysql_select_db("$dbname") or die ("Unable to select database");
	}
	else
	{
		mysql_query("LOCK TABLES users WRITE");
		mysql_query("update users set umode='$umode', uorder='$uorder', thold='$thold', noscore='$noscore', commentmax='$commentmax' where uid=$uid");	
	}
	getusrinfo($user);
	mysql_query("UNLOCK TABLES");
	
	docookie($userinfo[uid],$userinfo[uname],$userinfo[pass],$userinfo[storynum],$userinfo[umode],$userinfo[uorder],$userinfo[thold],$userinfo[noscore],$userinfo[ublockon],$userinfo[theme],$userinfo[commentmax]);
	Header("Location: user.php?"); // question is wierd bugfix
}

switch($op) {

	case "logout":
		logout();
		break;

	case "lost_pass":
		lost_pass();
		break;

	case "new user":
		confirmNewUser($uname, $email);
		break;

	case "finish":
		finishNewUser($uname, $email);
		break;

	case "mailpasswd":
		mail_password($uname, $code);
		break;

	case "userinfo":
		userinfo($uname, $bypass);
		break;

	case "login":
		login($uname, $pass);
		break;

	case "dummy":
		include("config.php");
		Header("Location: user.php");
		break;

	case "edituser":
		edituser();
		break;

	case "saveuser":
		saveuser($uid, $name, $uname, $email, $femail, $url, $pass, $vpass, $bio);
		break;

	case "edithome":
		edithome();
		break;
	
	case "chgtheme":
		chgtheme();
		break;
	
	case "savehome":
		savehome($uid, $uname, $theme, $storynum, $ublockon, $ublock);
		break;

	case "savetheme":
		savetheme($uid, $theme);
		break;


	case "editcomm":
		editcomm();
		break;

	case "savecomm":
		savecomm($uid, $uname, $umode, $uorder, $uthold, $noscore, $commentmax);
		break;

	default:
		main($user);
		break;
}
?>
