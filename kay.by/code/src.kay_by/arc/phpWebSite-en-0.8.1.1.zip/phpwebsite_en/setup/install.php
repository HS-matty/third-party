<?php

# --------------------------------------------------------
#
# Table structure for table 'adminblock'
#

mysql_query ("CREATE TABLE adminblock (
   title varchar(60),
   content text
)");


# --------------------------------------------------------
#
# Dumping data for table 'adminblock'
#

mysql_query ("INSERT INTO adminblock VALUES ('Administration Menu','Admin tools for the Web Technology Group\r\n<br /><span class=\"onebiggerred\">></span>\r\n<a href=\"admin.php\">Administration</a>\r\n<br /><span class=\"onebiggerred\">></span>\r\n<a href=\"admin.php?op=logout\">Logout</a>\r\n')");


# --------------------------------------------------------
#
# Table structure for table 'authors'
#

mysql_query ("CREATE TABLE authors (
   aid varchar(30) NOT NULL,
   name varchar(50),
   url varchar(60),
   email varchar(60),
   pwd varchar(32),
   counter int(11) DEFAULT '0' NOT NULL,
   PRIMARY KEY (aid)
)");


# --------------------------------------------------------
#
# Dumping data for table 'authors'
#
$admin_pass = md5("phpwebsite");
mysql_query ("INSERT INTO authors VALUES ('admin','Default Admin','index.php','delete_me@right.now','$admin_pass',0)");


# --------------------------------------------------------
#
# Table structure for table 'banner'
#

mysql_query ("CREATE TABLE banner (
   bid int(11) DEFAULT '0' NOT NULL auto_increment,
   cid int(11) DEFAULT '0' NOT NULL,
   imptotal int(11) DEFAULT '0' NOT NULL,
   impmade int(11) DEFAULT '0' NOT NULL,
   clicks int(11) DEFAULT '0' NOT NULL,
   imageurl varchar(100) NOT NULL,
   clickurl varchar(200) NOT NULL,
   date datetime,
   PRIMARY KEY (bid)
)");


# --------------------------------------------------------
#
# Table structure for table 'bannerclient'
#

mysql_query ("CREATE TABLE bannerclient (
   cid int(11) DEFAULT '0' NOT NULL auto_increment,
   name varchar(60) NOT NULL,
   contact varchar(60) NOT NULL,
   email varchar(60) NOT NULL,
   login varchar(10) NOT NULL,
   passwd varchar(10) NOT NULL,
   extrainfo text NOT NULL,
   PRIMARY KEY (cid)
)");


# --------------------------------------------------------
#
# Table structure for table 'bannerfinish'
#

mysql_query ("CREATE TABLE bannerfinish (
   bid int(11) DEFAULT '0' NOT NULL auto_increment,
   cid int(11) DEFAULT '0' NOT NULL,
   impressions int(11) DEFAULT '0' NOT NULL,
   clicks int(11) DEFAULT '0' NOT NULL,
   datestart datetime,
   dateend datetime,
   PRIMARY KEY (bid)
)");


# --------------------------------------------------------
#
# Table structure for table 'comments'
#

mysql_query ("CREATE TABLE comments (
   tid int(11) DEFAULT '0' NOT NULL auto_increment,
   pid int(11) DEFAULT '0',
   sid int(11) DEFAULT '0',
   date datetime,
   name varchar(60) NOT NULL,
   email varchar(60),
   url varchar(60),
   host_name varchar(60),
   subject varchar(60) NOT NULL,
   comment text NOT NULL,
   score tinyint(4) DEFAULT '0' NOT NULL,
   reason tinyint(4) DEFAULT '0' NOT NULL,
   PRIMARY KEY (tid)
)");


# --------------------------------------------------------
#
# Table structure for table 'counter'
#

mysql_query ("CREATE TABLE counter (
   type varchar(80) NOT NULL,
   var varchar(80) NOT NULL,
   count int(10) unsigned DEFAULT '0' NOT NULL
)");


#
# Dumping data for table 'counter'
#

mysql_query ("INSERT INTO counter VALUES ('browser','WebTV',0)");
mysql_query ("INSERT INTO counter VALUES ('browser','Lynx',0)");
mysql_query ("INSERT INTO counter VALUES ('browser','MSIE',0)");
mysql_query ("INSERT INTO counter VALUES ('browser','Opera',0)");
mysql_query ("INSERT INTO counter VALUES ('browser','Konqueror',0)");
mysql_query ("INSERT INTO counter VALUES ('total','hits',0)");
mysql_query ("INSERT INTO counter VALUES ('browser','Netscape',0)");
mysql_query ("INSERT INTO counter VALUES ('os','Linux',0)");
mysql_query ("INSERT INTO counter VALUES ('browser','Bot',0)");
mysql_query ("INSERT INTO counter VALUES ('browser','Other',0)");
mysql_query ("INSERT INTO counter VALUES ('os','Windows',0)");
mysql_query ("INSERT INTO counter VALUES ('os','Mac',0)");
mysql_query ("INSERT INTO counter VALUES ('os','FreeBSD',0)");
mysql_query ("INSERT INTO counter VALUES ('os','SunOS',0)");
mysql_query ("INSERT INTO counter VALUES ('os','IRIX',0)");
mysql_query ("INSERT INTO counter VALUES ('os','BeOS',0)");
mysql_query ("INSERT INTO counter VALUES ('os','OS/2',0)");
mysql_query ("INSERT INTO counter VALUES ('os','AIX',0)");
mysql_query ("INSERT INTO counter VALUES ('os','Other',0)");

# --------------------------------------------------------
#
# Table structure for table 'flags'
#

mysql_query ("CREATE TABLE flags (poll int(11) DEFAULT '1')");

#
# Dumping data for table 'flags'
#

mysql_query ("INSERT INTO flags VALUES ('1')");

#------------------------------------------------------
#
# Table structure for table 'help'
#

mysql_query ("CREATE TABLE help (
   name text NOT NULL,
   description longtext NOT NULL,
   admin tinyint(1) DEFAULT '0' NOT NULL,
   one int(11) DEFAULT '0' NOT NULL,
   two int(11) DEFAULT '0' NOT NULL,
   three int(11) DEFAULT '0' NOT NULL,
   four int(11) DEFAULT '0' NOT NULL,
   five int(11) DEFAULT '0' NOT NULL,
   six int(11) DEFAULT '0' NOT NULL
)");

#------------------------------------------------------
#
# Table structure for table 'image_category'
#

mysql_query ("CREATE TABLE image_category (
   category_id int(2) DEFAULT '0' NOT NULL auto_increment,
   name varchar(60) NOT NULL,
   PRIMARY KEY (category_id)
)");



#-----------------------------------------------------------
#
# Table structure for table 'images'
#

mysql_query ("CREATE TABLE images (
   image_id int(6) DEFAULT '0' NOT NULL auto_increment,
   filename varchar(25) NOT NULL,
   width int(3),
   height int(3),
   alt tinytext NOT NULL,
   category_id int(2),
   PRIMARY KEY (image_id)
)");


# --------------------------------------------------------
#
# Table structure for table 'lblocks'
#

mysql_query ("CREATE TABLE lblocks (
   id tinyint(4) DEFAULT '0' NOT NULL auto_increment,
   title varchar(60),
   content text,
   order_id int(3),
   PRIMARY KEY (id)
)");


# --------------------------------------------------------
#
# Table structure for table 'links_categories'
#

mysql_query ("CREATE TABLE links_categories (
   cid int(11) DEFAULT '0' NOT NULL auto_increment,
   title varchar(50) NOT NULL,
   PRIMARY KEY (cid)
)");


# --------------------------------------------------------
#
# Table structure for table 'links_links'
#

mysql_query ("CREATE TABLE links_links (
   lid int(11) DEFAULT '0' NOT NULL auto_increment,
   cid int(11) DEFAULT '0' NOT NULL,
   sid int(11) DEFAULT '0' NOT NULL,
   title varchar(100) NOT NULL,
   url varchar(100) NOT NULL,
   description text NOT NULL,
   date datetime,
   name varchar(60) NOT NULL,
   email varchar(60) NOT NULL,
   hits int(11) DEFAULT '0' NOT NULL,
   PRIMARY KEY (lid)
)");


# --------------------------------------------------------
#
# Table structure for table 'links_newlink'
#

mysql_query ("CREATE TABLE links_newlink (
   lid int(11) DEFAULT '0' NOT NULL auto_increment,
   cid int(11) DEFAULT '0' NOT NULL,
   sid int(11) DEFAULT '0' NOT NULL,
   title varchar(100) NOT NULL,
   url varchar(100) NOT NULL,
   description text NOT NULL,
   name varchar(60) NOT NULL,
   email varchar(60) NOT NULL,
   PRIMARY KEY (lid)
)");


# --------------------------------------------------------
#
# Table structure for table 'links_subcategories'
#

mysql_query ("CREATE TABLE links_subcategories (
   sid int(11) DEFAULT '0' NOT NULL auto_increment,
   cid int(11) DEFAULT '0' NOT NULL,
   title varchar(50) NOT NULL,
   PRIMARY KEY (sid)
)");


# --------------------------------------------------------
#
# Table structure for table 'main_page_content'
#

mysql_query ("CREATE TABLE main_page_content (
   main_title varchar(60),
   main_text mediumtext,
   main_image varchar(60),
   main_image_active int(1),
   alt varchar(60),
   active int(1)
)");

#
# Dumping data for table 'main_page_content'
#

mysql_query ("INSERT INTO main_page_content VALUES ('Welcome to phpWebSite',' <p>Developed by the Web Technology Group at Appalachian State University, phpWebSite provides a complete web site content management solution.  All client output is valid XHTML 1.0 and meets the W3C Web Accessibility Initiative requirements.</p>\r\n\r\n <p> You can administrate this site by going the  <a href=\"admin.php\">Administrative Menu</a> and logging on using the following username and password:</p>\r\n\r\n <p>Username:  admin<br />\r\n Password:  phpwebsite</p>\r\n\r\n <p>Once you are logged in you can change this content to fit your needs  Remember to please change the administrative password to protect your site.</p>\r\n\r\n <p>Thank you!</p>\r\n <p> - The phpWebSite Development Team</p>\r\n\r\nRemember to visit the themes and plugin/mods site to get more out of phpWebSite.<br /><a href=\"http://phpwsthemes.sourceforge.net/\">Themes</a><br /><a href=\"http://phpwsplugins.sourceforge.net/\">Plugins/Mods</a>','wtg_new.jpg','1','phpWebSite delivers valid XHTML for client interoperability',1)");

# --------------------------------------------------------
#
# Table structure for table 'menu'
#

mysql_query ("CREATE TABLE menu (
   menu_id int(6) DEFAULT '0' NOT NULL,
   menu_text varchar(50) NOT NULL,
   menu_url varchar(255) NOT NULL,
   menu_level int(1) DEFAULT '0' NOT NULL,
   menu_active int(1) DEFAULT '0' NOT NULL,
   menu_order int(3) DEFAULT '0',
   page_id int(4),
   PRIMARY KEY (menu_id)
)");

#
# Dumping data for table 'menu'
#

mysql_query ("INSERT INTO menu VALUES (1,'Home Page','index.php',1,1,1,NULL)");
mysql_query ("INSERT INTO menu VALUES (2,'Web Links','links.php',1,1,3,NULL)");
mysql_query ("INSERT INTO menu VALUES (3,'Your Account','user.php',1,1,6,NULL)");
mysql_query ("INSERT INTO menu VALUES (4,'Announcements','topics.php',1,1,2,NULL)");
mysql_query ("INSERT INTO menu VALUES (5,'Site Map','site_map.php',1,1,5,NULL)");
mysql_query ("INSERT INTO menu VALUES (6,'Top 10 Stats','top.php',1,1,4,NULL)");
mysql_query ("INSERT INTO menu VALUES (7,'Submit News','submit.php',1,1,7,NULL)");

# --------------------------------------------------------
#
# Table structure for table 'mod_poll_data'
#

mysql_query("CREATE TABLE mod_poll_data (
             pid int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	     data longtext)");

# --------------------------------------------------------
#
# Table structure for table 'mod_poll_flag'
#

mysql_query("CREATE TABLE mod_poll_flag (
             pid int(11),
	     flag tinyint(1))");
mysql_query("INSERT INTO mod_poll_flag VALUES ('0', '0')");

# --------------------------------------------------------
#
# Table structure for table 'mod_poll_comments'
#

mysql_query("CREATE TABLE mod_poll_comments (
             cid int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
             rid int(11),
             pid int(11),
	     date datetime,
	     name varchar(100),
	     email varchar(100),
	     url varchar(100),
	     host_name varchar(100),
	     subject varchar(100),
	     comment text,
	     score tinyint(4),
	     reason tinyint(4))");

# --------------------------------------------------------
#
# Table structure for table 'mod_userpage_data'
#

mysql_query("CREATE TABLE mod_userpage_data (
             id int(5) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	     title varchar(200),
	     data longtext)");

# --------------------------------------------------------
#
# Table structure for table 'modules'
#

mysql_query ("CREATE TABLE modules (
   id int(4) DEFAULT '0' NOT NULL auto_increment,
   name varchar(100) NOT NULL,
   source_file varchar(60) NOT NULL,
   img varchar(25) NOT NULL,
   plug_dir varchar(100) NOT NULL,
   block_pos tinyint(1) DEFAULT '0' NOT NULL,
   block_file varchar(20) NOT NULL,
   admin_only tinyint(1) DEFAULT '0' NOT NULL,
   user_only tinyint(1) DEFAULT '0' NOT NULL,
   admin_inc varchar(20) NOT NULL,
   about mediumtext NOT NULL,
   PRIMARY KEY (id)
)");


# --------------------------------------------------------
#
# Table structure for table 'new_referer'
#

mysql_query ("CREATE TABLE new_referer (
   ref_id int(11) DEFAULT '0' NOT NULL auto_increment,
   url text NOT NULL,
   hit_total int(8) DEFAULT '0' NOT NULL,
   time datetime DEFAULT '0000-00-00 00:00:00',
   PRIMARY KEY (ref_id),
   KEY ref_id (ref_id)
)");

# --------------------------------------------------------
#
# Table structure for table 'queue'
#

mysql_query ("CREATE TABLE queue (
   qid smallint(5) unsigned DEFAULT '0' NOT NULL auto_increment,
   uid mediumint(9) DEFAULT '0' NOT NULL,
   uname varchar(40) NOT NULL,
   subject varchar(100) NOT NULL,
   story text,
   timestamp datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
   topic varchar(20) DEFAULT 'Linux' NOT NULL,
   PRIMARY KEY (qid)
)");


# --------------------------------------------------------
#
# Table structure for table 'quotes'
#

mysql_query ("CREATE TABLE quotes (
   qid int(10) unsigned DEFAULT '0' NOT NULL auto_increment,
   quote text,
   PRIMARY KEY (qid)
)");


# --------------------------------------------------------
#
# Table structure for table 'rblocks'
#

mysql_query ("CREATE TABLE rblocks (
   id tinyint(4) DEFAULT '0' NOT NULL auto_increment,
   title varchar(60),
   content text,
   order_id int(3),
   PRIMARY KEY (id)
)");

# --------------------------------------------------------
#
# Table structure for table 'sections'
#

mysql_query ("CREATE TABLE sections (
   secid int(11) DEFAULT '0' NOT NULL auto_increment,
   secname varchar(40) NOT NULL,
   image varchar(50) NOT NULL,
   PRIMARY KEY (secid)
)");


# --------------------------------------------------------
#
# Table structure for table 'stories'
#

mysql_query ("CREATE TABLE stories (
   sid int(11) DEFAULT '0' NOT NULL auto_increment,
   aid varchar(30) NOT NULL,
   title varchar(80),
   time datetime,
   hometext text,
   bodytext text NOT NULL,
   comments int(11) DEFAULT '0',
   counter mediumint(8) unsigned,
   topic int(2) DEFAULT '1' NOT NULL,
   informant varchar(20) NOT NULL,
   notes text NOT NULL,
   exp_date datetime DEFAULT '9999-12-31 23:59:59',
   PRIMARY KEY (sid)
)");

#
# Table structure for table 'topics'
#

mysql_query ("CREATE TABLE topics (
   topicid int(2) DEFAULT '0' NOT NULL auto_increment,
   topicparent int(2) DEFAULT '0',
   topicname varchar(20),
   topicimage varchar(20),
   topictext varchar(40),
   topiclongtext longtext,
   counter int(11) DEFAULT '0' NOT NULL,
   PRIMARY KEY (topicid)
)");

# --------------------------------------------------------
#
# Table structure for table 'users'
#

mysql_query ("CREATE TABLE users (
   uid int(11) DEFAULT '0' NOT NULL auto_increment,
   name varchar(60) NOT NULL,
   uname varchar(25) NOT NULL,
   email varchar(60) NOT NULL,
   femail varchar(60) NOT NULL,
   url varchar(100) NOT NULL,
   pass varchar(100) NOT NULL,
   storynum tinyint(4) DEFAULT '10' NOT NULL,
   umode varchar(10) NOT NULL,
   uorder tinyint(1) DEFAULT '0' NOT NULL,
   thold tinyint(1) DEFAULT '0' NOT NULL,
   noscore tinyint(1) DEFAULT '0' NOT NULL,
   bio tinytext NOT NULL,
   ublockon tinyint(1) DEFAULT '0' NOT NULL,
   ublock mediumtext,
   theme varchar(255) NOT NULL,
   commentmax int(11) DEFAULT '4096' NOT NULL,
   counter int(11) DEFAULT '0' NOT NULL,
   PRIMARY KEY (uid)
)");

# --------------------------------------------------------
#
# Table structure for table 'version'
#

include("../version.php");
mysql_query ("CREATE TABLE version (version varchar(10))");
mysql_query ("INSERT INTO version VALUES ('$phpwebsite_version')");

?>
