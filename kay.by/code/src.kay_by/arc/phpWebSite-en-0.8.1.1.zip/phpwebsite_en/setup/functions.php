<?php
function dbconnect()
{
	include("../config.php");
	mysql_connect($dbhost, $dbuname, $dbpass);
	@mysql_select_db("$dbname") or die ("Unable to select database");
}

function warning_msg()
{
	echo "<form action=\"index.php\" method=\"post\">
	<p><font color=\"#ff0000\">
	The upgrade to version 0.8.0 requires data conversion!<br />
	It is recommended you only use this upgrade if you are running phpWebSite version 0.7.9 or 0.7.10,<br />
	and you have backed up your existing files and database.<br />
	If you have not backed up your existing files and database, you should exit setup and do so now.<br />
	</font></p>
	<input type=\"submit\" name=\"op\" value=\"PROCEED\" />
	</form>";
}

function main_menu()
{
	echo "<form action=\"index.php\" method=\"post\">
	<p><font color=\"#ff0000\">
	Please make sure your config.php file is configured correctly and choose an install type below.
	</font></p>
	<input type=\"submit\" name=\"op\" value=\"New Install\">
	<input type=\"submit\" name=\"op\" value=\"Upgrade\">
	</form>";
}

function install()
{
	dbconnect();
	include("./install.php");

	$result = mysql_query("SELECT * FROM main_page_content");
	if(!$result)
	{
		//include("./uninstall.php");
		setup_error("database");
	}
	else finish_install();
}

function finish_install()
{
	echo "<center><b>Setup Completed!</b><br />
	The setup has completed succesfully!<br />
	You can now login <a href=\"../admin.php\">Here</a>
	as:<br /><br /><b>Username:</b>&nbsp;&nbsp;admin<br />
	<b>Password:</b>&nbsp;&nbsp;phpwebsite<br /><br />
	Remember to visit the themes and plugin/mods site to get more out of phpWebSite.<br /><br />
	<a href=\"http://phpwsthemes.sourceforge.net/\">Themes</a><br />
	<a href=\"http://phpwsplugins.sourceforge.net/\">Plugins/Mods</a></center>";
}

function get_version()
{
	/* AFTER VERSION 0.8.0 CHECK THE "version" TABLE IN DATABASE FOR CURRENT VERSION */

	echo "What version are you upgrading from?<br /><br />
	<table border=\"0\">
	<tr>
		<td><form action=\"index.php\" method=\"post\">		      
		<input type=\"radio\" name=\"version\" value=\"0.7.9\" checked />0.7.9<br />
		<input type=\"radio\" name=\"version\" value=\"0.7.10\" />0.7.10<br />
		<input type=\"radio\" name=\"version\" value=\"0.8.0\" />0.8.0<br />
		<input type=\"radio\" name=\"version\" value=\"0.8.1\" />0.8.1<br /><br />
		<input type=\"submit\" name=\"op\" value=\"Continue\">
		</form></td>
	</tr>
	</table>";
}

function upgrade($version)
{
	dbconnect();
	include("./upgrade.php");

	switch($version)
	{
		case "0.7.6":
		sevensix_to_eight($version);
		eight_to_nine();
		nine_to_ten();
		seventen_to_eight();
		eight_to_eightone();
		eightone_to_eightonedotone();
		break;
		
		case "0.7.7":
		sevensix_to_eight($version);
		eight_to_nine();
		nine_to_ten();
		seventen_to_eight();
		eight_to_eightone();
		eightone_to_eightonedotone();
		break;
		
		case "0.7.8":
		eight_to_nine();
		nine_to_ten();
		seventen_to_eight();
		eight_to_eightone();
		eightone_to_eightonedotone();
		break;
		
		case "0.7.9":
		nine_to_ten();
		seventen_to_eight();
		eight_to_eightone();
		eightone_to_eightonedotone();
		break;
		
		case "0.7.10":
		seventen_to_eight();
		eight_to_eightone();
		eightone_to_eightonedotone();
		break;

		case "0.8.0":
		eight_to_eightone();
		eightone_to_eightonedotone();
		break;

		case "0.8.1":
		eightone_to_eightonedotone();
		break;
	}

	finish_upgrade($version);
}

function finish_upgrade($version)
{
	echo "<center><b>Upgrade Completed!</b><br />
	The setup has completed succesfully!<br /><br />
        You can now login <a href=\"../admin.php\">Here</a>
        as:<br /><br /><b>Username:</b>&nbsp;&nbsp;admin<br />
        <b>Password:</b>&nbsp;&nbsp;phpwebsite<br /><br />
	Remember to visit the themes and plugin/mods site to get more out of phpWebSite.<br /><br />
        <a href=\"http://phpwsthemes.sourceforge.net/\">Themes</a><br />
        <a href=\"http://phpwsplugins.sourceforge.net/\">Plugins/Mods</a>";
	
	update_config($version);
}

function check_config()
{
	include("../config.php");
	if ($dbuname == "your_username" && $dbpass == "your_password") $type = "config";
	else $type = "none";
	
	return $type;
}

function setup_error($type)
{
	echo "<center><b><font color=\"#ff0000\">ERROR!</font><b><br /><br />";

	switch($type)
	{
		case "config":
		echo "It appears you have not edited your config.php file yet!<br />
		You will need to do this before you continue!"; 
		break;
		
		case "database":
		echo "There was a database error during the setup!<br />
		You can try running the setup again.<br />
		If the problem persists, contact your system administrator.";
		break;
	}
	
	echo "</center>\n";
}

?>
