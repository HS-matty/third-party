<?php

function sevensix_to_eight($version)
{
	/* UPDATE TABLE: FLAGS */
	mysql_query("ALTER TABLE flags ADD version varchar(10)");
	mysql_query("UPDATE flags SET version='0_7_8'");
	
	/* UPDATE TABLE: AUTHORS */
	mysql_query("ALTER TABLE authors MODIFY pwd varchar(32)");

	if($version == "0.7.6")
	{
		$result = mysql_query("SELECT aid, pwd FROM authors");
	
		while(list($aid, $pwd) = mysql_fetch_row($result))
		{
			$new_pass = md5($pwd);
			mysql_query("UPDATE authors SET pwd='$new_pass' WHERE aid='$aid'");
		}
	}

	/* UPDATE TABLE: MENU */
	mysql_query("ALTER TABLE menu MODIFY menu_url varchar(255)");
	
	/* UPDATE TABLE: RIGHT BLOCKS */
	mysql_query("ALTER TABLE rblocks ADD order_id int(3)");
	$result = mysql_query("SELECT id FROM rblocks ORDER BY id");
	$order_id = 1;
	while(list($id) = mysql_fetch_row($result))
	{
		mysql_query("UPDATE rblocks SET order_id='$order_id' WHERE id='$id'");
		$order_id++;
	}

	/* UPDATE TABLE: LEFT BLOCKS */
	mysql_query("ALTER TABLE lblocks ADD order_id int(3)");
	$result = mysql_query("SELECT id FROM lblocks ORDER BY id");
	$order_id = 1;
	while(list($id) = mysql_fetch_row($result))
	{
		mysql_query("UPDATE lblocks SET order_id='$order_id' WHERE id='$id'");
		$order_id++;
	}

	/* UPDATE TABLE: STORIES */
	mysql_query ("ALTER TABLE stories ADD exp_date DATETIME DEFAULT '9999-12-31 23:59:59'");


	/* UPDATE TABLE: TOPICS */
	mysql_query("ALTER TABLE topics 
		ADD topicparent int(2) DEFAULT '0',
		ADD topiclongtext longtext
 	");

	/* DROP OLD HELP TABLE IF 0.7.7-dev */
	mysql_query("drop table help");
	
	/* CREATE TABLE: HELP */
	mysql_query ("CREATE TABLE help (
	   name text NOT NULL,
	   description longtext NOT NULL,
	   admin tinyint(1) DEFAULT '0' NOT NULL,
	   one int(11) DEFAULT '0' NOT NULL,
	   two int(11) DEFAULT '0' NOT NULL,
	   three int(11) DEFAULT '0' NOT NULL,
 	   four int(11) DEFAULT '0' NOT NULL,
	   five int(11) DEFAULT '0' NOT NULL,
	   six int(11) DEFAULT '0' NOT NULL
	)");
}

function eight_to_nine()
{
	mysql_query("UPDATE flags SET version='0_7_9'");

	/* UPDATE TABLE: MAIN_PAGE_CONTENT */
	mysql_query("ALTER TABLE main_page_content ADD main_image_active int(1)");
	mysql_query("UPDATE main_page_content SET main_image_active='1'");
	
}

function nine_to_ten()
{
	/* UPDATE TABLE: MAIN_PAGE_CONTENT */
	mysql_query("ALTER TABLE main_page_content ADD main_image_active int(1)");
	mysql_query("UPDATE main_page_content SET main_image_active='1'");
	mysql_query("ALTER TABLE user_pages CHANGE title title VARCHAR(200)");
	mysql_query("ALTER TABLE main_page_content CHANGE main_title main_title VARCHAR(200)");
	mysql_query("UPDATE flags SET version='0_7_10'");

	/* UPDATE POLLS */
	include("../mod/poll/poll_setup.php");
}

function seventen_to_eight()
{
	include("../mod/userpage/userpage_setup.php");
	include("../version.php");
	
	mysql_query("ALTER TABLE plugins RENAME TO modules");
	mysql_query("ALTER TABLE modules CHANGE source_file source_file varchar(60)");
	mysql_query ("CREATE TABLE version (version varchar(10))");
	mysql_query ("INSERT INTO version VALUES ('$phpwebsite_version')");
	mysql_query("DROP TABLE ephem");
	mysql_query("DROP TABLE mainblock");
	mysql_query("DROP TABLE messages");
	mysql_query("DROP TABLE seccont");
	mysql_query("DROP TABLE template_icons");
	mysql_query("ALTER TABLE new_referer CHANGE url url text");
}

function eight_to_eightone()
{
	/* NO DATABASE CHANGES IN 0.8.1 */
}

function eightone_to_eightonedotone()
{
	include("../config.php");
	include("../version.php");

	mysql_query("ALTER TABLE users CHANGE pass pass VARCHAR(100)");
	mysql_query("UPDATE version SET version='$phpwebsite_version'");
}

function update_config($version)
{
	switch($version)
	{
		case "0.7.6":
		echo "<table border=\"0\"><tr><td>
		      <b>ATTENTION!</b><br />
		      The following lines need to be added to your config.php file:<br /><br />
		      \$check_version = 1;	# Change to 0 to disable the up-to-date check in admin section.<br />
		      \$url_to_email = 1; 	# Set to 0 for articles to list the url for the author of an article. Set to 1 for it to list their email<br />
		      \$extend_menu = 0;	# 0 = Menu NOT fully extended by default. 1 = Menu IS fully extended by default<br />
		      \$unique_titles = 0;       # Whether or not pages will have unique titles<br />
		      \$limit_cache = 0; 	# set to one to disable browser cacheing<br />
		      \$menu_bullet = \"<b>&#183;</b>&nbsp;\"; # Set this to whatever you like for a menu bullet, \"\" for none.<br />
		      \$security_hash = \"sGw2mDi5vosEW74ngid2V5H7Ed7ske\";<br /><br />You need to change this to a random string, it can be any length but longer is better.  This fixes the security problem that occurs when multiple instances of phpWebSite are installed under a single domain. If you only have a single instance of phpWebSite per domain, you need not worry about this fix - although setting the security hash to a random string won't hurt :-)		
		      <br />
		      Also, if you are using specialized themes, please compare them to the updated defaults.
		      </td></tr></table>";
		break;

		case "0.7.7-dev":
		echo "<table border=\"0\"><tr><td>
		      <b>ATTENTION!</b><br />
		      The following lines need to be added to your config.php file:<br /><br />
		      \$unique_titles = 0;       # Whether or not pages will have unique titles<br />
		      \$menu_bullet = \"<b>&#183;</b>&nbsp;\"; # Set this to whatever you like for a menu bullet, \"\" for none.
		      \$security_hash = \"sGw2mDi5vosEW74ngid2V5H7Ed7ske\";<br /><br />You need to change this to a random string, it can be any length but longer is better.  This fixes the security problem that occurs when multiple instances of phpWebSite are installed under a single domain. If you only have a single instance of phpWebSite per domain, you need not worry about this fix - although setting the security hash to a random string won't hurt :-)
		      <br /><br />
		      Also, if you are using specialized themes, please compare them to the updated defaults.
		      </td></tr></table>";
		break;
		
		case "0.7.7-stable":
		echo "<table border=\"0\"><tr><td>
		      <b>ATTENTION!</b><br />
		      The following lines need to be added to your config.php file:<br /><br />
		      \$unique_titles = 0;       # Whether or not pages will have unique titles<br />
		      \$menu_bullet = \"<b>&#183;</b>&nbsp;\"; # Set this to whatever you like for a menu bullet, \"\" for none.
		      \$security_hash = \"sGw2mDi5vosEW74ngid2V5H7Ed7ske\";<br /><br />You need to change this to a random string, it can be any length but longer is better.  This fixes the security problem that occurs when multiple instances of phpWebSite are installed under a single domain. If you only have a single instance of phpWebSite per domain, you need not worry about this fix - although setting the security hash to a random string won't hurt :-)
		      <br /><br />
		      Also, if you are using specialized themes, please compare them to the updated defaults.
		      </td></tr></table>";
		break;

		case "0.7.8":
		echo "<table border=\"0\"><tr><td>
		      <b>ATTENTION!</b><br />
		      The following lines need to be added to your config.php file:<br /><br />
		      \$unique_titles = 0;       # Whether or not pages will have unique titles<br />
		      \$security_hash = \"sGw2mDi5vosEW74ngid2V5H7Ed7ske\";<br /><br />You need to change this to a random string, it can be any length but longer is better.  This fixes the security problem that occurs when multiple instances of phpWebSite are installed under a single domain. If you only have a single instance of phpWebSite per domain, you need not worry about this fix - although setting the security hash to a random string won't hurt :-)
		      </td></tr></table>";
		break;
		
		case "0.7.9":
		echo "<table border=\"0\"><tr><td>
		      <b>ATTENTION!</b><br />
		      The following lines need to be added to your config.php file:<br /><br />
		      \$unique_titles = 0;       # Whether or not pages will have unique titles<br />
		      \$security_hash = \"sGw2mDi5vosEW74ngid2V5H7Ed7ske\";<br /><br />You need to change this to a random string, it can be any length but longer is better.  This fixes the security problem that occurs when multiple instances of phpWebSite are installed under a single domain. If you only have a single instance of phpWebSite per domain, you need not worry about this fix - although setting the security hash to a random string won't hurt :-)
		      </td></tr></table>";
		break;
		
		case "0.7.10":
		break;

		case "0.8.0":
		case "0.8.1":
		break;
	}
}

?>
