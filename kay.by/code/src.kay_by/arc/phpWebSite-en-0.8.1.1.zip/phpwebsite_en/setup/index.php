<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head><title>phpWebSite Setup</title></head>
<body bgcolor="#ffffff" text="#000000" link="#0000ff" vlink="#800080" alink="#ff0000">

<center>
<img src="./poweredby.jpg" alt="websetup" align="bottom" border="0"/>
<br /><br />
<b>Welcome to the phpWebSite web based setup program.</b><br />
<b>Make sure your database has been backed up before running this setup!</b>
<br /><br />

<?php

include("./functions.php");

switch($op)
{
	case "New Install":
	install();
	break;

	case "Upgrade":
	warning_msg();
	break;

	case "PROCEED";
	$error_type = check_config();
	if($error_type == "none") get_version();
	else setup_error($type);
	break;
		
	case "Continue":
	upgrade($version);
	break;

	default:
	main_menu();
	break;
}

?>

</center>
</body>
</html>
