<?php
/**
 * This file updates the counter for the appropriate browser and OS a user is using.
 *
 * @author Karsten Dambekalns <k.dambekalns@fishfarm.de>
 *
 * @module counter
 * @modulegroup core
 * @package phpWebSite
 */

$HUA = getenv("HTTP_USER_AGENT");

if((strstr($HUA, "Nav")) || (strstr($HUA, "Gold")) || (strstr($HUA, "X11")) || (strstr($HUA, "Mozilla")) || (strstr($HUA, "Netscape")) AND (!strstr($HUA, "MSIE"))) $browser = "Netscape";

elseif(strstr($HUA, "MSIE")) $browser = "MSIE";
elseif(strstr($HUA, "Lynx")) $browser = "Lynx";
elseif(strstr($HUA, "Opera")) $browser = "Opera";
elseif(strstr($HUA, "WebTV")) $browser = "WebTV";
elseif(strstr($HUA, "Konqueror")) $browser = "Konqueror";
elseif((stristr($HUA, "bot")) || (strstr($HUA, "Google")) || (strstr($HUA, "Slurp")) || (strstr($HUA, "Scooter")) || (stristr($HUA, "Spider")) || (stristr($HUA, "Infoseek"))) $browser = "Bot";
else $browser = "Other";

if(strstr($HUA, "Win")) $os = "Windows";
elseif((strstr($HUA, "Mac")) || (strstr($HUA, "PPC"))) $os = "Mac";
elseif(strstr($HUA, "Linux")) $os = "Linux";
elseif(strstr($HUA, "FreeBSD")) $os = "FreeBSD";
elseif(strstr($HUA, "SunOS")) $os = "SunOS";
elseif(strstr($HUA, "IRIX")) $os = "IRIX";
elseif(strstr($HUA, "BeOS")) $os = "BeOS";
elseif(strstr($HUA, "OS/2")) $os = "OS/2";
elseif(strstr($HUA, "AIX")) $os = "AIX";
else $os = "Other";

mysql_query("update counter set count=count+1 where (type='total' and var='hits') or (var='$browser' and type='browser') or (var='$os' and type='os')");
?>
