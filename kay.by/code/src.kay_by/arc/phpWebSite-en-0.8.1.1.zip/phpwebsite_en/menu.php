<?php
/**
 * Displays the menu block.
 *
 * @module menu
 * @modulegroup core
 * @package phpWebSite
 */


// Check $menu and see what level we are on.  

if($extend_menu) full_menu($menu);
else
{
	if ($menu < 100) menu1($menu);
	else if ($menu < 10000 ) menu2($menu);
	else if($menu < 1000000) menu3($menu);
}

/**
 * Display Menu - First Level Menu
 *
 * @param int Menu ID
 */
function menu1($menu)
{
	include("config.php");
  
	$result = mysql_query("select menu_id, menu_text, menu_url, menu_order, page_id from menu where menu_level = 1 and menu_active = 1 order by menu_order");
  
	while(list($menu_id, $menu_text, $menu_url, $menu_order, $page_id) = mysql_fetch_row($result))
	{
		$temp = explode(":", $menu_url);
		if($temp[0] == "http")
		{
			echo $menu_bullet . "<a href=\"$menu_url\" target=\"_blank\">$menu_text</a><br />\n";
		}
		else if($page_id)
		{
			if($menu_url == 'mod.php?mod=userpage')
			echo $menu_bullet . "<a href=\"$menu_url&amp;menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
			else
			echo $menu_bullet . "<a href=\"$menu_url?menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
		} 
		else
		{
			if(substr_count($menu_url, "?"))
			echo $menu_bullet . "<a href=\"$menu_url&amp;menu=$menu_id\">$menu_text</a><br />";
			else
			echo $menu_bullet . "<a href=\"$menu_url?menu=$menu_id\">$menu_text</a><br />";
		}
    
		if ($menu == $menu_id)
		{
			$low_sub = $menu * 100;
			$high_sub = $low_sub + 99;
      
			$result_sub = mysql_query("select menu_id, menu_text, menu_url, menu_order, page_id from menu where menu_level = 2 and menu_active = 1 and menu_id >=  $low_sub and menu_id <=  $high_sub order by menu_order");
       
			while(list($menu_id, $menu_text, $menu_url, $menu_order, $page_id) = mysql_fetch_row($result_sub))
			{
				$temp = explode(":", $menu_url);
				if($temp[0] == "http")
				{
					echo "&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url\" target=\"_blank\">$menu_text</a><br />\n";
				}
				else if($page_id)
				{
					if($menu_url == 'mod.php?mod=userpage')
					echo"&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url&amp;menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
					else
					echo"&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url?menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
				}
				else
				{
					if(substr_count($menu_url, "?"))
					echo "&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url&amp;menu=$menu_id\">$menu_text</a><br />";
					else
					echo"&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url?menu=$menu_id\">$menu_text</a><br />";
				}
			}
       
		}
    
	}
}

/**
 * Display Menu - Second Level Menu
 *
 * @param int Menu ID
 */
function menu2($menu)
{
	include("config.php");

	$result = mysql_query("select menu_id, menu_text, menu_url, menu_order, page_id from menu where menu_level = 1 and menu_active = 1 order by menu_order");
  
	while(list($menu_id, $menu_text, $menu_url, $menu_order, $page_id) = mysql_fetch_row($result))
	{
		$temp = explode(":", $menu_url);
		if($temp[0] == "http")
		{
			echo $menu_bullet . "<a href=\"$menu_url\" target=\"_blank\">$menu_text</a><br />\n";
		}
		else if($page_id)
		{
			if($menu_url == 'mod.php?mod=userpage')
			echo $menu_bullet . "<a href=\"$menu_url&amp;menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
			else
			echo $menu_bullet . "<a href=\"$menu_url?menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
		}
		else
		{
			if(substr_count($menu_url, "?"))
			echo $menu_bullet . "<a href=\"$menu_url&amp;menu=$menu_id\">$menu_text</a><br />";
			else
			echo $menu_bullet . "<a href=\"$menu_url?menu=$menu_id\">$menu_text</a><br />";
		}

		if ((floor($menu / 100)) == $menu_id)
		{
			$low_sub = ((floor($menu / 100)) * 100);
			$high_sub = ($low_sub + 99);
       
			$result_sub = mysql_query("select menu_id, menu_text, menu_url, menu_order, page_id from menu where menu_level = 2 and menu_active = 1 and menu_id >=  $low_sub and menu_id <= $high_sub order by menu_order");
       
			while(list($menu_id, $menu_text, $menu_url, $menu_order, $page_id) = mysql_fetch_row($result_sub))
			{
				$temp = explode(":", $menu_url);
				if($temp[0] == "http")
				{
					echo "&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url\" target=\"_blank\">$menu_text</a><br />\n";
				}
				else if($page_id)
				{
					if($menu_url == 'mod.php?mod=userpage')
					echo"&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url&amp;menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
					else
					echo"&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url?menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
				}
				else
				{
					if(substr_count($menu_url, "?"))
					echo "&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url&amp;menu=$menu_id\">$menu_text</a><br />";
					else
					echo"&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url?menu=$menu_id\">$menu_text</a><br />";
				}

				if ($menu == $menu_id)
				{
					$low_sub = ($menu * 100);
					$high_sub = ($low_sub + 99);

					$result_sub2 = mysql_query("select menu_id, menu_text, menu_url, menu_order, page_id from menu where menu_level = 3 and menu_active = 1 and menu_id >=  $low_sub and menu_id <= $high_sub order by menu_order");
	   
					while(list($menu_id, $menu_text, $menu_url, $menu_order, $page_id) = mysql_fetch_row($result_sub2))
					{
						$temp = explode(":", $menu_url);
						if($temp[0] == "http")
						{
							echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url\" target=\"_blank\">$menu_text</a><br />\n";
						}
						else if($page_id)
						{
							if($menu_url == 'mod.php?mod=userpage')
							echo"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url&amp;menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
							else
							echo"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url?menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
						}
						else
						{
							if(substr_count($menu_url, "?"))
							echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url&amp;menu=$menu_id\">$menu_text</a><br />";
							else
							echo"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url?menu=$menu_id\">$menu_text</a><br />";
						}
					}
				}
			}
		}
	}
}

/**
 * Display Menu - Third Level Menu
 *
 * @param int Menu ID
 */
function menu3($menu)
{
	include("config.php");

	$result = mysql_query("select menu_id, menu_text, menu_url, menu_order, page_id from menu where menu_level = 1 and menu_active = 1 order by menu_order");
  
	while(list($menu_id, $menu_text, $menu_url, $menu_order, $page_id) = mysql_fetch_row($result))
	{
		$temp = explode(":", $menu_url);
		if($temp[0] == "http")
		{
			echo $menu_bullet . "<a href=\"$menu_url\" target=\"_blank\">$menu_text</a><br />\n";
		}
		else if($page_id)
		{
			if($menu_url == 'mod.php?mod=userpage')
			echo $menu_bullet . "<a href=\"$menu_url&amp;menu=$menu_id&page_id=$page_id\">$menu_text</a><br />";
			else
			echo $menu_bullet . "<a href=\"$menu_url?menu=$menu_id&page_id=$page_id\">$menu_text</a><br />";
		}
		else
		{
			if(substr_count($menu_url, "?"))
			echo $menu_bullet . "<a href=\"$menu_url&amp;menu=$menu_id\">$menu_text</a><br />";
			else
			echo $menu_bullet . "<a href=\"$menu_url?menu=$menu_id\">$menu_text</a><br />";
		}
    
		if ((floor($menu / 10000)) == $menu_id)
		{
			$low_sub = ((floor($menu / 10000)) * 100);
			$high_sub = ($low_sub + 99);
      
			$result_sub = mysql_query("select menu_id, menu_text, menu_url, menu_order, page_id from menu where menu_level = 2 and menu_active = 1 and menu_id >=  $low_sub and menu_id <= $high_sub order by menu_order");
      
			while(list($menu_id, $menu_text, $menu_url, $menu_order, $page_id) = mysql_fetch_row($result_sub))
			{
				$temp = explode(":", $menu_url);
				if($temp[0] == "http")
				{
					echo "&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url\" target=\"_blank\">$menu_text</a><br />\n";
				}
				else if($page_id)
				{
					if($menu_url == 'mod.php?mod=userpage')
					echo"&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url&amp;menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
					else
					echo"&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url?menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
				}
				else
				{
					if(substr_count($menu_url, "?"))
					echo "&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url&amp;menu=$menu_id\">$menu_text</a><br />";
					else
					echo"&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url?menu=$menu_id\">$menu_text</a><br />";
				}

				if ((floor($menu / 100)) == $menu_id)
				{
					$low_sub = (floor($menu /100) * 100);
					$high_sub = ($low_sub + 99);
	  
					$result_sub2 = mysql_query("select menu_id, menu_text, menu_url, menu_order, page_id from menu where menu_level = 3 and menu_active = 1 and menu_id >=  $low_sub and menu_id <= $high_sub order by menu_order");
	  
					while(list($menu_id, $menu_text, $menu_url, $menu_order, $page_id) = mysql_fetch_row($result_sub2))
					{
						$temp = explode(":", $menu_url);
						if($temp[0] == "http")
						{
							echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url\" target=\"_blank\">$menu_text</a><br />\n";
						}
						else if($page_id)
						{
							if($menu_url == 'mod.php?mod=userpage')
							echo"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url&amp;menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
							else
							echo"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url?menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
						}
						else
						{
							if(substr_count($menu_url, "?"))
							echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url&amp;menu=$menu_id\">$menu_text</a><br />";
							else
							echo"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url?menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
						}
					}
				}
			}
		}
	}
}

/**
 * Display Menu - Full Menu
 *
 * @param int Menu ID
 */
function full_menu()
{
	include("config.php");
	global $menu_bullet;
  
	$result = mysql_query("select menu_id, menu_text, menu_url, menu_order, page_id from menu where menu_level = 1 && menu_active = 1 order by menu_order");
  
	while(list($menu_id, $menu_text, $menu_url, $menu_order, $page_id) = mysql_fetch_row($result))
	{
		$temp = explode(":", $menu_url);
		if($temp[0] == "http")
		{
			echo $menu_bullet . "<a href=\"$menu_url\" target=\"_blank\">$menu_text</a><br />\n";
		}
		else if($page_id)
		{
			if($menu_url == 'mod.php?mod=userpage')
			echo "$menu_bullet<a href=\"$menu_url&amp;menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
			else
			echo "$menu_bullet<a href=\"$menu_url?menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
		}
		else echo "$menu_bullet<a href=\"$menu_url\">$menu_text</a><br />";
      
		$low_sub = $menu_id * 100;
		$high_sub = $low_sub + 99;

		$result_sub = mysql_query("select menu_id, menu_text, menu_url, menu_order, page_id from menu where menu_level = 2 && menu_active = 1 && menu_id >=  $low_sub && menu_id <=  $high_sub order by menu_order");
      
		while(list($menu_id, $menu_text, $menu_url, $menu_order, $page_id) = mysql_fetch_row($result_sub))
		{
			$temp = explode(":", $menu_url);
			if($temp[0] == "http")
			{
				echo "&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url\" target=\"_blank\">$menu_text</a><br />\n";
			}
			else if($page_id)
			{
				if($menu_url == 'mod.php?mod=userpage')
				echo "&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url&amp;menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
				else
				echo "&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url?menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
			}
			else echo "&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url\">$menu_text</a><br />";
			
			$low_sub = $menu_id * 100;
			$high_sub = $low_sub + 99;
	  
			$result_sub2 = mysql_query("select menu_id, menu_text, menu_url, menu_order, page_id from menu where menu_level = 3 && menu_active = 1 && menu_id >=  $low_sub && menu_id <=  $high_sub order by menu_order");
	  
			while(list($menu_id, $menu_text, $menu_url, $menu_order, $page_id) = mysql_fetch_row($result_sub2))
			{
				$temp = explode(":", $menu_url);
				if($temp[0] == "http")
				{
					echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url\" target=\"_blank\">$menu_text</a><br />\n";
				}
				else if($page_id)
				{
					if($menu_url == 'mod.php?mod=userpage')
					echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url&amp;menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
					else
					echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url?menu=$menu_id&amp;page_id=$page_id\">$menu_text</a><br />";
				}
				else echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$menu_bullet<a href=\"$menu_url\">$menu_text</a><br />";
			}
		}
	}
}
?>
