<?php

/**
 * Fills in the user block depending on preferences in
 * mod_calendar_settings
 *
 * @module cal_block.php
 * @modulegroup blockcode
 * @package Calendar
 */

include ("mod/calendar/calendar_config.php");
include ("mod/calendar/language.php");

$box_content = '';

$sql_setting = mysql_query ("select * from mod_calendar_settings");
$setting = mysql_fetch_array ($sql_setting);
extract ($setting);

global $calendar_display, $repeat_array, $temptime;
if ($calendar_display != '1'){
	include ("mod/calendar/calendar_display.php");
	$calendar_display = 1;
}

/**
 * Checks the mod_calendar_post for articles that require posting
 */
check_post();

/**
 * This view shows a small monthly calendar which allows views by day,
 * week or month depending on where you click. It chews Netscape up
 * unfortunately
 *
 */

if ($month_view) {
	if (!$date)
		$date = date_now("Ymd");
	$box_content .= small_month($date);
}

if ($month_view && $week_view)
	$box_content .= "
<br /><hr width=\"75%\" noshade=\"noshade\" /><br />";

/**
 * This view shows the events for the next 7 days
 */

if ($week_view) {
	$week_today = mktime (0, 0, 0, substr(date_now("Ymd"),4,2), substr(date_now("Ymd"),6,2), substr(date_now("Ymd"),0,4));
	$box_content .= "<b>$tran[This_Weeks_Events]</b><br /><br />";
	for ($i=$week_today; $i < ($week_today + (3600 * 24 * 7)); $i += (3600 * 24)){
		$current_day = date (Ymd, $i);
		$repeat_count = count_repeats($current_day);
		$repeat_array = get_repeats($current_day);
		$week_sql = mysql_query("select event_id, title from mod_calendar_events where event_date = '$current_day' order by title");		
		if (mysql_num_rows($week_sql) || $repeat_count){
			$week_event_found = 1;
			$box_content .= "
			<table width=\"100%\" cellspacing=\"0\" cellpadding=\"2\" border=\"0\">
			<tr>
				<td class=\"$block_top\" colspan=\"2\">" . format_date($current_day, "day_date") . "</td>
			</tr>";
			while ($row = mysql_fetch_array($week_sql)){
				extract ($row);
				$box_content .= "
			<tr>
				<td valign=\"top\" class=\"$block_body\" width=\"5%\">" . mini_view($event_id) . "</td>
				<td valign=\"top\" class=\"$block_body\"><a href=\"mod.php?mod=calendar&amp;op=show_event&amp;event_id=$event_id\">
					<span class=\"$smalltype\">$title</span></a>
				</td>
			</tr>";
			}
			$box_content .= list_repeats($repeat_array, $current_day, 9999, block_week);
			$box_content .= "
			</table>";
		}
		
	}
	if (!$week_event_found)
		$box_content .= "<i>$tran[No_events_this_week]</i>";
}

if (($month_view || $week_view) && ($cat_view || $subcat_view || $location_view))
	$box_content .= "
<br /><hr width=\"75%\" noshade=\"noshade\" /><br />";

/**
 * These views allow the searching of events by category, subcategory
 * or location.
 *
 */

if ($cat_view) {
	$cat_sql = mysql_query("select cat_id, category from mod_calendar_category order by category");
	if (mysql_num_rows($cat_sql))
	{
		$box_content .= "
<b>$tran[Search_events_by]...</b>
<form action=\"mod.php\" method=\"post\">
	<input type=\"hidden\" name=\"mod\" value=\"calendar\" />
	<input type=\"hidden\" name=\"op\" value=\"list_events\" />
	<input type=\"hidden\" name=\"sortby\" value=\"category\" />

	<span class=\"$smalltype\">
	<select name=\"cat_id\">";

		while (list($cat_id, $category) = mysql_fetch_array($cat_sql))
			$box_content .= "
		<option value=\"$cat_id\">$category</option>";

		$box_content .= "
	</select>
	</span>
	<span class=\"$smalltype\">
	<input type=\"submit\" value=\"$tran[cat_name] $tran[Events]\" />
	</span>
</form>";
	} elseif ($admintest)
		$box_content .= "<br /><i>$tran[No] $tran[cat_name] $tran[Found]</i>";
}

if ($subcat_view) {
	$subcat_sql = mysql_query("select subcat_id, subcat from mod_calendar_subcat order by subcat");
	if (mysql_num_rows($subcat_sql))
	{
		$box_content .= "
<form action=\"mod.php\" method=\"post\">
	<input type=\"hidden\" name=\"mod\" value=\"calendar\" />
	<input type=\"hidden\" name=\"op\" value=\"list_events\" />
	<input type=\"hidden\" name=\"sortby\" value=\"subcat\" />
	<span class=\"$smalltype\">
	<select name=\"subcat_id\">";

		while (list($subcat_id, $subcat) = mysql_fetch_array($subcat_sql))
			$box_content .= "
		<option value=\"$subcat_id\">$subcat</option>";

		$box_content .= "
	</select>
	</span>
	<span class=\"$smalltype\">
	<input type=\"submit\" value=\"$tran[subcat_name] $tran[Events]\" />
	</span>
</form>
";
	} elseif ($admintest)
	$box_content .= "<br /><i>$tran[No] $tran[subcat_name] $tran[Found]</i>";

}
if ($location_view) {
	$location_sql = mysql_query("select loc_id, loc_name from mod_calendar_location order by loc_name");
	if (mysql_num_rows($location_sql))
	{
		$box_content .= "
<form action=\"mod.php\" method=\"post\">
	<input type=\"hidden\" name=\"mod\" value=\"calendar\" />
	<input type=\"hidden\" name=\"op\" value=\"list_events\" />
	<input type=\"hidden\" name=\"sortby\" value=\"location\" />
	<span class=\"$smalltype\">
	<select name=\"loc_id\">";

		while (list($loc_id, $loc_name) = mysql_fetch_array($location_sql))
			$box_content .= "
		<option value=\"$loc_id\">$loc_name</option>";

		$box_content .= "
	</select>
	</span>
	<span class=\"$smalltype\">
	<input type=\"submit\" value=\"$tran[Location_Events]\" />
	</span>
</form>";
	} elseif ($admintest)
	$box_content .= "<br /><i>$tran[No_Locations_Found]</i>";

}


if (($month_view || $week_view || $cat_view || $subcat_view || $location_view) && $today_view)
	$box_content .= "
<br /><hr width=\"75%\" noshade=\"noshade\" /><br />";

/**
 * This view shows the current day's events
 *
 */

if ($today_view){
	$repeat_count = count_repeats(date_now(Ymd));
 	$search_day = date_now("Ymd");
	$repeat_array = get_repeats($search_day);
	$sql = "select title, starttime, allday, event_id from mod_calendar_events where event_date = '$search_day' order by starttime";
	$sql_result = mysql_query ($sql);
	$box_content .= "<b>$tran[Today_s_Events]</b><br /><br />";
	if (!mysql_num_rows($sql_result) && $repeat_count < 1)
		$box_content .= "
<table width=\"100%\" cellpadding=\"3\" cellspacing=\"0\" border=\"0\">
<tr>
	<td class=\"$block_top\" align=\"center\" colspan=\"2\"><i>$tran[No_events_today]</i></td>
</tr>
</table>";
	while ($row = mysql_fetch_array($sql_result)){
		extract($row);
		$box_content .= list_repeats($repeat_array, $search_day, $starttime, block_day);
		if ($temptime != $starttime) {
			if ($allday != 1)
				$box_content .= "
<table width=\"100%\" cellpadding=\"3\" cellspacing=\"0\" border=\"0\">
<tr>
	<td class=\"$block_top\" align=\"center\" colspan=\"2\">" . get_time($starttime). "</td>
</tr>
</table>";

			else
				$box_content .= "
<table width=\"100%\" cellpadding=\"3\" cellspacing=\"0\" border=\"0\">
<tr>
	<td class=\"$block_top\" align=\"center\" colspan=\"2\">$tran[All_Day]</td>
</tr>
</table>";

			$temptime = $starttime;
			$box_switch = 1;
		}
		$box_content .= "
<table width=\"100%\" cellpadding=\"3\" cellspacing=\"0\" border=\"0\">
<tr>
	<td valign=\"top\" class=\"$block_body\" width=\"5%\">" . mini_view($event_id) . "</td>
	<td valign=\"top\" class=\"$block_body\"><a href=\"mod.php?mod=calendar&amp;op=show_event&amp;event_id=$event_id\">
		<span class=\"$smalltype\">$title</span></a>
	</td>
</tr>
</table>";
	}
		$box_content .= list_repeats($repeat_array, $search_day, 9999, block_day);
}

/**
 * If the month view is not available, a small menu appears giving the
 * same view opportunities.
 *
 */

if (!$month_view)
	$box_content .= switch_views();

?>
