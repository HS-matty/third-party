<?php
function alt_month_view($date=''){
include ("mod/calendar/calendar_config.php");
include ("mod/calendar/language.php");
include ("header.php");

global $repeat_array, $tran, $holdtime;

	if (strlen( $date ) > 0 ) {
		$thisyear = substr ( $date, 0, 4 );
		$thismonth = substr ( $date, 4, 2 );
		$thisday = substr ( $date, 6, 2 );
	} else {
		if ( $month == 0 )
			$thismonth = date_now("m");
		else
			$thismonth = $month;
		if ( $year == 0 )
			$thisyear = date_now("Y");
		else
			$thisyear = $year;
		if ($day == 0)
			$thisday = date_now("d");
		else
			$thisday = $day;
	}

	$this = mktime (2,0,0, $thismonth, 1, $thisyear);

	$next = mktime (2, 0, 0, $thismonth + 1, 1, $thisyear );
	$nextyear = date ( "Y", $next );
	$nextmonth = date ( "m", $next );
	$nextday= date("d",$next);
	$nextdate = date ("Ymd", $next);

	$prev = mktime ( 2, 0, 0, $thismonth - 1, 1, $thisyear );
	$prevyear = date ( "Y", $prev );
	$prevmonth = date ( "m", $prev );
	$prevday = date ("d", $prev);
	$prevdate = date("Ymd", $prev);

	$startdate = date("Ymd", mktime(2,0,0,$thismonth,1,$thisyear));
	$enddate = date("Ymd", mktime(2,0,0,$nextmonth,$nextday-1,$nextyear));

	$wkstart = get_sunday_before ( $thisyear, $thismonth, 1 );
	$monthstart = mktime (2, 0, 0, $thismonth, 1, $thisyear );
	$monthend = mktime (2, 0, 0, $thismonth + 1, 0, $thisyear );

	$today = date_now("Ymd");

	$month_name = $tran[date("F", $this)];

	$sql = "select pic_$thismonth from mod_calendar_settings where pic_$thismonth != ''";
	$sql_result = mysql_query($sql);
	list($month_image) = mysql_fetch_row($sql_result);

	$box_title = "<div align=\"center\"><a href=\"mod.php?mod=calendar&amp;op=month_view&amp;date=$prevdate\">&lt;-</a> $month_name <a href=\"mod.php?mod=calendar&amp;op=month_view&amp;date=$nextdate\">-&gt;</a></div>";
	$content = "
    <table border=\"0\" width=\"100%\" cellspacing=\"1\" cellpadding=\"3\">";

	for($i = $monthstart; $i <= $monthend; $i = $i + (24 *3600)){
	  $sql = "select title, event_id, starttime from mod_calendar_events where event_date='" . date("Ymd", $i) . "' order by starttime, title";
	  $sql_result = mysql_query ($sql);
	  $current_day = date ("Ymd", $i);
	  $count = mysql_num_rows ($sql_result);
	  $repeat_count = count_repeats($current_day);
	  if ($repeat_count)
	    	  $repeat_array = get_repeats($current_day);

	  $count = $count + $repeat_count;

	  if ($count) {
	    $events_found = 1;
	    if ($color_on){
	      $highlight = "class=\"$misc_highlight\"";
	      $color_on = 0;
	    }
	    else {
	      unset($highlight);
	      $color_on = 1;
	    }
	    $content .= "
    <tr>
      <td class=\"$block_top\" width=\"20%\" valign=\"top\"><a href=\"mod.php?mod=calendar&amp;op=view_day&amp;date=" . date ("Ymd", $i) . "\">".date("l, j", $i)."</a></td>
      <td $highlight width=\"80%\">";
	    while($row = mysql_fetch_array($sql_result)){
	      extract ($row);
	      $content .= list_repeats ($repeat_array, $current_day, $starttime, "alt_month");
	      $content .= mini_view($event_id, $current_day). " <a href=\"./mod.php?mod=calendar&amp;op=show_event&amp;event_id=$event_id&amp;date=$current_day\">$title</a>&nbsp;&nbsp;&nbsp;".tell_time($event_id)."<br />";
	    }
	    $content .= list_repeats ($repeat_array, $current_day, '9999', 'alt_month');
	    $content .= "
      </td>
    <tr>";}
	}
	if (empty($events_found))
	  $content = "$tran[No_events_this_month]";
	else
	    $content .= "
    </table>";
	$content .= switch_views($date, "month");
	thememainbox ($box_title, $content);
	
}


function list_events($sortby)
{
include ("mod/calendar/calendar_config.php");
include ("mod/calendar/language.php");
include ("header.php");

global $cat_id, $subcat_id, $limit, $date_start, $date_end, $date, $repeat_array, $loc_id, $tran;

if (!$date_start)
	$date_start=date_now("Ymd");

$start_year=substr ($date_start, 0, 4);
$start_month=substr ($date_start, 4, 2);
$start_day=substr ($date_start, 6, 2);

if (!$date_end){
	$date_end = date("Ymd", mktime(2,0,0,$start_month+1,$start_day,$start_year));
}
	

$end_year=substr($date_end, 0, 4);
$end_month=substr($date_end, 4, 2);
$end_day=substr ($date_end, 6, 2);

$start_seed = mktime(2,0,0, $start_month, $start_day, $start_year);
$end_seed = mktime(2,0,0, $end_month, $end_day, $end_year);


$content .= "
<form action=\"mod.php\" method=\"post\">
	<input type=\"hidden\" name=\"mod\" value=\"calendar\" />
	<input type=\"hidden\" name=\"op\" value=\"list_events\" />
	<input type=\"hidden\" name=\"sortby\" value=\"$sortby\" />";

$sql_event = "select * from mod_calendar_events where ";
switch ($sortby) {

	case("category"):
		$sql_result = mysql_query("select * from mod_calendar_category where cat_id=$cat_id");
		$row = mysql_fetch_array($sql_result);
		extract ($row);
		$box_title = "$tran[Events_for] $tran[cat_name]: $category";
		$content .= "<input type=\"hidden\" name=\"cat_id\" value=\"$cat_id\" />";
		$content .= section_info($image_name, $description, $category);
		$sql_event .= "cat_id='$cat_id'";
		break;
	case("subcat"):
		$sql_result = mysql_query("select * from mod_calendar_subcat where subcat_id=$subcat_id");
		$row = mysql_fetch_array($sql_result);
		extract ($row);
		$box_title = "$tran[Events_for] $tran[subcat_name]: $subcat";
		$content .= "
		<input type=\"hidden\" name=\"subcat_id\" value=\"$subcat_id\" />";
		$content .= section_info($image_name, $description, $subcat);
		$sql_event .= "subcat_id='$subcat_id'";
		break;
	case("location"):
		$sql_result = mysql_query("select * from mod_calendar_location where loc_id=$loc_id");
		$row = mysql_fetch_array($sql_result);
		extract($row);
		$box_title = "$tran[Events_at] $loc_name";
		$content .= "<input type=\"hidden\" name=\"loc_id\" value=\"$loc_id\" />";
		$content .= section_info($image_name, $loc_desc, $loc_name);
		$sql_event .= "loc_id='$loc_id'";
		break;
}
$sql_event .= " and event_date >= '$date_start' and event_date < '$date_end'";
$sql_event .= " order by event_date, starttime";
#echo"$sql_event";

$sql_result = mysql_query($sql_event);

$previous_date  = $date_start;

if (mysql_num_rows($sql_result)){
	$content .= "
<ul>
<table cellspacing=\"0\" cellpadding=\"4\" border=\"0\" width=\"100%\">";
	while ($row = mysql_fetch_array ($sql_result)){
		extract ($row);
		$check_id[$event_id] = 1;
		$repeat_array = get_repeats($previous_date, $event_date);
		if ($repeat_array){
		while (list($key, $sub_array) = each ($repeat_array)){
			list ($rep_id, $rep_time, $rep_date) = array_values($sub_array);

			if ($check_id[$rep_id]){
				unset($repeat_array[$key]);
			} else {
				$rep_sql = "select title from mod_calendar_events where event_id='$rep_id'";
				if($sortby == "category")
					$rep_sql .= " and cat_id='$cat_id'";
				elseif($sortby == "subcat")
					$rep_sql .= " and subcat_id='$subcat_id'";
				elseif($sortby == "location")
					$rep_sql .= " and loc_id='$loc_id'";

				$rep_result = mysql_query($rep_sql);
				if (mysql_num_rows($rep_result)){
					list ($rep_title) = mysql_fetch_row($rep_result);
					$content .= "
<tr>
	<td width=\"1%\" valign=\"top\">" . mini_view($rep_id, $rep_date) . "</td>
	<td width=\"33%\" valign=\"top\"> <a href=\"mod.php?mod=calendar&amp;op=show_event&amp;event_id=$rep_id&amp;date=$rep_date\">$rep_title</a></td>
	<td valign=\"top\">" . format_date($rep_date) . "</td>
	<td valign=\"top\">" . tell_time($rep_id) . "</td>";
/*
if ($repeat_type)
	$content .= "<td><i>$tran[This_is_a_repeating_event]</i></td>";
*/

$content .= "
</tr>";

					$check_id[$rep_id] = 1;
				}
			}
		}
		}
		unset($repeat_array);

		$content .= "
<tr>
	<td width=\"1%\">" . mini_view($event_id) . "</td>
	<td width=\"33%\"> <a href=\"mod.php?mod=calendar&amp;op=show_event&amp;event_id=$event_id\">$title</a></td>
	<td width=\"33%\">" . format_date($event_date) . "</td>
	<td width=\"33%\">" . tell_time($event_id) . "</td>";
/*
if ($repeat_type)
	$content .= "<td><i>$tran[This_is_a_repeating_event]</i></td>";
*/

$content .= "
</tr>";

$event_found = 1;
	}
}
if (!isset($event_date)){
	$event_date=$previous_date;
	$content .= "
<table cellspacing=\"0\" cellpadding=\"4\" border=\"0\" width=\"100%\">";
}

		$repeat_array = get_repeats($event_date, $date_end);
		if ($repeat_array){
		while (list($key, $sub_array) = each ($repeat_array)){
			list ($rep_id, $rep_time, $rep_date) = array_values($sub_array);

			if ($check_id[$rep_id]){
				unset($repeat_array[$key]);
			} else {
				$rep_sql = "select title from mod_calendar_events where event_id='$rep_id'";
				if($sortby == "category")
					$rep_sql .= " and cat_id='$cat_id'";
				elseif($sortby == "subcat")
					$rep_sql .= " and subcat_id='$subcat_id'";
				elseif($sortby == "location")
					$rep_sql .= " and loc_id='$loc_id'";

				$rep_result = mysql_query($rep_sql);
				if (mysql_num_rows($rep_result)){
					list ($rep_title) = mysql_fetch_row($rep_result);
					$content .= "
<tr>
	<td width=\"1%\" valign=\"top\">" . mini_view($rep_id, $rep_date) . "</td>
	<td width=\"33%\" valign=\"top\"> <a href=\"mod.php?mod=calendar&amp;op=show_event&amp;event_id=$rep_id&amp;date=$rep_date\">$rep_title</a></td>
	<td valign=\"top\">" . format_date($rep_date) . "</td>
	<td valign=\"top\">" . tell_time($rep_id) . "</td>";
/*
if ($repeat_type)
	$content .= "<td><i>$tran[This_is_a_repeating_event]</i></td>";
*/
$content .= "
</tr>";

					$event_found = 1;
					$check_id[$rep_id] = 1;
				}
			}
		}
		}


	$content .= "
</table>";

	$content .= "<br />";

if ($event_found < 1)
	$content .= "<i>$tran[None_Found]</i>. ";

	if ($date_start > $date_end)
		$content .= "
	<i>$tran[Ending_search_date]</i>";

	$content .= "
	<br />
	<br />
	<table cellspacing=\"0\" border=\"0\">
	<tr>
		<td>$tran[Show_all_events_from]</td>
		<td>";

$date_order = format_date (NULL,"date_order");
switch ($date_order){
	case("mdy"):
		$content .= select_month ("start_month", $start_month) . select_day("start_day", $start_day) . select_year("start_year", $start_year);
		break;
	case("ymd"):
		$content .= select_year("start_year", $start_year) . select_month ("start_month", $start_month) . select_day("start_day", $start_day);
		break;
	case("dmy"):
		$content .= select_day("start_day", $start_day) . select_month ("start_month", $start_month) . select_year("start_year", $start_year);
		break;
}
	$content .= "
		</td>
	</tr>
	<tr>
		<td align=\"right\">$tran[until]</td>
		<td>";
switch ($date_order){
	case("mdy"):
		$content .= select_month ("end_month", $end_month) . select_day("end_day", $end_day) . select_year("end_year", $end_year);
		break;
	case("ymd"):
		$content .= select_year("end_year", $end_year) . select_month ("end_month", $end_month) . select_day("end_day", $end_day);
		break;
	case("dmy"):
		$content .= select_day("end_day", $end_day) . select_month ("end_month", $end_month) . select_year("end_year", $end_year);
		break;
}
$content .= "
	<input type=\"submit\" value=\"$tran[Go]!\" />
		</td>
	</tr>
	</table>

</form>";

if ($email)
	$content .= "<div align=\"center\"><hr /><br />$tran[For_more_information] <a href=\"mailto:$email\">$email</a></div>";

thememainbox($box_title, $content);
}

################################################
function view_event ($event_id, $event_date='')
{
include ("mod/calendar/calendar_config.php");
include ("mod/calendar/language.php");
global $tran;

$hold_date = $event_date;

$sql_result = mysql_query("select * from mod_calendar_events where event_id='$event_id'");
$row = mysql_fetch_array($sql_result);
extract ($row);

if ($loc_id){
	$sql_result = mysql_query("select loc_name from mod_calendar_location where loc_id=$loc_id");
	list($loc_name) = mysql_fetch_array ($sql_result);
}

if ($hold_date)
	$event_date = $hold_date;

$sql_result = mysql_query("select category from mod_calendar_category where cat_id='$cat_id'");
list ($category) = mysql_fetch_array($sql_result);

$sql_result = mysql_query("select subcat from mod_calendar_subcat where subcat_id='$subcat_id'");
list ($subcat) = mysql_fetch_array($sql_result);

if($image_name != "" && file_exists("$calendar_image_dir$image_name"))
	$size = GetImageSize ("$calendar_image_dir$image_name");

echo "
<html>
	<head>
	<title>$title</title>
	</head>
<body bgcolor=\"ffffff\">
<table width=\"100%\" border=\"0\" cellspacing=\"3\" cellpadding=\"3\">
<tr>
	<td>";
if (isset($size))
	echo "
	<div align=\"center\">
	<img src=\"$calendar_img_url$image_name\" width=\"$size[0]\" height=\"$size[1]\" alt=\"$title\" /><br />
	<h2>$title</h2></div>";
else
	echo "<div align=\"center\"><h2>$title</h2></div>";

if ($description)
	echo "$description";
else
	echo "<i>$tran[No_description]</i>";

echo "
	</td>
</tr>
<tr>
	<td align=\"center\"><hr /><b>" . format_date($event_date, "long_day") . ", " . format_date($event_date) . "<br />";

if ($loc_id)
	echo "$tran[Location]: $loc_name<br />";

echo tell_time($event_id) . "</b>";

switch ($repeat_type){
	case("day"):
		echo "<br /><font size=\"-2\">$tran[Scheduled_every_day_until] " . format_date($end_repeat)."</font>";
		break;
	case("week"):
		echo "<br /><font size=\"-2\">$tran[Scheduled_every] " . split_days($repeat_week_day) . " $tran[until] " . format_date($end_repeat)."</font>";
		break;
	case("month"):
		echo "<br /><font size=\"-2\">$tran[This_event_occurs] ";
		if ($month_repeat_type=='day')
			echo "$tran[on_this_date]";
		else
			echo "$tran[at_the_end_of]";
		echo " $tran[each_month].</font>";
		break;
	case("year"):
		echo "<br /><font size=\"-2\">$tran[This_is_a_yearly_event].</font>";
		break;
}

echo "
	</td>
</tr>
</table>
<div align=\"center\">
<form>
	<input type=\"button\" value=\"$tran[Close_Window]\" onClick=\"window.close()\" />
</form>
</div>
</body>
</html>";
exit;
}

function section_info($image_name='', $description='', $alt)
{
include ("mod/calendar/calendar_config.php");

if (strlen($image_name))
	$new_content .= "<img src=\"$calendar_img_url$image_name\" alt=\"$alt image\" border=\"0\" /><br /><br />";

if (strlen($description))
	$new_content .= "$description<br /><br />";

return $new_content;
}

###################################################################
function format_date($date, $type='full')
{
	include("mod/calendar/language.php");
	global $tran;

	$year = substr ($date, 0, 4);
	$month = substr ($date, 4, 2);
	$day = substr ($date, 6, 2);

	$sql_result = mysql_query ("select date_format from mod_calendar_settings");
	list ($date_format)=mysql_fetch_row ($sql_result);
	$date_seed = mktime(2,0,0,$month,$day,$year);
	$date_explode = explode ("^", $date_format);	
	list ($date_order, $month_form, $digit_style, $year_digits, $separator) = array_values($date_explode);

	if ($year_digits == "y4")
		$year_style = "Y";
	else
		$year_style = "y";

	switch ($month_form){

		case("number"):
			if ($digit_style == "double"){
				$month_style = "m";
				$day_style = "d";
			}elseif ($digit_style == "nozero"){
				$month_style = "n";
				$day_style = "j";
			}
			break;

		case("name"):
			$month_style = "F";
			if ($digit_style == "double")
				$day_style = "d";
			elseif ($digit_style == "nozero")
				$day_style = "j";
			break;

		case("short"):
			$month_style = "M";
			if ($digit_style == "double")
				$day_style = "d";
			elseif ($digit_style == "nozero")
				$day_style = "j";
			break;

	}

switch ($type) {
	case ("full"):
	if ($month_form == "number"){
		switch ($date_order){
			case ("mdy"):
			return date ("$month_style$separator$day_style$separator$year_style", $date_seed);
			break;

			case ("ymd"):
			return date ("$year_style$separator$month_style$separator$day_style", $date_seed);
			break;

			case ("dmy"):
			return date ("$day_style$separator$month_style$separator$year_style", $date_seed);
			break;
		}
	} else {
		switch ($date_order){
			case ("mdy"):
			$translate_temp = date ("$month_style", $date_seed);
			return $tran[$translate_temp] . " " . date ("$day_style, $year_style", $date_seed);
			break;

			case ("ymd"):
			$translate_temp = date ("$month_style", $date_seed);
			return date ("$year_style", $date_seed) . ", " . $tran[$translate_temp] . " " . date ("$day_style", $date_seed);
			break;

			case ("dmy"):
			$translate_temp = date ("$month_style", $date_seed);
			return date ("$day_style", $date_seed) . " " . $tran[$translate_temp] . ", " . date ("$year_style", $date_seed);
			break;
		}
	}
	break;

	case ("long_day"):
		$day = date ("l", $date_seed);
		return $tran[$day];
		break;
	case ("long_month"):
		$month_name = date("F", $date_seed);
		return $tran[$month_name];
		break;

	case ("short_month"):
		$month_name = date("M", $date_seed);
		return $tran[$month_name];
		break;

	case ("date_order"):
		return $date_order;
		break;

	case ("month_style"):
		return $month_style;
		break;

	case ("day_style"):
		return $day_style;
		break;

	case ("year_style"):
		return $year_style;
		break;

	case ("day_date"):
		$day = date ("l", $date_seed);
		$month = date("$month_style", $date_seed);
		if ($month_style == "F" || $month_style == "M"){
			$month = $tran[$month];
			$separator = " ";
		}
		if ($date_order != "dmy")
			$full = "$tran[$day], ".$month.$separator.date("$day_style", $date_seed);
		else
			$full = "$tran[$day], ".date("$day_style", $date_seed).$separator.$month;

		return $full;
		break;

}
}
########################################################

function check_me($var1, $var2, $type){
if ($var1 == $var2) {
	if ($type == "c")
		return " checked";
	elseif ($type == "s")
		return " selected";
	else
		return "Error: Improper type";
}
return;
}

####################################################
function get_time($time)
{
	$sql_result = mysql_query ("select time_format from mod_calendar_settings");
	list ($time_format) = mysql_fetch_array ($sql_result);

	if ($time_format == "m")
		return substr ($time,0,2) . ":" . substr($time,2,2);
	elseif ($time_format == "s")
		return date("g:ia", mktime (substr($time,0,2),substr($time,2,2)));
	else
		return "Error: Time format not set in database. Please check and try again.";
}

######################################################
function show_event($event_id, $date='') {
include ("mod/calendar/calendar_config.php");
include ("mod/calendar/language.php");
include ("header.php");
global $admintest, $tran;
$hold_date = $date;

$sql_result = mysql_query("select * from mod_calendar_events where event_id='$event_id'");
$row = mysql_fetch_array($sql_result);
extract ($row);

if ($loc_id){
	$sql_result = mysql_query("select loc_name from mod_calendar_location where loc_id=$loc_id");
	list($loc_name) = mysql_fetch_array ($sql_result);
}

if ($hold_date)
	$event_date = $hold_date;

$sql_result = mysql_query("select category from mod_calendar_category where cat_id='$cat_id'");
list ($category) = mysql_fetch_array($sql_result);

$sql_result = mysql_query("select subcat from mod_calendar_subcat where subcat_id='$subcat_id'");
list ($subcat) = mysql_fetch_array($sql_result);

$box_title = "$title";

if ($admintest)
	$box_title .= "&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"mod.php?mod=calendar&amp;op=event_admin&amp;event_id=$event_id\">[ $tran[Edit_Event] ]</a>";

if($image_name != "" && file_exists("$calendar_image_dir$image_name")){
	$size = @GetImageSize ("$calendar_image_dir$image_name");
	if ($size[0] > 250)
		$content = "<img src=\"$calendar_img_url$image_name\" width=\"$size[0]\" height=\"$size[1]\" alt=\"$title\" /><br />";
	else
		$content = "<img src=\"$calendar_img_url$image_name\" width=\"$size[0]\" height=\"$size[1]\" alt=\"$title\" align=\"left\" hspace=\"10\" />";
}
$content .= "
<table cellpadding=\"4\" cellspacing=\"0\" border=\"0\" width=\"100%\">
<tr>
	<td>$description</td>
</tr>
<tr>
	<td><b>" . format_date($event_date, "long_day") . ", " . format_date($event_date) . "<br />";

if ($loc_id)
	$content .= "Location: <a href=\"mod.php?mod=calendar&amp;op=list_events&amp;loc_id=$loc_id\">$loc_name</a><br />";

$content .= tell_time($event_id) . "</b>";

switch ($repeat_type){
	case("day"):
		$content .= "<br />$tran[Scheduled_every_day_until] " . format_date($end_repeat);
		break;
	case("week"):
		$content .= "<br />$tran[Scheduled_every] " . split_days($repeat_week_day) . " until " . format_date($end_repeat);
		break;
	case("month"):
		$content .= "<br />$tran[This_event_occurs] ";
		if ($month_repeat_type=='day')
			$content .= "$tran[on_this_date]";
		else
			$content .= "at the end of";
		$content .= " $tran[each_month].";
		break;
	case("year"):
		$content .= "<br />$tran[This_is_a_yearly_event].";
		break;
}

$content .= "
	</td>
</tr>
<tr>
	<td>";
if ($subcat_id)
	$content .= "$tran[See_other_events_under] <a href=\"mod.php?mod=calendar&amp;op=list_events&amp;sortby=category&amp;cat_id=$cat_id\">$category</a>: 
<a href=\"mod.php?mod=calendar&amp;op=list_events&amp;sortby=subcat&amp;subcat_id=$subcat_id\">$subcat</a><br />";
elseif ($cat_id)
	$content .= "$tran[See_other_events_under] <a href=\"mod.php?mod=calendar&amp;op=list_events&amp;sortby=category&amp;cat_id=$cat_id\">$category</a><br />";

$content .= "
	</td>
</tr>
</table>";

thememainbox($box_title, $content);

}


#########################################################
function select_month ($select_month_name, $current_month){
include ("./mod/calendar/language.php");
global $tran;
$month_style = format_date(NULL,"month_style");

	$month_stuff = "
	<select name=\"$select_month_name\">";

	for ($i=1; $i < 13 ; $i++){
		$month_stuff .= "
		<option value=\"" . date( "m", mktime( 2, 0, 0, $i, 1)) . "\"" . check_me ($current_month, date("m", mktime(2,0,0,$i,1)), "s") . ">";
		if ($month_style == "F" || $month_style == "M"){
			$temp_month = date("$month_style", mktime(2,0,0, $i, 1));
			$month_stuff .= $tran[$temp_month];
		} else {
			$month_stuff .= date("$month_style", mktime(2,0,0,$i,1));
		}
		$month_stuff .= "</option>";
	}

	$month_stuff .= "
	</select>";
	return $month_stuff;
}

#########################################################
function select_day ($select_day_name, $current_day){
$day_style = format_date(NULL,"day_style");
	$day_stuff .= "
	<select name=\"$select_day_name\">";

	for ($i=1; $i < 32 ; $i++){
		$day_stuff .= "
		<option" . check_me($current_day, date("d", mktime(2,0,0,1,$i) ), "s") . " value=\"" . date("d", mktime(2,0,0,1,$i)) . "\">" . date( "$day_style", mktime(2,0,0,1,$i) )  . "</option>";
	}

	$day_stuff .= "
	</select>";

	return $day_stuff;
}
########################################################
function select_year ($select_year_name, $current_year){
$year_style = format_date(NULL,"year_style");
	$year_stuff = "
	<select name=\"$select_year_name\">";

	for ($i = date_now(Y); $i < (date_now(Y)+10); $i++){
		$year_stuff .= "
		<option" . check_me($current_year,date( "Y", mktime(2,0,0,1,1, $i) ), "s") . " value=\"" . date("Y", mktime(2,0,0,1,1,$i))."\">" . date( "$year_style", mktime(2,0,0,1,1, $i) ) . "</option>";
	}

	$year_stuff .="
	</select>";
	return $year_stuff;
}

######################################################
function month_view($date=''){
include ("mod/calendar/calendar_config.php");
include ("mod/calendar/language.php");
include ("header.php");

$sql_setting = mysql_query ("select small_view from mod_calendar_settings");
list($small_view) = mysql_fetch_row ($sql_setting);

global $repeat_array, $tran;
	if (strlen( $date ) > 0 ) {
		$thisyear = substr ( $date, 0, 4 );
		$thismonth = substr ( $date, 4, 2 );
		$thisday = substr ( $date, 6, 2 );
	} else {
		if ( $month == 0 )
			$thismonth = date_now("m");
		else
			$thismonth = $month;
		if ( $year == 0 )
			$thisyear = date_now("Y");
		else
			$thisyear = $year;
		if ($day == 0)
			$thisday = date_now("d");
		else
			$thisday = $day;
	}

	$this = mktime (2,0,0, $thismonth, 1, $thisyear);

	$next = mktime (2, 0, 0, $thismonth + 1, 1, $thisyear );
	$nextyear = date ( "Y", $next );
	$nextmonth = date ( "m", $next );
	$nextday= date("d",$next);
	$nextdate = date ("Ymd", $next);

	$prev = mktime ( 2, 0, 0, $thismonth - 1, 1, $thisyear );
	$prevyear = date ( "Y", $prev );
	$prevmonth = date ( "m", $prev );
	$prevday = date ("d", $prev);
	$prevdate = date("Ymd", $prev);

	$startdate = date("Ymd", mktime(2,0,0,$thismonth,1,$thisyear));
	$enddate = date("Ymd", mktime(2,0,0,$nextmonth,$nextday-1,$nextyear));

	if ($start_on_monday)
	  $wkstart = get_monday_before ( $thisyear, $thismonth, 1 );
	else
	  $wkstart = get_sunday_before ( $thisyear, $thismonth, 1 );

	$monthstart = mktime (2, 0, 0, $thismonth, 1, $thisyear );
	$monthend = mktime (2, 0, 0, $thismonth + 1, 0, $thisyear );

	$today = date_now("Ymd");

	$month_name = $tran[date("F", $this)];

	$sql = "select pic_$thismonth from mod_calendar_settings where pic_$thismonth != ''";
	$sql_result = mysql_query($sql);
	list($month_image) = mysql_fetch_row($sql_result);

	$box_title = "
	<table width=\"100%\">
	<tr>
		<td align=\"left\">&lt;&lt;<a href=\"mod.php?mod=calendar&amp;op=month_view&amp;date=$prevdate\">$tran[Previous]</a></td>
		<td align=\"right\"><a href=\"mod.php?mod=calendar&amp;op=month_view&amp;date=$nextdate\">$tran[Next]</a>&gt;&gt;</td>
	</tr>
	</table>";

	$repeat_array = get_repeats($startdate,$enddate);
	$content = "<br />";

if ($small_view){
	$content .= "
<table cellpadding=\"4\" cellspacing=\"0\" border=\"0\" width=\"100%\">
<tr>
	<td width=\"25%\" align=\"left\">" . small_month($prevdate) . "</td>
	<td width=\"50%\" align=\"center\" valign=\"center\">";
}
	if($month_image != "" && file_exists("$calendar_image_dir$month_image")){
		$size = @GetImageSize ("$calendar_image_dir$month_image");
		$content .= "<div align=\"center\">
		<img src=\"$calendar_img_url$month_image\" width=\"$size[0]\" height=\"$size[1]\" alt=\"$month_name\" /></div>";
	}
	else
		$content .= "<div align=\"center\"><span class=\"$largetype\">$month_name, $thisyear</span></div><br />";
if ($small_view){
	$content .= "
	</td>
	<td width=\"25%\" align=\"right\">" . small_month($nextdate) . "</td>
</tr>
</table>";
}

$content .= "
	<!-- Main Calendar -->
<table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">
<tr>
	<td class = \"$calendar_lines\">
		<table border=\"0\" width=\"100%\" cellspacing=\"1\" cellpadding=\"2\">
		<tr>";
 if (empty($start_on_monday))
   $content .= "<th width=\"14%\" class=\"$block_top\">$tran[Sun]<br /><img src=\"./mod/calendar/spanner.gif\" alt=\"|\" width=\"60\" height=\"1\" /></th>";

 $content .= "
			<th width=\"14%\" class=\"$block_top\">$tran[Mon]<br /><img src=\"./mod/calendar/spanner.gif\" alt=\"|\" width=\"60\" height=\"1\" /></th>
			<th width=\"14%\" class=\"$block_top\">$tran[Tue]<br /><img src=\"./mod/calendar/spanner.gif\" alt=\"|\" width=\"60\" height=\"1\" /></th>
			<th width=\"14%\" class=\"$block_top\">$tran[Wed]<br /><img src=\"./mod/calendar/spanner.gif\" alt=\"|\" width=\"60\" height=\"1\" /></th>
			<th width=\"14%\" class=\"$block_top\">$tran[Thu]<br /><img src=\"./mod/calendar/spanner.gif\" alt=\"|\" width=\"60\" height=\"1\" /></th>
			<th width=\"14%\" class=\"$block_top\">$tran[Fri]<br /><img src=\"./mod/calendar/spanner.gif\" alt=\"|\" width=\"60\" height=\"1\" /></th>
			<th width=\"14%\" class=\"$block_top\">$tran[Sat]<br /><img src=\"./mod/calendar/spanner.gif\" alt=\"|\" width=\"60\" height=\"1\" /></th>";
 if ($start_on_monday)
   $content .= "<th width=\"14%\" class=\"$block_top\">$tran[Sun]<br /><img src=\"./mod/calendar/spanner.gif\" alt=\"|\" width=\"60\" height=\"1\" /></th>";

 $content .= "
		</tr>";
for ( $i = $wkstart; date("Ymd", $i) <= date ("Ymd", $monthend); $i += ( 24 * 3600 * 7 ) ) {
	$content .= "
		<tr>";
	for ( $j = 0; $j < 7; $j++ ) {
		$hold_time = '';
		$track_date = $i + ( $j * 24 * 3600 );

		if ( date ( "Ymd", $track_date ) >= date ( "Ymd", $monthstart ) && date ( "Ymd", $track_date ) <= date ( "Ymd", $monthend ) ) {
			$content .= "
			<td valign=\"top\"";

			if ( date ("Ymd", $track_date ) == $today)
				$content .= " class=\"$highlight_day\">";
			else
				$content .= " class=\"$numbered_day\">";

			$sql = "select title, event_id, starttime from mod_calendar_events where event_date='" . date("Ymd", $track_date) . "' order by starttime";
			$sql_result = mysql_query ($sql);

			$count = mysql_num_rows ($sql_result);
			$repeat_count = count_repeats(date("Ymd", $track_date));
			$count = $count + $repeat_count;
			if ($count) {
				$content .= "<a href=\"mod.php?mod=calendar&amp;op=view_day&amp;date=" . date ("Ymd", $track_date) . "\">" .date ("d", $track_date) . "</a><br />";

				if ($j==0)
					$content .= "<a href=\"mod.php?mod=calendar&amp;op=week_view&amp;date=".date ("Ymd", $i)."\"><span class=\"$smalltype\">$tran[Week]</span></a>";
				elseif(date("d", $track_date)== 1)
					$content .= "<a href=\"mod.php?mod=calendar&amp;op=week_view&amp;date=".date ("Ymd", $i)."\"><span class=\"$smalltype\">$tran[Week]</span></a>";

				$content .= "		
			<br />
				<table cellspacing=\"0\" cellpadding=\"1\" border=\"0\">
				<tr>";
				while($row = mysql_fetch_array($sql_result)){
					extract ($row);
					if ($que)
						$content .= "
				<tr>";

					$content .= list_repeats($repeat_array, date("Ymd", $track_date), $starttime, "month");
					$content .= "
					<td valign=\"top\" width=\"5%\">" . mini_view($event_id) . "</td>
					<td class=\"$smalltype\" align=\"left\"><a href=\"mod.php?mod=calendar&amp;op=show_event&amp;event_id=$event_id\">$title</a></td>
				</tr>";
					$que = 1;
				}
				$content .= list_repeats($repeat_array, date("Ymd", $track_date), 9999, "month");
				$que = 0;
				$content .= "
				</table>";
			}
			else{
				$content .= date ("d", $track_date)."<br />";
				if ($j==0)
					$content .= "
				<a href=\"mod.php?mod=calendar&amp;op=week_view&amp;date=".date ("Ymd", $i)."\"><span class=\"$smalltype\">$tran[Week]</span></a>
				<br /><br />";
				elseif(date("d", $track_date)== 1)
					$content .= "<a href=\"mod.php?mod=calendar&amp;op=week_view&amp;date=".date ("Ymd", $i)."\"><span class=\"$smalltype\">$tran[Week]</span></a><br /><br />";

			}
			if ($count >= 2)
				$content .= "<br /></td>";
			else
				$content .= "<br /><br /></td>";
		} else {
			$content .= "
			<td valign=\"top\" class=\"$calendar_foreground\">&nbsp;<br /><br /><br /><br /><br /></td>";
		}

	}

	$content .= "
		</tr>\n";
}

$content .= "
		</table>
	</td>
</tr>
</table>
<div align=\"center\">
<form action=\"mod.php\" method=\"post\">
	<input type=\"hidden\" name=\"mod\" value=\"calendar\" />
	<input type=\"hidden\" name=\"op\" value=\"month_view\" />";
$content .= select_month("month", $thismonth);
$content .= select_year("year", $thisyear);
$content .= "
	<input type=\"submit\" value=\"$tran[Go_to_Month]\" /><br />
</form>
</div>
	<!--End main calendar-->
";
$content .= switch_views($date, "month");
thememainbox ($box_title,$content);

}

################################################################
function small_month ($date){
include ("mod/calendar/calendar_config.php");
include ("mod/calendar/language.php");
global $tran;
$sql_setting = mysql_query ("select time_diff from mod_calendar_settings");
$setting = mysql_fetch_array ($sql_setting);
extract ($setting);


	$thisyear = substr ( $date, 0, 4 );
	$thismonth = substr ( $date, 4, 2 );
	$thisday = substr ( $date, 6, 2 );

	$prev = mktime (2, 0, 0, $thismonth - 1, 1, $thisyear );
	$prevyear = date ( "Y", $prev );
	$prevmonth = date ( "m", $prev );
	$prevdate = date ("Ymd", $prev);

	$today = date_now("Ymd");

	$monthstart = mktime (2, 0, 0, $thismonth, 1, $thisyear );
	$monthend = mktime (2, 0, 0, $thismonth + 1, 0, $thisyear );

	$startdate = date("Ymd", $monthstart);
	$enddate = date("Ymd", $monthend);

 if ($start_on_monday) 
   $wkstart = get_monday_before ( $thisyear, $thismonth, 1 );
 else
   $wkstart = get_sunday_before ( $thisyear, $thismonth, 1 );

	$sql = "select event_date from mod_calendar_events 
		where 
		event_date >= '$startdate' and 
		event_date <= '$enddate' 
		order by event_date";

	$sql_result = mysql_query($sql);

	while ($row = mysql_fetch_array($sql_result)){
		extract ($row);
		$event_array[$event_date] = "1"; 
	}

	$monthname = format_date($date,"long_month");
	$box_content .= "
	<div align=\"center\">
	<b><a href=\"mod.php?mod=calendar&amp;op=month_view&amp;date=$date\">" . $monthname . "</a></b>
	</div>
<table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"2\">
<tr>
	<td width=\"12%\" align=\"center\">&nbsp;</td>";

	for ( $i = 0; $i < 7; $i++ ) {
		$box_content .= "
	<td width=\"12%\" align=\"center\"><span class=\"$smalltype\">" . weekday_short_name ( $i ) ."</span></td>";
        }

        $box_content .= "
</tr>";

        for ( $i = $wkstart; date ( "Ymd", $i ) <= date ( "Ymd", $monthend );$i += ( 24 * 3600 * 7 ) ) {
                $box_content .= "
<tr>
        <td width=\"12%\" align=\"center\"><span class=\"$smalltype\"><a href=\"mod.php?mod=calendar&amp;op=week_view&amp;date=".date ("Ymd", $i)."\">&gt;</a></span></td>";

                for ( $j = 0; $j < 7; $j++ ) {
                        $date = $i + ( $j * 24 * 3600 );
                        if ( date ( "Ymd", $date ) >= date ( "Ymd", $monthstart ) && date ( "Ymd", $date ) <= date ( "Ymd", $monthend ) ) {
                                $box_content .= "
        <td align=\"center\" ";
                                if (date ( "Ymd", $date )==$today)
                                        $box_content .= "class=\"$highlight_day\"";    

                                $box_content .= ">
        <span class=\"$smalltype\">";

                                if ( $event_array[date(Ymd, $date)] || count_repeats(date(Ymd,$date)))
                                        $box_content .= "<a href=\"mod.php?mod=calendar&amp;op=view_day&amp;date=" . date("Ymd", $date) . "\">" . date ( "d", $date ) . "</a>";
                                else
                                        $box_content .= date("d", $date);

                                $box_content .= "</span>
        </td>";
                        } else {
                                $box_content .= "
        <td align=\"center\">&nbsp;</td>\n";
                        }
                }
                $box_content .= "
</tr>";
        }

        $box_content .= "
</table>";
        return $box_content;
}

#################################################################
function date_now($type){
include ("mod/calendar/language.php");
global $tran;
$sql_setting = mysql_query ("select time_diff from mod_calendar_settings");
$setting = mysql_fetch_array ($sql_setting);
extract ($setting);

$hour = date ("G", mktime (date(G)+$time_diff));
$time = date ("Hi", mktime((date(H)+($time_diff)), date(i)));
$day = date ("d", mktime((date(G)+$time_diff),0,0,date(n),date(j),date(Y)));
$month = date ("m", mktime ((date(G)+$time_diff),0,0,date(n),date(j),date(Y)));
$year = date ("Y", mktime ((date(G)+$time_diff),0,0,date(n),date(j),date(Y)));
$month_name =  date ("F", mktime ((date(G)+$time_diff),0,0,date(n),date(j),date(Y)));
$today = $year.$month.$day;

switch ($type){
        case("G"):
                return $hour;
        case("Hi"):
                return $time;
        case("d"):
                return $day;
        case("m"):
                return $month;
        case("Y"):
                return $year;
        case("Ymd"):
                return $today;
        case("F"):
                return $tran[$month_name];
        default:
                return "Error: Improper type passed";

}

}

####################################################
function view_day($date=''){
include ("mod/calendar/calendar_config.php");
include ("mod/calendar/language.php");
include ("header.php");
global $repeat_array, $holdtime, $tran;

	if (strlen($date)<1)
		$date = date_now(Ymd);

        $repeat_array = get_repeats($date);

        $thisyear = $year = substr ( $date, 0, 4 );
        $thismonth = $month = substr ( $date, 4, 2 );
        $thisday = $day = substr ( $date, 6, 2 );
        $this = mktime (2,0,0,$thismonth,$thisday,$thisyear);
        $count = count_repeats($date);
        $box_title= "
<table width=\"99%\" cellpadding = \"4\" cellspacing=\"0\" border=\"0\">
<tr>
        <td width=\"20%\" align=\"left\">
                &lt;&lt;<a href=\"./mod.php?mod=calendar&amp;op=view_day&amp;date=" . date("Ymd", mktime(2,0,0,$thismonth,$thisday-1,$thisyear)) . "\">$tran[Previous_Day]</a>
        </td>
        <td align=\"center\" width=\"60%\">$tran[Events_for]:
                " . format_date($date) . "
        </td>
        <td width=\"20%\" align=\"right\">
                <a href=\"./mod.php?mod=calendar&amp;op=view_day&amp;date=" . date("Ymd", mktime(2,0,0,$thismonth,$thisday+1,$thisyear)) . "\">$tran[Next_Day]</a> &gt;&gt;
        </td>
</tr>
</table>";
        $content .= "
                <table width=\"100%\" cellspacing=\"0\" cellpadding=\"5\" border=\"0\">
                <tr>
                        <td class=\"$block_top\" width=\"15%\"><b>$tran[Time]</b></td>
                        <td class=\"$block_top\"><b>$tran[Event]</b></td>
                </tr>";

        $sql_result = mysql_query ("select * from mod_calendar_events where event_date = '$date' order by starttime, title");

        if (mysql_num_rows ($sql_result) < 1 && $count < 1) {
                $content .= "
                <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                </tr>";
        }

        while ($row = mysql_fetch_array($sql_result)){
                extract ($row);

                $sql_result1 = mysql_query ("select category, cat_id from mod_calendar_category where cat_id = '$cat_id'");
                list ($category, $cat_id) = mysql_fetch_array($sql_result1) ;
                $sql_result2 = mysql_query ("select subcat, subcat_id from mod_calendar_subcat where subcat_id = '$subcat_id'");
                list ($subcat, $subcat_id) = mysql_fetch_array($sql_result2) ;

                $content .= list_repeats($repeat_array, $date, $starttime, "day");

                if (($starttime != $holdtime) && $allday != 1 ) {
                        if ($allday_switch || $time_switch){
                                $content .= "
                        </td>
                </tr>";
                                $allday_switch = 0;
                        }
                $time_switch = 1;

                $content .= "
                <tr>
                        <td width=\"10%\" align=\"left\" valign=\"top\"><b>" . get_time($starttime) . "</b></td>
                        <td>";
                        $holdtime = $starttime;

                } elseif ($allday == 1 && $allday_switch != 1){
                        $content .= "
                <tr>
                        <td width=\"10%\" align=\"left\" valign=\"top\"><b>All Day</b></td>
                        <td>";
                        $allday_switch = 1;
                }
                else
                        $content .= "<br />";



                $content .= mini_view($event_id) . " <a href=\"./mod.php?mod=calendar&amp;op=show_event&amp;event_id=$event_id\">$title</a>";
        }
                $content .= list_repeats($repeat_array, $date, 9999, day);

        $content .= "
                        </td>
                </tr>
                </table>";
        $content .= switch_views($date, "day");
        thememainbox ($box_title, $content);
}

########################################################################
function week_view ($date){
include ("mod/calendar/calendar_config.php");
include ("mod/calendar/language.php");
include ("header.php");
global $repeat_array, $temptime, $tran;
//Checks to see if it we are passed a date. If not, creates one based on today.
if (strlen( $date ) > 0 ) {
        $thisyear = substr ( $date, 0, 4 );
        $thismonth = substr ( $date, 4, 2 );
        $thisday = substr ( $date, 6, 2 );
} else {
        if ( $month == 0 )
                $thismonth = date_now("m");
        else
                $thismonth = $month;
        if ( $year == 0 )
                $thisyear = date_now("Y");
        else
                $thisyear = $year;
        if ($day == 0)
                $thisday = date_now(d);
        else
                $thisday = $day;
}

//next and previous week
$next = mktime (2, 0, 0, $thismonth, $thisday + 7, $thisyear );
$prev = mktime (2, 0, 0, $thismonth, $thisday - 7, $thisyear );

$today = date_now("Ymd");

 if ($start_on_monday)
   $wkstart = get_monday_before ($thisyear, $thismonth, $thisday );
 else
   $wkstart = get_sunday_before ( $thisyear, $thismonth, $thisday );

$wkend = $wkstart + ( 3600 * 24 * 6 );
$startdate = date ( "Ymd", $wkstart );
$enddate = date ( "Ymd", $wkend );
$repeat_array = get_repeats($startdate,$enddate);


 for ( $i = 0; $i < 7; $i++ ) {
   $days[$i] = $wkstart + ( 24 * 3600 ) * $i;
   $weekdays[$i] = weekday_short_name($i);
   $header[$i] = $weekdays[$i] . "<br />" . format_date(date("Ymd", $days[$i]), "short_month") . " " . date ("j", $days[$i] );
 }

$box_title = "
<table width=\"99%\" cellpadding = \"2\" cellspacing=\"0\" border=\"0\" >
<tr>
	<td align=\"center\" width=\"20%\">&lt;&lt;
		<a href=\"mod.php?mod=calendar&amp;op=week_view&amp;date=" . date("Ymd", $prev) . "\">$tran[Previous_Week]</a>
	</td>
	<td width=\"60%\" align=\"center\">$tran[Events_from] ";

if ( date ("m", $wkstart ) == date ("m", $wkend))
	$box_title .= date ("F j", $wkstart) . " - " . date("j, Y", $wkend);
else {
	if (date("Y", $wkstart) == date ("Y", $wkend))
		$box_title .= date ("F j", $wkstart) . " - " . date("F j, Y", $wkend);
	else
		$box_title .= date ("F j, Y", $wkstart) . " - " . date ("F j, Y", $wkend);
}

$box_title .= "

	</td>
	<td align=\"center\" width=\"20%\">
		<a href=\"mod.php?mod=calendar&amp;op=week_view&amp;date=" . date("Ymd", $next) . "\">$tran[Next_Week]</a>&gt;&gt;
	</td>
</tr>
</table>";

$content .= "
	<table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"3\">
	<tr>";

for ( $d= 0; $d < 7; $d++ ) {
	if ( date("Ymd",$days[$d]) == date("Ymd"))
		$content .= "
			<td width = \"14%\" class=\"$highlight_day\" align=\"center\">";
	else
		$content .= "
			<td width = \"14%\" class=\"$block_top\" align=\"center\">";
	
	$content .= "<a href=\"mod.php?mod=calendar&amp;op=view_day&amp;date=" . date("Ymd",$days[$d]) . "\">$header[$d]</a>
			</td>";
}
	$content .= "
		</tr>
		<tr>";

for ($i=0; $i < 7; $i++){
	$count = count_repeats(date("Ymd", $days[$i]));
 	$search_day = date ("Ymd", $days[$i]);
	$sql_result = mysql_query ("select title, starttime, allday, event_id from mod_calendar_events where event_date = '$search_day' order by starttime");
	$temptime='';
	$switch=0;
	$content .= "
			<td width=\"14%\" class=\"$numbered_day\" valign=\"top\">";

	if (mysql_num_rows($sql_result) < 1 && $count < 1)
		$content .= "&nbsp;";
	else {
		while ($row = mysql_fetch_array($sql_result)){
			extract($row);
			$content .= list_repeats($repeat_array, $search_day, $starttime, week);
			if ($temptime != $starttime) {
				if ($allday != 1)
					$content .= "
				<table width=\"100%\" cellpadding=\"3\" cellspacing=\"0\" border=\"0\">
				<tr>
					<td class=\"$block_top\" align=\"center\">" . get_time($starttime). "</td>
				</tr>
				</table>";

				else
					$content .= "
				<table width=\"100%\" cellpadding=\"3\" cellspacing=\"0\" border=\"0\">
				<tr>
					<td class=\"$block_top\" align=\"center\">$tran[All_Day]</td>
				</tr>
				</table>";

				$temptime = $starttime;
			}
			$content .= "
				<table width=\"100%\" cellpadding=\"3\" cellspacing=\"0\" border=\"0\">
				<tr>
					<td valign=\"top\" class=\"$block_body\" width=\"5%\">" . mini_view($event_id) . "</td>
					<td valign=\"top\" class=\"$block_body\"><a href=\"mod.php?mod=calendar&amp;op=show_event&amp;event_id=$event_id\">$title</a></td>
				</tr>
				</table>";
		}
	}

		$content .= list_repeats($repeat_array, $search_day, 9999, week);

	$content .= "
			</td>";	
}
$content .= "
	</tr>
	</table>";

$content .= switch_views($date, "week");
thememainbox ($box_title, $content);

}

function set_size ($image_name){
	include ("mod/calendar/calendar_config.php");

	if($image_name != "" && file_exists("$calendar_image_dir$image_name")){
		$size = @getimagesize("$calendar_image_dir$image_name");
		if ($size[1] < 300)
			$height = $size[1] + 100;
		else
			$height = 320;
		if ($size[0] < 250)
			$width = 300;
		else
			$width = $size[0] + 50;
	} else {
		$height = 250;
		$width = 300;
	}
	return array (height=>$height, width=>$width);
}
#############################################
function switch_views($date='', $dest=''){
	include ("mod/calendar/calendar_config.php");
	global $tran;

	$stuff .= "<br /><br /><div align=\"center\"><span class=\"$smalltype\">";
	if (!$date)
		$date = date_now("Ymd");

	switch ($dest){
		case("day"):
			$stuff .= "<a href=\"mod.php?mod=calendar&amp;op=view_day&amp;date=".date_now("Ymd")."\">$tran[Today]</a> | ";
			break;
		case("week"):
			$stuff .= "<a href=\"mod.php?mod=calendar&amp;op=week_view&amp;date=".date_now("Ymd")."\">$tran[This_Week]</a> | ";
			break;
		case("month"):
			$stuff .= "<a href=\"mod.php?mod=calendar&amp;op=month_view&amp;date=".date_now("Ymd")."\">$tran[This_Month]</a> | ";
			break;
	}

	$stuff .= "
	<a href=\"mod.php?mod=calendar&amp;op=view_day&amp;date=$date\">$tran[Day_View]</a> | <a href=\"mod.php?mod=calendar&amp;op=week_view&amp;date=$date\">$tran[Week_View]</a> | <a href=\"mod.php?mod=calendar&amp;op=month_view&amp;date=$date\">$tran[Month_View]</a>
</span></div>";
	return $stuff;

}


#######################################################3
function split_days ($repeat_week_day){
	include ("mod/calendar/language.php");
	global $tran;
	if (!$repeat_week_day)
		return "Error: Week string not sent.";
		list ($sun, $mon, $tue, $wed, $thu, $fri, $sat)=explode (":",$repeat_week_day);
	$total_days = $sun+$mon+$tue+$wed+$thu+$fri+$sat;
	if ($total_days==1)
		$count = 0;
	else
		$count = 1;
	if ($sun){
		$stuff .= "$tran[Sunday]";
		$comma = 1;
		$count++;
	}
	if ($mon){
		if ($count == $total_days){
			if ($total_days == 2)
				$stuff .= " and ";
			else
				$stuff .= ", and ";
		}
	elseif ($comma)
		$stuff .= ", ";
	$stuff .= "$tran[Monday]";
	$comma = 1;
	$count++;
	}
	if ($tue){
		if ($count == $total_days){
			if ($total_days == 2)
				$stuff .= " and ";
			else
				$stuff .= ", and ";
		}
		elseif ($comma)
			$stuff .= ", ";
		$stuff .= "$tran[Tuesday]";
		$comma = 1;
		$count++;

	}
	if ($wed){
		if ($count == $total_days){
			if ($total_days == 2)
				$stuff .= " and ";
			else
				$stuff .= ", and ";
		}
		elseif ($comma)
			$stuff .= ", ";
		$stuff .= "$tran[Wednesday]";
		$comma = 1;
		$count++;

	}
	if ($thu){
		if ($count == $total_days){
			if ($total_days == 2)
				$stuff .= " and ";
			else
				$stuff .= ", and ";
		}
		elseif ($comma)
			$stuff .= ", ";
		$stuff .= "$tran[Thursday]";
		$comma = 1;
		$count++;
		}
	if ($fri){
		if ($count == $total_days){
			if ($total_days == 2)
				$stuff .= " and ";
			else
				$stuff .= ", and ";
		}
		elseif ($comma)
			$stuff .= ", ";
		$stuff .= "$tran[Friday]";
		$comma = 1;
		$count++;

	}
	if ($sat){
		if ($count == $total_days){
			if ($total_days == 2)
				$stuff .= " and ";
			else
				$stuff .= ", and ";
		}
		elseif ($comma)
			$stuff .= ", ";
		$stuff .= "$tran[Saturday]";

	}

	return $stuff;
}
#####################################################
function tell_time ($event_id) {
	global $tran;

	$sql_result = mysql_query ("select allday, starttime, endtime from mod_calendar_events where event_id='$event_id'");
	if (mysql_num_rows($sql_result)< 1)
		return "Error: No event at this id.";

	$row = mysql_fetch_array($sql_result);
	extract ($row);
	if ($allday==1)
		$stuff .= "$tran[All_day_event]";
	else {
		if ($allday == 2)
			$stuff .= "$tran[Event_starts_at] " . get_time($starttime); 

		if ($allday != 2) {
			$stuff .= get_time($starttime) . " - " . get_time($endtime);
		}
			
	}
	return $stuff;
}
#####################################################
function mini_view ($event_id, $event_date=''){
	$sql_result = mysql_query("select image_name from mod_calendar_events where event_id='$event_id'");
	list ($image_name) = mysql_fetch_array ($sql_result);
	
	list ($height, $width) = array_values(set_size($image_name));
	$stuff = "
	<a href=\"javascript:void(0)\" onclick=\"open('mod.php?mod=calendar&amp;op=view_event&amp;event_id=$event_id";

	if ($event_date)
		$stuff .= "&amp;event_date=$event_date";

	$stuff .= "','ViewEvent','scrollbars=1,width=$width,height=$height')\">
	<img src=\"./mod/calendar/info.gif\" alt=\"" . tell_time($event_id) . "\" border=\"0\" width=\"8\" height=\"10\" /></a>";
	return $stuff;
}

####################################################
function count_repeats ($date){
	$repeat_days = get_repeats($date,$date);
	return count($repeat_days);
}
###################################################

function list_repeats ($repeat_array, $date, $time, $view){
	include ("mod/calendar/calendar_config.php");
	global $repeat_array, $holdtime, $temptime, $tran;
	if ($repeat_array){
		switch ($view){
			case("month"):
			while (list($key, $sub_array) = each($repeat_array)){
				list($event_id, $starttime, $event_date) = array_values($sub_array);
				if ($event_date == $date && $starttime <= $time){
					$rep_sql = "select title from mod_calendar_events where event_id='$event_id'";				
					$repeat_result = mysql_query($rep_sql);
					list ($title) = mysql_fetch_row($repeat_result);	
					if ($que)
						$stuff .= "
					<tr>";	
					$stuff .= "
						<td valign=\"top\" width=\"5%\">" . mini_view($event_id, $date) . "</td>
						<td class=\"$smalltype\" align=\"left\">
						<a href=\"mod.php?mod=calendar&amp;op=show_event&amp;event_id=$event_id&amp;date=$date\">$title</a></td>
					</tr>";
						$que = 1;
					unset($repeat_array[$key]);
				}
			}
			reset ($repeat_array);
			break;

			case("week"):
			while (list($key, $sub_array) = each($repeat_array)){
				list($event_id, $starttime, $event_date) = array_values($sub_array);
				if ($event_date == $date && $starttime <= $time){
					$rep_sql = "select title, allday from mod_calendar_events where event_id='$event_id'";				
					$repeat_result = mysql_query($rep_sql);
					list ($title, $allday) = mysql_fetch_row($repeat_result);
					if ($temptime != $starttime) {
						if ($allday != 1)
							$stuff .= "
				<table width=\"100%\" cellpadding=\"3\" cellspacing=\"0\" border=\"0\">
				<tr>
					<td class=\"$block_top\" align=\"center\" colspan=\"2\">" . get_time($starttime). "</td>
				</tr>
				</table>";

						else
							$stuff .= "
				<table width=\"100%\" cellpadding=\"3\" cellspacing=\"0\" border=\"0\">
				<tr>
					<td class=\"$block_top\" align=\"center\" colspan=\"2\">All Day</td>
				</tr>
				</table>";

						$temptime = $starttime;
						$que = 1;
					}
					$stuff .= "
				<table width=\"100%\" cellpadding=\"3\" cellspacing=\"0\" border=\"0\">
				<tr>
					<td valign=\"top\" class=\"$block_body\" width=\"5%\">" . mini_view($event_id, $date) . "</td>
					<td valign=\"top\" class=\"$block_body\"><a href=\"mod.php?mod=calendar&amp;op=show_event&amp;event_id=$event_id&amp;date=$date\">$title</a></td>
				</tr>
				</table>";
				unset($repeat_array[$key]);
				}
			}
			reset($repeat_array);
			break;
			
			case("day"):
			while (list($key, $sub_array) = each($repeat_array)){
				list($event_id, $starttime, $event_date) = array_values($sub_array);

				if ($event_date == $date && $starttime <= $time){
					$rep_sql = "select title, allday from mod_calendar_events where event_id='$event_id'";				
					$repeat_result = mysql_query($rep_sql);
					list ($title, $allday) = mysql_fetch_row($repeat_result);
					$sql_result1 = mysql_query ("select category, cat_id from mod_calendar_category where cat_id = '$cat_id'");
					list ($category, $cat_id) = mysql_fetch_array($sql_result1) ;
					$sql_result2 = mysql_query ("select subcat, subcat_id from mod_calendar_subcat where subcat_id = '$subcat_id'");
					list ($subcat, $subcat_id) = mysql_fetch_array($sql_result2) ;

					if (($starttime != $holdtime) && $allday != 1 ) {
						if ($allday_switch || $time_switch){
							$stuff .= "
				</td>
			</tr>";
							$allday_switch = 0;
						}
						$time_switch = 1;
						$stuff .= "
			<tr>
				<td width=\"10%\" align=\"left\" valign=\"top\"><b>" . get_time($starttime) . "</b></td>
				<td>";
						$holdtime = $starttime;

					} elseif ($allday == 1 && $allday_switch != 1){
						$stuff .= "
			<tr>
				<td width=\"10%\" align=\"left\" valign=\"top\"><b>$tran[All_Day]</b></td>
				<td>";
						$allday_switch = 1;
					}
					else
						$stuff .= "<br />";
					$stuff .= mini_view($event_id, $date) . " <a href=\"./mod.php?mod=calendar&amp;op=show_event&amp;event_id=$event_id&amp;date=$date\">$title</a>";
					unset($repeat_array[$key]);
				}
			}
			reset($repeat_array);
			break;

			case ("block_day"):
			while (list($key, $sub_array) = each($repeat_array)){
				list($event_id, $starttime, $event_date) = array_values($sub_array);
				if ($event_date == $date && $starttime <= $time){
					$rep_sql = "select title, allday from mod_calendar_events where event_id='$event_id'";				
					$repeat_result = mysql_query($rep_sql);
					list ($title, $allday) = mysql_fetch_row($repeat_result);
					if ($temptime != $starttime) {
						if ($allday != 1)
							$stuff .= "
				<table width=\"100%\" cellpadding=\"3\" cellspacing=\"0\" border=\"0\">
				<tr>
					<td class=\"$block_top\" align=\"center\" colspan=\"2\">" . get_time($starttime). "</td>
				</tr>
				</table>";

						else
							$stuff .= "
				<table width=\"100%\" cellpadding=\"3\" cellspacing=\"0\" border=\"0\">
				<tr>
					<td class=\"$block_top\" align=\"center\" colspan=\"2\">$tran[All_Day]</td>
				</tr>
				</table>";

						$temptime = $starttime;
						$que = 1;
					}
					$stuff .= "
				<table width=\"100%\" cellpadding=\"3\" cellspacing=\"0\" border=\"0\">
				<tr>
					<td valign=\"top\" class=\"$block_body\" width=\"5%\">" . mini_view($event_id, $date) . "</td>
					<td valign=\"top\" class=\"$block_body\"><a href=\"mod.php?mod=calendar&amp;op=show_event&amp;event_id=$event_id&amp;date=$date\"><span class=\"$smalltype\">$title</span></a></td>
				</tr>
				</table>";
				unset($repeat_array[$key]);
				}
			}
			reset($repeat_array);
			break;

			case("alt_month"):
			while (list($key, $sub_array) = each($repeat_array)){
				list($event_id, $starttime, $event_date) = array_values($sub_array);

				if ($event_date == $date && $starttime <= $time){
					$rep_sql = "select title, allday from mod_calendar_events where event_id='$event_id'";				
					$repeat_result = mysql_query($rep_sql);
					list ($title, $allday) = mysql_fetch_row($repeat_result);
					$stuff .= mini_view($event_id, $date) . " <a href=\"./mod.php?mod=calendar&amp;op=show_event&amp;event_id=$event_id&amp;date=$date\">$title</a>&nbsp;&nbsp;&nbsp;".tell_time($event_id)."<br />";
					unset($repeat_array[$key]);
				}
			}
			reset($repeat_array);
			break;

			case ("block_week"):
			while (list($key, $sub_array) = each($repeat_array)){
				list($event_id, $starttime, $event_date) = array_values($sub_array);
				$rep_sql = "select title from mod_calendar_events where event_id='$event_id'";				
				$repeat_result = mysql_query($rep_sql);
				list ($title) = mysql_fetch_row($repeat_result);
				$stuff .= "
				<tr>
					<td valign=\"top\" class=\"$block_body\" width=\"5%\">" . mini_view($event_id, $date) . "</td>
					<td valign=\"top\" class=\"$block_body\">
						<a href=\"mod.php?mod=calendar&amp;op=show_event&amp;event_id=$event_id&amp;date=$date\"><span class=\"$smalltype\">$title</span></a>
					</td>
				</tr>";
				unset($repeat_array[$key]);
			}
			
				reset($repeat_array);
				break;
		}
		return $stuff;
	}
	$hold_time = $time;
}
################################################################
function get_repeats($start_date, $end_date=0)
{
	if ($end_date==0)
		$end_date=$start_date;
	$sql = "select * from mod_calendar_events 
		where 
		repeat_type != '' and event_date <= $end_date order by starttime";
	$sql_result = mysql_query($sql);
	$start_month = substr($start_date, 4, 2);
	$start_day = substr($start_date, 6, 2);
	$start_year = substr ($start_date, 0, 4);

	$end_month = substr($end_date, 4, 2);
	$end_day = substr($end_date, 6, 2);
	$end_year = substr ($end_date, 0, 4);

	$start_seed = mktime (2, 0, 0, $start_month, $start_day, $start_year);
	$end_seed = mktime (2, 0, 0, $end_month, $end_day, $end_year);
	$j=0;
	while ($row = mysql_fetch_array($sql_result)){
		extract($row);
		switch ($repeat_type){
			case("day"):
				for ($i=$start_seed;$i <= $end_seed; $i = $i+(24 * 3600) ){
					$temp_date = date("Ymd", $i);
					if ($temp_date > $event_date && $temp_date <= $end_repeat)
						$repeat_days[] = array($event_id, $starttime, $temp_date); 
				}
				break;

			case("week"):
				for ($i=$start_seed;$i <= $end_seed; $i = $i+(24 * 3600) ){
					$week_array = explode (":",$repeat_week_day);
					$dow_check = date(w, $i);
					$temp_date = date("Ymd", $i);
					if (($week_array[$dow_check]) && ($temp_date > $event_date) &&($temp_date <= $end_repeat)){
						$repeat_days[] = array($event_id, $starttime, $temp_date);
					}
				}
				break;

			case("month"):
				for ($i=$start_seed;$i <= $end_seed; $i = $i+(24 * 3600) ){
					$temp_date = date("Ymd", $i);
					if ($month_repeat_type == 'day'){
						if ((substr($event_date,6,2)==substr($temp_date,6,2))&& ($temp_date > $event_date) && ($temp_date <= $end_repeat)){
							$repeat_days[] = array($event_id, $starttime, $temp_date);
						}
					}
					elseif ($month_repeat_type == 'end'){
						if ((date("t",mktime(2,0,0,$start_month,1,$start_year))==date("d",$i)) && ($temp_date > $event_date) && ($temp_date <= $end_repeat)){
							$repeat_days[] = array($event_id, $starttime, $temp_date);
						}
					}
				}
				break;

			case("year"):
				for ($i=$start_seed;$i <= $end_seed; $i = $i+(24 * 3600) ){
					$temp_date = date("Ymd", $i);
					if (date("md", $i) == substr($event_date,4,4) && ($temp_date > $event_date) && ($temp_date <= $end_repeat))
							$repeat_days[] = array($event_id, $starttime, $temp_date);
				}
				break;

			default:
				break;
		}
	}
	return $repeat_days;
}


// Get the Sunday of the week that the specified date is in.
// (If the date specified is a Sunday, then that date is returned.)
function get_sunday_before ( $year, $month, $day ) {
  $weekday = date ( "w", mktime (2, 0, 0, $month, $day, $year ) );
  $newdate = mktime (2, 0, 0, $month, $day - $weekday, $year );
  return $newdate;
}

function get_monday_before ( $year, $month, $day ) {
  $weekday = date ( "w", mktime (2, 0, 0, $month, $day, $year ) );
  $newdate = mktime (2, 0, 0, $month, $day - $weekday + 1, $year );
  return $newdate;
}


// Return the abbreviated weekday name
// params:
//   $w - weekday (0=Sun,...,6=Sat)
function weekday_short_name ( $w ) {
  global $tran;
  include ("mod/calendar/calendar_config.php");

  if (empty($start_on_monday)) {
    switch ( $w ) {
    case 0: return "$tran[Sun]";
    case 1: return "$tran[Mon]";
    case 2: return "$tran[Tue]";
    case 3: return "$tran[Wed]";
    case 4: return "$tran[Thu]";
    case 5: return "$tran[Fri]";
    case 6: return "$tran[Sat]";
    }
  } else {
    switch ( $w ) {
    case 0: return "$tran[Mon]";
    case 1: return "$tran[Tue]";
    case 2: return "$tran[Wed]";
    case 3: return "$tran[Thu]";
    case 4: return "$tran[Fri]";
    case 5: return "$tran[Sat]";
    case 6: return "$tran[Sun]";
    }
  }
  return "unknown-weekday($w)";
}


/**
 * Checks date and posts calendar events 
 * 
 *
 * @module cal_functions
 * @modulegroup admin
 * @package Calendar
 * @author Matthew McNaney
 */
function check_post(){
	global $tran;
  $date = date_now("Ymd");
  $sql = mysql_query("select post_event_id, topic, post_end from mod_calendar_post where post_start <= '$date' and posted='0'");
  while (list ($post_event_id, $topic, $post_end) = mysql_fetch_row($sql)){
    $exp_date = substr($post_end,0,4)."-".substr($post_end,4,2)."-".substr($post_end,6,2). " 00:00:00";
    $fetch_event= mysql_query("select event_id, title, description from mod_calendar_events where event_id='$post_event_id'");
    list ($event_id, $title, $description) = mysql_fetch_row($fetch_event);
	if (strlen($description))
		$description .= "<br /><br />";

	$description .= "$tran[Click] <a href=\"mod.php?mod=calendar&amp;op=show_event&amp;event_id=$event_id\">$tran[here]</a> $tran[for_more_information]";

    $create_story = "insert into stories (aid, title, time, hometext, bodytext, topic, informant, exp_date, counter) values ('Calendar', '$title', '" . date("Y-m-d H:i:s") . "', '$description', '', '$topic', 'Calendar', '$exp_date', 0)";
    mysql_query ($create_story);
	$get_sid = mysql_query("select sid from stories order by sid desc limit 1");
	list($article_id) = mysql_fetch_row($get_sid);
    mysql_query ("update mod_calendar_post set posted='1', article_id='$article_id' where post_event_id='$post_event_id'");
  }

}

?>
