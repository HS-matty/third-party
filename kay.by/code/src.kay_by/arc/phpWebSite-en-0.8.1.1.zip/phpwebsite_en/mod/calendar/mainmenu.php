<?php
include("header.php");
include("mod/calendar/calendar_config.php");
include("mod/calendar/language.php");
global $tran;

$date_order = format_date (NULL,"date_order");
$sql_result = mysql_query("select name from modules where plug_dir='calendar'");
list ($plug_name) = mysql_fetch_row ($sql_result);

$box_title = "<form action=\"mod.php\" method=\"post\">
		<input type=\"hidden\" name=\"mod\" value=\"calendar\" />
		<input type=\"hidden\" name=\"op\" value=\"change_name\" />
		<input type=\"text\" name=\"plug_name\" size=\"20\" maxsize=\"100\" value=\"$plug_name\" />
		<input type=\"submit\" value=\"$tran[Change_Name]\" />
	</form>";

$content = "
<table cellpadding=\"2\" cellspacing=\"2\" border=\"0\" width=\"100%\">";

if (strlen ($note))
	$content .= "<tr><td class=\"$misc_highlight\" align=\"center\" colspan=\"2\">$note</td>
</tr>";

$content .= "
<tr>
	<td>
	<form action=\"mod.php\" method=\"post\">
		<input type=\"hidden\" name=\"mod\" value=\"calendar\" />
		<input type=\"hidden\" name=\"op\" value=\"cat_admin\" />
		<input type=\"submit\" value=\"$tran[Create] $tran[cat_name]\" />
	</form>
	</td>
</tr>
<tr>
	<td>
";

$sql_result = mysql_query ("select cat_id, category from mod_calendar_category");
if (mysql_num_rows($sql_result) > 0){
	$content .= "
	<form action=\"mod.php\" method=\"post\">
		<input type=\"hidden\" name=\"mod\" value=\"calendar\" />
		<input type=\"hidden\" name=\"op\" value=\"cat_admin\">
		<select name=\"cat_id\">
	";
	while ($row = mysql_fetch_array($sql_result))
	{
		extract($row);

		$content .= "
			<option value=\"$cat_id\">$category</option>";
	}
	$content .= "
		</select>
		<input type=\"submit\" value=\"$tran[Edit] $tran[cat_name]\" />
		<input type=\"submit\" name=\"delete_cat\" value=\"$tran[Remove] $tran[cat_name]\" />
	</form>
	";
}

$content .= "
	</td>
</tr>
";

$sql_result = mysql_query ("select cat_id, category from mod_calendar_category");
if (mysql_num_rows($sql_result) > 0){
	$content .= "
<tr>
	<td>
	<form action=\"mod.php\" method=\"post\">
		<input type=\"hidden\" name=\"mod\" value=\"calendar\" />
		<input type=\"hidden\" name=\"op\" value=\"subcat_admin\">
		<select name=\"cat_id\">";

	while ($row = mysql_fetch_array($sql_result))
	{
		extract($row);
		$content .= "
			<option value=\"$cat_id\">$category</option>";
	}
	$content .= "
		</select>
		<input type=\"submit\" value=\"$tran[Create] $tran[subcat_name]\">
	</form>
	</td>
</tr>
	";
}

$sql_result = mysql_query ("select subcat_id, subcat, cat_id from mod_calendar_subcat order by cat_id, subcat");

if (mysql_num_rows($sql_result) > 0){

	$content .= "
<tr>
	<td>
	<form action=\"mod.php\" method=\"post\">
		<input type=\"hidden\" name=\"mod\" value=\"calendar\" />
		<input type=\"hidden\" name=\"op\" value=\"subcat_admin\" />
		<select name=\"subcat_id\">";

	while ($subcategories = mysql_fetch_array($sql_result))
	{
		extract($subcategories);
		if ($cat_id != $cat_id_cache) {
			$sql_result2 = mysql_query ("select category from mod_calendar_category 
						where cat_id=$cat_id");
			list ($category) = mysql_fetch_row ($sql_result2);
			$cat_id_cache = $cat_id;
		}
		$content .= "
			<option value=\"$subcat_id\">$category: $subcat</option>";
	}
	$content .= "
		</select>
		<input type=\"submit\" value=\"$tran[Edit] $tran[subcat_name]\">
		<input type=\"submit\" name=\"delete_subcat\" value=\"$tran[Remove] $tran[subcat_name]\" />
	</form>
	</td>
</tr>";
}

$content .= "
<tr>
	<td>
	<form action=\"mod.php\" method=\"post\">
		<input type=\"hidden\" name=\"mod\" value=\"calendar\" />
		<input type=\"hidden\" name=\"op\" value=\"location_admin\" />
		<input type=\"submit\" value=\"$tran[Add_Location]\" />
	</form>
";

$loc_result = mysql_query ("select loc_id, loc_name from mod_calendar_location order by loc_name");
if (mysql_num_rows($loc_result) > 0){
	$content .= "
	<form action=\"mod.php\" method=\"post\">
		<input type=\"hidden\" name=\"mod\" value=\"calendar\" />
		<input type=\"hidden\" name=\"op\" value=\"location_admin\" />
		<select name=\"loc_id\">";
	while ($row = mysql_fetch_array($loc_result)){
		extract($row);
		$content .= "
			<option value=\"$loc_id\">$loc_name</option>";
	}
	$content .= "
		</select>
		<input type=\"submit\" name=\"edit_loc\" value=\"$tran[Edit_Location]\" />
		<input type=\"submit\" name=\"delete_location\" value=\"$tran[Remove_Location]\" />
	</form>";
}

$content .= "
	</td>
</tr>
<tr>
	<td>
	<form action=\"mod.php\" method=\"post\">
		<input type=\"hidden\" name=\"mod\" value=\"calendar\" />
		<input type=\"hidden\" name=\"op\" value=\"event_admin\" />
	 	<input type=\"submit\" value=\"$tran[Create_Event]\" />
	</form>
	</td>
</tr>";

$sql_result = mysql_query ("select * from mod_calendar_events order by title");
if (mysql_num_rows($sql_result)){
	$title='';
	$content .= "
<tr>
	<td>
	<form action=\"mod.php\" method=\"post\">
		<input type=\"hidden\" name=\"mod\" value=\"calendar\" />
		<input type=\"hidden\" name=\"op\" value=\"event_admin\" />
		<select name=\"event_id\">";


	while ($row = mysql_fetch_array($sql_result)) {
		extract($row);
		$content .= "
			<option value=\"$event_id\">$title -  Starts on: " . format_date($event_date) . "</option>";
	}
	$content .= "
		</select>
		<input type=\"submit\" value=\"$tran[Edit_Event]\" />
		<input type=\"submit\" name=\"delete_event\" value=\"$tran[Delete_Event]\" />
	</form>
	</td>
</tr>
<tr>
	<td>
	<form action=\"mod.php\" method=\"post\">
	<input type=\"hidden\" name=\"mod\" value=\"calendar\" />
	<input type=\"hidden\" name=\"op\" value=\"purge_events\" />";
switch ($date_order){
	case("mdy"):
		$content .= select_month ("purge_month", date_now(m)) . select_day("purge_day", date_now(d)) . select_year("purge_year", date_now(Y));
		break;
	case("ymd"):
		$content .= select_year("purge_year", date_now(Y)) . select_month ("purge_month", date_now(m)) . select_day("purge_day", date_now(d));
		break;
	case("dmy"):
		$content .= select_day("purge_day", date_now(d)) . select_month ("purge_month", date_now(m)) . select_year("purge_year", date_now(Y));
		break;
}
$content .= "
	<input type=\"submit\"  value=\"$tran[Purge_Events]\" />
	</form>
	</td>
</tr>


";
}
$content .= "
</table>
<hr />";

$sql_result = mysql_query("select * from mod_calendar_settings");
$row = mysql_fetch_array($sql_result);
extract ($row);

$sql_result = mysql_query("select block_pos from modules where name='Calendar'");
list($block_pos) = mysql_fetch_row ($sql_result);

$sql_result = mysql_query ("select date_format from mod_calendar_settings");
list ($date_format)=mysql_fetch_row ($sql_result);
$date_explode = explode ("^", $date_format);	
list ($date_order, $month_form, $digit_style, $year_digits, $separator) = array_values($date_explode);


$content .= "
<b>$tran[Other_Options]:</b>
<table cellspacing= \"8\" cellpadding=\"6\" border=\"0\">
<tr>
	<td valign=\"top\" class=\"$block_top\" align=\"center\">
	<b>Date</b><br /><br />
	<table cellspacing= \"0\" cellpadding=\"4\" border=\"0\">
	<tr>
	<td class=\"$block_body\">
<form action=\"mod.php\" method=\"post\">
	<input type=\"hidden\" name=\"mod\" value=\"calendar\" />
	<b>$tran[Change_Date_Format]</b><br />
	<input type=\"hidden\" name=\"op\" value=\"date_format\" />
	<select name=\"date_order\">
		<option value=\"mdy\"" . check_me($date_order, "mdy", "s") . ">Month Day Year</option>
		<option value=\"ymd\"" . check_me($date_order, "ymd", "s") . ">Year Month Day</option>
		<option value=\"dmy\"" . check_me($date_order, "dmy", "s") . ">Day Month Year</option>
	</select><br />
	<select name=\"date_style\">
		<option value=\"number^double^y4\"" . check_me("$month_form^$digit_style^$year_digits", "number^double^y4", "s") . ">09".$separator."05".$separator."2001</option>
		<option value=\"number^double^y2\"" . check_me("$month_form^$digit_style^$year_digits", "number^double^y2", "s") . ">09".$separator."05".$separator."01</option>
		<option value=\"number^nozero^y4\"" . check_me("$month_form^$digit_style^$year_digits", "number^nozero^y4", "s") . ">9".$separator."5".$separator."2001</option>
		<option value=\"number^nozero^y2\"" . check_me("$month_form^$digit_style^$year_digits", "number^nozero^y2", "s") . ">9".$separator."5".$separator."01</option>
		<option value=\"name^double^y4\"" . check_me("$month_form^$digit_style^$year_digits", "name^double^y4", "s") . ">$tran[September] 05, 2001</option>
		<option value=\"name^double^y2\"" . check_me("$month_form^$digit_style^$year_digits", "name^double^y2", "s") . ">$tran[September] 05, 01</option>
		<option value=\"name^nozero^y4\"" . check_me("$month_form^$digit_style^$year_digits", "name^nozero^y4", "s") . ">$tran[September] 5, 2001</option>
		<option value=\"name^nozero^y2\"" . check_me("$month_form^$digit_style^$year_digits", "name^nozero^y2", "s") . ">$tran[September] 5, 01</option>
		<option value=\"short^double^y4\"" . check_me("$month_form^$digit_style^$year_digits", "short^double^y4", "s") . ">$tran[Sep] 05, 2001</option>
		<option value=\"short^double^y2\"" . check_me("$month_form^$digit_style^$year_digits", "short^double^y2", "s") . ">$tran[Sep] 05, 01</option>
		<option value=\"short^nozero^y4\"" . check_me("$month_form^$digit_style^$year_digits", "short^nozero^y4", "s") . ">$tran[Sep] 5, 2001</option>
		<option value=\"short^nozero^y2\"" . check_me("$month_form^$digit_style^$year_digits", "short^nozero^y2", "s") . ">$tran[Sep] 5, 01</option>
	</select><br />
	<select name=\"separator\">
		<option" . check_me($separator, "-", "s") . ">-</option>
		<option" . check_me($separator, "/", "s") . ">/</option>
		<option" . check_me($separator, "+", "s") . ">+</option>
		<option" . check_me($separator, "|", "s") . ">|</option>
		<option" . check_me($separator, ".", "s") . ">.</option>
		<option" . check_me($separator, ",", "s") . ">,</option>
		<option" . check_me($separator, ":", "s") . ">:</option>
		<option" . check_me($separator, ";", "s") . ">;</option>
		<option" . check_me($separator, "'", "s") . ">'</option>
		<option" . check_me($separator, "_", "s") . ">_</option>
	</select><input type=\"submit\" value=\"$tran[Go]!\" />
</form>
<hr />
<form action=\"mod.php\" method=\"post\">
<input type=\"hidden\" name=\"mod\" value=\"calendar\" />
<b>$tran[Edit_Month_Image]</b><br />
	<input type=\"hidden\" name=\"op\" value=\"set_month_image\" />" . select_month("month", date_now("m")) . "
	<input type=\"submit\" value=\"$tran[Go]!\" />
</form>
	</td>
	</tr>
	</table>
	</td>
	<td valign=\"top\" class=\"$block_top\" align=\"center\">
	<b>$tran[Change_User_View]</b><br /><br />
	<table cellspacing= \"0\" cellpadding=\"4\" border=\"0\">
	<tr>
	<td class=\"$block_body\">

		<form action=\"mod.php\" method=\"post\">
		<input type=\"hidden\" name=\"mod\" value=\"calendar\" />
		<input type=\"hidden\" name=\"op\" value=\"user_view\" />
		<input type=\"checkbox\" name=\"month_view\" value=\"1\"" . check_me($month_view, 1, "c") . " /> $tran[Month_View]<br />
		<input type=\"checkbox\" name=\"week_view\" value=\"1\"" . check_me($week_view, 1, "c") . " /> $tran[Week_View]<br />
		<input type=\"checkbox\" name=\"cat_view\" value=\"1\"" . check_me($cat_view, 1, "c") . " /> $tran[cat_name] $tran[View]<br />
		<input type=\"checkbox\" name=\"subcat_view\" value=\"1\"" . check_me($subcat_view, 1, "c") . " /> $tran[subcat_name] $tran[View]
		<br />
		<input type=\"checkbox\" name=\"location_view\" value=\"1\"" . check_me($location_view, 1, "c") . " /> $tran[Location_View]
		<br />
		<input type=\"checkbox\" name=\"today_view\" value=\"1\"" . check_me($today_view, 1, "c") . " /> $tran[Today_s_Events_View]
		<br />
		<hr />
		<input type=\"checkbox\" name=\"small_view\" value=\"1\"" . check_me($small_view, 1, "c") . " /> $tran[Small_Month_View]
		<br />
		<input type=\"radio\" name=\"block_pos\" value=\"1\"" . check_me($block_pos, 1, "c") . " /> $tran[Left_Side]<br />
		<input type=\"radio\" name=\"block_pos\" value=\"3\"" . check_me($block_pos, 3, "c") . " /> $tran[Right_Side]<br />
		<input type=\"radio\" name=\"block_pos\" value=\"0\"" . check_me($block_pos, 0, "c") . " /> $tran[Hide_Calendar]<br />
		<br />
		<input type=\"submit\" value=\"$tran[Go]!\" />
		<br />
		</form>
	</td>
	</tr>
	</table>
	</td>
	<td class=\"$block_top\" valign=\"top\" align=\"center\">
		<b>$tran[Time_Format]</b><br /><br />
	<table cellspacing= \"0\" cellpadding=\"4\" border=\"0\">
	<tr>
	<td class=\"$block_body\">
<form action=\"mod.php\" method=\"post\">
	<input type=\"hidden\" name=\"mod\" value=\"calendar\" />
	<b>$tran[Change_Time_Format]</b><br />
	<input type=\"hidden\" name=\"op\" value=\"format_time\" />
	<input type=\"radio\" name=\"time_format\" value=\"m\"" . check_me($time_format, "m", "c") . " />$tran[Military]<br />
	<input type=\"radio\" name=\"time_format\" value=\"s\"" . check_me($time_format, "s", "c") . " />$tran[Standard]<br />
	<input type=\"submit\" value=\"$tran[Go]!\" />
</form>
<hr />
<form action=\"mod.php\" method=\"post\">
	<input type=\"hidden\" name=\"mod\" value=\"calendar\" />
	<b>$tran[Change_Time_Difference]</b><br />
	<input type=\"hidden\" name=\"op\" value=\"server_time\" />
$tran[Server_Time]:<br /><b>" . get_time(date("Hi")) . " $tran[on] " . format_date(date("Ymd")) . "</b>.<br />$tran[Your_time]:<br/> <b>" . 
get_time(date_now("Hi")) . " $tran[on] " . format_date(date_now("Ymd")) . "</b><br />$tran[Difference_needed]?<br />
	<select name=\"time_diff\">";

for ($i=-24;$i<25;$i++){
	$content .= "
		<option" . check_me($i, $time_diff, "s") . ">$i</option>";
}

$content .= "
	</select>
	<input type=\"submit\" value=\"$tran[Go]!\" />
</form>
	</td>
	</tr>
	</table>		
	</td>

</tr>
</table>

";

thememainbox ($box_title, $content);

?>
