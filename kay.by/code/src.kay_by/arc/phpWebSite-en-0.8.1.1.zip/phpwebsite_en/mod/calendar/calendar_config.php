<?php

#make a folder under you image directory.make sure it has nobody.nobody access
$calendar_image_dir="./images/calendar/";
$calendar_img_url = "./images/calendar/";

# If you are worried about Netscape 4.x lagging on month view
# (Netscape can't handle embedded tables for anything) set this 1
# for an alternate view.
$netscape_view = 1;

# If your week starts on Monday set this to 1
$start_on_monday = 1;

############################################################
# Desc: Substitute the colors and styles you are using in
# 	your themes with the variables below. Beware
#	if your themes don't use similar definitions.
############################################################

$block_top = "type2"; ##Small blocks will have this theme as their header
$block_body = "type4"; ## Small blocks will be shaded with this color
$misc_highlight = "type4"; ##Various highlights throughout plug-in will use this theme.
$error_color = "error"; #color that highlights error spots in admin section
$smalltype = "smalltype"; #a small font span very important for small month
$calendar_lines = "type0"; ## Forms lines in month view, usually dark
$highlight_day = "type4"; #day that bears highlighting, usually when it is today
$calendar_foreground = "type3"; ## Filler on calendar background but not a numbered day
$numbered_day = "type5"; ## color underneath a numbered day
$largetype = "bigtext"; ## For certain headlines a larger font size
?>
