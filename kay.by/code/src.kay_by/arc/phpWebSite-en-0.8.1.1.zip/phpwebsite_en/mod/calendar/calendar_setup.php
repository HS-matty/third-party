<?php

include("../../open_session.php");

function dbconnect()
{
	include ("../../config.php");
	mysql_connect($dbhost, $dbuname, $dbpass);
	@mysql_select_db("$dbname") or die ("Unable to select database");
}

dbconnect();
$dbconnect = 1;


$title = "Calendar Plug_in";

if ($ready == "no")
{
	$content= "<p>Plug In aborted</p>
	<p>Click <a href=\"../../admin.php\">here</a> to go back to administrator page.<br />
	Click <a href=\"calendar_setup.php\">here</a> to try setup again.</p>";
}
else if($ready=="yes")
{
	dbconnect();
	$install_check = mysql_query ("select * from modules where plug_dir='calendar'");
	if (mysql_num_rows($install_check) != 1)
	{
		$insert_plugin = "INSERT INTO modules VALUES ( NULL, 'Calendar', 'mod.php?mod=calendar', 'calendar.gif', 'calendar', '1', 'cal_block.php', '0', '0', 'mainmenu', 'Calendar - written by Matthew McNaney.')";
		$result = mysql_query($insert_plugin);

		if ($result == 0)
		{
			$content = "MySQL says: Error number - " . mysql_errno() . "<br />" . mysql_error();
 		}
	}
	else
	{
	  $modify_plugin = "update modules set source_file='mod.php?mod=calendar'";
	  $result = mysql_query($modify_plugin);
		if ($result == 0)
		{
			$content = "MySQL says: Error number - " . mysql_errno() . "<br />" . mysql_error();
 		}

		$content .= "Current Calendar Install Updated.";
		$already_there = 1;
	}

	if (!$already_there)
	{
		$setting_table = "CREATE TABLE mod_calendar_settings (
					id tinyint(1) not null,
					month_view tinyint(1),
					week_view tinyint(1),
					cat_view tinyint(1),
					subcat_view tinyint(1),
					location_view tinyint(1),
					today_view tinyint(1),
					small_view tinyint(1),
					date_format varchar(35),
					time_format char(1),
					time_diff int(3),
					month_pics tinyint(4),
					pic_01 varchar(30),
					pic_02 varchar(30),
					pic_03 varchar(30),
					pic_04 varchar(30),
					pic_05 varchar(30),
					pic_06 varchar(30),
					pic_07 varchar(30),
					pic_08 varchar(30),
					pic_09 varchar(30),
					pic_10 varchar(30),
					pic_11 varchar(30),
					pic_12 varchar(30),
					PRIMARY KEY(id),
					KEY id (id))";

		$result2 = mysql_query($setting_table);

		if ($result2 == 0) $content .= "MySQL says: Error number - " . mysql_errno() . "<br />" . mysql_error();

		$setting_data = "INSERT INTO mod_calendar_settings VALUES ( '0', '1', '1', '1', '1', '1', '1', '1', 'mdy^name^double^y4^-', 's', '0', '1', '', '', '', '', '', '', '', '', '', '', '', '')";

		$result3 = mysql_query($setting_data);
		if ($result3 == 0) $content .= "MySQL says: Error number - " . mysql_errno() . "<br />" . mysql_error();

		$category_table = "CREATE TABLE mod_calendar_category (
				cat_id int(10) unsigned DEFAULT '0' NOT NULL auto_increment,
				category varchar(30),
				description text,
				image_name varchar(30),
				email varchar(30),
				PRIMARY KEY (cat_id))";

		$result4 = mysql_query($category_table);
		if ($result4 == 0) $content .= "MySQL says: Error number - " . mysql_errno() . "<br />" . mysql_error();

		$event_table = "CREATE TABLE mod_calendar_events (
				event_id int(10) unsigned DEFAULT '0' NOT NULL auto_increment,
				cat_id int(10),
				subcat_id int(10),
				title varchar(40),
				image_name varchar(30),
				description text,
				loc_id int(8),
				event_date int(8),
				starttime varchar(4),
				endtime varchar(4),
				allday tinyint(1) DEFAULT '0' NOT NULL,
				repeat_type varchar(5),
				repeat_week_day varchar(14),
				month_repeat_type char(3),
				end_repeat int(8),
				PRIMARY KEY (event_id))";

		$result5 = mysql_query($event_table);
		if ($result5 == 0) $content .= "MySQL says: Error number - " . mysql_errno() . "<br />" . mysql_error();

		$location_table = "CREATE TABLE mod_calendar_location (
				loc_id int(8) DEFAULT '0' NOT NULL auto_increment,
				loc_name varchar(60) NOT NULL,
				loc_desc text,
				image_name varchar(60),
				email varchar(60),
				PRIMARY KEY (loc_id))";

		$result6 = mysql_query($location_table);
		if ($result6 == 0) $content .= "MySQL says: Error number - " . mysql_errno() . "<br />" . mysql_error();

		$subcat_table = "CREATE TABLE mod_calendar_subcat (
				subcat_id int(8) DEFAULT '0' NOT NULL auto_increment,
				subcat varchar(30),
				description text,
				image_name varchar(30),
				email varchar(50),
				cat_id int(10),
				PRIMARY KEY (subcat_id))";


		$result7 = mysql_query($subcat_table);
		if ($result7 == 0) $content .= "MySQL says: Error number - " . mysql_errno() . "<br />" . mysql_error();

		$post_table = "CREATE TABLE mod_calendar_post (
				post_event_id int(10) DEFAULT '0' NOT NULL,
				topic int(2) DEFAULT '0' NOT NULL,
				post_start int(8) DEFAULT '0' NOT NULL,
				post_end int(8) DEFAULT '0' NOT NULL,
				posted tinyint(1) DEFAULT '0' NOT NULL,
				article_id int(11) DEFAULT '0' NOT NULL)";

		$result8 = mysql_query($post_table);
		if ($result8 ==0) $content .= "MySQL says: Error number - " . mysql_errno() . "<br />" . mysql_error();

		$adminpw = md5($security_hash);
		$create_admin = "insert into authors (aid, name, pwd) values ('Calendar', 'Calendar', '$adminpw')";
		$result9 = mysql_query($create_admin);
		if ($result9 ==0) $content .= "MySQL says: Error number - " . mysql_errno() . "<br />" . mysql_error();


		if ($result && $result2 && $result3 && $result4 && $result5 && $result5 && $result6 && $result7 && $result8 && $result9)
		$content .= "<span class=\"onebiggerred\">Plug-in Install complete</span><br/>
		<p>The calendar should now appear on your homepage. Enjoy!<br />Make sure to change the password on the Calendar Admin account AND delete calendar_setup.php!</p>";
		else
		$content .= "There was an error in setup.";
	}
}
else
{
	$content = "<p>This setup installs the calendar plug-in into phpWebsite.</p>
		<p>Are you ready to install Calendar Plug-in?<br />
		<a href=\"./calendar_setup.php?ready=yes\">YES</a>&nbsp;&nbsp;&nbsp;
		<a href=\"./calendar_setup.php?ready=no\">NO</a></p>";
}

echo "<html><head><title>Calendar Module Setup</title></head>
<body bgcolor=\"white\">
<table border=\"0\" align=\"center\" width=\"60%\">
<tr>
	<td align=\"center\"><b>$title</b></td>
</tr>
<tr>
	<td align=\"center\"><br />$content</td>
</tr>
</table>
</body>
</html>";

?>
