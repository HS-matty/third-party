<?php

/*
 * This userpage class has all the functions necessary to
 * create and edit a userpage instance.
 *
 * @module userpage
 * @package phpWebSite
 * @author Adam Morton, adam@tux.appstate.edu
*/

include("./mod/userpage/userpage_functions.php");

/* This class contains all the variables and functions needed to
   create and edit a userpage. */
class userpage
{
	var $new_page;
	var $editing_page;
	var $text_mode;
	var $page_active;
	var $sub_active;
	var $text_active;
	var $image_active;
	var $main_title;
	var $subtitle;
	var $text;
	var $imagename;
	var $alt;
	var $layout;
	var $sections;

/* Creates a new userpage and makes it active. */
function userpage ()
{
	include("./mod/userpage/userpage_config.php");

	$this->new_page = 1;
	$this->editing_page = 0;
	$this->text_mode = 0;
	$this->page_active = 1;
	$this->layout = $default_layout;
	$this->sections = $num_sections;
	$this->main_title = "New Web Page";
}

/* Sets the active flags for sub-titles, text, and images */
function set_active ($sub, $text, $image)
{
	for($i=0; $i<$this->sections; $i++) $this->sub_active[$i] = $sub[$i];
	for($i=0; $i<$this->sections; $i++) $this->text_active[$i] = $text[$i];
	for($i=0; $i<$this->sections; $i++) $this->image_active[$i] = $image[$i];
}

/* Sets the title of this userpage */	
function set_title ($newtitle)
{
	global $error_type;
	
	if(!$newtitle) $error_type = "main_title";
	$this->main_title = $newtitle;
}

/* Sets all subtitles for this userpage */
function set_subtitle ($newsubtitle)
{
	for($i=0; $i<$this->sections; $i++)
	$this->subtitle[$i] = $newsubtitle[$i];
}

/* Sets all the text for this userpage */
function set_text ($newtext)
{
	global $error_type;

	if(!$newtext[0]) $error_type = "text";

	for($i=0; $i<$this->sections; $i++)
	$this->text[$i] = $newtext[$i];
}

/* Sets all image attributes for this userpage */
function set_image ($newimage, $newimage_name, $newimage_type, $newimage_size, $alttag, $index, $old_image)
{
	global $error_type, $error_section;

	include("./mod/userpage/userpage_config.php");

	$this->alt[$index] = htmlspecialchars($alttag);
	
	$temp_type = explode(";", $newimage_type);

	if($old_image && !$alttag)
	{
		$error_type = "alt_tag";
		$error_section = $index + 1;
	}

	if($newimage != "none" && $newimage != "")
	{
		if($newimage_size > $max_image_size)
		{
			$error_type = "image_size";
			$error_section = $index + 1;
		}
		else if(!(substr_count($allowed_types, $temp_type[0]) > 0))
		{
			$error_type = "image_type";
			$error_section = $index + 1;
		}
		else if(!$alttag)
		{
			$error_type = "alt_tag";
			$error_section = $index + 1;
		}

		if($error_type != 'image_size' && $error_type != 'image_type')
		{
			$this->imagename[$index] = $newimage_name;
			$result = copy($newimage, $image_directory.$newimage_name);
			if(!$result)
			{
				$error_type = "permissions";
				$error_section = $index + 1;
			}
		}
	}
}

/* Sets the layout number for this userpage */
function set_layout ($newlayout)
{
	$this->layout = $newlayout;
}

/* Sets the text mode for this userpage. 0 for plain text
   and 1 for HTML formatted. */
function set_textmode ($text_mode)
{
	$this->text_mode = $text_mode;
}

/* Prints a preview warning box and asks the user for input. */
function previewing ()
{
	$title = "<b>Preview Web Page</b>";

	$content = "<center><b>Below is a preview of your page.<br />
	Press the back button to edit it some more.<br />
	Press the next button to save it in the database.</b>
	<form action=\"mod.php\" method=\"post\">
	<table border=\"0\" width=\"50%\">
	<tr><td align=\"center\">
	<input type=\"hidden\" name=\"mod\" value=\"userpage\" />
	<input type=\"hidden\" name=\"op\" value=\"finish\" />
	<input type=\"submit\" name=\"back\" value=\"Back\" />
	</td><td align=\"center\">
	<input type=\"submit\" name=\"finish\" value=\"Next\" />
	</td></tr></table>
	</form></center>\n";
		
	thememainbox($title, $content);

}

/* Simply prints out a button so an admin can directly edit
   this userpage. */
function admin_edit ()
{
	global $current_id;

	echo "<form method=\"post\" action=\"mod.php\">
	<input type=\"hidden\" name=\"mod\" value=\"userpage\" />
	<input type=\"hidden\" name=\"op\" value=\"edit_userpage\" />
	<input type=\"hidden\" name=\"page_id\" value=\"$current_id\" />
	<input type=\"submit\" value=\"Edit Page\" />
	</form>\n";
}

/* Calls the appropriate template function depending on this
   userpage's current layout */
function view_page ()
{
	global $current_data;
	$current_data = $this;

	if($this->is_active())
	{
		$temp = 'template' . $this->layout;
		$temp($this);
	}
}

/* Shows the data contained in this userpage and allows the user to edit it */
function edit_page ()
{
	global $current_data;
	$current_data = $this;

	include("config.php");
	include("./mod/userpage/userpage_config.php");

	$this->back_to_admin();

	if($this->new_page) $title = "<b>New Web Page</b>";
	else $title = "<b>Edit Web Page</b>";

	$page_title = htmlspecialchars(stripslashes($this->main_title));

	$content = "<table align=\"center\" cellspacing=\"10\"><tr>
	<td class=\"type5\" colspan=\"2\">
	<form action=\"mod.php\" method=\"post\" enctype=\"multipart/form-data\">
	<center>\n";

	if($this->text_mode) $content .= "
	<input type=\"radio\" name=\"text_mode\" value=\"0\" />&nbsp;<b>Plain Text</b>
	&nbsp;&nbsp;&nbsp;
	<input type=\"radio\" name=\"text_mode\" value=\"1\" checked=\"checked\" />&nbsp;<b>HTML</b>\n";
	else $content .= "
	<input type=\"radio\" name=\"text_mode\" value=\"0\" checked=\"checked\"/>&nbsp;<b>Plain Text</b>
	&nbsp;&nbsp;&nbsp;
	<input type=\"radio\" name=\"text_mode\" value=\"1\"  />&nbsp;<b>HTML</b>\n";

	$content .= "</center><br />
	<b>Title:</b><br />
        <input type=\"text\" name=\"title\" value=\"$page_title\" maxlength=\"200\" size=\"40\" />
	<br /><hr /><br />";
	
	for($i=0; $i < $this->sections; $i++)
	{
		$j = $i+1;

		$sub = htmlspecialchars(stripslashes($this->subtitle[$i]));
		if(!$this->text_mode)
		$this->text[$i] = str_replace("<br />", "\n", $this->text[$i]);

		$text = htmlspecialchars(stripslashes($this->text[$i]));
		$alttag = htmlspecialchars(stripslashes($this->alt[$i]));
		$img = $this->imagename[$i];

		if($this->sub_active[$i]) $sub_select = "checked=\"checked\"";
		else $sub_select = "";

		if($this->text_active[$i]) $text_select = "checked=\"checked\"";
		else $text_select = "";

		if($this->image_active[$i]) $image_select = "checked=\"checked\"";
		else $image_select = "";

		$content .= "
	<input type=\"checkbox\" name=\"sub_active[$i]\" value=\"$j\" $sub_select />
	<b>Subtitle $j:</b><br />
	<input type=\"text\" name=\"subtitle[$i]\" value=\"$sub\" maxlength=\"200\" size=\"40\" />
	<br />
	<input type=\"checkbox\" name=\"text_active[$i]\" value=\"$j\" $text_select />
	<b>Text $j:</b><br />
	<textarea name=\"text[$i]\" cols=\"50\" rows=\"15\" wrap=\"virtual\">$text</textarea>
	<br />
	<input type=\"checkbox\" name=\"image_active[$i]\" value=\"$j\" $image_select />
	<b>Image $j:</b><br />
		";
		
		if($img) $content .= "<input type=\"hidden\" name=\"old_image[$i]\" value=\"1\" />
		<input type=\"hidden\" name=\"img_id\" value=\"$i\" />
		<img src=\"./mod/userpage/images/$img\" alt=\"$alttag\" /><br />
		<input type=\"submit\" name=\"remove_image\" value=\"Remove Image\" /><br />\n";
		else $content .= "<input type=\"hidden\" name=\"old_image[$i]\" value=\"0\" />\n";

		$content .= "
	<input type=\"file\" name=\"image[$i]\" maxlength=\"80\" size=\"40\" /><br />
	<b>Short Image Description $j:</b><br />
	<input type=\"text\" name=\"alt[$i]\" value=\"$alttag\" maxlength=\"80\" size=\"40\" />
	<br /><hr /><br />
		";
	}
	
	$content .= "<center>
	<a href=\"./mod.php?mod=userpage&amp;op=show_layouts\" target=\"_blank\">Layout</a>
	<br /><table border=\"0\" width=\"30%\">\n<tr>\n";

	for($i=0; $i < $num_layouts; $i++)
	{
		$j = $i+1;

		if($this->layout == $j) $sel = "checked=\"checked\"";
		else $sel = "";
		
		$content .= "<td align=\"center\">
		<input type=\"radio\" name=\"layout\" value=\"$j\" $sel />
		<br />$j
		</td>\n";
	}

	$content .= "</tr></table></td></tr><tr>
	<td align=\"center\">
	<input type=\"hidden\" name=\"mod\" value=\"userpage\" />
	<input type=\"hidden\" name=\"op\" value=\"save_data\" />
	<input type=\"submit\" name=\"back\" value=\"Back\" />
	</td>
	<td align=\"center\"><input type=\"submit\" name=\"next\" value=\"Next\" /></td>
	</tr>
	</form>
	</td>
</tr>
</table>
	";

	thememainbox($title, $content);
}

/* Allows the user to select a layout for this userpage */
function show_layouts ()
{
	include("./mod/userpage/userpage_config.php");

	echo "<b>Current Layouts</b>";
	echo "<table border=\"0\" width=\"100%\">
	<tr><td align=\"center\" colspan=\"2\">\n";

	for($i=1; $i <= $num_layouts; $i++)
	{
		$temp = 'layout_message' . $i;
		$description = $$temp;

		echo "<tr><td><img src=\"./mod/userpage/images/layouts/layout$i.gif\" alt=\"Layout $i\" />
		<br /></td><td><b>Layout $i</b><br /><p>$description</p></td></tr>\n";
	}

	echo "</table>\n";
}

function remove_image ($img_id)
{
	$this->image_active[$img_id] = 0;
	$this->imagename[$img_id] = "";
	$this->alt[$img_id] = "";
}

/* Saves the current data of this userpage in the database */
function save_page ()
{
	global $current_data, $current_id;

	$this->new_page = 0;
	$page_title = $this->main_title;
	$data = addslashes(serialize($this));

	mysql_query("LOCK TABLES mod_userpage_data WRITE");
	$result = mysql_query("INSERT INTO mod_userpage_data VALUES ('', '$page_title', '$data')");

	if($result)
	{
		$result = mysql_query("SELECT max(id) FROM mod_userpage_data");
		mysql_query("UNLOCK TABLES");
		list($current_id) = mysql_fetch_row($result);
		
		$this->back_to_admin();
		$title = "New Web Page Saved!";
		$content = "<b>Your new page has successfully been saved to the database!</b>";
		thememainbox($title, $content);
	}
	else
	{
		$this->new_page = 1;
		$title = "<font color=\"red\"><b>ERROR!!</b></font>";
		$content = "<b>There was a database error when attempting to save your page!</b><br /><br />
		Please try to save it again in a moment.<br />
		If the problem persists, contact your system administrator.";
		thememainbox($title, $content);
		$this->view_page();
		include("footer.php");
		exit();
	}
}

/* Updates the current data of this userpage in the database */
function update_page ()
{
	global $current_data, $current_id;

	$page_title = $this->main_title;
	$this->editing_page = 0;
	$data = addslashes(serialize($this));

	$result = mysql_query("UPDATE mod_userpage_data SET title='$page_title', data='$data' WHERE id='$current_id'");

	if($result)
	{
		$this->back_to_admin();
		$title = "Web Page Updated!";
		$content = "<b>Your page has successfully been updated in the database!</b><br /><br />
		You can choose to add this page to the menu again or keep the current placement by clicking the finish button.
		<br /><form method=\"post\" action=\"admin.php\">
		<input type=\"submit\" value=\"Finish\" /></form>";
		thememainbox($title, $content);
	}
	else
	{
		$title = "<font color=\"red\"><b>ERROR!!</b></font>";
		$content = "<b>There was a database error when attempting to update your page!</b><br /><br />
		Please try to save it again in a moment.<br />If the problem persists, contact your system administrator.";
		thememainbox($title, $content);
		$this->view_page();
	}
}

/* This function strips any php tags from the text areas in
   this userpage and adds slashes to any quotes etc. */
function format_data ()
{
	$this->main_title = str_replace("<?", "<NOPHP", $this->main_title);
	$this->main_title = str_replace("?>", "NOPHP>", $this->main_title);

	for($i=0; $i < $this->sections; $i++)
	{
		$this->subtitle[$i] = str_replace("<?", "<NOPHP", $this->subtitle[$i]);
		$this->subtitle[$i] = str_replace("?>", "NOPHP>", $this->subtitle[$i]);
		
		$this->text[$i] = str_replace("<?", "<NOPHP", $this->text[$i]);
		$this->text[$i] = str_replace("?>", "NOPHP>", $this->text[$i]);
		if(!$this->text_mode)
		$this->text[$i] = str_replace("\n", "<br />", $this->text[$i]);
		
		$this->imagename[$i] = str_replace("<?", "<NOPHP", $this->imagename[$i]);
		$this->imagename[$i] = str_replace("?>", "NOPHP>", $this->imagename[$i]);

		$this->alt[$i] = str_replace("<?", "<NOPHP", $this->alt[$i]);
		$this->alt[$i] = str_replace("?>", "NOPHP>", $this->alt[$i]);
	}
}

/* Prints an error box if this userpage has an error, then allows the
   user to re-edit their userpage to correct the error */
function page_error ($type, $page_id="")
{
	global $error_section;

	include("./mod/userpage/userpage_config.php");

	$title = "<font color=\"red\"><b>ERROR!!</b></font>";
	$content = "<b>The following error has occurred:</b><br /><br />\n";

	switch($type)
	{
		case "page_id":
		$content .= "You must specify a page id when attempting to access a page!";
		break;

		case "active":
		$content .= "Page not active!";
		break;

		case "not_found":
		$content .= "Page not found!<br />Page ID: $page_id";
		break;

		case "refresh":
		$this->back_to_admin();
		$content .= "Data lost! This error can occur by hitting your browser's refresh or back button.<br />
		Please try to navigate the site with the provided <b>Next</b> and <b>Back</b> buttons.\n";
		break;

		case "main_title":
		$content .= "You have not submitted a main title for your page! Please enter a main title now.";
		break;

		case "text":
		$content .= "The first text area does not appear to contain text, please enter some now.\n";
		break;

		case "image_size":
		$content .= "The file you selected for image <b>$error_section</b> is too large!<br />
		The largest file size allowed on this server is $max_image_size bytes.<br />Please select a smaller image for uploading now.";
		break;

		case "image_type":
		$content .= "The file you selected for image <b>$error_section</b> is not a valid image type!<br />
            	The valid types are:<br /><br />$allowed_types<br /><br />Please select a new file for uploading now.";
		break;

		case "alt_tag":
		$content .= "You have not supplied a short description for image <b>$error_section</b>!<br />
           	Please enter a short description for image <b>$error_section</b>.";
		break;
		
		case "permissions":
		$content .= "There was a file system error when attempting to upload image <b>$error_section</b>!<br />
		Consult your network administrator";
		break;
	}
	
	$content .= "<br /><br />";
	thememainbox($title, $content);
}

/* Simply prints a link back to the main phpwebsite admin menu */
function back_to_admin ()
{
	echo "<center><b><a href=\"./admin.php\">Admin Menu</a></b></center><br />";
}

/* Returns the active status of this userpage */
function is_active ()
{
	return $this->page_active;
}

/* End of Class: userpage */
}

?>
