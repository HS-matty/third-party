<?php

/*
 * 
 * ATTENTION!! 
 * - Images will have to be manually moved to the ./mod/userpage/images directory.
 *
*/

class userpage
{
	var $new_page;
	var $editing_page;
	var $text_mode;
	var $page_active;
	var $sub_active;
	var $text_active;
	var $image_active;
	var $main_title;
	var $subtitle;
	var $text;
	var $imagename;
	var $alt;
	var $layout;
	var $sections;
}

mysql_query("CREATE TABLE mod_userpage_data (
             id int(5) NOT NULL PRIMARY KEY,
	     title varchar(200),
	     data longtext)");

$result = mysql_query("SELECT page_id, title, active, layout, num_sections FROM user_pages ORDER BY page_id");

while(list($page_id, $title, $active, $layout, $num_sections) = mysql_fetch_row($result))
{
	$temp = new userpage;

	$temp->new_page = 0;
	$temp->page_active = $active;
	$temp->main_title = $title;
	if($layout != NULL) $temp->layout = $layout;
	else $temp->layout = 1;
	$temp->sections = $num_sections;
	
	$result2 = mysql_query("SELECT level, subtitle, text, image, sub_active, text_active, image_active, alt FROM page_content WHERE page_id='$page_id'");

	while(list($level, $subtitle, $text, $image, $sub_active, $text_active, $image_active, $alttag) = mysql_fetch_row($result2))
	{
		$i = $level - 1;
		
		$temp->subtitle[$i] = $subtitle;
		$temp->text[$i] = nl2br(str_replace("content.php?", "mod.php?mod=userpage&amp;", $text));
		if($image && $image != "none") $temp->imagename[$i] = $image;
		$temp->sub_active[$i] = $sub_active;
		$temp->text_active[$i] = $text_active;
		$temp->image_active[$i] = $image_active;
		$temp->alt[$i] = $alttag;
	}

	$data = addslashes(serialize($temp));

	mysql_query("LOCK TABLES mod_userpage_data WRITE");
	mysql_query("INSERT INTO mod_userpage_data VALUES ('$page_id', '$title', '$data')");
	mysql_query("UNLOCK TABLES");

	mysql_query("UPDATE menu SET menu_url='mod.php?mod=userpage' WHERE page_id='$page_id'");
}

mysql_query("ALTER TABLE mod_userpage_data MODIFY id int(5) NOT NULL AUTO_INCREMENT");

//mysql_query("DROP TABLE user_pages");
//mysql_query("DROP TABLE page_content");

/* FIX LINKS IN OTHER CONTENT */
$result = mysql_query("SELECT id, content FROM lblocks");

while(list($temp_id, $temp_content) = mysql_fetch_row($result))
{
	$temp2 = str_replace("content.php?", "mod.php?mod=userpage&amp;", $temp_content);
	mysql_query("UPDATE lblocks SET content='$temp2' WHERE id='$temp_id'");
}

$result = mysql_query("SELECT id, content FROM rblocks");

while(list($temp_id, $temp_content) = mysql_fetch_row($result))
{
	$temp2 = str_replace("content.php?", "mod.php?mod=userpage&amp;", $temp_content);
	mysql_query("UPDATE rblocks SET content='$temp2' WHERE id='$temp_id'");
}

$result = mysql_query("SELECT main_text FROM main_page_content");
list($temp_content) = mysql_fetch_row($result);
$temp2 = str_replace("content.php?", "mod.php?mod=userpage&amp;", $temp_content);
mysql_query("UPDATE main_page_content SET main_text='$temp2'");

$result = mysql_query("SELECT sid, hometext, bodytext FROM stories");

while(list($temp_id, $temp_home, $temp_body) = mysql_fetch_row($result))
{
	$temp1 = str_replace("content.php?", "mod.php?mod=userpage&amp;", $temp_home);
	$temp2 = str_replace("content.php?", "mod.php?mod=userpage&amp;", $temp_body);
	mysql_query("UPDATE stories SET hometext='$temp1', bodytext='$temp2' WHERE sid='$temp_id'");
}

?>
