<?php

$num_sections = 3;
$image_directory = "./mod/userpage/images/";
$max_image_size = "200000";
$allowed_types = "image/jpeg, image/gif, image/pjpeg, image/x-png";

$num_layouts = 6;
$default_layout = 1;
$layout_message1 = "Two-column layout with text and subtitles left justified in the left-hand column. Images are centered in the right-hand column.";
$layout_message2 = "Two-column layout with images centered in the left-hand column. Text and subtitles left justified in the right-hand column.";
$layout_message3 = "Two-column layout with images centered in the left-hand column.  Text and subtitles left justified in the right-hand column. Text without an associated image spans both columns.";
$layout_message4 = "Two-column layout with text and subtitles left justified in the left-hand column. Images are centered in the left-hand column. Text without an associated image spans both columns.";
$layout_message5 = "Single column layout with left justified text. Images alternate from right to left, text fills remaining space. Text without an associated image spans full column.";
$layout_message6 = "Single column layout with left justified text. Images alternate from left to right, text fills remaining space. Text without an associated image spans full column.";

?>

