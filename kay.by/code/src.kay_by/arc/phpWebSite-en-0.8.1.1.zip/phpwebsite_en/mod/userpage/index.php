<?php

/*
 * This is the hub of the userpage module. All operational
 * decisions are made here.
 *
 * @module userpage
 * @package phpWebSite
 * @author Adam Morton, adam@tux.appstate.edu
*/

/* Include class file. Module specific functions are included in it. */
include("./mod/userpage/userpage.php");

/* Include needed core/config files. */
include("config.php");
if(!isset($mainfile)) include("mainfile.php");
include("open_session.php");

session_register("current_data");
session_register("current_id");
session_register("error_type");
session_register("error_section");

if($op != "on_off" && $op != "show_layouts" && $op != "delete_userpage")
include("header.php");

/* BEGIN ADMIN SWITCH */
if($admintest == $security_hash)
switch($op)
{
	case "create_userpage":
	$current_data = new userpage;
	$current_data->edit_page();
	break;
	
	case "save_data":
	if($remove_image)
	{
		$current_data->remove_image($img_id);
		$current_data->edit_page();
	}
	else if($next)
	{
		$error_type = "none";
		$current_data->set_active($sub_active, $text_active, $image_active);
		$current_data->set_title($title);
		$current_data->set_subtitle($subtitle);
		$current_data->set_text($text);
		for($i=0; $i<$current_data->sections; $i++)
		$current_data->set_image($image[$i], $image_name[$i], $image_type[$i], $image_size[$i], $alt[$i], $i, $old_image[$i]);
		$current_data->set_layout($layout);
		$current_data->set_textmode($text_mode);
		$current_data->format_data();

		/* Check for errors */
		if($error_type != 'none')
		{
			$current_data->page_error($error_type);
			$current_data->edit_page();
			break;
		}
		$current_data->previewing();
		$current_data->view_page();
	}
	else
	list_userpages();
	break;
	
	case "show_layouts":
	$current_data->show_layouts();
	break;

	case "save_layout":
	$current_data->set_layout($layout);
	$current_data->edit_page();
	break;

	case "finish":
	if($back) $current_data->edit_page();
	else if($current_data->new_page)
	{
		$current_data->save_page();
		choose_menu($current_id);
	}
	else if($current_data->editing_page)
	{
		$current_data->update_page();
		choose_menu($current_id);
	}
	else $current_data->page_error("refresh");
	break;
	
	case "list_userpages":
	list_userpages();
	break;
	
	case "on_off":
	$result = mysql_query("SELECT data FROM mod_userpage_data WHERE id='$page_id'");
	list($data) = mysql_fetch_row($result);
	$current_data = new userpage;
	$current_data = unserialize($data);
	$current_data->page_active = $switch;
	$data = addslashes(serialize($current_data));
	mysql_query("UPDATE mod_userpage_data SET data='$data' WHERE id='$page_id'");
	mysql_query("UPDATE menu SET menu_active='$switch' WHERE page_id='$page_id'");
	include("header.php");
	list_userpages();
	break;
	
	case "confirm_delete":
	confirm_delete($page_id);
	break;
	
	case "delete_userpage":
	mysql_query("DELETE FROM mod_userpage_data WHERE id='$page_id'");
	mysql_query("DELETE FROM menu WHERE page_id='$page_id'");
	include("header.php");
	list_userpages();
	break;

	case "edit_userpage":
	if($page_id)
	{
		$current_id = $page_id;
		$result = mysql_query("SELECT data FROM mod_userpage_data WHERE id='$current_id'");
		list($data) = mysql_fetch_row($result);
		
		if(!$data)
		{
			$current_data = new userpage;
			$current_data->page_error("not_found", $page_id);
			break;
		}
		
		$current_data = new userpage;
		$current_data = unserialize($data);
		$current_data->editing_page = 1;
		$current_data->edit_page();
	}
	else
	{
		$current_data = new userpage;
		$current_data->page_error("page_id");
	}
	break;
}
/* END ADMIN SWITCH */

/* BEGIN USER SWITCH */
if(!$op)
switch($op)
{
	default:
	if(!$op)
	if($page_id)
	{
		$current_id = $page_id;
		$result = mysql_query("SELECT data FROM mod_userpage_data WHERE id='$current_id'");
		list($data) = mysql_fetch_row($result);
		
		if(!$data)
		{
			$current_data = new userpage;
			$current_data->page_error("not_found", $page_id);
			break;
		}
		
		$current_data = new userpage;
		$current_data = unserialize($data);
		
		if($current_data->is_active())
		{
			if($admintest == $security_hash)
			$current_data->admin_edit();
			$current_data->view_page();
		}
		else
		echo $current_data->page_error("active");
	}
	else
	{
		$current_data = new userpage;
		$current_data->page_error("page_id");
	}
	break;
}

if($op != "show_layouts")
include("footer.php");

?>
