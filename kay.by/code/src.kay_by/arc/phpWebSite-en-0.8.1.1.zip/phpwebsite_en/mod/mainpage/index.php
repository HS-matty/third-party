<?php

/*
 * This is the hub of the mainpage module. All operational
 * decisions are made here.
 *
 * @module mainpage
 * @package phpWebSite
 * @author Adam Morton, adam@tux.appstate.edu
*/

/* Include class file. Module specific functions are included in it. */
include("./mod/mainpage/mainpage.php");
include("./mod/mainpage/mainpage_config.php");

/* Include needed core/config files. */
include("config.php");
if(!isset($mainfile)) include("mainfile.php");
include("open_session.php");

session_register("current_data");
session_register("error_type");

include("header.php");

if($admintest == $security_hash && $op)
switch($op)
{	
	case "edit_mainpage":
	$result = mysql_query("SELECT active, data FROM mod_mainpage_data");
	if($result)
	{
		list($active, $data) = mysql_fetch_row($result);
		$current_data = unserialize($data);
		$current_data->edit_mainpage($active);
	}
	else
	{
		$current_data = new mainpage;
		$current_data->error("database");
	}
	break;
	
	case "save_mainpage":
	if($remove_image)
	{
		$current_data->remove_image();
		$current_data->edit_mainpage($active);
		break;
	}
	$error_type = "none";
	$current_data->set_data($title, $text, $image, $image_name, $image_size, $image_type, $alt, $image_active);
	if($error_type != "none")
	{
		$current_data->error($error_type);
		$current_data->edit_mainpage($active);
	}
	else $current_data->update_data($active);
	break;
}

include("footer.php");

?>
