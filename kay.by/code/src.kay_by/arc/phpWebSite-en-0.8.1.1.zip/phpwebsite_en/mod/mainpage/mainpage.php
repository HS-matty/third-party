<?php

/*
 * This mainpage class has all the functions necessary to
 * create and edit a mainpage instance.
 *
 * @module mainpage
 * @package phpWebSite
 * @author Adam Morton, adam@tux.appstate.edu
*/

class mainpage 
{
	var $title;
	var $text;
	var $image;
	var $alt;
	var $image_active;

function mainpage ()
{
	$this->title = "Welcome to phpWebSite";
	$this->text = "Developed by the Web Technology Group at Appalachian State University, phpWebSite provides a complete web site content management solution.
	All client output is valid XHTML 1.0 and meets the W3C Web Accessibility Initiative requirements.
	</p>\r\n\r\n
	<p> You can administrate this site by going the  <a href=\"admin.php\">Administrative Menu</a>
	and logging on using the following username and password:</p>\r\n\r\n
	<p>Username:  admin<br />\r\n Password:  phpwebsite</p>\r\n\r\n
	<p>Once you are logged in you can change this content to fit your needs
	Remember to please change the administrative password to protect your site.</p>\r\n\r\n
	<p>Thank you!</p>\r\n
	<p> - The phpWebSite Development Team</p>\r\n\r\n";
	$this->image = "wtg.jpg";
	$this->alt = "phpWebSite delivers valid XHTML for client interoperability";
	$this->image_active = 1;
}

function set_data ($title, $text, $image, $image_name, $image_size, $image_type, $alt, $image_active)
{
	global $error_type;
	include("./mod/mainpage/mainpage_config.php");

	$this->title = strip_tags($title, $allowed_tags);
	$this->text = strip_tags($text, $allowed_tags);
	$this->image_active = strip_tags($image_active);
	$this->alt = strip_tags($alt);

	if($image != "none")
	{
		$temp_type = explode(";", $image_type);

		if($image_size > $max_image_size) $error_type = "image_size";
		else if(!(substr_count($allowed_types, $temp_type[0]) > 0)) $error_type = "image_type";
		else if(!$alt) $error_type = "alt";

		if($error_type != "image_size" && $error_type != "image_type")
		{
			$this->image = $image_name;
			if(!copy($image, $image_directory.$image_name))
			{
				$error_type = "image_creation";
				$this->image = "none";
			}
		}
	}

	if($this->image != "none" && $this->alt == "") $error_type = "alt";
}

function view_mainpage ()
{
	include("./mod/mainpage/mainpage_config.php");

	$main_title = stripslashes($this->title);
	$main_text = stripslashes($this->text);
	$main_image = $this->image;
	$main_alt = $this->alt;
	
	if (!strstr ($main_title, '<p') && !strstr ($main_title, '<table') && !strstr ($main_title, '<br'))
        $main_title = nl2br($main_title);

	if (!strstr ($main_text, '<p') && !strstr ($main_text, '<table') && !strstr ($main_text, '<br'))
        $main_text = str_replace ("\n" , "<br />", $main_text). "<br />";

	if($this->image_active)
	{
		$size = GetImageSize ("$image_directory$main_image");
		/* The image is wide, therefore it will be placed above the information. */
		if ($size[0] >250)
		$content = "<center><img src=\"$image_directory$main_image\" border=\"0\" alt=\"$main_alt\" /></center><br /><br />\n";
		else
		$content = "<img src=\"$image_directory$main_image\" border=\"0\" alt=\"$main_alt\" align=\"right\" hspace=\"5\" vspace=\"5\" />\n";
	}
	
	$content .= "$main_text<br />";

	thememainbox($main_title, $content);
}

function edit_mainpage ($active)
{
	include("./mod/mainpage/mainpage_config.php");

	$main_title = stripslashes($this->title);
	$main_text = stripslashes($this->text);
	$main_image = stripslashes($this->image);
	$main_alt = stripslashes($this->alt);
	
	$title = "Edit Main Page";
	$content = "<form action=\"mod.php\" method=\"post\" enctype=\"multipart/form-data\">\n";

	if($active) $content .= "<input type=\"checkbox\" name=\"active\" value=\"1\" checked=\"checked\" />\n";
	else $content .= "<input type=\"checkbox\" name=\"active\" value=\"1\" />\n";

	$content .= "Make this content active?<br /><br />
	Main Title:<br />
	<input type=\"text\" name=\"title\" value=\"$main_title\" maxlength=\"200\" size=\"40\" /><br />
        Main Text: <br />
	<textarea name=\"text\" cols=\"50\" rows=\"15\" wrap=\"virtual\">$main_text</textarea><br />
	Main Image: <br />\n";

	if($main_image != "none")
	{
		$content .= "<img src=\"$image_directory$main_image\" alt=\"$main_alt\" /><br />
		<input type=\"submit\" name=\"remove_image\" value=\"Remove Image\" /><br />
        	<input type=\"file\" name=\"image\" maxlength=\"60\" size=\"25\" /><br />
        	Short Image Description:<br />
        	<input type=\"text\" name=\"alt\" maxlength=\"60\" size=\"33\" value=\"$main_alt\" />\n";
	}
	else
	{
		$content .= "<input type=\"file\" name=\"image\" maxlength=\"60\" size=\"25\" /><br />
        	Short Image Description:<br />
        	<input type=\"text\" name=\"alt\" maxlength=\"60\" size=\"33\" value=\"$main_alt\" />\n";
	}

	if($this->image_active) $content .= "<br /><input type=\"checkbox\" name=\"image_active\" value=\"1\" checked=\"checked\" />\n";
	else $content .= "<br /><input type=\"checkbox\" name=\"image_active\" value=\"1\" />\n";

	$content .= "Make this image active?<br /><br />
	<input type=\"hidden\" name=\"mod\" value=\"mainpage\" />
	<input type=\"hidden\" name=\"op\" value=\"save_mainpage\" />
	<input type=\"submit\" value=\"Submit\" />
	</form>\n";

	thememainbox($title, $content);
}

function remove_image ()
{
	$this->image = "none";
	$this->alt = "";
	$this->image_active = 0;
	
	$title = "Image Removed";
	$content = "You must save your data via the SUBMIT button for the changes to take effect!";
	thememainbox($title, $content);
}

function update_data ($active)
{
	$data = addslashes(serialize($this));
	$result = mysql_query("UPDATE mod_mainpage_data SET active='$active', data='$data'");
	
	if($result)
	{
		$this->back_to_admin();
		$title = "Main Page Updated!";
		$content = "<b>Your page has successfully been updated in the database!</b><br />\n";
		thememainbox($title, $content);
	}
	else
	{
		$this->error("database");
		$this->edit_mainpage($active);
	}
}

/* Simply prints a link back to the main phpwebsite admin menu */
function back_to_admin ()
{
	echo "<center><b><a href=\"./admin.php\">Admin Menu</a></b></center><br />";
}

function error ($type)
{
	include("./mod/mainpage/mainpage_config.php");
	$title = "<span class=\"onebiggerred\">ERROR!</span>";
	
	switch($type)
	{
		case "database":
		$content .= "<b>There was a database error when attempting to update your page!</b><br /><br />
		Please try to save it again in a moment.<br />If the problem persists, contact your system administrator.\n";
		break;

		case "image_size":
		$content .= "The file you selected for your image is too large!<br />
		The largest file size allowed on this server is $max_image_size bytes.<br />Please select a smaller image for uploading now.";
		break;

		case "image_type":
		$content .= "The file you selected for your image is not a valid image type!<br />
            	The valid types are:<br /><br />$allowed_types<br /><br />Please select a new file for uploading now.\n";
		break;

		case "alt":
		$content .= "You must supply a small description for images (around 15-20 characters).\n";
		break;
		
		case "image_creation":
		$content = "A problem occured when attempting to upload your image.<br />If the problem persists, contact your system administrator.\n";
		break;
	}
	$content .= "<br /><br />";
	thememainbox($title, $content);
}

}

?>
