<?php

$allowed_tags = "<a><b><i><table><td><tr><hr><br><p><ul><li><form><input>";
$image_directory = "./mod/mainpage/images/";
$max_image_size = "20000";
$allowed_types = "image/jpeg, image/gif, image/pjpeg, image/x-png";

?>
