<?php

class mainpage 
{
	var $title;
	var $text;
	var $image;
	var $alt;
	var $image_active;
	
function mainpage ()
{
	$this->title = "Welcome to phpWebSite";
	$this->text = "Developed by the Web Technology Group at Appalachian State University, phpWebSite provides a complete web site content management solution.
	All client output is valid XHTML 1.0 and meets the W3C Web Accessibility Initiative requirements.
	</p>\r\n\r\n
	<p> You can administrate this site by going the  <a href=\"admin.php\">Administrative Menu</a>
	and logging on using the following username and password:</p>\r\n\r\n
	<p>Username:  admin<br />\r\n Password:  phpwebsite</p>\r\n\r\n
	<p>Once you are logged in you can change this content to fit your needs
	Remember to please change the administrative password to protect your site.</p>\r\n\r\n
	<p>Thank you!</p>\r\n
	<p> - The phpWebSite Development Team</p>\r\n\r\n";
	$this->image = "wtg.jpg";
	$this->alt = "phpWebSite delivers valid XHTML for client interoperability";
	$this->image_active = 1;
}
}

mysql_query("CREATE TABLE mod_mainpage_data (
		id int(1) AUTO_INCREMENT PRIMARY KEY,
		active int(1),
		data longtext)");

$result = mysql_query("SELECT main_title, main_text, main_image, main_image_active, alt, active FROM main_page_content");

if($result)
{
	list($main_title, $main_text, $main_image, $main_image_active, $alt, $active) = mysql_fetch_row($result);

	$temp = new mainpage;
	$temp->title = $main_title;
	$temp->text = $main_text;
	$temp->image = $main_image;
	$temp->alt = $main_alt;
	$temp->image_active = $main_image_active;

	$data = addslashes(serialize($temp));
}
else
{
	$temp = new mainpage;
	$data = addslashes(serialize($temp));
	$active = 1;
}

mysql_query("INSERT INTO mod_mainpage_data VALUES ('', '$active', '$data')");

//mysql_query("DROP TABLE main_page_content");

?>
