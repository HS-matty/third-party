<?php

include("./mod/mainpage/mainpage.php");

$result = mysql_query("SELECT active, data FROM mod_mainpage_data");
if($result)
{
	list($active, $data) = mysql_fetch_row($result);
	if($active)
	{
		$current_data = unserialize($data);
		$current_data->view_mainpage();
	}
}

?>
