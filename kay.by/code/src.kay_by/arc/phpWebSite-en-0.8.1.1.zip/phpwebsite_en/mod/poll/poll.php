<?php

/*********************************************************/
/* Poll/Surveys Class and Functions                      */
/*							 */
/* @module poll						 */
/* @package phpWebSite					 */
/* @author Ryan Cowan, ryan@tux.appstate.edu             */
/*							 */ 
/*********************************************************/

session_register("current_poll");
session_register("mode");
session_register("thold");
session_register("order");

class poll
{
	var $title;
	var $num_options;
	var $options;
	var $new_poll;
	var $option_votes;
	var $option_count;
	var $total_votes;
	var $ip_array;

/*Initializes the variables.*/
function poll()
{
	include("./mod/poll/poll_config.php");

	$this->title = "";
	$this->num_options = $max_options;
	$this->new_poll = 1;
	$this->option_count = 0;
	$this->total_votes = 0;
	$this->ip_array[0] = "0.0.0.0";
}

/*Will output a create poll form if the poll is new or a edit poll form*/
/*if the poll is already present.                                      */
function poll_form($pid)
{
	global $current_poll;
	$current_poll = $this;

	$result = mysql_query("SELECT flag FROM mod_poll_flag");
	list($active) = mysql_fetch_row($result);
	
	if($active)
	{
		echo "<br /><table border=\"1\" align=\"left\"><tr><td class=\"active\">
		<a href = \"mod.php?mod=poll&amp;op=deactivate_poll&amp;pid=$pid\">Current Poll is On</a></td>
		</tr></table><br /><br />";
	}
	else
	{
		echo "<br /><table border=\"1\" align=\"left\"><tr><td class=\"inactive\">
		<a href = \"mod.php?mod=poll&amp;op=activate_poll&amp;pid=$pid\">Current Poll is Off</a></td>
		</tr></table><br /><br />";
	}

	if($pid!=0)
	{
		$result = mysql_query("SELECT data FROM mod_poll_data WHERE pid ='$pid'");
		list($data) = mysql_fetch_row($result);
		stripslashes($data);
		$this = unserialize($data);
		$box_title = "
		Edit Poll
		| <a href=\"mod.php?mod=poll&amp;op=create_poll\">Create Poll</a>
		| <a href=\"mod.php?mod=poll&amp;op=results&amp;pid=$pid\">View Results</a>
		| <a href=\"mod.php?mod=poll&amp;op=delete_poll&amp;title=$this->title&amp;pid=$pid&amp;ok=0\">
		Delete Poll</a>";

	}
	else
		$box_title = "Create Poll";

	$box_stuff .= "
		<form action=\"mod.php\" method=\"get\" enctype=\"multipart/form-data\" >
		<p>Poll Title:
		 <input type=\"text\" name=\"title\" value=\"".stripslashes($this->title)."\" size=\"50\" maxlength=\"150\" /></p>
		<p>Please enter each available option into a single field.</p>";

	for($i = 0; $i < $this->num_options; $i++)
	{
		$j = $i+1;
		$opt = $this->options[$i];
		$box_stuff .= "Option $j:";
		$box_stuff .= "<input type=\"text\" name=\"option[$i]\" value=\"".stripslashes($opt)."\" size=\"50\" maxlength=\"150\" /><br />";
	}
	
	if($this->poll_check_active($pid))
		$selected = "checked=\"checked\"";
	else
		$selected = "";
	
	$box_stuff .="
	<center>Make Current Poll: <input type=\"checkbox\" name=\"active\" value=\"1\" $selected />&nbsp;
       	<input type=\"hidden\" name=\"pid\" value=\"$pid\" />
	<input type=\"hidden\" name=\"mod\" value=\"poll\" />
	<input type=\"hidden\" name=\"op\" value=\"save\" />
	<input type=\"submit\" value=\"Save\" /></form></center>";

	themesidebox($box_title, $box_stuff);

	//POLL ADMINISTRATION STARTS HERE

	$box_title = "Poll/Survey Administration";
	
	$box_stuff = "<center><table border=\"0\" cellspacing=\"1\" cellpadding=\"1\" width=\"99%\">";	
	$row = mysql_num_rows(mysql_query("SELECT pid FROM mod_poll_data"));
	if ($row==0)
	{
		$box_stuff .= "</table><center>
		<span class = \"onebiggerred\" >No Polls Saved!</span><br /></center>";
	}
	else
	{	
		$box_stuff .="<tr>
		<th align=\"center\" ><b>Current Poll</b></th>
		<th align=\"center\" ><b>Title</b></th>
		<th></th>
		</tr>";
		
		$result= mysql_query("SELECT * FROM mod_poll_data");
		$box_stuff .= "<form action=\"mod.php\" method=\"get\" enctype=\"multipart/form-data\" >";
		
		$result_flag = mysql_query("SELECT pid FROM mod_poll_flag");
		list($flag) = mysql_fetch_row($result_flag);

		while (list($pid, $data)=mysql_fetch_row($result))
		{
			stripslashes($data);
			$temp = unserialize($data);

			if($pid==$flag)
				$selected = "checked=\"checked\"";
			else
				$selected = "";

			$box_stuff .= "
			<tr>
			<td class = \"type5\"align=\"center\">
			<input type=\"radio\" name = \"pid\" value = \"$pid\" $selected /></td>
			<td class = \"type5\" align=\"center\">
			<a href = \"mod.php?mod=poll&amp;op=results&amp;pid=$pid\">".stripslashes($temp->title)."</a></td>
			<td class = \"type5\" align=\"right\">
			<a href = \"mod.php?mod=poll&amp;op=edit_poll&amp;pid=$pid\">Edit</a> |
			<a href = \"mod.php?mod=poll&amp;op=delete_poll&amp;pid=$pid&amp;ok=0\">
			Delete</a>
			</td></tr>
			";
		}

		$box_stuff .= "<tr>
		<td colspan=\"2\"></td>
		<td class = \"type5\" align = \"right\"><br />
		<a href=\"mod.php?mod=poll&amp;op=delete_all&amp;ok=0\">Purge</a></td>
		</tr></table><br />
		<input type=\"hidden\" name=\"mod\" value=\"poll\" />
		<input type=\"hidden\" name=\"op\" value=\"set_poll_active\" />
		<input type=\"submit\" value=\"Make Current Poll\" /></form></center>";
	}
	themesidebox($box_title, $box_stuff);
}

function poll_check_active($pid)
{
	$result = mysql_query("SELECT pid FROM mod_poll_flag");
	list($temp) = mysql_fetch_row($result);
	if($pid==$temp)
		return 1;
	else
		return 0;	
}

function poll_set_active($pid)
{
	mysql_query("UPDATE mod_poll_flag SET pid = $pid");
}

function poll_activate()
{
	$polls = mysql_query("SELECT * FROM mod_poll_data");
	$rows = mysql_num_rows($polls);
	if($rows!=0)
		mysql_query("UPDATE mod_poll_flag SET flag = '1'");
}

function poll_deactivate()
{
	mysql_query("UPDATE mod_poll_flag SET flag = '0'");
}

function poll_set_title($title)
{
	$this->title = addslashes(htmlspecialchars(magic_check($title)));
}

function poll_set_option($opt)
{
	$size = sizeof($opt);
	
	for ($i=0; $i <= $size; $i++)
	{
		//Makes sure that an option was not skipped.  If it is blank
		//it will simply moves the the next option it finds up.
		if($opt[$i]=="")
		{
			$j=$i;
			while ($opt[$j]=="" && $j<=$size)
				$j++; 
			$this->options[$i] = addslashes(htmlspecialchars(magic_check($opt[$j])));
			$opt[$j]="";
		}
		else
		  $this->options[$i] = addslashes(htmlspecialchars(magic_check($opt[$i])));
	}
	
	$i = 1;
	while($this->options[$i] != "")
	{
		$this->option_votes[$i] = "0";
		$i++;	
	}
	$this->option_count = $i;
}

function poll_update($pid)
{
	$poll = serialize($this);
	$data = addslashes($poll);
	mysql_query("lock table mod_poll_data write");
	mysql_query("UPDATE mod_poll_data SET data = '$data' WHERE pid = $pid");
	mysql_query("unlock table");
}
	
function poll_save()
{
	$poll = serialize($this);
	$data = addslashes($poll);
	mysql_query("lock table mod_poll_data write");
	mysql_query("INSERT INTO mod_poll_data (data) VALUES ('$data')");
	mysql_query("unlock table");
}

function poll_delete_all($ok)
{
	if($ok)
	{
		mysql_query("DELETE FROM mod_poll_comments");
		mysql_query("DELETE FROM mod_poll_data");
		mysql_query("UPDATE mod_poll_flag SET pid = '0'");
		$poll = new poll;
		$poll->poll_deactivate();
		new_poll();
	}
	else
	{
		$box_title = "<center>Delete All Polls</center>";
		$box_stuff = "
		<center>
		<h3>WARNING</h3>
		<p>You are about to delete all existing poll data and turn off polls!!!</p>
		<p>Are you sure?</p><p>
		 <a href=\"mod.php?mod=poll&amp;op=delete_all&amp;ok=1\">YES</a>
		|<a href=\"mod.php?mod=poll&amp;op=create_poll\">NO</a></p>
		</center>
		";

		themesidebox($box_title, $box_stuff);
	}

}

function poll_delete($pid, $ok)
{
	if($ok)
	{
		mysql_query("DELETE FROM mod_poll_comments WHERE pid = '$pid'");
		mysql_query("DELETE FROM mod_poll_data WHERE pid = '$pid'");
		
		$poll = new poll;
		$active=$poll->poll_check_active($pid);
		if($active)
		{
			//The polls will be turned off if the poll to be deleted is active.
			$poll->poll_deactivate();
			$poll->poll_set_active("0");
		}
		new_poll();
	}
	else
	{
		$box_title = "<center>Remove an existing poll</center>";
		$box_stuff = "<center>
		<h3>WARNING</h3>
		<p>You are about to delete this poll.</p>
		<p>Are you sure?</p><p>
		 <a href=\"mod.php?mod=poll&amp;op=delete_poll&amp;pid=$pid&amp;ok=1\">YES</a>
		|<a href=\"mod.php?mod=poll&amp;op=delete_poll&amp;pid=$pid&amp;ok=2\">NO</a></p>
		</center>
		";

		themesidebox($box_title, $box_stuff);
		echo "<center>";
		poll_booth($pid);
		echo "</center>";
	}
}

}
?>
