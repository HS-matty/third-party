<?php

session_register("mode");
session_register("thold");
session_register("order");

function modone() 
{
	include("./mod/poll/poll_config.php");
	include("config.php");
	global $admintest;

	if((($admintest==$security_hash) && ($poll_moderate == 1)) || (($poll_moderate == 2) && $user)) 
		echo "<form action=\"mod.php\" method=\"get\" enctype=\"multipart/form-data\" >";
}

function modtwo() 
{
	include("./mod/poll/poll_config.php");
	include("config.php");

	global $admintest;

	if((($admintest==$security_hash) && ($poll_moderate == 1)) || (($poll_moderate == 2) && $user)) 
	{
		echo " | <select name=\"reason\">";
		for($i=0; $i<sizeof($poll_reasons); $i++) 
		{
			echo "<option value=\"$i\">$poll_reasons[$i]</option>\n";
		}
		echo " | </select>";
	}
}

function modthree($cid, $pid, $all) 
{
	include("./mod/poll/poll_config.php");
	include("config.php");

	global $admintest;

	if((($admintest==$security_hash) && ($poll_moderate == 1)) || (($poll_moderate==2) && $user)) 
		echo "<input type=\"hidden\" name=\"mod\" value=\"poll\" />
		<input type=\"hidden\" name=\"all\" value=\"$all\" />
		<input type=\"hidden\" name=\"pid\" value=\"$pid\" />
		<input type=\"hidden\" name=\"cid\" value=\"$cid\" />
		<input type=\"hidden\" name=\"op\" value=\"moderate\" />
		<input type=\"submit\" value=\"Moderate\" />
		</form>";
}

function reply_preview($rid, $pid, $subject, $comment, $postanon) 
{
	include("config.php");	
	include("./mod/poll/poll_config.php");

	global $user, $userinfo, $EditedMessage, $cookie, $datetime;
	
	if((isset($user)) && ($postanon!="on")) 
	{
		getusrinfo($user);
		$name = $userinfo[uname];
		$email = $userinfo[femail];
		$url = $userinfo[url];
		$score = 1;
	} 
	else 
	{
		$name = $poll_anonymous; 
		$email = ""; 
		$url = "";
		$score = 0;
	}	 
	
	$time = getdate();
	$date = $time['year']."-".$time['mon']."-".$time['mday']." ". $time['hours'].":".$time['minutes'].":".$time['seconds'];
	formatTimestamp($date);
	
	if ($subject == "") 
		$title = "(No Subject)<br />"; 
	else 
		$title = "$subject";	

	$box_title = "<span class=\"type4bigger\" style=\"background-color : #e0e0e0;\">Comment for $title</span>";

	$box_content = "$title";

	$box_content .= " | (Score: $score)";
			
	if($email!="")
		$box_content .= "<br />by: <a href=\"mailto:$email\">$name</a> ($email) on: $datetime"; 
	else
		$box_content .= "<br />by: $name on: $datetime";

	if ($name != $poll_anonymous) 
		$box_content .= "<br />(<a href=\"user.php?op=userinfo&amp;uname=$name\">User Info</a>) ";
	
	if (eregi("http://",$url)) 
		$box_content .= "<a href=\"$url\" target=\"window\">$url</a><br /> "; 
	else
		$box_content .= "<br />";

	if($posttype=="exttrans") 
		$box_content .= str_replace("\n", "<br />", (htmlspecialchars($comment)));
	elseif($posttype=="plaintext") 
		$box_content .= str_replace("\n", "<br />",$comment);
	else
 		$box_content .= $comment;
	
	themesidebox($box_title, $box_content);

	$box_title = "<span class=\"type4bigger\" style=\"background-color : #e0e0e0;\">Comment for $title</span>";

	$box_content = "<form action=\"mod.php\" method=\"post\">";
	$box_content .= "<br /><b>Your Name: </b>";

	if ((isset($user)) && ($postanon=="off")) 
	{
		cookiedecode($user);
		$box_content .= "<a href=\"user.php\">$cookie[1]</a> 
		[ <a href=\"user.php?op=logout\">Logout</a> ]<br />";
	} 
	 	
	if ($name != $poll_anonymous) 
		$box_content .= "<br />(<a href=\"user.php?op=userinfo&amp;uname=$name\">User Info</a>)&nbsp;"; 
	else
		$box_content .= "$poll_anonymous [ <a href=\"user.php\">Login</a> ]<br />"; 

	$box_content .= "
	<b>Subject:</b><br />
	<input type=\"text\" name=\"subject\" size=\"50\" maxlength=\"60\" value=\"$subject\" /><br />
	<br /><b>Comment:</b><br />
	<textarea cols=\"50\" rows=\"10\" name=\"comment\" wrap=\"virtual\">$comment</textarea><br />
	Allowed HTML:<br />";

	while (list($key) = each($allowhtml))
		$box_content .= " &lt;".$key."&gt;";

	$box_content .= "<br />";
	
	if($postanon)
		$box_content .= "<input type=\"checkbox\" name=\"postanon\" checked=\"checked\" />
		Post Anonymously<br />"; 
	else
		$box_content .= "<input type=\"checkbox\" name=\"postanon\" />Post Anonymously<br />";

	$box_content .= "
	<input type=\"hidden\" name=\"mod\" value=\"poll\" />
	<input type=\"hidden\" name=\"pid\" value=\"$pid\" />
	<input type=\"hidden\" name=\"rid\" value=\"$rid\" />
	<input type=\"submit\" name=\"op\" value=\"Preview\" />
	<input type=\"submit\" name=\"op\" value=\"Ok!\" /> 
	<select name=\"posttype\">
		<option value=\"exttrans\">Extrans (html tags to text)</option>
		<option value=\"html\">HTML Formatted</option>
		<option value=\"plaintext\" selected=\"selected\">Plain Old Text</option>
	</select>
	</form><br />";
	themesidebox($box_title, $box_content);
}

function reply_form($cid, $rid, $pid)
{
	include("config.php");
	include("./mod/poll/poll_config.php");

	global $user, $cookie, $datetime, $security_hash, $admintest;
	cookiedecode($user);
		
	if($cid!=0)
	{
		$result = mysql_query("SELECT subject FROM mod_poll_comments WHERE cid='$cid'");
		list($subject) = mysql_fetch_row($result);
		stripslashes($subject);
		if(!eregi("[RE:]", $subject))
		{
			$temp = "RE: ";
			$temp .= $subject;
			$subject = $temp;
		}
	}
	else
		$subject = "";	
	
	if ($subject=="")
		$title = "POLL";
	else
		$title = $subject;

	$box_title = "<span class=\"type4bigger\" style=\"background-color : #e0e0e0;\">Comment for $title</span>";

	$box_content = "<form action=\"mod.php\" method=\"post\">";
	$box_content .= "<br /><b>Your Name: </b>";
	if (isset($user)) 
	{
		$box_content .= "<a href=\"user.php\">$cookie[1]</a> 
		[ <a href=\"user.php?op=logout\">Logout</a> ]<br />";
	} 
	else 
		 $box_content .= "$poll_anonymous [ <a href=\"user.php\">Login</a> ]<br />"; 

	$box_content .= "
	<b>Subject:</b><br />
	<input type=\"text\" name=\"subject\" size=\"50\" maxlength=\"60\" value=\"$subject\" /><br />
	<br /><b>Comment:</b><br />
	<textarea cols=\"50\" rows=\"10\" name=\"comment\" wrap=\"virtual\"></textarea><br />
	Allowed HTML:<br />";

	while (list($key) = each($allowhtml))
		$box_content .= " &lt;".$key."&gt;";

	$box_content .= "<br />";
	
	
	
	$box_content .= "<input type=\"checkbox\" name=\"postanon\" />Post Anonymously<br />";
	$box_content .= "
	<input type=\"hidden\" name=\"mod\" value=\"poll\" />
	<input type=\"hidden\" name=\"pid\" value=\"$pid\" />
	<input type=\"hidden\" name=\"rid\" value=\"$cid\" />
	<input type=\"submit\" name=\"op\" value=\"Preview\" />
	<input type=\"submit\" name=\"op\" value=\"Ok!\" /> 
	<select name=\"posttype\">
		<option value=\"exttrans\">Extrans (html tags to text)</option>
		<option value=\"html\">HTML Formatted</option>
		<option value=\"plaintext\" selected=\"selected\">Plain Old Text</option>
	</select>
	</form><br />";
	themesidebox($box_title, $box_content);
}

function display_comments($cid, $pid) 
{
	include("config.php");
	include("./mod/poll/poll_config.php");
	
	global $mode, $thold, $order, $user, $userinfo;
	echo $mode;	
	getusrinfo($user);
	//Sets the default values.
	if(!isset($mode))
	{
		if(isset($user))			     		
			$mode = $userinfo[umode];
		else
			$mode=$default_mode;
	}
	
	if(!isset($order))
	{
		if(isset($user))	   
			$order = $userinfo[uorder];
		else
			$order=$default_order;
	}

	if(!isset($thold))
	{
		if(isset($user)) 
			$thold = $userinfo[thold];
		else
			$thold=$default_thold;
	}

	echo "
	<table width=\"100%\">
		<tr>
			<td class=\"type4\" style=\"background-color : #e0e0e0;\"><center>
			The comments are owned by the poster. We are not responsible for its content.</center>
			</td>
		</tr>
	</table>";
	
	$result = mysql_query("SELECT * FROM mod_poll_comments WHERE pid='$pid'");

	if(mysql_num_rows($result)==0)
		echo "<span class=\"onebiggerred\"><center>
		<br />No comments yet! Be the first!<br /><br /></span>
		<a href = \"mod.php?mod=poll&amp;op=reply&amp;pid=$pid&amp;cid=0&amp;rid=0\">
		Reply To Poll</a><br /><br /></center>";
	else
	{
		echo "	<center>
			<form action=\"mod.php\" method=\"get\" enctype=\"multipart/form-data\" >
			Threshold:&nbsp;<select name=\"new_thold\">";
			for ($i=-1; $i<=5; $i++)
			{
				echo "<option value=\"$i\"";
				if($thold==$i)
					echo "selected=\"selected\"";
				echo ">$i</option>";
			}
			echo "</select>";

			echo "&nbsp;<select name=\"new_mode\">
			<option value=\"nocomments\"";
			if($mode==nocomment)
				echo "selected=\"selected\"";
			echo ">No Comments</option>
			<option value=\"nested\"";
			if($mode==nested)
				echo "selected=\"selected\"";
			echo ">Nested</option>
			<option value=\"threaded\"";
			if($mode==threaded)
				echo "selected=\"selected\"";
			echo ">Threaded</option>
			<option value=\"flat\" ";
			if($mode==flat)
				echo "selected=\"selected\"";
			echo ">Flat</option>
			</select>";

			echo "&nbsp;
			<select name=\"new_order\">
			<option value=\"4\" ";
			if($order==4)
				echo "selected=\"selected\"";
			echo ">Oldest First</option>	
			<option value=\"1\" ";
			if($order==1)
				echo "selected=\"selected\"";
			echo ">Newest First</option>	
			<option value=\"3\" ";
			if($order==3)
				echo "selected=\"selected\"";
			echo ">Lowest Score First</option>	
			<option value=\"2\" ";
			if($order==2)
				echo "selected=\"selected\"";
			echo ">Highest Score First</option>	
			</select>	   
		
			<input type=\"hidden\" name=\"mod\" value=\"poll\" />
			<input type=\"hidden\" name=\"pid\" value=\"$pid\" />
			<input type=\"hidden\" name=\"op\" value=\"results\" />
			<br /><input type=\"submit\" value=\"Refresh\" />
			</form>";

		echo "<hr size=\"1\" width=\"50%\" />";
		
		echo  "<a href = \"mod.php?mod=poll&amp;op=reply&amp;pid=$pid&amp;cid=0&amp;rid=0\">
		Reply To Poll</a><br /><br /></center>";
		
		if($mode!="nocomments")
		{
			echo "<table width=\"100%\"><tr><td>";
			DisplayTopic($cid, $pid);
			echo "</td></tr></table>";
		}
	}	
}

function DisplayTopic ($tcid, $pid) 
{
	include("config.php");
	include("./mod/poll/poll_config.php");

	global $admintest, $mode, $order, $thold;
	
	if($tcid==0)
		$q = "SELECT cid, rid, date, name, email, url, host_name, subject, comment, score, reason 
		FROM mod_poll_comments WHERE rid=0 AND pid='$pid'";
	else
		$q = "SELECT cid, rid, date, name, email, url, host_name, subject, comment, score, reason 
		FROM mod_poll_comments WHERE cid='$tcid' AND pid='$pid'";

	if($order==1) 
		$q .= " order by cid DESC";
	if($order==2) 
		$q .= " order by score DESC";
	if($order==3) 
		$q .= " order by score ASC";
	if($order==4) 
		$q .= " order by cid ASC";

	$data = mysql_query("$q");
	while(list($cid, $rid, $date, $name, $email, $url, $host_name, $subject, $comment, $score, $reason) = 
		mysql_fetch_row($data))
	{
		if($score>=$thold)
		{	
			modone();
			if ($name == "") 
				$name = $poll_anonymous; 
		
			if ($subject == "") 
				$subject = "(No Subject)"; 

			echo"
			<table>
			<tr>
				<td class=\"type4\" style=\"background-color : #e0e0e0;\">";

			$datetime = formatTimestamp($date);
			stripslashes($subject);
			cookiedecode($user);
			if ($email) 
			{
				echo "$subject ";
				modtwo();
				if(!$cookie[7]) 
				{
					echo "(Score: $score";
					if($reason>0)
 						echo ", $poll_reasons[$reason]";
					echo ")";
				}
				echo "<br />by: <a href=\"mailto:$email\">$name</a> ($email) on: $datetime"; 
			} 
			else 
			{
				echo "$subject ";
				modtwo();
				if(!$cookie[7]) 
				{
					echo "(Score: $score";
					if($reason>0) echo ", $poll_reasons[$reason]";
					echo ")";
				}
				echo "<br />by: $name on: $datetime";
			}			
		
    			// If you are admin you can see the Poster IP address (you have this right, no?)
		
			if ($name != $poll_anonymous) 
				echo "<br />(<a href=\"user.php?op=userinfo&amp;uname=$name\">User Info</a>) ";

			if (eregi("http://",$url)) { echo "<a href=\"$url\" target=\"window\">$url</a> "; }
			
			if($admintest==$security_hash) 
			{
			    $result= mysql_query("select host_name from mod_poll_comments where cid='$cid'");
			    list($host_name) = mysql_fetch_row($result);
			    echo "<br />(IP: $host_name)";
			}
			
			echo "
			</td></tr>
			<tr><td class=\"type3\">";
			stripslashes($comment);
			if(($cookie[10]) && (strlen($comment) > $cookie[10])) 
			{
				echo substr("$comment", 0, $cookie[10])."<br />
				<a href=\"mod.php?mod=poll&amp;op=large_comment&amp;cid=$cid&amp;pid=$pid\">
				Read the rest of this comment...</a>";
			}	
			elseif(strlen($comment) > $poll_commentlimit)
			{
				echo substr("$comment", 0, $poll_commentlimit)."<br />
				<a href=\"mod.php?mod=poll&amp;op=large_comment&amp;cid=$cid&amp;pid=$pid\">
				Read the rest of this comment...</a>";
			}
			else 
				echo $comment;
	
			echo "
			</td></tr><tr><td>
			<br />[	
			<a href =\"mod.php?mod=poll&amp;op=reply&amp;cid=$cid&amp;rid=0&amp;pid=$pid\">
			Reply</a>]";
		
			if(($tcid!=0) && ($mode=="threaded"))
				if($rid!=0)
					echo " | <a href=\"mod.php?mod=poll&amp;op=results&amp;cid=$rid&amp;pid=$pid\">
					Parent</a> ]";
				else
					echo " | <a href=\"mod.php?mod=poll&amp;op=results&amp;cid=$rid&amp;pid=$pid\">
					Top Level</a> ]";

			if($admintest==$security_hash) 
				echo " | <a href=\"mod.php?mod=poll&amp;op=delete_comment&amp;cid=$cid&amp;pid=$pid&amp;ok=0\">
				Delete</a> ]
				<br /><br />";
			else 	
				echo " ]<br /><br />";
			
			modthree($cid, $pid, 0);	
			
			echo "</td></tr></table>";
			
		}

		DisplayKids($cid, $pid);							
	}
		echo  "<center><br /><a href = \"mod.php?mod=poll&amp;op=reply&amp;pid=$pid&amp;cid=0&amp;rid=0\">
		Reply To Poll</a><br /><br /></center></td></tr></table>";
}

function admin_hip($cid)
{
	//Had to be added because the admin test was crashing the recursive call in DisplayKids.
	include("config.php");
	global $admintest;
	
	if($admintest==$security_hash)
	{
    		$result= mysql_query("select host_name from mod_poll_comments where cid='$cid'");
    		list($host_name) = mysql_fetch_row($result);
    		echo "<br />(IP: $host_name)";
	}
}

function DisplayKids ($cid, $pid) 
{
	include("config.php");
	include("./mod/poll/poll_config.php");

	global $mode, $order, $thold;

	cookiedecode($user);
	$q = "SELECT cid, rid, date, name, email, url, host_name, subject, comment, score, reason 
	FROM mod_poll_comments WHERE rid='$cid' and pid='$pid'";
	
	if($order==1) 
		$q .= " order by cid DESC";
	if($order==2) 
		$q .= " order by score DESC";
	if($order==3) 
		$q .= " order by score ASC";
	if($order==4) 
		$q .= " order by cid ASC";

	
	$result = mysql_query("$q");
	while(list($cid, $rid, $date, $name, $email, $url, $host_name, $subject, $comment, $score, $reason)
		= mysql_fetch_row($result))
	{	
		if(($mode=="nested") || ($mode=="flat"))
		{
			if($score>=$thold)
			{	
			modone();
			if (!eregi("[a-z0-9]", $name))
			$name = $poll_anonymous;
			if (!eregi("[a-z0-9]", $subject)) 
				$subject = "(No Subject)";
	
			if($mode=="nested")
				echo "<blockquote>";

			echo "
			<table><tr><td class=\"type4\" style=\"background-color : #e0e0e0;\">";

			$datetime = formatTimestamp($date);
			stripslashes($subject);
			if ($email) 
			{
				echo "$subject";
				modtwo();
				if(!$cookie[7]) 
				{
					echo "(Score: $score";
					if($reason>0) 
						echo ", $reasons[$reason]";
					echo ")";
					echo "<br />by: <a href=\"mailto:$email\">$name</a> ($email) on: $datetime";
				}
 			} 
			else 
			{
				echo "$subject ";
				modtwo();
				if(!$cookie[7]) 
				{
					echo "(Score: $score";
					if($reason>0) 
						echo ", $reasons[$reason]";
					echo ")";
				}
				echo "<br /> by: $name on: $datetime";
			}			
	
			if ($name != $poll_anonymous) 
				echo "<br />(<a href=\"user.php?op=userinfo&amp;uname=$name\">User Info</a>) ";
			if (eregi("http://",$url)) 
				echo "<a href=\"$url\" target=\"window\">$url</a> "; 
		
			admin_hip($cid);

			echo "</td></tr><tr><td class=\"type3\">";
			stripslashes($comment);
			if(($cookie[10]) && (strlen($comment) > $cookie[10])) 
			{
				echo substr("$comment", 0, $cookie[10])."<br />
				<a href=\"mod.php?mod=poll&amp;op=large_comment&amp;cid=$cid&amp;pid=$pid\">
				Read the rest of this comment...</a>";
			}
			elseif(strlen($comment) > $poll_commentlimit)
			{
				echo substr("$comment", 0, $poll_commentlimit)."<br />
				<a href=\"mod.php?mod=poll&amp;op=large_comment&amp;cid=$cid&amp;pid=$pid\">
				Read the rest of this comment...</a>";
			}
			else 
				echo "$comment";
		
			echo "</td></tr><tr><td>[	
			<a href =\"mod.php?mod=poll&amp;op=reply&amp;cid=$cid&amp;pid=$pid&amp;rid=$rid\">
			Reply</a>]";
			
			admin_delete($cid, $pid);
			modthree($cid, $pid, 0);
			echo "</td></tr></table>";
			}
			
			DisplayKids($cid, $pid);

			if($mode=="nested")
				echo "</blockquote></td></tr></table>";
		}
		else
		{
			if($score>=$thold)
			{
				echo "<blockquote>";
				
				if (!eregi("[a-z0-9]", $name)) $name = $anonymous;
				if (!eregi("[a-z0-9]", $subject)) $subject = "(No Subject)";
				$datetime = formatTimestamp($date);
				
				echo "<a href=\"mod.php?mod=poll&amp;op=results&amp;pid=$pid&amp;cid=$cid\">
				$subject</a> by: $name on: $datetime<br /><br />
				";
			} 
			DisplayKids($cid, $pid);
				echo "</blockquote>";
		}
	}
}

function admin_delete($cid, $pid)
{
	//Had to be added because the admin test was crashing the recursive call in DisplayKids.
	include("config.php");
	
	global $admintest;

	if($admintest==$security_hash) 
		echo " | <a href=\"mod.php?mod=poll&amp;op=delete_comment&amp;cid=$cid&amp;pid=$pid&amp;ok=0\">
		Delete</a> ] 
		<br /><br />";
	else
		echo " ]<br /><br />";
}

function single_comment($cid, $pid, $temp)
{
	include("config.php");
	include("./mod/poll/poll_config.php");

	global $admintest;
	
	cookiedecode($user);

	$result = mysql_query("SELECT date, name, email, url, subject, comment, score, reason FROM mod_poll_comments 
		WHERE cid='$cid' AND pid='$pid'");
	list($date, $name, $email, $url, $subject, $comment, $score, $reason) = mysql_fetch_row($result);

	echo "<a name=\"$tid\"></a>";
	echo "<table width=\"100%\" border=\"0\" summary=\"Data Comment Display\">
	<tr><td class=\"type4\" style=\"background-color : #e0e0e0;\">";

	if(!$reply)
		modone();

	if ($name == "") 
		$name = $poll_anonymous; 

	if ($subject == "") 
		echo "(No Subject)"; 

	formatTimestamp($date);
	stripslashes($subject);	
	echo "$subject"; 

	if(!$reply)
		modtwo(); 

	if(!$cookie[7]) 
	{
		echo " | (Score: $score";
		if($reason>0)
			echo ", $poll_reasons[$reason]";
		echo ")";
	}
				
	if($email!="")
		echo "<br />by: <a href=\"mailto:$email\">$name</a> ($email) on: $datetime"; 
	else
		echo "<br />by: $name on: $datetime";
				
	if ($name != $poll_anonymous) 
		echo "<br />(<a href=\"user.php?op=userinfo&amp;uname=$name\">User Info</a>) "; 
			
	if (eregi("http://",$url)) 
		echo "<a href=\"$url\" target=\"window\">$url</a> "; 
			
	if($admintest==$security_hash) 
	{
		$result= mysql_query("SELECT host_name FROM mod_poll_comments WHERE cid='$cid'");
		list($host_name) = mysql_fetch_row($result);
		echo "<br />(IP: $host_name)";
	}
	
	echo "</td></tr><tr><td class=\"type3\">
	".stripslashes($comment)."</td></tr></table></td></tr></table><br />";

	if(!$temp)
	{
		echo "[	
		<a href =\"mod.php?mod=poll&amp;op=reply&amp;cid=$cid&amp;rid=$rid&amp;pid=$pid\">Reply</a>]";
		
		if($admintest==$security_hash) 
			echo " | <a href=\"mod.php?mod=poll&amp;op=delete_comment&amp;cid=$cid&amp;pid=$pid&amp;ok=0\">
			Delete</a> ] |
			<br /><br />";
		else 
			echo " ]<br /><br />";

		modthree($cid, $pid, 1); 
	
		echo "<br />&nbsp;<hr size=\"1\">&nbsp;<br />";
		echo "<a href=\"mod.php?mod=poll&amp;op=results&amp;pid=$pid\">Back</a>"; 
	}

}

function save_comments($subject, $comment, $postanon, $pid, $rid, $posttype) 
{
	include("config.php");
	include("./mod/poll/poll_config.php");

	global $user, $userinfo, $EditedMessage, $cookie;
	$subject = htmlspecialchars(magic_check($subject));
	$subject = FixQuotes(filter_text($subject, "nohtml"));
	$comment = htmlspecialchars(magic_check($comment));
	if($posttype=="exttrans")
		$comment = FixQuotes(str_replace("\n", "<br />", check_words($comment)));
	elseif($posttype=="plaintext")
		$comment = FixQuotes(str_replace("\n", "<br />",(filter_text($comment))));
	else
		$comment = FixQuotes(filter_text($comment));
	
	if (($user) && (!$postanon)) 
	{
		getusrinfo($user);
		$name = $userinfo[uname];
		$email = $userinfo[femail];
		$url = $userinfo[url];
		$score = 1;
	} 
	else 
	{
		$name = ""; 
		$email = ""; 
		$url = "";
		$score = 0;
	}

	$ip = getenv("REMOTE_HOST");
	if (empty($ip)) 
	    $ip = getenv("REMOTE_ADDR");
	
	mysql_query("LOCK TABLES mod_poll_comments WRITE");
	
	if($user)
	{
		$result = mysql_query("SELECT COUNT(cid) FROM mod_poll_comments WHERE name='$name' AND pid=$pid");
		list($count) = mysql_fetch_row($result);
	}
	else
	{
		$result = mysql_query("SELECT COUNT(cid) FROM mod_poll_comments WHERE host_name='$ip' AND pid=$pid");
		list($count) = mysql_fetch_row($result);
	}
		
	//begin duplicate control
	$result = mysql_query("SELECT count(cid) FROM mod_poll_comments WHERE rid='$rid' AND pid='$pid' AND subject='$subject' AND comment='$comment'");
	list($tia) = mysql_fetch_row($result);

	//begin troll control
	if($user)
	{
		list($troll) = mysql_fetch_row(mysql_query("select count(*) from mod_poll_comments where (score=-1) and 
		(name='$userinfo[uname]') and (to_days(now()) - to_days(date) < 3)"));
	} 
	elseif(!$score) 
	{
		list($troll) = mysql_fetch_row(mysql_query("select count(*) from mod_poll_comments where (score=-1) and 
		(host_name='$ip') and (to_days(now()) - to_days(date) < 3)"));
	}
	
	//Makes sure the user hasn't exceeded the maximum amount.
	if($count>$poll_max_comments)
	{
		$box_title = "<center>Cannot Post Comment</center>";
		$box_stuff = "
		<center>
		<h3>WARNING</h3>
		<p>You have reached the maximum number of posts allowed for a poll.</p>";
		
		if ($name=="") 
			$box_stuff .= "<p>If you are at a public computer please login and try again. 
			<br /><a href=\"user.php\">Login</a></p>";
		 
		$box_stuff .= "<a href=\"mod.php?mod=poll&amp;op=results&amp;pid=$pid\">Ok</a></center>";

		themesidebox($box_title, $box_stuff);
		
		mysql_query("UNLOCK TABLES");
	}
	elseif((!$tia) && ($troll < 6)) 
	{
		mysql_query("INSERT INTO mod_poll_comments (rid, pid, date, name, email, url, host_name, subject, comment, score, reason) VALUES ('$rid', '$pid', now(), '$name', '$email', '$url', '$ip', '$subject', '$comment', '$score', '0')");
		mysql_query("UNLOCK TABLES");
		poll_results($pid);
		if($allow_comments)
			display_comments($cid, $pid);	
	}
	else 
	{
		if($tia)
		{
			$box_title = "Duplicate";
			$box_content = "<p> = [Did you submit twice?</p>
			<a href=\"mod.php?mod=poll&amp;op=results&amp;pid=$pid\">Back to Results</a>";
			
			themesidebox($box_title, $box_content);
		}
		elseif($troll > 5)
		{
			$box_title = "<center>Cannot Post Comment</center>";
			$box_content = "<p><center>This account or IP has been temporarily disabled.
			</p><a href=\"mod.php?mod=poll&amp;op=results&amp;pid=$pid\">Back to Results</a>";
			
			themesidebox($box_title, $box_content);
		}
	}
}

function comment_delete($cid, $pid, $ok)
{
	include("./mod/poll/poll_config.php");
	
	if($ok)
	{
		$result = mysql_query("SELECT rid FROM mod_poll_comments WHERE cid= $cid");
		list($rid) = mysql_fetch_row($result);
		if($rid==0)
			mysql_query("UPDATE mod_poll_comments SET rid=0 WHERE rid=$cid");
		mysql_query("DELETE FROM mod_poll_comments WHERE cid = $cid");
		
		poll_results($pid);
		if($allow_comments)
			display_comments(0, $pid);
	}
	else
	{
		$box_title = "<center>Remove a comment</center>";
		$box_stuff = "
		<center>
		<h3>WARNING</h3>
		<p>You are about to delete this comment.</p>
		<p>Are you sure?</p><p>
		 <a href=\"mod.php?mod=poll&amp;op=delete_comment&amp;cid=$cid&amp;pid=$pid&amp;ok=1\">YES</a>
		|<a href=\"mod.php?mod=poll&amp;op=results&amp;pid=$pid\">NO</a></p>
		</center>
		";

		themesidebox($box_title, $box_stuff);
		single_comment($cid, $pid, 1);
	}
}

?>
