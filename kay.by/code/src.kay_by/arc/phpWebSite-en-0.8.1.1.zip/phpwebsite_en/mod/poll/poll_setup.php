<?php

/* UPDATE POLLS */
	
class poll
{
	var $title;
	var $num_options;
	var $options;
	var $new_poll;
	var $option_votes;
	var $option_count;
	var $total_votes;
	var $ip_array;
}

mysql_query("CREATE TABLE mod_poll_data (
       	pid int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	data longtext)");

mysql_query("CREATE TABLE mod_poll_flag (
       	pid int(11),
	flag tinyint(1))");

mysql_query("CREATE TABLE mod_poll_comments (
  	cid int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
      	rid int(11),
      	pid int(11),
	date datetime,
	name varchar(100),	
	email varchar(100),	
	url varchar(100),	
	host_name varchar(100),	
	subject varchar(100),	
	comment text,	
	score tinyint(4),
	reason tinyint(4))");

$result = mysql_query("SELECT poll FROM flags");
list($active) = mysql_fetch_row($result);
$result = mysql_query("SELECT max(pollID) FROM poll_desc");
list($id) = mysql_fetch_row($result);

if($active)
	mysql_query("INSERT INTO mod_poll_flag values ('$id', '1')");
else 
	mysql_query("INSERT INTO mod_poll_flag values ('0', '0')");
	
$poll = mysql_query("SELECT pollID FROM poll_desc ORDER BY pollID");
if($poll)
{
	while(list($pollid) = mysql_fetch_row($poll))
	{
		$poll_desc = mysql_query("SELECT pollTitle, voters FROM poll_desc WHERE pollID='$pollid'");
		
		list($polltitle, $voters) = mysql_fetch_row($poll_desc);
		$temp = new poll;
		$temp->new_poll = 0;
		$temp->title = $polltitle;

		$max = mysql_query("SELECT MAX(voteID) FROM poll_data WHERE pollID='$pollid'");
		list($max_options)=mysql_fetch_row($max);
		$temp->num_options = $max_options;

		$temp->total_votes = $voters;

		$poll_data = mysql_query("SELECT optionText, optionCount, voteID FROM poll_data WHERE pollID='$pollid'");
		$rows = mysql_num_rows($poll_data);
		$j=0;
		
		for($i=0; $i<$rows; $i++)
		{
			list($text, $count, $vid) = mysql_fetch_row($poll_data);
			if($text!="")
			{
				$temp->options[$j] = $text;
				$temp->option_votes[$j] = $count;
				$j++;
			}
		}
		$temp->option_count = $j;
		$temp->ip_array[0] = "0.0.0.0";
		$data = serialize($temp);
		$data2 =  addslashes($data);

		mysql_query("LOCK TABLES mod_poll_data WRITE");
		mysql_query("INSERT INTO mod_poll_data (data) VALUES ( '$data2')");	
		mysql_query("UNLOCK TABLES");

		$comment_data = mysql_query("SELECT tid, pid, date, name, email, url, host_name, subject, comment, score, reason FROM 
			pollcomments WHERE pollID='$pollid'");

		mysql_query("LOCK TABLES mod_poll_data WRITE");
		$result = mysql_query("SELECT MAX(pid) FROM mod_poll_data");	
		list($pid) = mysql_fetch_row($result);
		mysql_query("UNLOCK TABLES");


		while(list($cid, $rid, $date, $name, $email, $url, $host_name, $subject, $comment, $score, $reason) = 
		mysql_fetch_row($comment_data))
		{
			if($score>5)
				$score=5;
			if($score<-1)
				$score=-1;
			mysql_query("INSERT INTO mod_poll_comments (cid, rid, pid, date, name, email, url, host_name, subject, comment, 
			score, reason) VALUES ('$cid', '$rid', '$pid', '$date', '$name', '$email', '$url', '$host_name', '$subject', 
			'$comment', '$score', '$reason')");
		}
	
	}
}

?>
