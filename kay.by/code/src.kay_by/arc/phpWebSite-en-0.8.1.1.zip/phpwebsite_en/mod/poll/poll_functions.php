<?php

include("./mod/poll/poll.php");
include("config.php");

//These are functions that didn't really fit into the poll class.

//This function is used to show the poll on the index.php page.
function poll_show()
{
	include("./mod/poll/poll_config.php");

	global $current_poll;

	$result = mysql_query("SELECT pid FROM mod_poll_flag");
	list($pid) = mysql_fetch_row($result);

	$result = mysql_query("SELECT data FROM mod_poll_data WHERE pid='$pid'"); 
	list($data) = mysql_fetch_row($result);
	stripslashes($data);
	$current_poll = new poll;
	$current_poll = unserialize($data);
	
	$boxContent = "<form action=\"mod.php\" method=\"post\">
	<input type=\"hidden\" name=\"mod\" value=\"poll\" />
	<input type=\"hidden\" name=\"op\" value=\"vote\" />
	<input type=\"hidden\" name=\"pid\" value=\"$pid\" />
	<input type=\"hidden\" name=\"forwarder\" value=\"$url\" />";

	$boxTitle = "Survey";

	$boxContent .= "<b>".stripslashes($current_poll->title)."</b><br />";
	
	for($i = 0; $i < $current_poll->option_count; $i++)
	{
		$option_text = $current_poll->options[$i];
		$boxContent .= "
		<input type=\"radio\" name=\"voteid\" value=\"$i\" />".stripslashes($option_text)."
		<br />";
		$j++;
	}

	$boxContent .= "
	<input type=\"submit\" value=\"Vote Now!\" /><br />
	[ <a href=\"mod.php?mod=poll&amp;op=results&amp;pid=$pid&amp;cid=0\">
	View Results
	</a>] <br />
	[ <a href=\"mod.php?mod=poll&amp;op=lists\">
	Past Surveys
	</a>]
	<br />";

	$result = mysql_query("SELECT cid FROM mod_poll_comments where pid='$pid'");
	$total = mysql_num_rows($result);
	$boxContent .= "<br />Votes: <b>$current_poll->total_votes</b><br />";

	if($allow_comments)
		$boxContent .= "Comments: <b>$total</b>";

	$boxContent .= "</form>";
	themepollbox($boxTitle, $boxContent);
}

/* Simply prints a link back to the main phpwebsite admin menu */
function back_to_admin()
{
	global $security_hash, $admintest;

	if($admintest==$security_hash)
		echo "<center><b><a href=\"./admin.php\">Back to Admin Menu</a></b></center>";
}

/* Simply prints a link back to the poll admin menu */
function back_to_survey($pid)
{
	global $security_hash, $admintest;

	if($admintest==$security_hash)
	{
		echo "<center><p><b><a href=\"./mod.php?mod=poll&amp;op=edit_poll&amp;pid=$pid\">
		Back to Survey/Polls Menu</a></b></p></center>";
	}
}

//Sets the layout values for the poll comments.
function set_poll($new_mode, $new_thold, $new_order)
{
	global $mode, $thold, $order;
	
	$mode=$new_mode;
	$thold=$new_thold;
	$order=$new_order;
}

//If the user hasn't voted in the past day, the vote will be recorded.
//Else the user will be told that the vote is invalid and that they have already voted.
function vote_poll($pid, $voteid)
{
	include("./mod/poll/poll_config.php");
	
	$result = mysql_query("SELECT data FROM mod_poll_data WHERE pid='$pid'"); 
	list($data) = mysql_fetch_row($result);
	stripslashes($data);
	$poll = new poll;
	$poll = unserialize($data);
	
	//If the vote is limited to one vote per IP it checks for it.
	//Else the vote is tallied.
	if($vote_restrict)
	{
		//Gets the current IP.
		$ip = getenv("REMOTE_HOST");
		if(empty($ip))
	    		$ip = getenv("REMOTE_ADDR");
	
		$i=0;
		$found=0;
		
		//Checks to see if the IP has already voted.
		do{
			$array_ip = $poll->ip_array[$i];
			if($array_ip==$ip)
				$found = 1;
			$i++;
			$temp = $poll->ip_array[$i];
		}while($poll->ip_array[$i]!="");	
		
		//If the IP was found and invalid vote msg is displayed.
		//Else the IP is added to the array and the vote is tallied.
		if($found) 
		{
			$box_title = "<center>Invalid Vote</center>";
			$box_stuff = "
			<center>
			<h3>WARNING</h3>
			<p>You have already voted!
			<br /><br />
		 	<a href=\"index.php\">OK</a>
			</center>
			";
			themesidebox($box_title, $box_stuff);
			return 0;
		}
		else
		{
			$poll->ip_array[$i] = $ip;
			$i = $poll->option_votes[$voteid];
			$i++;
			$poll->option_votes[$voteid] = $i;
			$poll->total_votes++;
		}
	}
	else
	{
		$i = $poll->option_votes[$voteid];
		$i++;
		$poll->option_votes[$voteid] = $i;
		$poll->total_votes++;
	}		
	
	$cpoll = serialize($poll);
	$data = addslashes($cpoll);
	mysql_query("lock table mod_poll_data write");
	mysql_query("UPDATE mod_poll_data SET data = '$data' WHERE pid = $pid");
	mysql_query("unlock table");
	return 1;
}

//This is used to show polls in a "booth"
function poll_booth($pid)
{
	include("config.php");
	include("./mod/poll/poll_config.php");
	
	$result = mysql_query("SELECT pid FROM mod_poll_flag");
	list($pid) = mysql_fetch_row($result);

	$result = mysql_query("SELECT data FROM mod_poll_data WHERE pid='$pid'"); 
	list($data) = mysql_fetch_row($result);
	stripslashes($data);
	$current_poll = new poll;
	$current_poll = unserialize($data);
	
	$boxContent = "<form action=\"mod.php\" method=\"post\">
	<input type=\"hidden\" name=\"mod\" value=\"poll\" />
	<input type=\"hidden\" name=\"op\" value=\"vote\" />
	<input type=\"hidden\" name=\"pid\" value=\"$pid\" />
	<input type=\"hidden\" name=\"forwarder\" value=\"$url\" />";

	$boxTitle = "Survey";

	$boxContent .= "<b>".stripslashes($current_poll->title)."</b><br />";
	
	for($i = 0; $i < $current_poll->option_count; $i++)
	{
		$option_text = $current_poll->options[$i];
		$boxContent .= "
		<input type=\"radio\" name=\"voteid\" value=\"$i\" />".stripslashes($option_text)."
		<br />";
		$j++;
	}

	$boxContent .= "
	<input type=\"submit\" value=\"Vote Now!\" /><br />
	[ <a href=\"mod.php?mod=poll&amp;op=results&amp;pid=$pid\">
	View Results
	</a>] <br />
	[ <a href=\"mod.php?mod=poll&amp;op=lists\">
	Past Surveys
	</a>]
	<br />";

	$result = mysql_query("SELECT cid FROM mod_poll_comments where pid='$pid'");
	$total = mysql_num_rows($result);
	$boxContent .= "<br />Votes: <b>$poll->total_votes</b><br />";
	if($allow_comments)
		$boxContent .= "Comments: <b>$total</b>";
	$boxContent .= "</form></td></tr></table>";
	echo "<table border=\"0\" width=\"$block_percent%\"><tr><td class=\"type3\" valign=\"top\">";
	themepollbox($boxTitle, $boxContent);
	echo "</td></tr></table>";
}

function list_polls()
{
	$box_title = "Past Results";
	
	$result = mysql_query("SELECT pid, data FROM mod_poll_data ORDER BY pid"); 
	while(list($pid, $data) = mysql_fetch_row($result))
	{
		$current_poll=unserialize($data);

		$box_content .= "<br /><span class=\"onebiggerred\">&gt;</span> 
		<a href=\"mod.php?mod=poll&amp;op=show_poll&amp;pid=$pid\">".stripslashes($current_poll->title)."</a><br />
		<a href=\"mod.php?mod=poll&amp;op=results&amp;pid=$pid\">
		Results</a> - $current_poll->total_votes votes\n";
	}
	themesidebox($box_title, $box_content);
}

function poll_results($pid)
{
	back_to_survey($pid);
        $result = mysql_query("SELECT data FROM mod_poll_data WHERE pid = '$pid'");
	list($data) = mysql_fetch_row($result);
	stripslashes($data);
	$current_poll = new poll;
	$current_poll = unserialize($data);
	
	echo "
	<table width=\"100%\" cellspacing=\"0\" cellpadding=\"3\" border=\"0\">
	<tr>
		<td colspan=\"2\" class=\"type4\" style=\"background-color : #e0e0e0;\" align=\"center\">
		<b>".stripslashes($current_poll->title)."</b>
		</td>
	</tr>";
		
	// cycle through all options
	for($i = 0; $i < $current_poll->option_count; $i++)
	{
		$option_text = $current_poll->options[$i];
		echo "<tr><td class=\"type5\" width=\"50%\" align=\"right\">
		".stripslashes($option_text)."</td>";
		
		$c=$current_poll->option_votes[$i];
		if($current_poll->total_votes != 0)
			$percent = ($c / $current_poll->total_votes) * 100;
		else
			$percent = 0;

		echo "<td class=\"type5\" width=\"50%\"align=\"left\">";
		if ($percent > 0)
			echo "<img src=\"images/mainbar.gif\" height=\"16\" width=\"$percent\" alt=\"$percent%\" />";
		else
			echo "<img src=\"images/mainbar.gif\" height=\"16\" width=\"1\" alt=\"$percent%\" />";
		$hold = sprintf(" %.2f %% (%d)", $percent, $c);
		echo "$hold</td></tr>";
        }

	echo "<tr><td colspan=\"2\" class=\"type5\">
	<b>Total Votes: $current_poll->total_votes</b>
		</td>
	</tr>
	</table><br />";
}	

function new_poll()
{
	$new_poll = new poll;
	back_to_admin();
	$new_poll->poll_form(0);
}

function magic_check($quotable)
{
	//DO NOT CHANGE!! It has to be done this way to deal with chars such as qoutes.

	if (get_magic_quotes_gpc())
	{
    		return stripslashes($quotable);
  	}
}

?>
