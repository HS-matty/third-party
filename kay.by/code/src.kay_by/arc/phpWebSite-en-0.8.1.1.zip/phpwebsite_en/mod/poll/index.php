<?php

include("config.php");
include("open_session.php");
if(!isset($mainfile)) include("mainfile.php");

include("header.php");

include("./mod/poll/poll_comments.php");
include("./mod/poll/poll_functions.php");
include("./mod/poll/poll_config.php");

session_register("current_poll");
session_register("mode");
session_register("thold");
session_register("order");

global $admintest;

//Admin only operations
if($admintest==$security_hash)
switch($op)
{
	case activate_poll:
	$current_poll = new poll;
	$current_poll->poll_activate();
	back_to_admin();
	$current_poll->poll_form($pid);
	break;

	case create_poll:
	new_poll();
	break;

	case deactivate_poll:
	$current_poll = new poll;
	$current_poll->poll_deactivate();
	back_to_admin();
	$current_poll->poll_form($pid);
	break;

	case delete_all:
	$poll = new poll;
	$poll->poll_delete_all($ok);
	break;

	case delete_comment:
	comment_delete($cid, $pid, $ok);
	break;

	case delete_poll:
	$poll = new poll;
	$poll->poll_delete($pid, $ok);
	break;

	case edit_poll:
	$poll = new poll;
	back_to_admin();
	$poll->poll_form($pid);
	break;

	case moderate:
	$result = mysql_query("SELECT score FROM mod_poll_comments WHERE cid='$cid'");
	list($score) = mysql_fetch_row($result);
	global $mode, $thold;
	$q = "UPDATE mod_poll_comments SET";
	if($reason==9) 
	{
		// Overrated
		if($score!=-1)
		{
			$q .= " score=score-1 WHERE cid='$cid'";
			mysql_query($q);
		}
	}			
	elseif($reason==10)
	{ 
		 //Underrated
		if($score!=5)
		{
			$q .= " score=score+1 WHERE cid='$cid'";
			mysql_query($q);
		}
	}
	elseif(($reason>=1) && ($reason <=4))
	{ 
		if($score!=-1)
			$q .= " score=score-1, reason=$reason WHERE cid='$cid'";
		else
			$q .= " reason=$reason WHERE cid='$cid'";
		mysql_query($q);
	}
	elseif (($reason>=5) && ($reason<=8))
	{
		if($score!=5) 
			$q .= " score=score+1, reason=$reason WHERE cid='$cid'";
		else
			$q .= " reason=$reason WHERE cid='$cid'";
		mysql_query($q);
	}
	poll_results($pid);
	$result = mysql_query("SELECT score FROM mod_poll_comments WHERE cid='$cid'");
	list($score) = mysql_fetch_row($result);
	
	if($mode!="threaded")
		$cid=0;
	if($allow_comments)
	{
		//Sets the new layout values.
		if(isset($new_mode))
			$mode=$new_mode;
		if(isset($new_thold))
			$thold=$new_thold;
		if(isset($new_order))
			$order=$new_order;
		display_comments($cid, $pid);	
	}
	break;

	case save:
	$current_poll = new poll;
	$current_poll->poll_set_title($title);
	$current_poll->poll_set_option($option);
	if ($pid==0)
		$pid = $current_poll->poll_save();
	else
		$current_poll->poll_update($pid);
	if($pid=="")
	{
		$result = mysql_query("SELECT MAX(pid) FROM mod_poll_data");
		list($pid) = mysql_fetch_row($result);
	}
	if($active)
		$current_poll->poll_set_active($pid);
	back_to_admin();
	$current_poll->poll_form($pid);
	break;

	case set_poll_active:
	$poll = new poll;
	$poll->poll_set_active($pid);
	new_poll();
	break;	
}

//Operations for Users
switch($op)
{
	case large_comment:
	single_comment($cid, $pid, 0);
	break;

	case lists:
	list_polls();
	break;

	case "Ok!":
	save_comments($subject, $comment, $postanon, $pid, $rid, $posttype);
	
	break; 

	case "Preview":
	if($cid!=0)
		single_comment($cid, $pid, 1);
	reply_preview($rid, $pid, $subject, $comment, $postanon);
	break;
	
	case results:
	global $allow_comments, $mode, $thold, $order;
	poll_results($pid);
	if($allow_comments)
	{
		//Sets the new layout values.
		if(isset($new_mode))
			$mode=$new_mode;
		if(isset($new_thold))
			$thold=$new_thold;
		if(isset($new_order))
			$order=$new_order;
		display_comments($cid, $pid);	
	}
	break;

	case reply:
	if($cid!=0)
		single_comment($cid, $pid, 1);
	reply_form($cid, $rid, $pid, $mode);
	break;

	case show_poll;
	poll_booth($pid);
	break;

	case vote:
	$valid = vote_poll($pid, $voteid);
	if($valid)
	{
		poll_results($pid);
		if($allow_comments)
			display_comments($cid, $pid);
	}
	break;
}
	include("footer.php");

?>
