<?php
################
# Admin Config #
################

$max_options = 6;  		#The maximum number of options allowed for each poll.

##################
# Comment Config #
##################

$vote_restrict = 1;		#0 = Allows user's to vote as many time as they want to.
				#1 = Allows only one vote per ip address per poll.

$allow_comments = 1;  		#0 = Disable comments for polls
		      		#1 = Allows comments for polls

$default_mode = "nested";       #Sets the default comment layout.     		
				#nocomments
				#flat
			      	#nested
				#threaded

$default_order = "4"; 		#Sets the default order for comments.   
				#1 = Newest First
				#2 = Highest Score First
			      	#3 = Lowest Score First
			   	#4 = Oldest First

$default_thold = "0";  		#Sets the default thereshold for the poll comments. 
				#-1: Uncut and Raw(Minimum Score)
				# 0: Almost Everything 
				# 1: Filter Most Anonymous
				# 2, 3, 4:  
				# 5: Shows Only The Best(Maximum Score)
			  	#Comments scored less than this setting will be ignored. 
				#Anonymous posts start at 0, logged in posts start at 1. Moderators add and subtract points.

$poll_max_comments = 50;        #This is the maximum number of comments allowed per user/per article.


$poll_commentlimit = 4096; 	#Maximum number of characters show in post.  If more, a Read More link is used.

$poll_anonymous = "Anonymous";

$allowhtml = array("p"=>2,	# 2 means accept all qualifiers: <foo bar>
                   "b"=>1,	# 1 means accept the tag only: <foo>
                   "i"=>1,
                   "a"=>2,
                   "em"=>1,
                   "br"=>1,
                   "strong"=>1,
                   "blockquote"=>1,
                   "tt"=>1,
                   "li"=>1,
                   "ol"=>1,
                   "div"=>2,
                   "ul"=>1);

#####################
# Moderation Config #
#####################

$poll_moderate = 1;		# 1 for comment moderation by admin
              			# 2 for moderation by anyone
	      			# 0 for no moderation

$poll_reasons = array('As Is',
		'Offtopic',
		'Flamebait',
		'Troll',
		'Redundant',
		'Insightful',
		'Interesting',
		'Informative',
		'Funny',
		'Overrated',
		'Underrated');

# number of "Bad" reasons in $reasons, skipping 0 (which is "As Is", neutral)
$badreasons = 4;

?>
