<?php

###################################################
#    Web Links Functions:                         #
#       These are the web links functions.        #
###################################################

function links()
{
	include ("header.php");
	include ("config.php");

        GraphicAdmin(0);

	echo "
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">
<tr>
	<td class=\"type0\">
<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
<tr>
	<td class=\"type4\">";
	$current_links_result = mysql_query("select * from links_links order by title");
	$current_links_numrows = mysql_num_rows($current_links_result);
	
	if($current_links_numrows > 0)
	echo "There are <span class=\"boldtext\">$current_links_numrows</span> Links in our Database";
	else
	echo "There are <span class=\"boldtext\">0</span> Links in our Database";

echo "</td>
</tr>
<tr>
	<td class=\"type5\">";

	//LIST CURRENT LINKS
	if ($current_links_numrows > 0)
	{
		echo "
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">
<tr><td>";
	
	while(list($lid, $cid, $sid, $title, $url) = mysql_fetch_row($current_links_result))
	{
		echo "Page Title:<a href=\"admin.php?op=LinksModLink&amp;lid=$lid\">$title</a>
		Page URL:$url<br />
		";
	}

	echo "
</td></tr></table>
<br />";

	}

	echo "
</td></tr></table>
</td></tr></table><br />";


// Add a New Link to Database

	$result = mysql_query("select cid, title from links_categories");
	$numrows = mysql_num_rows($result);
	
	if ($numrows > 0)
	{
		echo "
	<!--INDIVIDUAL BLOCKS-->
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">
<tr>
	<td class=\"type0\">
<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
<tr>
	<td class=\"type4\">Add a New Link</td>
</tr>
<tr>
	<td class=\"type5\"><form method=\"post\" action=\"admin.php\">
	Page Title: <input type=\"text\" name=\"title\" size=\"50\" maxlength=\"100\" />
	<br />
	Page URL: <input type=\"text\" name=\"url\" size=\"50\" maxlength=\"100\" value=\"http://\" />
	<br />
		";
		
		$result=mysql_query("select cid, title from links_categories order by title");
		echo "Category: <select name=\"cat\">";
		
		while(list($cid, $title) = mysql_fetch_row($result))
		{
			echo "<option value=\"$cid\">$title</option>";
			$result2=mysql_query("select sid, title from links_subcategories where cid=$cid order by title");
			
			while(list($sid, $stitle) = mysql_fetch_row($result2))
			{
				echo "<option value=\"$cid-$sid\">$title / $stitle</option>";
			}
		}
		
		echo "
	</select><br /><br />Description: (255 characters max)<br />
	<textarea name=\"description\" cols=\"60\" rows=\"5\" wrap=\"virtual\"></textarea>
	<input type=\"hidden\" name=\"name\" value=\"admin\" />
	<input type=\"hidden\" name=\"email\" value=\"admin\"/><br /><br />
	<input type=\"hidden\" name=\"op\" value=\"LinksAddLink\" />
	<input type=\"hidden\" name=\"new\" value=\"0\" />
	<input type=\"hidden\" name=\"lid\" value=\"0\" />
	<center><input type=\"submit\" value=\"Add URL\" /></center></form>
</td></tr></table>
</td></tr></table><br />
	";
	}
	
	//If Categories is set
	if($category_type > 0)
	echo "
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"80%\" align=\"center\">
<tr>
	<td class=\"type0\">
<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
<tr>
	<td class=\"type4\">Add a Main Category</td>
</tr>
<tr>
	<td class=\"type5\"><form method=\"post\" action=\"admin.php\">
	Name: <input type=\"text\" name=\"title\" size=\"30\" maxlength=\"100\" />
	<input type=\"hidden\" name=\"op\" value=\"LinksAddCat\" />
	<input type=\"submit\" value=\"Add\" />
	</form>
</td></tr></table>
</td></tr></table>
<br />
	";
	//End Categories Form  -Adam

	//If Sub-Categories is set
	if($category_type == 2)
	{
		$result = mysql_query("select * from links_categories");
		$numrows = mysql_num_rows($result);
	
		if ($numrows > 0)
		{
			echo "
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"80%\" align=\"center\">
<tr>
	<td class=\"type0\">
<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
<tr>
	<td class=\"type4\">Add a SUB-Category</td>
</tr>
<tr>
	<td class=\"type5\"><form method=\"post\" action=\"admin.php\">
	Name: <input type=\"text\" name=\"title\" size=\"30\" maxlength=\"100\" />&nbsp;in&nbsp;
			";
	
			$result=mysql_query("select cid, title from links_categories order by title");

			echo "<select name=\"cid\">";
			
			while(list($ccid, $ctitle) = mysql_fetch_row($result))
			echo "<option value=\"$ccid\">$ctitle</option>";
		
			echo "
	</select>
	<input type=\"hidden\" name=\"op\" value=\"LinksAddSubCat\" />
	<input type=\"submit\" value=\"Add\" /></form>
</td></tr></table>
</td></tr></table>
<br />
			";
		}
	}//End Sub-Categories Form  -Adam

	//If Categories or Sub-Categories is set
	if($category_type > 0)
	{
		$result = mysql_query("select * from links_categories");
		$numrows = mysql_num_rows($result);
	
		if ($numrows>0)
		{
			echo "
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"80%\" align=\"center\">
<tr>
	<td class=\"type0\">
<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
<tr>
	<td class=\"type4\">Modify Category</td>
</tr>
<tr>
	<td class=\"type5\"><form method=\"post\" action=\"admin.php\">
			";
		
			$result=mysql_query("select cid, title from links_categories order by title");
		
			echo "Category: <select name=\"cat\">";

			while(list($cid, $title) = mysql_fetch_row($result))
			{
				echo "<option value=\"$cid\">$title</option>
				";
				if($category_type == 2)
				{
					$result2=mysql_query("select sid, title from links_subcategories where cid=$cid order by title");
					while(list($sid, $stitle) = mysql_fetch_row($result2))
					echo "<option value=\"$cid-$sid\">$title / $stitle</option>
					";
				}
			}

			echo "
	</select>
	<input type=\"hidden\" name=\"op\" value=\"LinksModCat\" />
	<input type=\"submit\" value=\"Modify\" />
	</form>
</td></tr></table>
</td></tr></table>
<br />
			";
		}//END IF STATEMENT  -Adam
	}

	$new_link_result = mysql_query("select lid, cid, sid, title, url, description, name, email from links_newlink order by lid");
	$new_link_numrows = mysql_num_rows($new_link_result);
	
	//LIST LINKS WAITING FOR VALIDATION
	if ($new_link_numrows > 0)
	{
		echo "<form action=\"admin.php\" method=\"post\">";
		echo "
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">
<tr>
	<td class=\"type0\">
<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
<tr>
	<td class=\"type4\">Links Waiting for Validation</td>
</tr>
<tr>
	<td class=\"type5\">
		";
	
		while(list($lid, $cid, $sid, $title, $url, $description, $name, $email) = mysql_fetch_row($new_link_result))
		{
			echo "
<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
<tr>
	<td class=\"type4small\">Link Submission #$lid</td>
</tr>
<tr>
	<td class=\"type5\">
	Page Title: <input type=\"text\" name=\"title\" value=\"$title\" size=\"50\" maxlength=\"100\" /><br />
	Page URL: <input type=\"text\" name=\"url\" value=\"$url\" size=\"50\" maxlength=\"100\" />&nbsp;
	<center>[&nbsp;<a target=_blank href=\"$url\">Visit</a>&nbsp;]</center><br />
	Description: <br /><textarea name=\"description\" cols=\"60\" rows=\"5\" wrap=\"virtual\">$description</textarea><br />
	Name: <input type=\"text\" name=\"name\" size=\"20\" maxlength=\"100\" value=\"$name\" /><br />
	Email: <input type=\"text\" name=\"email\" size=\"20\" maxlength=\"100\" value=\"$email\" /><br />
			";

			$result2=mysql_query("select cid, title from links_categories order by title");

			echo "
	</td>
</tr>
<tr>
	<td class=\"type4small\" align=\"center\">
	<span class=\"onebiggerred\">Submission Decision</span><br />
	<input type=\"hidden\" name=\"new\" value=\"1\" />
	<input type=\"hidden\" name=\"lid\" value=\"$lid\" />
	Category: <select name=\"cat\">
			";

			while(list($ccid, $ctitle) = mysql_fetch_row($result2))
			{
				$sel = "";
				echo "<option value=\"$ccid $sel\">$ctitle</option>";
				$result3=mysql_query("select sid, title from links_subcategories where cid=$ccid order by title");
				while(list($ssid, $stitle) = mysql_fetch_row($result3))
				{
					$sel = "";
					echo "<option value=\"$ccid-$ssid $sel\">$ctitle / $stitle</option>";
				}
			}
			echo "</select>
	<input type=\"hidden\" name=\"op\" value=\"LinksAddLink\" />
	<input type=\"submit\" value=\"Add\" /><br /> 
	[ <a href=\"admin.php?op=LinksDelNew&amp;lid=$lid\">Delete</a> ]
</td></tr></table><br />";
		}

		echo "
</td></tr></table>
</td></tr></table>
<br /></form>
		";
	}
	
	include ("footer.php");
}

function LinksModLink($lid)
{
	include ("header.php");
	$result = mysql_query("select cid, sid, title, url, description, name, email, hits from links_links where lid=$lid");
	
	echo "
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">
<tr>
	<td class=\"type0\">
		<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
			<tr>
				<td class=\"type4\">
				Modify Links
				</td>
			</tr>
			<tr>
				<td class=\"type5\">";
	
	while(list($cid, $sid, $title, $url, $description, $name, $email, $hits) = mysql_fetch_row($result))
	{
		echo "<form action=\"admin.php\" method=\"post\">
		Page Title: <input type=\"text\" name=\"title\" value=\"$title\" size=\"50\" maxlength=\"100\" /><br />
		Page URL: <input type=\"text\" name=\"url\" value=\"$url\" size=\"50\" maxlength=\"100\" />&nbsp;
		[ <a href=\"$url\">Visit</a> ]<br />
		Description: <br /><textarea name=\"description\" cols=\"60\" rows=\"10\" wrap=\"virtual\">$description</textarea><br />
		</td></tr><tr>
		<td class=\"type4small\" align=\"center\">
		<span class=\"onebiggerred\">Submission Decision</span><br />
		<input type=\"hidden\" name=\"lid\" value=\"$lid\" />
		Category: <select name=\"cat\">";
		
		$result2 = mysql_query("select cid, title from links_categories order by title");

		while(list($ccid, $ctitle) = mysql_fetch_row($result2))
		{
			$sel = "";
			if ($cid == $ccid && !$sid)
			{
				$sel = "selected";
			}
			echo "<option value=\"$ccid\" $sel>$ctitle</option>\n";
			$result3=mysql_query("select sid, title from links_subcategories where cid=$ccid order by title");
			
			while(list($ssid, $stitle) = mysql_fetch_row($result3))
			{
				$sel = "";
				if ($sid==$ssid)
				{
					$sel = "selected";
				}
				echo "<option value=\"$ccid-$ssid\" $sel>$ctitle / $stitle</option>\n";
			}
		}
		
		echo "</select>
		      <input type=\"hidden\" name=\"op\" value=\"LinksModLinkS\">
		      <input type=\"submit\" value=\"Modify\" /> <br />[ <a href=\"admin.php?op=LinksDelLink&amp;lid=$lid\">Delete</a> ]<br />
		";
    	
	}
	echo "</td></tr></table>
	      </td></tr></table>
	      </form><br />
	";
	
	include ("footer.php");
}

function LinksModLinkS($lid, $title, $url, $description, $name, $email, $hits, $cat)
{
	$cat = explode("-", $cat);
	if ($cat[1]=="")
	{
		$cat[1] = 0;
	}
	$title = stripslashes(FixQuotes($title));
	$url = stripslashes(FixQuotes($url));
	$description = stripslashes(FixQuotes($description));
	$name = stripslashes(FixQuotes($name));
	$email = stripslashes(FixQuotes($email));
	mysql_query("update links_links set cid='$cat[0]', sid='$cat[1]', title='$title', url='$url', description='$description', name='$name', email='$email', hits='$hits' where lid=$lid");
	Header("Location: admin.php?op=links");
}

function LinksDelLink($lid)
{
	mysql_query("delete from links_links where lid=$lid");
	Header("Location: admin.php?op=links");
}

function LinksModCat($cat)
{
	include ("header.php");
	GraphicAdmin(0);
	$cat = explode("-", $cat);
	
	if ($cat[1]=="")
	{
		$cat[1] = 0;
	}
	echo "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\"><tr>
	<td class=\"type0\">
		<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
			<tr>
				<td class=\"type4\">Modify Category</td>
			</tr>
			<tr>
				<td class=\"type5\">";
	if ($cat[1] == 0)
	{
		$result=mysql_query("select title from links_categories where cid=$cat[0]");
		list($title) = mysql_fetch_row($result);
		
		echo "<form action=\"admin.php\" method=\"get\">
		Name: <input type=\"text\" name=\"title\" value=\"$title\" size=\"51\" maxlength=\"50\" />
		<input type=\"hidden\" name=\"sub\" value=\"0\" />
		<input type=\"hidden\" name=\"cid\" value=\"$cat[0]\" />
		<input type=\"hidden\" name=\"op\" value=\"LinksModCatS\" />
		<input type=\"submit\" value=\"Save Changes\" />
		</form>
		<form action=\"admin.php\" method=\"get\">
		<input type=\"hidden\" name=\"sub\" value=\"0\" />
		<input type=\"hidden\" name=\"cid\" value=\"$cat[0]\" />
		<input type=\"hidden\" name=\"op\" value=\"LinksDelCat\" />
		<input type=\"submit\" value=\"Delete\" />
		</form>";
	}
	else
	{
		$result=mysql_query("select title from links_categories where cid=$cat[0]");
		list($ctitle) = mysql_fetch_row($result);
		$result2=mysql_query("select title from links_subcategories where sid=$cat[1]");
		list($stitle) = mysql_fetch_row($result2);
		
		echo "<form action=\"admin.php\" method=\"get\">
		Category Name: $ctitle<br />
		Sub-Category Name:
		<input type=\"text\" name=\"title\" value=\"$stitle\" size=\"51\" maxlength=\"50\" />
		<input type=\"hidden\" name=\"sub\" value=\"1\" />
		<input type=\"hidden\" name=\"cid\" value=\"$cat[0]\" />
		<input type=\"hidden\" name=\"sid\" value=\"$cat[1]\" />
		<input type=\"hidden\" name=\"op\" value=\"LinksModCatS\" />
		<input type=\"submit\" value=\"Save Changes\" />
		</form>
		<form action=\"admin.php\" method=\"get\" />
		<input type=\"hidden\" name=\"sub\" value=\"1\" />
		<input type=\"hidden\" name=\"cid\" value=\"$cat[0]\" />
		<input type=\"hidden\" name=\"sid\" value=\"$cat[1]\" />
		<input type=\"hidden\" name=\"op\" value=\"LinksDelCat\" />
		<input type=\"submit\" value=\"Delete\" />
		</form>";
	}
	echo "</td></tr></table>
	      </td></tr></table>
	      <br />
	";
	include("footer.php");
}

function LinksModCatS($cid, $sid, $sub, $title)
{
	if ($sub==0)
	{
		mysql_query("update links_categories set title='$title' where cid=$cid");
	}
	else
	{
		mysql_query("update links_subcategories set title='$title' where sid=$sid");
	}
	Header("Location: admin.php?op=links");
}

function LinksDelCat($cid, $sid, $sub, $ok=0)
{
	if($ok==1)
	{
		if ($sub>0)
		{
			mysql_query("delete from links_subcategories where sid=$sid");
			mysql_query("delete from links_links where sid=$sid");
		}
		else
		{
			mysql_query("delete from links_categories where cid=$cid");
			mysql_query("delete from links_subcategories where cid=$cid");
			mysql_query("delete from links_links where cid=$cid AND sid=0");
		}
		Header("Location: admin.php?op=links");    
	}
	else
	{
		include("header.php");
		echo "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">
<tr>
	<td class=\"type0\">
		<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
			<tr>
				<td class=\"type4\">Delete Link Category</td></tr>
			<tr>
				<td class=\"type5bigger\">";
		echo "<center>WARNING: Are you sure you want to delete this Category and ALL its Links?<br /><br />";
	}
	
	echo " [ <a href=\"admin.php?op=LinksDelCat&amp;cid=$cid&amp;sid=$sid&amp;sub=$sub&amp;ok=1\">Yes</a> | <a href=\"admin.php?op=links\">No</a> ]<br /><br />";
	echo "</center></td></tr></table>
	      </td></tr></table>
	";
	include("footer.php");	
}


function LinksDelNew($lid)
{
	mysql_query("delete from links_newlink where lid=$lid");
	Header("Location: admin.php?op=links");
}

function LinksAddCat($title)
{
	$result = mysql_query("select cid from links_categories where title='$title'");
	$numrows = mysql_num_rows($result);
	
	if ($numrows>0)
	{
		include("header.php");
		GraphicAdmin(0);
		echo "
		<table width=\"100%\" cellspacing=\"0\" cellpadding=\"1\" border=\"0\">
		<tr>
		<td class=\"type0\">
		<table width=\"100%\" cellspacing=\"0\" cellpadding=\"8\" border=\"0\">
		<tr>
		<td class=\"type5\"><center><br />";
		echo "<span class=\"onebiggerred\">ERROR: The Category $title already exist!</span><br /><br />";
		echo "</td></tr></table>
		      </td></tr></table>";
		      
		include("footer.php");
	}
	else
	{
		mysql_query("insert into links_categories values (NULL, '$title')");
		Header("Location: admin.php?op=links");
	}
}

function LinksAddSubCat($cid, $title)
{
	$result = mysql_query("select cid from links_subcategories where title='$title' AND cid='$cid'");
	$numrows = mysql_num_rows($result);
	
	if ($numrows>0)
	{
		include("header.php");
		GraphicAdmin(0);
		echo "
		<table width=\"100%\" cellspacing=\"0\" cellpadding=\"1\" border=\"0\">
		<tr>
		<td class=\"type0\">
		<table width=\"100%\" cellspacing=\"0\" cellpadding=\"8\" border=\"0\">
		<tr>
		<td class=\"type5\"><center><br />";
		echo "<span class=\"onebiggerred\">ERROR: The SubCategory $title already exist!</span><br /><br />";
		echo "</td></tr></table>
		      </td></tr></table>
		";
		include("footer.php");
	}
	else
	{
		mysql_query("insert into links_subcategories values (NULL, '$cid', '$title')");
		Header("Location: admin.php?op=links");
	}
}

function LinksAddLink($new, $lid, $title, $url, $cat, $description, $name, $email)
{
	if(substr($url, 0, 7) != 'http://') $url = 'http://' . $url;

	$result = mysql_query("select url from links_links where url='$url'");
	$numrows = mysql_num_rows($result);
	include ("config.php");
	
	if ($numrows>0)
	{
		include("header.php");
		GraphicAdmin(0);
		echo "
		<table width=\"100%\" cellspacing=\"0\" cellpadding=\"1\" border=\"0\">
		<tr>
		<td class=\"type0\">
		<table width=\"100%\" cellspacing=\"0\" cellpadding=\"8\" border=\"0\">
		<tr>
		<td class=\"type5\"><br />";
		echo "<span class=\"onebiggerred\">ERROR: This URL is already listed in the Database!</span><br /><br />
		";
		echo "</td></tr></table>
		      </td></tr></table>
		";
		include("footer.php");
	}
	else //BEGIN BIG ELSE STATEMENT  -MuD
	{

		// Check if Title exist
		if ($title=="")
		{
			include("header.php");
			GraphicAdmin(0);
			echo "
			<table width=\"100%\" cellspacing=\"0\" cellpadding=\"1\" border=\"0\">
			<tr>
			<td class=\"type0\">
			<table width=\"100%\" cellspacing=\"0\" cellpadding=\"8\" border=\"0\">
			<tr>
			<td class=\"type5\"><br />";
			echo "<span class=\"onebiggerred\">ERROR: You need to type a TITLE for your URL!</span><br /><br />";
			echo "</td></tr></table>
			      </td></tr></table>
			";
			include("footer.php");
			exit(0);
		}
		
		// Check if URL exist
		if ($url=="")
		{
			include("header.php");
			GraphicAdmin(0);
			echo "
			<table width=\"100%\" cellspacing=\"0\" cellpadding=\"1\" border=\"0\">
			<tr>
			<td class=\"type0\">
			<table width=\"100%\" cellspacing=\"0\" cellpadding=\"8\" border=\"0\">
			<tr>
			<td class=\"type5\"><br />";
			echo "<span class=\"onebiggerred\">ERROR: You need to type a URL for your URL!</span><br /><br />";
			echo "</td></tr></table>
			      </td></tr></table>
			";
			include("footer.php");
			exit(0);
		}
		
		// Check if Description exist
    		if ($description=="")
		{
			include("header.php");
			GraphicAdmin(0);
			echo "
			<table width=\"100%\" cellspacing=\"0\" cellpadding=\"1\" border=\"0\">
			<tr>
			<td class=\"type0\">
			<table width=\"100%\" cellspacing=\"0\" cellpadding=\"8\" border=\"0\">
			<tr>
			<td class=\"type5\"><br />";
			echo "<span class=\"onebiggerred\">ERROR: You need to type a DESCRIPTION for your URL!</span>
			<br /><br />";
			echo "</td></tr></table>
			      </td></tr></table>
			";
			include("footer.php");
			exit(0);
		}
		
		$cat = explode("-", $cat);
		if ($cat[1]=="")
		{
			$cat[1] = 0;
		}
		
		$title = stripslashes(FixQuotes($title));
		$url = stripslashes(FixQuotes($url));
		$description = stripslashes(FixQuotes($description));
		$name = stripslashes(FixQuotes($name));
		$email = stripslashes(FixQuotes($email));
		
		mysql_query("insert into links_links values (NULL, '$cat[0]', '$cat[1]', '$title', '$url', '$description', now(), '$name', '$email', '0')");
		Header("Location: admin.php?op=links");
		
		if ($new==1)
		{
			mysql_query("delete from links_newlink where lid=$lid");
			if ($email=="")
			{
			}
			else
			{
				$subject = "Your Link at $sitename";
				$message = "Hello $name:\n\n";
				$message .= "We approved your link submission for our search engine.\n\n";
				$message .= "Page Name: $title\nPage URL: $url\n\n";
				$message .= "Description: $description\n\n";
				$message .= "You can browse our search engine at: $nuke_url/links.php\n\nThanks for your submission!\n\n$sitename";
				
				mail($email, $subject, $message, "From: $adminmail\nX-Mailer: PHP/" . phpversion());
			}
		}
		include("footer.php");
	}
}    

?>
