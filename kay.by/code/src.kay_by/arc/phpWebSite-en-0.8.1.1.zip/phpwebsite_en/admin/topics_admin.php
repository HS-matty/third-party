<?php

##################################################
#    Topics Manager Functions:                   #
#       Used to create and manage new topics.    #
##################################################

function topicsmanager()
{
	include("header.php");
	GraphicAdmin(0);

	$result = mysql_query("select topicid, topicparent, topicname, topicimage, topictext from topics order by topicid");

	if (mysql_num_rows($result)>0)
	{
	$boxtitle="Current Active Topics";
	$boxcontent="Click to Edit<br />
		<table border=\"0\" width=\"100%\" align=\"center\" cellpadding=\"2\">
			<tr>
			";
		while(list($topicid, $topicparent, $topicname, $topicimage, $topictext) = mysql_fetch_array($result))
		{
		    $boxcontent.="
			<td class=\"type5\" align=\"center\">
			<a href=\"admin.php?op=topicedit&amp;topicid=$topicid\">
			<img src=\"$tipath$topicimage\" border=\"0\" alt=\"Topic Number $topicid\" /><br />
			$topictext</a></td>";

		    	$count++;
		    	if ($count == 3)
		    	{
		        	$boxcontent.="</tr><tr>";
				$count = 0;
		    	}
		}

	$boxcontent.="</td></tr></table>";
	thememainbox($boxtitle,$boxcontent);
	}

	$boxtitle=" <a name=\"Add\"></a>Add a New Topic";
	$boxcontent="
        <form action=\"admin.php\" method=\"post\" enctype=\"multipart/form-data\">
        Topic Name:
        <input class=\"textbox\" type=\"text\" name=\"topictext\" size=\"20\" maxlength=\"40\" value=\"$topictext\"><br />
		Topic Image:
		<input type=\"file\" name=\"topicimage\" maxlength=\"60\" size=\"20\" /><br />
	";

	$result2 = mysql_query("select topicid, topictext from topics where topicparent=0 order by topictext");
	$boxcontent.="Under topic: <select name=\"topicparent\">
	<option value=\"0\">None</option>
	";

	while(list($topicid, $topictext) = mysql_fetch_row($result2))
	{
		$boxcontent.="<option value=\"$topicid\">$topictext</option>";
		$result3 = mysql_query("select topicid, topictext from topics where topicparent=$topicid order by topictext");

		while(list($topicid, $childtopictext) = mysql_fetch_row($result3))
		{
			$boxcontent.="<option value=\"$topicid\">$topictext / $childtopictext</option>";
		}
	}

	$boxcontent.="
        </select><br /><br />
        <span class=\"boldtext\">Topic Long Text:</span><br />
        <textarea name=\"topiclongtext\" rows=\"8\" cols=\"51\"></textarea><br />
		<input type=\"hidden\" name=\"topicname\" value=\"default\" />
        <input type=\"hidden\" name=\"op\" value=\"topicmake\" />
        <input type=\"submit\" value=\"Add Topic\" />
        </form>
	";

	if ($result)
	mysql_free_result($result);
	thememainbox($boxtitle,$boxcontent);
	include("footer.php");
}

function topicedit($topicid)
{
	include("header.php");
	GraphicAdmin(0);
	$result = mysql_query("select topicparent, topicname, topicimage, topictext, topiclongtext from topics where topicid='$topicid'");
	list($topicparent, $topicname, $topicimage, $topictext, $topiclongtext) = mysql_fetch_array($result);

	$boxtitle="Edit Topic: $topictext";
	if($topicimage == "bl.gif"){
	  $boxcontent="
	<form action=\"admin.php\" method=\"post\" enctype=\"multipart/form-data\">
	[No Image]<br /><br />
	Topic Name: (just a name for your topic - max: 40 characters)<br />
	<input type=\"text\" name=\"topictext\" size=\"40\" maxlength=\"40\" value=\"$topictext\" /><br /><br />
	Topic Image: (current image is shown, upload newer image here)<br />
	<input type=\"file\" name=\"topicimage\" /><br /><br />
	";
	}
	else{
	  $boxcontent="
	<form action=\"admin.php\" method=\"post\" enctype=\"multipart/form-data\">
	<img src=\"$tipath$topicimage\" border=\"0\" align=\"right\" alt=\"Topic Number $topicid\" /><br />
	Topic Name: (just a name for your topic - max: 40 characters)<br />
	<input type=\"text\" name=\"topictext\" size=\"40\" maxlength=\"40\" value=\"$topictext\" /><br /><br />
	Topic Image: (current image is shown, upload newer image here)<br />
	<input type=\"file\" name=\"topicimage\" /><br />or <input type=\"checkbox\" name=\"blank_image\" value=\"1\" />&nbsp;No Image?<br /><br />
	";
	}

	$result2 = mysql_query("select topicid, topictext from topics where topicparent=0 order by topictext");
	$boxcontent.="Under topic:<br />
	<select name=\"topicparent\">
	<option value=\"0\">None</option>
	";

	while(list($tmptopicid, $topictext) = mysql_fetch_row($result2))
	{
		if ($topicid == $tmptopicid)
			continue;
		if ($topicparent == $tmptopicid)
			$boxcontent.="<option value=\"$tmptopicid\" selected=\"selected\">$topictext</option>";
		else
			$boxcontent.="<option value=\"$tmptopicid\">$topictext</option>";

		$result3 = mysql_query("select topicid, topictext from topics where topicparent=$tmptopicid order by topictext");
		while(list($tmptopicid, $childtopictext) = mysql_fetch_row($result3))
		{
			if ($topicid == $tmptopicid)
				continue;
			if ($topicparent == $tmptopicid)
				$boxcontent.="<option value=\"$tmptopicid\" selected=\"selected\">$topictext / $childtopictext</option>";
			else
				$boxcontent.="<option value=\"$tmptopicid\">$topictext / $childtopictext</option>";
		}
	}

	$boxcontent.="
        </select><br /><br />
        Topic Long Text: (a long description for your topic)<br />
        <textarea name=\"topiclongtext\" rows=\"8\" cols=\"51\">$topiclongtext</textarea><br />
	<input type=\"hidden\" name=\"topicid\" value=\"$topicid\" />
	<input type=\"hidden\" name=\"old_topicimage\" value=\"$topicimage\" />
	<input type=\"hidden\" name=\"op\" value=\"topicchange\" /><br />
	<input type=\"submit\" name=\"save\" value=\"Save Changes\" />
	<input type=\"submit\" name=\"delete\" value=\"Delete Topic\" />
	</form>
	";
	thememainbox($boxtitle,$boxcontent);
	include("footer.php");
}


function topicmake($topicparent, $topicname, $topicimage, $topictext, $topiclongtext, $topicimage_name, $topicimage_type, $topicimage_size)
{
	include("config.php");
	if($topicimage != "none"){
	  if($topicimage_size > $max_user_file_size)
	    page_error("$topicimage_name : The image you are trying to upload is too large. <br />
	            The largest allowable size is: $max_user_file_size b.<br />
		    Your file is: $topicimage_size b.");
	  
		if(substr_count($topicimage_type, ";"))
		{
			$stuff = explode(";", $topicimage_type);
			$this_image_type = $stuff[0];
		}
		else
		$this_image_type = $topicimage_type;

		if(substr_count($allowed_types, $this_image_type) > 0)
		{
			if(copy($topicimage, $tipath.$topicimage_name)){}
			else
			page_error("$topicimage_name : The image did not load sucessfully.  Please try again.<br />");
		}
		else
		page_error("$topicimage_name : This image is of the wrong file type.<br />
	                    The allowed types are: $allowed_types<br />
		            You file is of type: $topicimage_type");
	}
	else{
	  $topicimage_name="bl.gif";
	}
	$topicname = stripslashes(FixQuotes($topicname));
	$topicimage_name = stripslashes(FixQuotes($topicimage_name));
	$topictext = stripslashes(FixQuotes($topictext));
	$topiclongtext = stripslashes(FixQuotes($topiclongtext));

	mysql_query("INSERT INTO topics (topicparent, topicname, topicimage, topictext, topiclongtext, counter) VALUES ('$topicparent','$topicname','$topicimage_name','$topictext','$topiclongtext','0')");
}

function topicchange($topicid, $topicparent, $topicname, $topicimage, $topictext, $topiclongtext, $topicimage_name, $topicimage_type, $topicimage_size, $flag)
{
	include("config.php");

	if($flag)
	{
		if($topicimage_size > $max_user_file_size)
		page_error("$topicimage_name : The image you are trying to upload is too large. <br />
	        	    The largest allowable size is: $max_user_file_size b.<br />
			    Your file is: $topicimage_size b.");

		if(substr_count($topicimage_type, ";"))
		{
			$stuff = explode(";", $topicimage_type);
			$this_image_type = $stuff[0];
		}
		else
		$this_image_type = $topicimage_type;

		if(substr_count($allowed_types, $this_image_type) > 0)
		{
			if(copy($topicimage, $tipath.$topicimage_name)){}
			else
			page_error("$topicimage_name : The image did not load sucessfully.  Please try again.<br />");
		}
		else
		page_error("$topicimage_name : This image is of the wrong file type.<br />
	                    The allowed types are: $allowed_types<br />
		            You file is of type: $topicimage_type");
	}

	$topicname = stripslashes(FixQuotes($topicname));
	$topicimage_name = stripslashes(FixQuotes($topicimage_name));
	$topictext = stripslashes(FixQuotes($topictext));
	$topiclongtext = stripslashes(FixQuotes($topiclongtext));

	mysql_query("update topics set topicparent='$topicparent', topicname='$topicname', topicimage='$topicimage_name', topictext='$topictext', topiclongtext='$topiclongtext' where topicid=$topicid");
}

function topicdelete($topicid, $ok=0)
{
	if ($ok==1)
	{
		mysql_query("update topics set topicparent='0' where topicparent='$topicid'");
		$result=mysql_query("select sid from stories where topic='$topicid'");
		list($sid) = mysql_fetch_row($result);
		mysql_query("delete from stories where topic='$topicid'");
		mysql_query("delete from topics where topicid='$topicid'");
		$result = mysql_query("select sid from comments where sid='$sid'");
		list($sid) = mysql_fetch_row($result);
		mysql_query("delete from comments where sid='$sid'");
		Header("Location: admin.php?op=topicsmanager");
	}
	else
	{
		include("header.php");
		GraphicAdmin(0);
		$result2=mysql_query("select topicimage, topictext from topics where topicid='$topicid'");
		list($topicimage, $topictext) = mysql_fetch_row($result2);

		echo "
	<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\" width=\"95%\">
	<tr>
	<td class=\"type0\">
	<table border=\"0\" cellpadding=\"1\" cellspacing=\"0\" width=\"100%\">
	<tr>
	<td class=\"type5\"><img src=\"$tipath$topicimage\" border=\"0\" alt=\"Topic Number $topicid\" /><br />
	<span class=\"boldtext\">Delete Topic $topictext</span><br /><br />
	Are you sure you want to delete Topic $topictext?<br />
	This will delete ALL its stories and its comments!<br /><br />
	[ <a href=\"admin.php?op=topicsmanager\">No</a> | <a href=\"admin.php?op=topicdelete&amp;topicid=$topicid&amp;ok=1\">Yes</a> ]</center><br /><br />
	</td>
	</tr>
	</table>
	</td>
	</tr>
	</table>
		";
		include("footer.php");
	}
}

function topicerror($message)
{
	include ("header.php");
	GraphicAdmin(0);

	echo "
<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
<tr>
	<td type=\"0\">
<table border=\"0\" width=\"100%\" cellpadding=\"5\" cellspacing=\"1\">
<tr>
	<td class=\"type4\"><spann class=\"onebiggerred\">Data Error!!</span></td>
</tr>
<tr>
	<td class=\"type5\" align=\"center\"><b>The following error has occurred:</b><br /><br />
	$message<br /><br />
        Please hit the back button on your browser and re-submit your data.
        </td>
</tr>
</table>
</td></tr></table>
        ";

	include("footer.php");
	exit();
}

?>
