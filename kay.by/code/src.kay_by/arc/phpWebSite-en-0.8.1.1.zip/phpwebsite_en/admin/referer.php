<?PHP

#####################################################
#    Referrer Functions:                             #
#       Used to track who links to the web site.    #
#####################################################

function hreferer($sortby, $filter)
{
	if (!isset($sortby))
		$sortby="hit_total";

	if (!isset($filter))
		$filter="all";

	include ("header.php");
	include("config.php");
	GraphicAdmin(0);

	$box_title = "HTTP Referrers Outside of <a href=\"$nuke_url\">$nuke_url</a>";
	$box_stuff = "";

	if ($sortby == "url")
		$direction = "asc";
	else
		$direction = "desc";

	if ($filter != 'all')
		$filter_str = "where hit_total >= '$filter'";
	else
		$filter_str = "";	

        $sql_result = mysql_query("select url, hit_total, time from new_referer $filter_str order by $sortby $direction");
        if ($sql_result == 0){
                $box_stuff = "MySQL says:" . mysql_error(). "<br />";
		$box_stuff .= "select url, hit_total, time from new_referer $filter_str order by $sortby $direction";
		themesidebox($box_title, $box_stuff);
}
        if (mysql_num_rows($sql_result) > 0)
        {
		$box_stuff = "
	<!-- Begin referer.php -->
	<table cellspacing=\"0\" cellpadding=\"2\" border=\"0\" width=\"99%\">
	<tr>
		<td class=\"type2\" align=\"left\">URL</td>
		<td class=\"type2\" align=\"center\">Total Hits</td>
		<td class=\"type2\" align=\"center\">Last Hit</td>
	</tr>";

                while ( list($url, $hits, $last_hit) = mysql_fetch_row ($sql_result) ) {
			$box_stuff .= "
	<tr>
		<td class=\"type5\"><a href=\"$url\" target=\"_blank\">";
			if (strlen($url) > 60)
				$box_stuff .= substr($url,0,60) . "... ";
			else
				$box_stuff .= $url;

			$box_stuff .= "</a></td>
		<td class=\"type5\" align=\"right\">$hits</td>
		<td class=\"type5\" align=\"right\">$last_hit</td>
	</tr>";
                }
        } else
                        $box_stuff = "<br /><span class=\"type5bigger\">None found</span><br /><br />";

#####################################



        $box_stuff .= "
	<tr>
	<td class=\"type4\" align=\"left\" width=\"50%\" colspan=\"3\">
		<table cellpadding=\"1\" cellspacing=\"0\" border=\"0\" width=\"99%\">
		<tr>
			<td class=\"type4\" align=\"left\" width=\"50%\">
			<form action=\"admin.php\" method=\"post\">
			Order by:
			<input type=\"hidden\" name=\"op\" value=\"hreferer\" />
			<input type=\"hidden\" name=\"filter\" value=\"$filter\" />
			<select name=\"sortby\">
				<option value=\"hit_total\"";
	if ($sortby=="hit_total")
		$box_stuff .= " selected";

	$box_stuff .= ">Total Hits</option>
			<option value=\"url\"";
        if ($sortby=="url")
                $box_stuff .= " selected";

	$box_stuff .= ">Name</option>
			<option value=\"time\"";
        if ($sortby=="time")
                $box_stuff .= " selected";

        $box_stuff .= ">Last On</option>
			</select>
			<input type=\"submit\" value=\"&nbsp;&nbsp;&nbsp;&nbsp;Go!&nbsp;&nbsp;&nbsp;&nbsp;\" />
			</form>
			</td>
			<td class=\"type4\" align=\"right\" width=\"50%\">
       		 	<form action=\"admin.php\" method=\"post\">
		Filter:
        	        <input type=\"hidden\" name=\"op\" value=\"hreferer\" />
			<input type=\"hidden\" name=\"sortby\" value=\"$sortby\" />
               		<select name=\"filter\">
                        <option value=\"all\"";
        if ($filter=="all")
                $box_stuff .= " selected";

        $box_stuff .= ">All</option>
                        <option value=\"5\"";
        if ($filter=="5")
                $box_stuff .= " selected";

        $box_stuff .= ">Over 5</option>
                        <option value=\"25\"";
        if ($filter=="25")
                $box_stuff .= " selected";

        $box_stuff .= ">Over 25</option>
			<option value=\"50\"";
        if ($filter=="50")
                $box_stuff .= " selected";

        $box_stuff .= ">Over 50</option>
			<option value=\"100\"";
        if ($filter=="100")
                $box_stuff .= " selected";

        $box_stuff .= ">Over 100</option>
			<option value=\"250\"";
        if ($filter=="250")
                $box_stuff .= " selected";

        $box_stuff .= ">Over 250</option>
			<option value=\"1000\"";
        if ($filter=="1000")
                $box_stuff .= " selected";

        $box_stuff .= ">Over 1000</option>
			<option value=\"5000\"";
        if ($filter=="5000")
                $box_stuff .= " selected";

        $box_stuff .= ">Over 5000</option>
			<option value=\"10000\"";
        if ($filter=="10000")
                $box_stuff .= " selected";

        $box_stuff .= ">Over 10000</option>
                </select>
                <input type=\"submit\" value=\"&nbsp;&nbsp;&nbsp;&nbsp;Go!&nbsp;&nbsp;&nbsp;&nbsp;\" />
        	</form>
        	</td>
		</tr>
		</table>
	</td>
</tr>
<tr>
        <td class=\"type4\" align=\"center\" colspan=\"3\">
        <form action=\"admin.php\" method=\"post\">
                <input type=\"hidden\" name=\"op\" value=\"delreferer\" />
                <input type=\"submit\" value=\"Delete Referrers\" />
        </form>
        </td>
</tr>
</table>
<!-- End of referrers -->
";
        themesidebox($box_title, $box_stuff);
        include ("footer.php");
}

function delreferer($action)
{
        include("config.php");

	if ($action == 'yes'){
	        mysql_query("delete from new_referer");
	        Header("Location: admin.php?op=hreferer");
	}
	else if ($action == 'no')
		Header("Location: admin.php?op=hreferer");

	else {
		include ("header.php");
		$title = "Delete Referrers";
		$content ="<span class=\"onebiggerred\">Are you sure you want to delete ALL of the referrers?</span><br />
		<a href=\"admin.php?op=delreferer&amp;action=yes\">YES</a>
		&nbsp;&nbsp;&nbsp;
		<a href=\"admin.php?op=hreferer&amp;action=no\">NO</a>";
		themesidebox ($title, $content);
	}
	include("footer.php");
}

?>
