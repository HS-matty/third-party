<?php
function delete_child($one, $two, $three, $four, $five, $six) {
//Takes in values and deletes that item and all children underneath it - confirms deletion
include ("./header.php");
$stuff .= "<form action=\"./admin.php?op=help_delete_child\" method=\"post\">\n";
	$result = mysql_query("SELECT * FROM help WHERE one='$one' AND two='$two' AND three='$three' AND four='$four' AND five='$five' AND six='$six'");
	while ($row = mysql_fetch_array($result)) {
		$name = $row["name"];
	}
$stuff .= "<p>Are you sure you want to delete the branch named $name?</p>\n
	<p>\n
	<input type=\"radio\" name=\"go\" value=\"13\" />Yes\n
	<input type=\"radio\" name=\"stop\" value=\"13\" />No\n
	<input type=\"hidden\" name=\"change\" value=\"1\" />\n
	<input type=\"hidden\" name=\"one\" value=\"$one\" />\n
	<input type=\"hidden\" name=\"two\" value=\"$two\" />\n
	<input type=\"hidden\" name=\"three\" value=\"$three\" />\n
	<input type=\"hidden\" name=\"four\" value=\"$four\" />\n
	<input type=\"hidden\" name=\"five\" value=\"$five\" />\n
	<input type=\"hidden\" name=\"six\" value=\"$six\" />\n
	<input type=\"submit\" value=\"Submit\" /></p>";
themesidebox("Delete", $stuff);
include ("./footer.php");
}

function add_child($code, $name, $description, $one, $two, $three, $four, $five, $six) {
//Takes values and makes database entries under given values - error checks for duplicate names
include ("./header.php");
if($code) { $stuff .= "<h3>\"$name\" Exists! or Invalid</h3>"; }
$stuff .= "<form action=\"./admin.php?op=help_add_child\" method=\"post\">\n
	<p>Name:<input type=\"text\" value=\"$name\" size=\"50\" maxlength=\"50\" name=\"name\" /></p>\n
	<p>Description:<br /><textarea name=\"description\" cols=\"50\" rows=\"10\" wrap=\"soft\">$description</textarea></p>\n
	<p><input type=\"hidden\" name=\"change_ok\" value=\"1\" />
<input type=\"hidden\" name=\"one\" value=\"$one\" />\n
<input type=\"hidden\" name=\"two\" value=\"$two\" />\n
<input type=\"hidden\" name=\"three\" value=\"$three\" />\n
<input type=\"hidden\" name=\"four\" value=\"$four\" />\n
<input type=\"hidden\" name=\"five\" value=\"$five\" />\n
<input type=\"hidden\" name=\"six\" value=\"$six\" />\n
<input type=\"hidden\" name=\"change_ok\" value=\"1\" />\n
</p>\n<input type=\"submit\" value=\"Submit\" /><br /></p></form>";
themesidebox("Add", $stuff);
include ("./footer.php");
}

function modify_child($code, $name, $description, $one, $two, $three, $four, $five, $six) {
//Takes values and create small form for updating item - error checks for duplicate names
include ("./header.php");
if($code) { $stuff .= "<h3>\"$name\" Exists!</h3>"; }
$stuff .= "<form action=\"./admin.php?op=help_modify_child\" method=\"post\">\n
	<p>Name:<input type=\"text\" value=\"$name\" size=\"50\" maxlength=\"50\" name=\"name\" /></p>\n
	<p>Description:<br /><textarea name=\"description\" cols=\"50\" rows=\"10\" wrap=\"soft\">$description</textarea></p>\n
	<p><input type=\"hidden\" name=\"change_ok\" value=\"1\" />\n
<input type=\"hidden\" name=\"one\" value=\"$one\" />\n
<input type=\"hidden\" name=\"two\" value=\"$two\" />\n
<input type=\"hidden\" name=\"three\" value=\"$three\" />\n
<input type=\"hidden\" name=\"four\" value=\"$four\" />\n
<input type=\"hidden\" name=\"five\" value=\"$five\" />\n
<input type=\"hidden\" name=\"six\" value=\"$six\" />\n
</p>\n
	<p><input type=\"submit\" value=\"Submit\" /><br /></p>\n</form>";
themesidebox ("Edit", $stuff);
include ("./footer.php");
}

function family_tree() {
//Shows all database items in a nested fashion - links go to modify_child

$result = mysql_query("SELECT admin FROM help ORDER BY admin ASC");
while ($row = mysql_fetch_array($result)) {
	$active_admin = $row["admin"];
}
$list .= "[ <a href=\"./admin.php?op=help_add_child\">Add Top Level Item</a> ";
if ($active_admin) {
	$list .= "| <a href=\"./admin.php?op=deactivate_admin\">Clear Administration Section</a> ]";
}else{
	$list .= "] <br /><br />&#167; = Mark Administration Section";
}
$list .= "<br /><br />";
$result = mysql_query("SELECT * FROM help ORDER BY one, two, three, four, five, six");
while ($row = mysql_fetch_array($result)) {
	$name = $row["name"];
	$one = $row["one"];
	$two = $row["two"];
	$three = $row["three"];
	$four = $row["four"];
	$five = $row["five"];
	$six = $row["six"];
	$admin_bool = $row["admin"];
$modify_link = "<a href=\"./admin.php?op=help_modify_child&amp;one=$one&amp;two=$two&amp;three=$three&amp;four=$four&amp;five=$five&amp;six=$six\">";
$add_link = "&nbsp;[ <a href=\"./admin.php?op=help_add_child&amp;one=$one&amp;two=$two&amp;three=$three&amp;four=$four&amp;five=$five&amp;six=$six\"> Add</a> ";
$delete_link = "<a href=\"./admin.php?op=help_delete_child&amp;one=$one&amp;two=$two&amp;three=$three&amp;four=$four&amp;five=$five&amp;six=$six\"> Delete</a> ]"; 
if (!$active_admin) {
$admin_link = "<a 
href=\"./admin.php?op=activate_admin&amp;one=$one&amp;two=$two&amp;three=$three&amp;four=$four&amp;five=$five&amp;six=$six\"> 
<span style=\"font-size : 1em; text-decoration : none\"> &#167;</span></a>"; }else{
$admin_link = "";
}
// the variable $admin_bool will designate administrative sections
if($one && !$two) {
$list .= "<div style=\"text-indent : 0em";
$list .= admin_indicator($admin_bool);
$list .= "$one. $modify_link $name</a> $add_link | $delete_link $admin_link </div>"; 
}elseif ($two && !$three) {
$list .= "<div style=\"text-indent : 1em";
$list .= admin_indicator($admin_bool);
$list .= "$one.$two $modify_link $name</a> $add_link | $delete_link $admin_link </div>"; 
}elseif ($three && !$four) {
$list .= "<div style=\"text-indent : 2em";
$list .= admin_indicator($admin_bool);
$list .= "$one.$two.$three $modify_link $name</a> $add_link | $delete_link $admin_link </div>";
}elseif ($four && !$five) {
$list .= "<div style=\"text-indent : 3em";
$list .= admin_indicator($admin_bool);
$list .= "$one.$two.$three.$four $modify_link $name</a> $add_link | $delete_link $admin_link </div>";
}elseif ($five && !$six) {
$list .= "<div style=\"text-indent : 4em";
$list .= admin_indicator($admin_bool);
$list .= "$one.$two.$three.$four.$five $modify_link $name</a> $add_link | $delete_link $admin_link </div>";
}elseif ($six) {
$list .= "<div style=\"text-indent : 5em";
$list .= admin_indicator($admin_bool);
$list .="$one.$two.$three.$four.$five.$six $modify_link $name</a> &nbsp;[ $delete_link </div>";
}else{
$list .= "ERROR";
}
}
return $list;
}
function admin_indicator($admin_bool)
{
	//Change this to whatevery you would like the administrative level indicator to be, highlight would be good here.
if($admin_bool) { return "; color : red\">"; }else{ return "\">"; }
}

function help_main() {
include ("./header.php");
GraphicAdmin("");
themesidebox("Help System", family_tree());
include ("./footer.php");
}

?>
