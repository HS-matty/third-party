<?php

######################################################################
#
# phpWebSite: Web Content Management and Portal System
# =====================================================
#
# Copyright (c) 2000 by Appalachian State University
# Web Technology Group, Student Development
#
#
# This software contains GPL code from the following:
#
# PHP-NUKE: Web Portal System
# ===========================
#
# Copyright (c) 2000 by Francisco Burzi (fburzi@ncc.org.ve)
# http://www.ncc.org.ve/php-nuke.php
#
# This modules is to have special sections for articles, reviews, etc.
#
# This program is free software. You can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License.
#
# This file has been edited by the following developers with Appalachian
# State Universitys Web Technology Group:
#
#	Adam Morton, am26882@appstate.edu
#       Brian Lambeth, bl31705@appstate.edu
#
######################################################################


/*********************************************************/
/* New Block Functions                                   */
/*                                                       */
/* Admin Functions for new block code                    */
/* Jason Campbell, campbelljd@xplozivemedia.com          */
/*********************************************************/

function blocks()
{
	include("header.php");
	GraphicAdmin(0);

	echo "<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
<tr>
	<td class=\"type0\">
<table width=\"100%\" border=\"0\" cellpadding=\"8\" cellspacing=\"1\">
<tr>
	<td class=\"type4\">Edit Blocks</td></tr>
<tr>
	<td class=\"type5\">
	";
	$result = mysql_query("select id, block_level, block_location, block_secid, block_title, block_content, block_active, block_name, block_php from blocks ORDER BY block_location,block_level");

	if (mysql_num_rows($result) > 0)
	{
		while(list($id, $block_level, $block_location, $block_secid, $block_title, $block_content, $block_active, $block_name, $block_php) = mysql_fetch_array($result))
		{
			?>
	<form action="admin.php" method="post">
	Title:
	<input type="text" name="title" size="30" maxlength="60" value="<?php echo $block_title; ?>" /><br />
	Content:
	<br />
	<?php
	$temptext = htmlspecialchars($block_content);
	?>
	<textarea cols="50" rows="6" name="content" wrap=\"virtual\"><?php echo $temptext; ?></textarea><br />
	<input type="hidden" name="id" value="<?php echo $id; ?>" />
	<select name="op">
	<option value="changelblock">Change Block</option>
	<option value="deletelblock">Delete Block</option>
	</select>
	<input type="submit" value="Go!" />
	</form>
	<br /><br />
			<?php
		}
	}
	echo "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"70%\" align=\"center\">
<tr>
	<td class=\"type0\">
<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
<tr>
	<td class=\"type4\">Create New Block	</td>
</tr>

<tr>
	<td class=\"type5\">";

	?>

	<form action="admin.php" method="post">
	Title:<input type="text" name="title" size="30" maxlength="60" /><br />
	Content:<br />
	<textarea cols="50" rows="6" name="content" wrap=\"virtual\"></textarea><br />
	<input type="hidden" name="op" value="makeblock" />
	<input type="submit" value="Make Block" />
	</form>
	</td>
</tr>
</table>	</td>
</tr>
</table>
</td>
</tr>
</table>
	</td>
</tr>
</table>
	<?php
	include("footer.php");
}

function makeblock($title, $content)
{
	$title = stripslashes(FixQuotes($title));
	$content = stripslashes(FixQuotes($content));
	mysql_query("INSERT INTO blocks VALUES (NULL,'$title','$content')");
	Header("Location: admin.php?op=blocks");
}

function changeblock($id, $title, $content)
{
	$title = stripslashes(FixQuotes($title));
	$content = stripslashes(FixQuotes($content));
	mysql_query("update blocks set title='$title', content='$content' where id=$id");
	Header("Location: admin.php?op=blocks");
}

function deleteblock($id)
{
	mysql_query("delete from blocks where id='$id'");
	Header("Location: admin.php?op=blocks");
}


/*********************************************************/
/* RIGHT Blocks Functions                                */
/*********************************************************/

function rblocks()
{
	include("header.php");
	GraphicAdmin(0);

	$boxtitle="Create New Right Block";
	$boxcontent="
	<form action=\"admin.php\" method=\"post\">
	Title:<input type=\"text\" name=\"title\" size=\"30\" maxlength=\"60\" /><br />
	Content:<br />
	<textarea cols=\"50\" rows=\"6\" name=\"content\" wrap=\"virtual\"></textarea><br />
	<input type=\"hidden\" name=\"op\" value=\"makerblock\" />
	<input type=\"submit\" value=\"Make Right Block\" />
	</form>
	<br />";
	thememainbox($boxtitle,$boxcontent);

	$result = mysql_query("select id, title, content, order_id from rblocks order by order_id");

	if (mysql_num_rows($result) > 0)
	{
		$boxtitle="Edit Right Blocks";
		$boxcontent="";
		while(list($id, $title, $content, $order_id) = mysql_fetch_array($result))
		{

        $boxcontent.="
	<form action=\"admin.php\" method=\"post\">
	Title:
	<input type=\"text\" name=\"title\" size=\"30\" maxlength=\"50\" value=\"$title\" /><br />
	Content:
	<br />";
		$temptext = htmlspecialchars($content);
	$boxcontent.="
	<textarea cols=\"50\" rows=\"6\" name=\"content\" wrap=\"virtual\">$temptext</textarea><br />
	Move Block:
	<a href=\"admin.php?op=rblock_order&amp;action=up&amp;id=$id\"><img src=\"./images/menu/up.gif\" border=\"0\" alt=\"Move up\" /></a>
	<a href=\"admin.php?op=rblock_order&amp;action=down&amp;id=$id\"><img src=\"./images/menu/down.gif\" border=\"0\" alt=\"Move down\" /></a>
	<br />
	<select name=\"op\">
	<option value=\"changerblock\">Change Right Block</option>
	<option value=\"deleterblock\">Delete Right Block</option>
	</select>
	<input type=\"hidden\" name=\"id\" value=\"$id\" />
	<input type=\"hidden\" name=\"order_id\" value=\"$order_id\" />
	<input type=\"submit\" value=\"Go!\" />
	</form>
	<br /><br />";

		}
	thememainbox($boxtitle,$boxcontent);
	}

	include("footer.php");
}

function rblock_order($id, $action)
{
	$result = mysql_query("select order_id from rblocks where id='$id'");
	list($current_order) = mysql_fetch_row($result);
	$result = mysql_query("select max(order_id) from rblocks");
	list($max_order) = mysql_fetch_row($result);

	if($action == 'up')
	{
		if($current_order == '1')
		{
			mysql_query("update rblocks set order_id=order_id-1 where id!='$id'");
			mysql_query("update rblocks set order_id='$max_order' where id='$id'");
		}
		else
		{
			$new_order = $current_order - 1;
			$result = mysql_query("select id from rblocks where order_id='$new_order'");
			list($id2) = mysql_fetch_row($result);
			mysql_query("update rblocks set order_id='$current_order' where id='$id2'");
			mysql_query("update rblocks set order_id='$new_order' where id='$id'");
		}
	}
	else if($action == 'down')
	{
		if($current_order == $max_order)
		{
			mysql_query("update rblocks set order_id=order_id+1 where id!='$id'");
			mysql_query("update rblocks set order_id='1' where id='$id'");
		}
		else
		{
			$new_order = $current_order + 1;
			$result = mysql_query("select id from rblocks where order_id='$new_order'");
			list($id2) = mysql_fetch_row($result);
			mysql_query("update rblocks set order_id='$current_order' where id='$id2'");
			mysql_query("update rblocks set order_id='$new_order' where id='$id'");
		}
	}
	else page_error("Invalid action: $action");

	Header("Location: admin.php?op=rblocks");
}

function makerblock($title, $content)
{
	$title = stripslashes(FixQuotes($title));
	$content = stripslashes(FixQuotes($content));

	mysql_query("LOCK TABLES rblocks WRITE");
	$result = mysql_query("select max(order_id) from rblocks");
	list($order_id) = mysql_fetch_row($result);
	$order_id++;
	mysql_query("INSERT INTO rblocks VALUES (NULL,'$title','$content','$order_id')");
	mysql_query("UNLOCK TABLES");

	Header("Location: admin.php?op=rblocks");
}

function changerblock($id, $title, $content)
{
	$title = stripslashes(FixQuotes($title));
	$content = stripslashes(FixQuotes($content));
	mysql_query("update rblocks set title='$title', content='$content' where id=$id");
	Header("Location: admin.php?op=rblocks");
}

function deleterblock($id, $order_id)
{
	mysql_query("update rblocks set order_id=order_id-1 where order_id>'$order_id'");
	mysql_query("delete from rblocks where id='$id'");
	Header("Location: admin.php?op=rblocks");
}


/*********************************************************/
/* LEFT Block Functions                                  */
/*********************************************************/

function lblocks()
{
	include("header.php");
	GraphicAdmin(0);

	$boxtitle="Create New Left Block";
	$boxcontent="
	<form action=\"admin.php\" method=\"post\">
	Title:<input type=\"text\" name=\"title\" size=\"30\" maxlength=\"60\" /><br />
	Content:<br />
	<textarea cols=\"50\" rows=\"6\" name=\"content\" wrap=\"virtual\"></textarea><br />
	<input type=\"hidden\" name=\"op\" value=\"makelblock\" />
	<input type=\"submit\" value=\"Make Left Block\" />
	</form>
	<br />";
	thememainbox($boxtitle,$boxcontent);

	$result = mysql_query("select id, title, content, order_id from lblocks order by order_id");

	if (mysql_num_rows($result) > 0)
	{
		$boxtitle="Edit Left Blocks";
		$boxcontent="";
		while(list($id, $title, $content, $order_id) = mysql_fetch_array($result))
		{
	$boxcontent.="
	<form action=\"admin.php\" method=\"post\">
	Title:
	<input type=\"text\" name=\"title\" size=\"30\" maxlength=\"60\" value=\"$title\" /><br />
	Content:
	<br />";
	$temptext = htmlspecialchars($content);
	$boxcontent.="<textarea cols=\"50\" rows=\"6\" name=\"content\" wrap=\"virtual\">$temptext</textarea><br />
	Move Block:
	<a href=\"admin.php?op=lblock_order&amp;action=up&amp;id=$id\"><img src=\"./images/menu/up.gif\" border=\"0\" alt=\"Move up\" /></a>
	<a href=\"admin.php?op=lblock_order&amp;action=down&amp;id=$id\"><img src=\"./images/menu/down.gif\" border=\"0\" alt=\"Move down\" /></a>
	<br />
	<select name=\"op\">
	<option value=\"changelblock\">Change Left Block</option>
	<option value=\"deletelblock\">Delete Left Block</option>
	</select>
	<input type=\"hidden\" name=\"id\" value=\"$id\" />
	<input type=\"hidden\" name=\"order_id\" value=\"$order_id\" />
	<input type=\"submit\" value=\"Go!\" />
	</form>
	<br /><br />";

		}
	thememainbox($boxtitle,$boxcontent);
	}


	include("footer.php");
}

function lblock_order($id, $action)
{
	$result = mysql_query("select order_id from lblocks where id='$id'");
	list($current_order) = mysql_fetch_row($result);
	$result = mysql_query("select max(order_id) from lblocks");
	list($max_order) = mysql_fetch_row($result);

	if($action == 'up')
	{
		if($current_order == '1')
		{
			mysql_query("update lblocks set order_id=order_id-1 where id!='$id'");
			mysql_query("update lblocks set order_id='$max_order' where id='$id'");
		}
		else
		{
			$new_order = $current_order - 1;
			$result = mysql_query("select id from lblocks where order_id='$new_order'");
			list($id2) = mysql_fetch_row($result);
			mysql_query("update lblocks set order_id='$current_order' where id='$id2'");
			mysql_query("update lblocks set order_id='$new_order' where id='$id'");
		}
	}
	else if($action == 'down')
	{
		if($current_order == $max_order)
		{
			mysql_query("update lblocks set order_id=order_id+1 where id!='$id'");
			mysql_query("update lblocks set order_id='1' where id='$id'");
		}
		else
		{
			$new_order = $current_order + 1;
			$result = mysql_query("select id from lblocks where order_id='$new_order'");
			list($id2) = mysql_fetch_row($result);
			mysql_query("update lblocks set order_id='$current_order' where id='$id2'");
			mysql_query("update lblocks set order_id='$new_order' where id='$id'");
		}
	}
	else page_error("Invalid action: $action");

	Header("Location: admin.php?op=lblocks");
}

function makelblock($title, $content)
{
	$title = stripslashes(FixQuotes($title));
	$content = stripslashes(FixQuotes($content));

	mysql_query("LOCK TABLES lblocks WRITE");
	$result = mysql_query("select max(order_id) from lblocks");
	list($order_id) = mysql_fetch_row($result);
	$order_id++;
	mysql_query("INSERT INTO lblocks VALUES (NULL,'$title','$content','$order_id')");
	mysql_query("UNLOCK TABLES");

	Header("Location: admin.php?op=lblocks");
}

function changelblock($id, $title, $content)
{
	$title = stripslashes(FixQuotes($title));
	$content = stripslashes(FixQuotes($content));
	mysql_query("update lblocks set title='$title', content='$content' where id=$id");
	Header("Location: admin.php?op=lblocks");
}

function deletelblock($id, $order_id)
{
	mysql_query("update lblocks set order_id=order_id-1 where order_id>'$order_id'");
	mysql_query("delete from lblocks where id='$id'");
	Header("Location: admin.php?op=lblocks");
}

?>
