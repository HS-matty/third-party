<?PHP

############################################################
#    Banners Administration Functions:                     #
#       No information at this time on these functions.    #
############################################################

function BannersAdmin()
{
	include ("header.php");
	GraphicAdmin(0);
	dbconnect();
	echo "<span class=\"type4\"><b>Banners Administration</b></span><br /><br />";

// Banners List
	$boxtitle="Current Active Banners";
	$boxcontent="<br />
<table width=\"100%\" border=\"0\" class=\"type5\">
<tr class=\"type6\">
	<td>ID</td>
	<td>Impressions</td>
	<td>Imp. Left</td>
	<td>Clicks</td>
	<td>% Clicks</td>
	<td>Client Name</td>
	<td>Functions</td>
</tr>
<tr>
	";
	$result = mysql_query("select bid, cid, imptotal, impmade, clicks, date from banner order by bid");

	while(list($bid, $cid, $imptotal, $impmade, $clicks, $date) = mysql_fetch_row($result))
	{
		$result2 = mysql_query("select cid, name from bannerclient where cid=$cid");
		list($cid, $name) = mysql_fetch_row($result2);

		if($impmade==0)
		{
			$percent = 0;
		}
		else
		{
			$percent = substr(100 * $clicks / $impmade, 0, 5);
		}

		if($imptotal==0)
		{
			$left = "Unlimited";
	    	}
		else
		{
			$left = $imptotal-$impmade;
	    	}
	    	$boxcontent.="
	<td>$bid</td>
	<td>$impmade</td>
	<td>$left</td>
	<td>$clicks</td>
	<td>$percent%</td>
	<td>$name</td>
	<td>
	<a href=\"admin.php?op=BannerEdit&amp;bid=$bid\">Edit</a>
	 | <a href=\"admin.php?op=BannerDelete&amp;bid=$bid&amp;ok=0\">Delete</a></td>
</tr>
<tr>
		";
	}

	$boxcontent.="</td></tr></table><br />";
	thememainbox($boxtitle,$boxcontent);

// Finished Banners List
	$boxtitle="Finished Banners";
	$boxcontent="<br />

<table width=\"100%\" border=\"0\" class=\"type5\">
<tr class=\"type6\">
	<td>ID</td>
	<td>Imp.</td>
	<td>Clicks</td>
	<td>% Clicks</td>
	<td>Date Started</td>
	<td>Date Ended</td>
	<td>Client Name</td>
	<td>Functions</td>
</tr>
<tr>
	";
	$result = mysql_query("select bid, cid, impressions, clicks, datestart, dateend from bannerfinish order by bid");

	while(list($bid, $cid, $impressions, $clicks, $datestart, $dateend) = mysql_fetch_row($result))
	{
	$result2 = mysql_query("select cid, name from bannerclient where cid=$cid");
	list($cid, $name) = mysql_fetch_row($result2);
	$percent = substr(100 * $clicks / $impressions, 0, 5);
	$boxcontent.="
	<td>$bid</td>
	<td>$impressions</td>
	<td>$clicks</td>
	<td>$percent%</td>
	<td>$datestart</td>
	<td>$dateend</td>
	<td>$name</td>
	<td>
	<a href=\"admin.php?op=BannerFinishDelete&amp;bid=$bid\">Delete</a></td>
</tr>
<tr>
	    ";
	}
	$boxcontent.="</td></tr></table><br />";
	thememainbox($boxtitle,$boxcontent);

// Clients List
	$boxtitle="Advertising Clients";
	$boxcontent="<br />

<table width=\"100%\" border=\"0\" class=\"type5\">
<tr class=\"type6\">
	<td>ID</td>
	<td>Client Name</td>
	<td>Active Banners</td>
	<td>Contact Name</td>
	<td>Contact Email</td>
	<td>Functions</td>
</tr>
<tr>
	";
	$result = mysql_query("select cid, name, contact, email from bannerclient  order by cid");

	while(list($cid, $name, $contact, $email) = mysql_fetch_row($result))
	{
		$result2 = mysql_query("select cid from banner where cid=$cid");
		$numrows = mysql_num_rows($result2);
	$boxcontent.="
	<td>$cid</td>
	<td>$name</td>
	<td>$numrows</td>
	<td>$contact</td>
	<td>$email</td>
	<td>
	<a href=\"admin.php?op=BannerClientEdit&amp;cid=$cid\">Edit</a> |
	<a href=\"admin.php?op=BannerClientDelete&amp;cid=$cid\">Delete</a></td>
</tr>
<tr>
	";
	}

	$boxcontent.= "</td></tr></table><br />";
	thememainbox($boxtitle,$boxcontent);

// Add Banner
	$result = mysql_query("select * from bannerclient");
	$numrows = mysql_num_rows($result);

	if($numrows>0)
	{
	$boxtitle="Add a New Banner";
	$boxcontent="<br />
	<form action=\"admin.php?op=BannersAdd\" method=\"post\">
	Client Name <select name=\"cid\">";

		$result = mysql_query("select cid, name from bannerclient");
		while(list($cid, $name) = mysql_fetch_row($result))
		{
			$boxcontent.="<option value=\"$cid\">$name</option>";
		}
		$boxcontent.="</select><br />
		Impressions Purchased <input type=\"text\" name=\"imptotal\" size=\"12\" maxlength=\"11\" /> 0 = Unlimited<br />
		Image URL <input type=\"text\" name=\"imageurl\" size=\"50\" maxlength=\"100\" /><br />
		Click URL <input type=\"text\" name=\"clickurl\" size=\"50\" maxlength=\"200\" /><br />
		<input type=\"hidden\" name=\"op\" value=\"BannersAdd\" />
		<input type=\"submit\" value=\"Add Banner\" />
		</form>
		";
	thememainbox($boxtitle,$boxcontent);
    }
// Add Client
	$boxtitle="Add a New Client";
	$boxcontent="<br />
	<form action=\"admin.php?op=BannersAddClient\" method=\"post\">
	Client Name <input type=\"text\" name=\"name\" size=\"30\" maxlength=\"60\" /><br />
	Contact Name <input type=\"text\" name=\"contact\" size=\"30\" maxlength=\"60\" /><br />
	Contact Email <input type=\"text\" name=\"email\" size=\"30\" maxlength=\"60\" /><br />
	Client Login <input type=\"text\" name=\"login\" size=\"12\" maxlength=\"10\" /><br />
	Client Password <input type=\"text\" name=\"passwd\" size=\"12\" maxlength=\"10\" /><br />
	Extra Info<br /><textarea name=\"extrainfo\" cols=\"60\" rows=\"10\" wrap=\"virtual\"></textarea><br />
	<input type=\"hidden\" name=\"op\" value=\"BannerAddClient\" />
	<input type=\"submit\" value=\"Add Client\" />
	</form>";
	thememainbox($boxtitle,$boxcontent);
	include ("footer.php");
}

function BannersAdd($name, $cid, $imptotal, $imageurl, $clickurl)
{
	mysql_query("insert into banner values (NULL, '$cid', '$imptotal', '1', '0', '$imageurl', '$clickurl', now())");
	Header("Location: admin.php?op=BannersAdmin#top");
}

function BannerAddClient($name, $contact, $email, $login, $passwd, $extrainfo)
{
	mysql_query("insert into bannerclient values (NULL, '$name', '$contact', '$email', '$login', '$passwd', '$extrainfo')");
	Header("Location: admin.php?op=BannersAdmin#top");
}

function BannerFinishDelete($bid)
{
	mysql_query("delete from bannerfinish where bid=$bid");
	Header("Location: admin.php?op=BannersAdmin#top");
}

function BannerDelete($bid, $ok=0)
{
	if ($ok==1)
	{
		dbconnect();
		mysql_query("delete from banner where bid='$bid'");
		Header("Location: admin.php?op=BannersAdmin#top");
	}
	else
	{
		include("header.php");
		dbconnect();
		GraphicAdmin(0);
		$result=mysql_query("select cid, imptotal, impmade, clicks, imageurl, clickurl from banner where bid=$bid");
		list($cid, $imptotal, $impmade, $clicks, $imageurl, $clickurl) = mysql_fetch_row($result);

		$boxtitle="Delete Banner";
		$boxcontent="<br />
	<a href=\"$clickurl\"><img src=\"$imageurl\" border=\"1\" /></a><br />
	<a href=\"$clickurl\">$clickurl</a><br /><br />
<table width=\"100%\" border=\"0\" class=\"type5\">
<tr class=\"type6\">
	<td>ID</td>
	<td>Impressions</td>
	<td>Imp. Left</td>
	<td>Clicks</td>
	<td>% Clicks</td>
	<td>Client Name</td>
</tr>
<tr>
		";

		$result2 = mysql_query("select cid, name from bannerclient where cid=$cid");
		list($cid, $name) = mysql_fetch_row($result2);
		$percent = substr(100 * $clicks / $impmade, 0, 5);

		if($imptotal==0)
		{
			$left = unlimited;
		}
		else
		{
			$left = $imptotal-$impmade;
		}
		$boxcontent.="
	<td>$bid</td>
	<td>$impmade</td>
	<td>$left</td>
	<td>$clicks</td>
	<td>$percent%</td>
	<td>$name</td>
</tr>
<tr>
		";
	}
	$boxcontent.="</td></tr></table>
	<br />
	Are you sure you want to delete this Banner?<br /><br />
	[ <a href=\"admin.php?op=BannersAdmin#top\">No</a> | <a href=\"admin.php?op=BannerDelete&amp;bid=$bid&amp;ok=1\">Yes</a> ]
	<br />";
	thememainbox($boxtitle,$boxcontent);
	include("footer.php");
}

function BannerEdit($bid)
{
	include("header.php");
	dbconnect();
	GraphicAdmin(0);
	$result=mysql_query("select cid, imptotal, impmade, clicks, imageurl, clickurl from banner where bid=$bid");
	list($cid, $imptotal, $impmade, $clicks, $imageurl, $clickurl) = mysql_fetch_row($result);

	$boxtitle="Edit Banner";
	$boxcontent="<br />
	<img src=\"$imageurl\" border=\"1\" /><br /><br />
	<form action=\"admin.php?op=BannerChange\" method=\"post\">
	Client Name <select name=\"cid\">
	";

	$result = mysql_query("select cid, name from bannerclient where cid=$cid");
	list($cid, $name) = mysql_fetch_row($result);

	$boxcontent.="<option value=\"$cid\" selected=\"selected\">$name</option>";

	$result = mysql_query("select cid, name from bannerclient");

	while(list($ccid, $name) = mysql_fetch_row($result))
	{
		if($cid!=$ccid)
		{
			$boxcontent.="<option value=\"$ccid\">$name</option>";
		}
	}
	$boxcontent.="</select><br />";

	if($imptotal==0)
	{
		$impressions = "Unlimited";
	}
	else
	{
		$impressions = $imptotal;
	}

	$boxcontent.="
	Add More Impressions <input type=\"text\" name=\"impadded\" size=\"12\" maxlength=\"11\" /> Purchased <b>$impressions</b> Made <b>$impmade</b>
	<br />
	Image URL <input type=\"text\" name=\"imageurl\" size=\"50\" maxlength=\"60\" value=\"$imageurl\" />
	<br />
	Click URL <input type=\"text\" name=\"clickurl\" size=\"50\" maxlength=\"100\" value=\"$clickurl\" />
	<br />
	<input type=\"hidden\" name=\"bid\" value=\"$bid\" />
	<input type=\"hidden\" name=\"imptotal\" value=\"$imptotal\" />
	<input type=\"hidden\" name=\"op\" value=\"BannerChange\" />
	<input type=\"submit\" value=\"Change Banner\" />
	</form>
	";
	thememainbox($boxtitle,$boxcontent);
	include("footer.php");
}

function BannerChange($bid, $cid, $imptotal, $impadded, $imageurl, $clickurl)
{
	dbconnect();
	$imp = $imptotal+$impadded;
	mysql_query("update banner set cid='$cid', imptotal='$imp', imageurl='$imageurl', clickurl='$clickurl' where bid=$bid");
	Header("Location: admin.php?op=BannersAdmin#top");
}

function BannerClientDelete($cid, $ok=0)
{
	if ($ok==1)
	{
		dbconnect();
		mysql_query("delete from banner where cid='$cid'");
		mysql_query("delete from bannerclient where cid='$cid'");
		Header("Location: admin.php?op=BannersAdmin#top");
	}
	else
	{
		include("header.php");
		dbconnect();
		GraphicAdmin(0);
		$result=mysql_query("select cid, name from bannerclient where cid=$cid");
		list($cid, $name) = mysql_fetch_row($result);

		$boxtitle="Delete Advertising Client";
		$boxcontent="<br />
	You are about to delete client <b>$name</b> and all its Banners!<br /><br />
		";

		$result2 = mysql_query("select imageurl, clickurl from banner where cid=$cid");
		$numrows = mysql_num_rows($result2);

		if($numrows==0)
		{
			$boxcontent.="This client doesn't have any banner running now.<br /><br />
			";
		}
		else
		{
			$boxcontent.="<span class=\"onebiggerred\">WARNING!</span><br />
			This client has the following ACTIVE BANNERS running in $sitename<br /><br />
			";
		}

		while(list($imageurl, $clickurl) = mysql_fetch_row($result2))
		{
			$boxcontent.="
			<a href=\"$clickurl\"><img src=\"$imageurl\" border=\"1\" /></a><br />
			<a href=\"$clickurl\">$clickurl</a><br /><br />
			";
		}
	}

	$boxcontent.="Are you sure you want to delete this Client and ALL its Banners?<br /><br />
	[ <a href=\"admin.php?op=BannersAdmin#top\">No</a> | <a href=\"admin.php?op=BannerClientDelete&amp;cid=$cid&amp;ok=1\">Yes</a> ]
	<br /><br />";
	thememainbox($boxtitle,$boxcontent);
	include("footer.php");
}

function BannerClientEdit($cid)
{
	include("header.php");
	dbconnect();
	GraphicAdmin(0);
	$result = mysql_query("select name, contact, email, login, passwd, extrainfo from bannerclient where cid=$cid");
	list($name, $contact, $email, $login, $passwd, $extrainfo) = mysql_fetch_row($result);

	$boxtitle="Edit Advertising Client";
	$boxcontent="<br />
	<form action=\"admin.php?op=BannerClientChange\" method=\"post\">
	Client Name <input type=\"text\" name=\"name\" value=\"$name\" size=\"30\" maxlength=\"60\" /><br />
	Contact Name <input type=\"text\" name=\"contact\" value=\"$contact\" size=\"30\" maxlength=\"60\" /><br />
	Contact Email <input type=\"text\" name=\"email\" size=\"30\" maxlength=\"60\" value=\"$email\" /><br />
	Client Login <input type=\"text\" name=\"login\" size=\"12\" maxlength=\"10\" value=\"$login\" /><br />
	Client Password <input type=\"text\" name=\"passwd\" size=\"12\" maxlength=\"10\" value=\"$passwd\" /><br />
	Extra Info <br /><textarea name=\"extrainfo\" cols=\"60\" rows=\"10\" wrap=\"virtual\">$extrainfo</textarea><br />
	<input type=\"hidden\" name=\"cid\" value=\"$cid\" />
	<input type=\"hidden\" name=\"op\" value=\"BannerClientChange\" />
	<input type=\"submit\" value=\"Change Client\" />
	</form>
	";
	thememainbox($boxtitle,$boxcontent);
	include("footer.php");
}

function BannerClientChange($cid, $name, $contact, $email, $extrainfo, $login, $passwd)
{
	dbconnect();
	mysql_query("update bannerclient set name='$name', contact='$contact', email='$email', login='$login', passwd='$passwd' where cid=$cid");
	Header("Location: admin.php?op=BannersAdmin#top");
}

?>
