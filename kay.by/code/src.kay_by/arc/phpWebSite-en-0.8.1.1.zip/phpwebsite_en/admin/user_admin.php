<?php

/*********************************************************/
/* Admin/Authors Functions                               */
/*********************************************************/

function displayadmins()
{
	include("header.php");
	GraphicAdmin(0);
	echo "
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">
<tr>
	<td class=\"type0\">
<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
<tr>
	<td class=\"type4\">Current Administrators</td>
</tr>
<tr>
	<td class=\"type5\">";

	$result = mysql_query("select aid, name from authors");

	echo "<table border=\"0\">";
	
	while(list($a_aid, $name) = mysql_fetch_row($result))
	{
		echo "<tr><td class=\"type5\">$a_aid</td>";
		echo "<td class=\"type5\">&nbsp;[&nbsp;<a href=\"admin.php?op=modifyadmin&amp;chng_aid=$a_aid\">Modify Info</a> | ";
		echo"<a href=\"admin.php?op=deladmin&amp;del_aid=$a_aid\">Delete Author</a>&nbsp;]</td>";
		echo "</tr>";
	}
?>
</table>
	</td>
</tr>
</table>
	</td>
</tr>
</table>
<br />
<table border="0" cellspacing="0" cellpadding="0" width="100%">
<tr>
	<td class="type0">
<table width="100%" border="0" cellspacing="1" cellpadding="3">
<tr>
	<td class="type4">Create New Administrator</td>
</tr>
<tr>
	<td class="type5">
	<form action="admin.php" method="post">
	<table border="0">
	<tr>
	<td class="type5">Handle *</td>
	<td class="type5"><input type="text" name="add_aid" size="30" maxlength="30" /></td>
	</tr>
	<tr>
	<td class="type5">Name *</td>
	<td class="type5"><input type="text" name="add_name" size="30" maxlength="50" /></td>
	</tr>
	<tr>
	<td class="type5">Email *</td>
	<td class="type5"><input type="text" name="add_email" size="30" maxlength="60" /></td>
	</tr>
	<tr>
	<td class="type5">URL</td>
	<td class="type5"><input type="text" name="add_url" size="30" maxlength="60" /></td>
	</tr>
	<tr>
	<td class="type5">Password *</td>
	<td class="type5"><input type="text" name="add_pwd" size="12" maxlength="12" /></td>
	</tr>
	<tr>
	<td class="type5" colspan="2">
	<input type="hidden" name="op" value="AddAuthor" />
	<input type="submit" value="Add Author" />
	</td>
	</tr>
	</table>
	</form>* indicates required fields
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
<?php

	include("footer.php");
}


function modifyadmin($chng_aid)
{
	$titlebar = "<span class=\"boldtext\">update $chng_aid</span>";
	include("header.php");
$result = mysql_query("select aid, name, url, email, pwd from authors where aid='$chng_aid'");
	list($chng_aid, $chng_name, $chng_url, $chng_email, $chng_pwd) = mysql_fetch_row($result);

	echo "
	<!--INDIVIDUAL BLOCKS-->
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">
<tr>
	<td class=\"type0\">
		<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
			<tr>
				<td class=\"type4\">Modify $chng_name</td>	</tr>
			<tr>
				<td class=\"type5\">";
	
	?>

	<form action="admin.php" method="post">
	<table border="0" cellspacing="0" cellpadding="0" width="100%">
	<tr>
	<td class="type5">Name</td>
	<td class="type5"> <?php echo $chng_name ?><input type="hidden" name="chng_name" value="<?php echo $chng_name ?>" /></td>
	</tr>
	<tr>
	<td class="type5">Handle*</td>
	<td class="type5"> <input type="text" name="chng_aid" value="<?php echo $chng_aid?>" /></td>
	</tr>
	<tr>
	<td class="type5">Email*</td>
	<td class="type5"> <input type="text" name="chng_email" value="<?php echo $chng_email?>" size="30" maxlength="60" /></td>
	</tr>
	<tr>
	<td class="type5">URL</td>
	<td class="type5"> <input type="text" name="chng_url" value="<?php echo $chng_url?>" size="30" maxlength="60" /></td>
	</tr>
	<tr>
	<td class="type5">Password</td>
	<td class="type5"> <input type="password" name="chng_pwd"  size="12" maxlength="12" /></td>
	</tr>
	<tr>
	<td class="type5">Retype Password</td>
	<td class="type5"> <input type="password" name="chng_pwd2" size="12" maxlength="12" /> (for changes only) </td>
	</tr>
	<input type="hidden" name="op" value="UpdateAuthor" />
	<tr>
	<td  class="type5" colspan="2"><input type="submit" value="Update Author" /></td>
	</tr>
	</table>
	</form>
	* indicates required fields
	</td>
			</tr>
		</table>
	</td>
</tr>
</table>

	<?php
	include("footer.php");
}

function updateadmin($chng_aid, $chng_name, $chng_email, $chng_url, $chng_pwd, $chng_pwd2)
{
	if (!($chng_aid && $chng_name && $chng_email))
		Header("Location: admin.php?op=adminMain");

	if ($chng_pwd2 != "")
	{
		if($chng_pwd != $chng_pwd2)
		{
			include("header.php");
			GraphicAdmin(0);
			echo "<br /><span class=\"onebiggerred\">Sorry, the new passwords do not match. Go back and try again.</span>";
			include("footer.php");
			exit;
		}
		$chng_pwd = md5($chng_pwd);
		$result = mysql_query("update authors set aid='$chng_aid', email='$chng_email', url='$chng_url', pwd='$chng_pwd' where name='$chng_name'");
		Header("Location: admin.php?op=adminMain");
	}
	else
	{
		$result = mysql_query("update authors set aid='$chng_aid', email='$chng_email', url='$chng_url' where name='$chng_name'");
		Header("Location: admin.php?op=adminMain");
	}
}

/*********************************************************/
/* Users Functions                                       */
/*********************************************************/

function displayUsers()
{
        include("header.php");
	GraphicAdmin(0);
	echo "
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">
<tr>
	<td class=\"type0\">
<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
<tr>
	<td class=\"type4\">Edit Current User</td>
</tr>
<tr>
	<td class=\"type5\">
	<form method=\"post\" action=\"admin.php\">
        <span class=\"boldtext\">Handle: </span>&nbsp;&nbsp;
	<select name=\"chng_uid\">
	<option value=\"187\">&nbsp;</option>\n";
	
	$result = mysql_query("SELECT uid, uname FROM users ORDER BY uname");
	while(list($uid, $uname) = mysql_fetch_row($result))
	{
		echo "<option value=\"$uid\">$uname</option>\n";
	}

	echo "
	</select>
        <select name=\"op\">
        <option value=\"modifyUser\">Modify User</option>
        <option value=\"delUser\">Delete User</option></select>
        <input type=\"submit\" value=\"Go!\" />
	</form>
	</td>
</tr>
</table>
</td></tr></table>
<br />
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">
<tr>
	<td class=\"type0\">
<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
<tr>
	<td class=\"type4\">Create New User</td>
</tr>
<tr>
	<td class=\"type5\">
	<form action=\"admin.php\" method=\"post\">
<table border=\"0\">
<tr>";
?>
	<td class="type5">Handle *</td>
	<td class="type5"><input type="text" name="add_uname" size="30" maxlength="25" /></td>
</tr>
<tr>
	<td class="type5">Name</td>
	<td class="type5"><input type="text" name="add_name" size="30" maxlength="50" /></td>
</tr>
<tr>
	<td class="type5">Email *</td>
	<td class="type5"> <input type="text" name="add_email" size="30" maxlength="60" /></td>
</tr>
<tr>
	<td class="type5">Fake Email</td>
	<td class="type5"> <input type="text" name="add_femail" size="30" maxlength="60" /></td>
</tr>
<tr>
	<td class="type5">URL</td>
	<td class="type5"> <input type="text" name="add_url" size="30" maxlength="60" /></td>
</tr>
<tr>
	<td class="type5">Password</td>
	<td class="type5"> <input type="text" name="add_pass" size="12" maxlength="12" /></td>
</tr>
<tr>
	<td class="type5" colspan="2">
	<input type="hidden" name="op" value="addUser" />
	<input type="submit" value="Add User" />
	</td>
</tr>
</table>
	</form>
	* indicates required fields
	</td>
</tr>
</table>
</td></tr></table>

<?php
        include("footer.php");
}

function modifyUser($chng_user)
{
        include("header.php");
        include("config.php");
        
	if ($user_dblocation)
	{
		@mysql_select_db("$user_dbname") or die ("Unable to select database");
		$result = mysql_query("select uid, uname, name, url, email, femail, pass from users where uid='$chng_user'");
		@mysql_select_db("$dbname") or die ("Unable to select database");

	}
	else
	{
		$result = mysql_query("select uid, uname, name, url, email, femail, pass from users where uid='$chng_user'");
	}
	
        if(mysql_num_rows($result) > 0)
	{
        	while(list($chng_uid, $chng_uname, $chng_name, $chng_url, $chng_email, $chng_femail, $chng_pass) = mysql_fetch_row($result))
		{
	echo "
	<!--INDIVIDUAL BLOCKS-->
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">
<tr>
	<td class=\"type0\">
		<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
			<tr>
				<td class=\"type4\">Update User: $chng_uname</td>	</tr>
			<tr>
				<td class=\"type5\">";
	
	?>

<form action="admin.php" method="get">
	<table border="0">
	<tr>
	<td class="type5">User ID</td>
	<td class="type5"><?php echo $chng_uid ?></td>
	</tr>
	<tr>
	<td class="type5">Handle *</td>
	<td class="type5"><input type="text" name="chng_uname" value="<?php echo $chng_uname ?>" /></td>
	</tr>
	<tr>
	<td class="type5">Name</td>
	<td class="type5"><input type="text" name="chng_name" value="<?php echo $chng_name ?>" /></td>
	</tr>
	<tr>
	<td class="type5">URL</td>
	<td class="type5"><input type="text" name="chng_url" value="<?php echo $chng_url ?>" size="30" maxlength="60"></td>
	</tr>
	<tr>
	<td class="type5">Email *</td>
	<td class="type5"><input type="text" name="chng_email" value="<?php echo $chng_email ?>" size="30" maxlength="60"></td>
	</tr>
	<tr>
	<td class="type5">Fake Email</td>
	<td class="type5"><input type="text" name="chng_femail" value="<?php echo $chng_femail ?>" size="30" maxlength="60"></td>
	</tr>
	<tr>
	<td class="type5">Password</td>
	<td class="type5"><input type="password" name="chng_pass"  size="12" maxlength="12" /></td>
	</tr>
	<tr>
	<td class="type5">Retype Password</td>
	<td class="type5"><input type="password" name="chng_pass2" size="12" maxlength="12" /> (for changes only) </td>
	</tr>
	<input type="hidden" name="chng_uid" value="<?php echo $chng_uid; ?>" />
	<input type="hidden" name="op" value="updateUser" />
	<tr>
	<td class="type5" colspan="2"><input type="submit" value="Update User" /></td>
	</tr>
	</table>
	</form>
<?php
                }
                echo "* indicates compulsory fields";
echo "</td>
			</tr>
		</table>
	</td>
</tr>
</table>
<!--END INDIVIDUAL BLOCKS-->";
		echo "</td></tr></table>
		      </td></tr></table>
		";
        }
	else
	{
                echo "<center><span class=\"onebiggerred\">User doesn't exist!</span> <br />Go back and try again.</center>";
        }
        include("footer.php");
}

function updateUser($chng_uid, $chng_uname, $chng_name, $chng_url, $chng_email, $chng_femail, $chng_pass, $chng_pass2)
{
        include("config.php");  
	$tmp = 0;
	if ($chng_pass2 != "")
	{
        	if($chng_pass != $chng_pass2)
		{
                	$titlebar = "<span class=\"boldtext\">Bad Password</span>";
                	include("header.php");
			GraphicAdmin(0);
			
                	echo "<span class=\"onebiggerred\">Sorry, the new passwords do not match. Click back and try again</span>";
                        include("footer.php");
                        exit;
                }
		$tmp = 1;
        }
	
	if ($tmp == 0)
	{
		if ($user_dblocation)
		{
			@mysql_select_db("$user_dbname") or die ("Unable to select database");
			mysql_query("update users set uname='$chng_uname', name='$chng_name', email='$chng_email', femail='$chng_femail', url='$chng_url' where uid='$chng_uid'");
			@mysql_select_db("$dbname") or die ("Unable to select database");
		}
		else
		{
			mysql_query("update users set uname='$chng_uname', name='$chng_name', email='$chng_email', femail='$chng_femail', url='$chng_url' where uid='$chng_uid'");
		}
	}
	
	if ($tmp == 1)
	{
		$cpass = crypt($chng_pass);
		$cpass = crypt($chng_pass,substr($cpass,0,2));
		if ($user_dblocation)
		{
			@mysql_select_db("$user_dbname") or die ("Unable to select database");
			mysql_query("update users set uname='$chng_uname', name='$chng_name', email='$chng_email', femail='$chng_femail', url='$chng_url', pass='$cpass' where uid='$chng_uid'");		
			@mysql_select_db("$dbname") or die ("Unable to select database");
		}
		else
		{
			mysql_query("update users set uname='$chng_uname', name='$chng_name', email='$chng_email', femail='$chng_femail', url='$chng_url', pass='$cpass' where uid='$chng_uid'");	
		}
	}
	
	header("Location: admin.php?op=adminMain");
}

?>
