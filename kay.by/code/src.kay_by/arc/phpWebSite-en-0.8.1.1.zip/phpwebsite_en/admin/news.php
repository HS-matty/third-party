<?PHP

/*********************************************************/
/* Announcement/News Functions	                         */
/*********************************************************/

function deleteStory ($qid)
{
	$result = mysql_query("delete from queue where qid=$qid");
	
	if (!$result)
	{
		echo mysql_errno(). ": ".mysql_error(). "<br />";
		return;
	}
	Header("Location: admin.php?op=adminMain");
}

function displayStory ($qid)
{
	global $user, $subject, $story;
	include ('config.php');
	include ('header.php');

	GraphicAdmin(0);
	$result = mysql_query("SELECT qid, uid, uname, subject, story, topic FROM queue where qid=$qid");
	list($qid, $uid, $uname, $subject, $story, $topic) = mysql_fetch_row($result);
	mysql_free_result($result);
	
	$subject = stripslashes($subject);
	$story = stripslashes($story);
	?>

<table width="100%" cellpadding="0" cellspacing="0" border="0">
<tr>
	<td class="type0">
<table width="100%" cellpadding="8" cellspacing="1" border="0">
<tr>
	<td class="type5bigger">
	<form action="admin.php" method="post">
	Name:<br /><input type="text" name="author" size="50" value="<?PHP echo "$uname"; ?>" />
	<br /><br />
	Subject:<br /><input type="text" name="subject" size="50" value="<?PHP echo htmlspecialchars($subject); ?>" />
<?PHP
	if($topic=="")
	$topicimage = $default_topic_image;
	else
	{
		$result = mysql_query("select topicimage from topics where topicid=$topic");
		list($topicimage) = mysql_fetch_row($result);
	}

	echo "<br /><br />
<table width=\"80%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
<tr>
	<td class=\"type0\">
<table width=\"100%\" cellpadding=\"8\" cellspacing=\"2\" border=\"0\">
<tr>
	<td class=\"type5\">
	<img src=\"$tipath$topicimage\" border=\"0\" align=\"right\">
	";

	themepreview($subject, $story);

	echo "
</td></tr></table>
</td></tr></table>
	<br />
	Topic:<br /><select name=\"topic\">";

	$toplist = mysql_query("select topicid, topictext from topics order by topictext");
	
        echo "<option value=\"\">Select Topic:</option>";

        while(list($topicid, $topics) = mysql_fetch_row($toplist))
	{
        	if ($topicid==$topic)
		$sel = "selected ";
        	echo "<option $sel value=\"$topicid\">$topics</option>";
		$sel = "";
        }
	$story = eregi_replace('<br[[:space:]]*/?[[:space:]]*>', "", $story);
?>
	</select><br /><br />
	Intro Text:<br /><textarea cols="50" rows="7" name="hometext" wrap="virtual"><?PHP echo "$story"; ?></textarea>
	<br />
	Full Text:<br /><textarea cols="50" rows="8" name="bodytext" wrap="virtual"></textarea><br />
	(Did you check URLs?)<br />
	<input type="checkbox" name="allow_expire" value="1" />
	Expiration Date:
	<?php echo date_select($month, $day, $year); ?>
	<br />
	<select name="op">
	<option value="DeleteStory">Delete Announcement</option>
	<option value="PreviewAgain" SELECTED>Preview Again</option>
	<option value="PostStory">Post Announcement</option>
	</select>
	<input type="hidden" name="qid" size="50" value="<?PHP echo "$qid"; ?>" />
	<input type="hidden" name="uid" size="50" value="<?PHP echo "$uid"; ?>" />
	<input type="submit" value="Go!">
	</td>
</tr>
</table>
	</td>
</tr>
</table>
</form>
<?PHP
	include ('footer.php');
}

function previewStory ($qid, $uid, $author, $subject, $hometext, $bodytext, $topic, $month='', $day='', $year='', $allow_expire)
{
	global $user, $boxstuff;
	include ('config.php');
	include ('header.php');
	GraphicAdmin(0);

	$subject = stripslashes($subject);
	$hometext = stripslashes($hometext);
	$bodytext = stripslashes($bodytext);
?>

<table width="100%" cellpadding="0" cellspacing="0" border="0">
<tr>
	<td class="type0">
<table width="100%" cellpadding="8" cellspacing="2" border="0">
<tr>
	<td class="type5bigger">
	<form action="admin.php" method=post>
	<br />Name:<br /><input type="text" name="author" size="50" value="<?PHP echo"$author"; ?>" />
	<br />Subject:<br /><input type="text" name="subject" size="50" value="<?PHP echo"$subject"; ?>" />
<?PHP
	if ($topic=="")
	$topicimage = $default_topic_image;
	else
	{
		$result = mysql_query("select topicimage from topics where topicid='$topic'");
		list($topicimage) = mysql_fetch_row($result);
	}

	echo "<br /><br />
<table width=\"80%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
<tr>
	<td class=\"type0\">
<table width=\"100%\" cellpadding=\"8\" cellspacing=\"2\" border=\"0\">
<tr>
	<td class=\"type5\">
	<img src=\"$tipath$topicimage\" border=\"0\" align=\"right\" />
	";
	
	themepreview($subject, $hometext, $bodytext);
	
	echo "
</td></tr></table>
</td></tr></table>
	<br />
	Topic:<br />
	<select name=\"topic\">";

	$toplist = mysql_query("select topicid, topictext from topics order by topictext");
	
        echo "<option value=\"\">All Topics</option>";
	
        while(list($topicid, $topics) = mysql_fetch_row($toplist))
	{
        	if ($topicid==$topic)
		$sel = "selected=\"selected\" ";

        	echo "<option $sel value=\"$topicid\">$topics</option>";
		$sel = "";
        }
?>
	</select>	
	<br />
	Intro Text:<br /><textarea cols="50" rows="7" name="hometext" wrap="virtual"><?PHP echo"$hometext"; ?></textarea>
	<br />
	Full Text:<br /><textarea cols="50" rows="10" name="bodytext" wrap="virtual"><?PHP echo"$bodytext"; ?></textarea>
	<br />(Did you check URLs?)<br />
	<input type="checkbox" name="allow_expire" value="1" <?php if ($allow_expire) echo "checked"; ?> />
	Expiration Date:
	<?php echo date_select($month, $day, $year); ?>
	<br />

	<input type="hidden" NAME="qid" size="50" value="<?PHP echo"$qid"; ?>" />
	<input type="hidden" NAME="uid" size="50" value="<?PHP echo "$uid"; ?>" />
	<select name="op">
		<option value="DeleteStory">Delete Announcement</option>
		<option value="PreviewAgain" SELECTED>Preview Again</option>
		<option value="PostStory">Post Announcement</option>
	</select>
	<input type="submit" value="Go!"></form>
	</td>
</tr>
</table>
	</td>
</tr>
</table>
</form>
<?PHP
	include ('footer.php');
}

function postStory ($qid, $uid, $author, $subject, $hometext, $bodytext, $topic, $notes, $month, $day, $year, $allow_expire)
{
	include("config.php");
	global $current_admin;
	if ($allow_expire)
		$expire_date = "$year-$month-$day 23:59:59";
	else
		$expire_date = "2099-12-31 23:59:59";

	if ($uid == -1) $author = "";
	if ($hometext == $bodytext) $bodytext = "";

	$subject = str_replace("(\r\n|\n|\r)", "<br />", $subject);
	$hometext = str_replace("(\r\n|\n|\r)", "<br />", $hometext);
	$bodytext = str_replace("(\r\n|\n|\r)", "<br />", $bodytext);
	$notes = str_replace("(\r\n|\n|\r)", "<br />", $notes);
	
	if(substr_count($subject, "<?")) $subject = str_replace("<?", "<NOPHP", $subject);
	if(substr_count($hometext, "<?")) $hometext = str_replace("<?", "<NOPHP", $hometext);
	if(substr_count($bodytext, "<?")) $bodytext = str_replace("<?", "<NOPHP", $bodytext);
	if(substr_count($notes, "<?")) $notes = str_replace("<?", "<NOPHP", $notes);
	
	$subject = addslashes($subject);
	$hometext = addslashes($hometext);
	$bodytext = addslashes($bodytext);
	$notes = addslashes($notes);

	$result = mysql_query("insert into stories values (NULL, '$current_admin', '$subject', now(), '$hometext', '$bodytext', '0', '0', '$topic','$author', '$notes', '$expire_date')");

	if (!$result)
	{
		echo mysql_errno(). ": ".mysql_error(). "<br />";
		return;
	}
	
	if ($uid == -1)
	{
	}
	else
	{
	    if ($user_dblocation)
		{
			@mysql_select_db("$user_dbname") or die ("Unable to select database");
			mysql_query("update users set counter=counter+1 where uid='$uid'");
			@mysql_select_db("$dbname") or die ("Unable to select database");
		}
		else
		{
			mysql_query("update users set counter=counter+1 where uid='$uid'");		
		}
	}
	
	mysql_query("update authors set counter=counter+1 where aid='$current_admin'");
	
	//if ($ultramode)
	//{
    	//    ultramode();
	//}
	deleteStory($qid);
}

function editStory ($sid)
{
	global $user, $subject, $hometext, $bodytext, $notes, $topic;
	include ('header.php');
	include ('config.php');
	GraphicAdmin(0);
	$result = mysql_query("SELECT title, hometext, bodytext, topic, notes, informant, exp_date FROM stories where sid=$sid");
	list($subject, $hometext, $bodytext, $topic, $notes, $informant, $exp_date) = mysql_fetch_row($result);
	mysql_free_result($result);

	if ($exp_date == "2099-12-31 23:59:59"){
		$month = date('m');
		$day = date ('d');
		$year = date ('Y');
		$allow_expire = 0;
	} else {
		$month = date('m', strtotime($exp_date));
		$day = date('d', strtotime($exp_date));
		$year = date('Y', strtotime($exp_date));
		$allow_expire = 1;
	}

	$subject = stripslashes($subject);
	$hometext = stripslashes($hometext);
	$bodytext = stripslashes($bodytext);
	$notes = stripslashes($notes);
	$result=mysql_query("select topicimage from topics where topicid=$topic");
	list($topicimage) = mysql_fetch_row($result);
	
	echo "<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
<tr>
	<td class=\"type0\">
<table width=\"100%\" border=\"0\" cellpadding=\"4\" cellspacing=\"1\">
<tr>
	<td class=\"type4\">
		Edit Announcement
	</td>
</tr>

<tr>
	<td class=\"type5\">
	";
	
	echo "<br />
<table width=\"80%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
<tr>
	<td class=\"type0\">
<table width=\"100%\" border=\"0\" cellpadding=\"8\" cellspacing=\"1\">
<tr>
	<td class=\"type5\">
	";
	
	if($topicimage)
	echo "<img src=\"$tipath$topicimage\" border=\"0\" align=\"right\" />";
	else
	echo "<img src=\"$tipath$default_topic_image\" border=\"0\" align=\"right\" />";

	themepreview($subject, $hometext, $bodytext);
	echo "</td></tr></table>
	      </td></tr></table><br /><br />";
	?>

	<form action="admin.php" method=post>
	<br />Name:<br />
	<input type="text" name="informant" size="50" value="<?PHP echo "$informant"; ?>">
	<br />Subject:<br />
	<input type="text" name="subject" size="50" value="<?PHP echo "$subject"; ?>"><br />
	Topic: <select name="topic">
<?PHP
	$toplist = mysql_query("select topicid, topictext from topics order by topictext");
	
        echo "<option value=\"\">All Topics</option>\n
	";
        while(list($topicid, $topics) = mysql_fetch_row($toplist))
	{
        	if ($topicid==$topic)
		{
			$sel = "selected ";
		}
        	echo "<option $sel value=\"$topicid\">$topics</option>\n
		";
		$sel = "";
        }
	?>
	</select>
	<br />Intro Text:<br />
	<textarea cols="50" rows="7" name="hometext" wrap="virtual"><?PHP echo str_replace ("<br />", "\n", $hometext); ?></textarea>
	<br />Full Text:<br />
	<textarea cols="50" rows="10" name="bodytext" wrap="virtual"><?PHP echo str_replace ("<br />", "\n", $bodytext); ?></textarea><br />
	(Did you check URLs?)<br />
	<input type="checkbox" name="allow_expire" value="1" <?php if ($allow_expire) echo "checked"; ?> />
	Expiration Date: <?php echo date_select($month, $day, $year); ?><br />
	<input type="hidden" name="sid" size="50" value="<?PHP echo"$sid"; ?>" />
	<input type="hidden" name="op" value="ChangeStory" />
	<input type="submit" value="Change_Announcement" />
	</td>
</tr>
</table>
	</td>
</tr>
</table>
</form>
<?PHP
	include ('footer.php');
}

function removeStory ($sid, $ok=0)
{
	if($ok)
	{
		mysql_query("DELETE FROM stories where sid=$sid");
		mysql_query("DELETE FROM comments where sid=$sid");
		Header("Location: admin.php");
	}
	else
	{
		include("header.php");
		GraphicAdmin("");
		$result=mysql_query("select title from stories where sid=$sid");
		list($title) = mysql_fetch_row($result);
		echo "Are you sure you want to remove announcement: $title, and all its comments?";
		echo "<br /><br />[ <a href=\"admin.php\">No</a> | <a href=\"admin.php?op=RemoveStory&amp;sid=$sid&amp;ok=1\">Yes</a> ]";
		include("footer.php");
	}
}

function changeStory ($sid, $subject, $hometext, $bodytext, $topic, $notes, $month, $day, $year, $allow_expire, $informant)
{
	global $current_admin;
	
	if ($allow_expire)
		$exp_date = $year.'-'.$month.'-'.$day.' 23:59:59';
	else
		$exp_date = "2099-12-31 23:59:59";
	$subject = filter_text(stripslashes(FixQuotes($subject)));
	$hometext = filter_text(stripslashes(FixQuotes($hometext)));
	$bodytext = filter_text(stripslashes(FixQuotes($bodytext)));
	$notes = stripslashes(FixQuotes($notes));
	mysql_query("update stories set title='$subject', hometext='$hometext', bodytext='$bodytext', topic='$topic', notes='$notes', exp_date='$exp_date', informant='$informant' where sid=$sid");
	Header("Location: admin.php?op=adminMain");
}

function adminStory()
{
	global $current_admin;

	include ('header.php');
	include ('config.php');
	GraphicAdmin(0);
	?>

<form action="admin.php" method="post">
<table border="0" width="100%" cellpadding="0" cellspacing="0">
<tr>
	<td class="type0">
<table border="0" width="100%" cellpadding="6" cellspacing="1">
	<tr>
		<td class="type4"><a name="new"></a>New Announcement</td>
	</tr>

	<tr>
	<td class="type5">
	Title:<br />
	<input type="text" name="subject" size="50" value="" /><br />
	<br />Topic:
<?php
        
	$toplist = mysql_query("select topicid, topictext from topics order by topictext");
	
        echo "<select name=\"topic\">";
        echo "<option value=\"\">Select Topic:</option>\n
	";
	
        while(list($topicid, $topics) = mysql_fetch_row($toplist))
	{
    		if ($topicid==$topic)
		{
			$sel = "selected=\"selected\" ";
		}
    		echo "<option $sel value=\"$topicid\">$topics</option>\n
		";
		$sel = "";
    	}
        echo "</select>
	";
	?>
	<br /><br />The Announcement:<br />
	<textarea cols="55" rows="12" name="hometext" wrap="virtual"></textarea><br />
	Extended Text:<br />
	<textarea cols="55" rows="12" name="bodytext" wrap="virtual"></textarea><br />
	(Are you sure you included a URL? Did you test them for typos?)
	<br />
	<input type="checkbox" name="allow_expire" value="1" />
	Expiration Date:
	<?php echo date_select($month, $day, $year); ?>
	<br />
	<select name="op">
		<option value="PreviewAdminStory">Preview Admin Announcement</option>
		<option value="PostAdminStory">Post Admin Announcement</option>
	</select>
	<input type="submit" value="Go!" />
	</td>
</tr>
</table>
	</td>
</tr>
</table>
</form>
<?php
	include ('footer.php');
}

function previewAdminStory($subject, $hometext, $bodytext, $topic, $month, $day, $year, $allow_expire)
{
	global $user, $current_admin;
	include ('header.php');
	include ('config.php');
	GraphicAdmin(0);

	echo "
<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
<tr>
	<td class=\"type0\">
<table border=\"0\" width=\"100%\" cellpadding=\"8\" cellspacing=\"1\">
<tr>
        <td class=\"type4\">Preview Annoucement</td>
</tr>

<tr>
	<td class=\"type5\"><form action=\"admin.php\" method=\"post\">";
	
	$subject = stripslashes($subject);
	$hometext = stripslashes($hometext);
	$bodytext = stripslashes($bodytext);
	
	if(!$topic)
	$topicimage = $default_topic_image;
	else
	{
		$result=mysql_query("select topicimage from topics where topicid='$topic'");
		list($topicimage) = mysql_fetch_row($result);
	}
	
	echo "<br />
<table border=\"0\" width=\"80%\" cellpadding=\"0\" cellspacing=\"0\">
<tr>
	<td class=\"type0\">
<table border=\"0\" width=\"100%\" cellpadding=\"8\" cellspacing=\"1\">
<tr>
	<td class=\"type5\"><img src=\"$tipath$topicimage\" border=\"0\" align=\"right\" />
	";
	
	themepreview($subject, $hometext, $bodytext);
	
	echo "</td></tr></table>
	      </td></tr></table>";
	?>
	
	<br />Title:<br />
	<input type="text" name="subject" size="50" value="<?PHP echo "$subject"; ?>"><br />
	<br />Topic:<select name="topic">
<?PHP
	
	$toplist = mysql_query("select topicid, topictext from topics order by topictext");
	
        echo "<option value=\"\">All Topics</option>\n";
	
        while(list($topicid, $topics) = mysql_fetch_row($toplist))
	{
        	if ($topicid==$topic)
		{
			$sel = "selected=\"selected\" ";
		}
        	echo "<option $sel value=\"$topicid\">$topics</option>\n
		";
		$sel = "";
        }
	?>
	</select>
	<br /><br />The Announcement:<br />
	<textarea cols="70" rows="12" name="hometext" wrap="virtual"><?PHP echo "$hometext"; ?></textarea><br />
	<textarea cols="70" rows="12" name="bodytext" wrap="virtual"><?PHP echo "$bodytext"."$allow_expire"; ?></textarea><br />
	<input type="checkbox" name="allow_expire" value="1" <?php if($allow_expire) echo "checked" ?> />
	Expiration Date:<?php echo date_select($month, $day, $year); ?><br />
	<select name="op">
	<option value="PreviewAdminStory" selected=\"selected\">Preview Admin Announcement</option>
	<option value="PostAdminStory">Post Admin Announcement</option>
	</select>
	<input type="submit" value="Go!" />
	</td></tr></table></td></tr></table></form>
<?PHP
	include ('footer.php');

}

function postAdminStory($subject, $introstory, $fullstory, $topic, $month, $day, $year, $allow_expire)
{
	include("config.php");
	global $current_admin;
	if ($allow_expire)
		$exp_date = $year.'-'.$month.'-'.$day.' 23:59:59';
	else
		$exp_date = "2099-12-31 23:59:59";

	$subject = filter_text(stripslashes(FixQuotes(str_replace("(\r\n|\n|\r)", "<br />", $subject))));
	$introstory = filter_text(stripslashes(FixQuotes(str_replace("(\r\n|\n|\r)", "<br />", $introstory))));
	$fullstory = filter_text(stripslashes(FixQuotes(str_replace("(\r\n|\n|\r)", "<br />", $fullstory))));
	$result = mysql_query("insert into stories values (NULL, '$current_admin', '$subject', now(), '$introstory', '$fullstory', '0', '0', '$topic', '$current_admin', '$notes', '$exp_date')");

	if (!$result)
	{
		echo mysql_errno(). ": ".mysql_error(). "<br />";
		exit();
	}
	
	$result = mysql_query("update authors set counter=counter+1 where aid='$current_admin'");

	Header("Location: admin.php?op=adminMain");
}

/*********************************************************/
/* Comments Delete Function                              */
/*********************************************************/

// This function is a big crap. I need to delete all babies comments
// maybe by setting a unique number for each Parent comment?
// Anyone, please help me to do this!

function removeComment ($tid, $sid)
{
        $leave = mysql_query ("select pid from comments where tid = $tid");
        list ($pid) = mysql_fetch_array($leave);

	$loop = mysql_query ("select tid, sid from comments where pid = $tid");
	if ($loop)
		while (list ($loop_tid, $loop_sid) = mysql_fetch_array($loop))
			removeComment ($loop_tid, $loop_sid);

	mysql_query("delete from comments where tid = $tid");

	mysql_query("update stories set comments=comments-1 where sid=$sid");

	if ($pid==0)
		Header("Location: article.php?sid=$sid");
	else
		return;
}

function RemovePollComment ($tid, $pollID)
{
        $leave = mysql_query ("select pid from pollcomments where tid = $tid");
        list ($pid) = mysql_fetch_array($leave);

        $loop = mysql_query ("select tid, pollID from pollcomments where pid = $tid");
        if ($loop)
                while (list ($loop_tid, $loop_pollID) = mysql_fetch_array($loop))
                        RemovePollComment ($loop_tid, $loop_pollID);

        mysql_query("delete from pollcomments where tid = $tid");

        if ($pid==0)
                Header("Location: pollBooth.php?op=results&pollID=$pollID");
        else
                return;
}

?>
