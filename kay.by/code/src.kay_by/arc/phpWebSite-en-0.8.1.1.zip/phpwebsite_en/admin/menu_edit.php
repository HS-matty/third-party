<?php

#############################################
//Main Menu Edit Page
#############################################


function edit_menu () 
{
  include ("header.php");

  GraphicAdmin(0);  

echo "
      <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width = \"100%\"><tr><td class=\"type0\">
      <table border=\"0\" cellpadding=\"8\" cellspacing=\"1\" width = \"100%\">
      <tr><td class = \"type4\" colspan =\"4\">Edit Main Menu</td></tr>
      <tr><td class = \"type5\" colspan =\"4\">To add a new menu item, choose 'Add Menu Item...'.<br />To edit an existing menu item, simply choose that menu item.</td></tr>";

$result = mysql_query("select menu_id, menu_text, menu_url, menu_active, menu_order from menu where menu_level = 1 order by menu_order");

echo "<tr><td class=\"type5\" colspan=\"4\">[<a href=\"admin.php?op=add_main_menu\">Add Top Level Main Menu Item</a>]</td></tr>";

 while(list($menu_id, $menu_text, $menu_url, $menu_active, $menu_order) = mysql_fetch_row($result)){

     $low_sub = $menu_id * 100;

     $high_sub = $low_sub + 99;

     echo "<tr><td class=\"type5\"><a href=\"admin.php?op=edit_menu_item&amp;menu_id=$menu_id\">$menu_text</a><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"admin.php?op=add_sub_menu&amp;low_sub=$low_sub\">[Add Menu Item Under $menu_text]</a></td>";

     if ($menu_active){
       echo "<td class=\"active\"><a href=\"admin.php?op=menu_active&amp;menu_id=$menu_id&amp;menu_active=$menu_active\">ON</a></td>";
     }

     else {echo "<td class=\"inactive\"><a href=\"admin.php?op=menu_active&amp;menu_id=$menu_id&amp;menu_active=$menu_active\">OFF</a></td>";
     }

     echo " <td class=\"type5\"><a href=\"admin.php?op=menu_prompt_delete&amp;menu_id=$menu_id\">Delete</a></td>
        <td class=\"type5\"><a href=\"admin.php?op=order_menu&amp;menu_id=$menu_id\">Order</a></td></tr>";

     $result_sub = mysql_query("select menu_id, menu_text, menu_url, menu_active, menu_order from menu where menu_level = 2 and menu_id >=  $low_sub and menu_id <=  $high_sub order by menu_order");

     while(list($menu_id, $menu_text, $menu_url, $menu_active, $menu_order) = mysql_fetch_row($result_sub)){

       $low_sub2 = $menu_id * 100;
       $high_sub2 = $low_sub2 + 99;


       echo"<tr><td class=\"type5\"><span class=\"onebiggerred\">&gt;&gt;</span><a href=\"admin.php?op=edit_menu_item&amp;menu_id=$menu_id\">$menu_text</a><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"admin.php?op=add_sub_menu&amp;low_sub=$low_sub2\">[Add Menu Item Under $menu_text]</a></td>";

       if ($menu_active){
         echo "<td class=\"active\"><a href=\"admin.php?op=menu_active&amp;menu_id=$menu_id&amp;menu_active=$menu_active\">ON</a></td>";
       }

       else {echo "<td class=\"inactive\"><a href=\"admin.php?op=menu_active&amp;menu_id=$menu_id&amp;menu_active=$menu_active\">OFF</a></td>";
       }

       echo "<td class=\"type5\"><a href=\"admin.php?op=menu_prompt_delete&amp;menu_id=$menu_id\">Delete</a></td>
        <td class=\"type5\"><a href=\"admin.php?op=order_menu&amp;menu_id=$menu_id\">Order</a></td></tr>";

     $result_sub2 = mysql_query("select menu_id, menu_text, menu_url, menu_active, menu_order from menu where menu_level = 3 and menu_id >=  $low_sub2 and menu_id <=  $high_sub2 order by menu_order");
     while(list($menu_id, $menu_text, $menu_url, $menu_active, $menu_order) = mysql_fetch_row($result_sub2)){

       echo"<tr><td class=\"type5\"><span class=\"onebiggerred\">&gt;&gt;&gt;&gt;</span><a href=\"admin.php?op=edit_menu_item&amp;menu_id=$menu_id\">$menu_text</a></td>";

       if ($menu_active){
         echo "<td class=\"active\"><a href=\"admin.php?op=menu_active&amp;menu_id=$menu_id&amp;menu_active=$menu_active\">ON</a></td>";
       }

       else {echo "<td class=\"inactive\"><a href=\"admin.php?op=menu_active&amp;menu_id=$menu_id&amp;menu_active=$menu_active\">OFF</a></td>";
       }

       echo "<td class=\"type5\"><a href=\"admin.php?op=menu_prompt_delete&amp;menu_id=$menu_id\">Delete</a></td><td class=\"type5\"><a href=\"admin.php?op=order_menu&amp;menu_id=$menu_id\">Order</a></td></tr>";


      }
     }
 }


echo "</table></td></tr></table>";
include ('footer.php');

}


function add_main_menu () 
{
  include ("header.php");
  GraphicAdmin(0);

  echo "
      <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width = \"100%\"><tr><td class=\"type0\">
      <table border=\"0\" cellpadding=\"8\" cellspacing=\"1\" width = \"100%\">
      <tr><td class = \"type4\">Add Menu Item</td></tr>
      <tr><td class = \"type5\">


<form action=\"admin.php\">
        Menu Text: <br /><input type=\"text\" name=\"menu_text\" maxlength=\"20\" size=\"40\" />
        <br />
        Menu URL:<br /><input type=\"text\" name=\"menu_url\" maxlength=\"255\" size=\"40\" />
        <br />
	For off-site links, please give the full URL. (ie: http://phpwebsite.appstate.edu)
	<br />
        <input type=\"hidden\" name=\"op\" value=\"menu_post\" />
        <input type=\"submit\" value=\"Submit\" />
</form>
        </td></tr></table></td></tr></table>";

  include ('footer.php');

}

function menu_post ($menu_text, $menu_url)
{

  mysql_query("lock table menu write");
  $result_id = mysql_query ("select max(menu_id) from menu where menu_id >= '0' and menu_id < '100'");
  list($menu_id) = mysql_fetch_row($result_id);

  $result_order = mysql_query ("select max(menu_order) from menu where menu_level='1'");
  list($menu_order) = mysql_fetch_row($result_order);


 $menu_id = $menu_id + 1;
  $menu_order = $menu_order + 1;

  mysql_query("insert into menu (menu_id, menu_text, menu_url, menu_level, menu_active, menu_order) values ('$menu_id', '$menu_text', '$menu_url', '1', '1', '$menu_order')");

  mysql_query("unlock table");

  return $menu_id;
}

function add_sub_menu () 
{
  global $low_sub;

  include ("header.php");
  GraphicAdmin(0);

  echo "
      <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width = \"100%\"><tr><td class=\"type0\">
      <table border=\"0\" cellpadding=\"8\" cellspacing=\"1\" width = \"100%\">
      <tr><td class = \"type4\">Add Menu Item</td></tr>
      <tr><td class = \"type5\">

<form action=\"admin.php\">
        Menu Text: <br /><input type=\"text\" name=\"menu_text\" maxlength=\"60\" size=\"33\" />
        <br />
        Menu URL:<br /><input type=\"text\" name=\"menu_url\" maxlength=\"255\" size=\"33\" />
        <input type=\"hidden\" name=\"op\" value=\"sub_menu_post\" />
        <input type=\"hidden\" name=\"low_sub\" value=\"$low_sub\" /><br />
        <input type=\"submit\" value=\"Submit\" />
        </form></td></tr></table></td></tr></table>";
  include ('footer.php');
}


function sub_menu_post ($low_sub, $menu_text, $menu_url)
{
  $high_sub = $low_sub + 99;

  mysql_query("lock table menu write");
  $result_id = mysql_query ("select max(menu_id) from menu where menu_id >= '$low_sub' and menu_id <= '$high_sub'");
  list($menu_id) = mysql_fetch_row($result_id);

  $result_order = mysql_query ("select max(menu_order) from menu where menu_id >= '$low_sub' and menu_id <= '$high_sub'");
  list($menu_order) = mysql_fetch_row($result_order);

  if ($menu_id == ""){
    $menu_id = $low_sub;
    $menu_order = 0;

  }

  else{
    $menu_id = $menu_id + 1;
    $menu_order = $menu_order + 1;
  }

  if ($menu_id < 10000){
    mysql_query("insert into menu (menu_id, menu_text, menu_url, menu_level, menu_active, menu_order) values ('$menu_id', '$menu_text', '$menu_url', '2', '1', '$menu_order')");
  }
  else {
    mysql_query("insert into menu (menu_id, menu_text, menu_url, menu_level, menu_active, menu_order) values ('$menu_id', '$menu_text', '$menu_url', '3', '1', '$menu_order')");
  }
  mysql_query("unlock table");

}

function menu_prompt_delete ()
{

  global $menu_id;
  include ("header.php");
  GraphicAdmin(0);

  echo "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width = \"100%\"><tr><td class=\"type0\">
      <table border=\"0\" cellpadding=\"8\" cellspacing=\"1\" width = \"100%\">
      <tr><td class = \"type4\">Delete Menu Item</td></tr>
      <tr><td class = \"type5\">";

  $delete_result =  mysql_query("select  menu_text, menu_url from menu  where menu_id = $menu_id");
  list($menu_text, $menu_url) = mysql_fetch_row($delete_result);

  echo "<p>Are you sure that you want to delete the link:</p><p class=\"type5bigger\">$menu_text -> $menu_url</p><p><a href=\"admin.php?op=menu_delete&amp;menu_id=$menu_id\">Yes</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"admin.php?op=edit_menu\">No</a></p>
        </td></tr></table></td></tr></table>";

  include ("footer.php");

}

function menu_delete ($menu_id)
{
  $low_sub = $menu_id * 100;
  $high_sub = ($low_sub + 99);
  
  $result = mysql_query("select menu_text from menu where menu_id >= '$low_sub' and menu_id <= '$high_sub'");
  list($menu_text) = mysql_fetch_row($result);
  
  
  if (!$menu_text){
    
    $menu_id_del = $menu_id;
 
    $low_sub2 = ((floor($menu_id / 100)) * 100);
    $high_sub2 = ($low_sub2 + 99);
    
    $result_orderup = mysql_query("select menu_id, menu_order from menu where menu_id = '$menu_id'");
    list($menu_id, $menu_order_del) = mysql_fetch_row($result_orderup);
    
    $result_orderup2 = mysql_query ("select menu_id, menu_order from menu where menu_order > '$menu_order_del' and menu_id >='$low_sub2' and menu_id <= '$high_sub2' order by menu_order asc");
 
   while(list($menu_id, $menu_order) = mysql_fetch_row($result_orderup2)){
      
      $updated_menu_order = ($menu_order - 1);
      
      
      if ($updated_menu_order < 0){
        $updated_menu_order = 0;
      }
      
      mysql_query ("update menu set menu_order='$updated_menu_order' where menu_id='$menu_id'");
      
    }
    
    mysql_query ("delete from menu where menu_id = '$menu_id_del'");

    
  }
  
  else {
    menu_error();
  }
}

function menu_error ()

{
  include ("header.php");
  GraphicAdmin(0);

  echo "This Menu Item contains sub menus, you must delete them before deleting this menu item.
<form action=\"admin.php\"><input type=\"hidden\" name=\"op\" value=\"edit_menu\" /><input type=\"submit\" value=\"Back\" /></form>";

  include ("footer.php");
}


function menu_active ($menu_id, $menu_active)
{
 $result = mysql_query ("select page_id from menu where menu_id=$menu_id"); 
  list($page_id) = mysql_fetch_row($result);

  if($page_id) {
    if($menu_active){
 
    mysql_query("update user_pages set active='0' where page_id='$page_id'");
    mysql_query("update menu set menu_active='0' where page_id='$page_id'");
  }
  
  else {
    mysql_query("update user_pages set active='1' where page_id='$page_id'");   
    mysql_query("update menu set menu_active='1' where page_id='$page_id'");
  }
  }
  else{
        if($menu_active)
        mysql_query("update menu set menu_active='0' where menu_id='$menu_id'");
        else
        mysql_query("update menu set menu_active='1' where menu_id='$menu_id'");
  }
}


function edit_menu_item ($menu_id)
{

  include ("header.php");
  GraphicAdmin(0);

  $result = mysql_query ("select menu_text, menu_url, menu_order, page_id from menu where menu_id=$menu_id"); 
  $row = mysql_fetch_array($result);
  extract($row);
  
  if($menu_url == "mod.php?mod=userpage")
  $update_url = "mod.php";
  else
  $update_url = $menu_url;

  echo "
      <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width = \"100%\"><tr><td class=\"type0\">
      <table border=\"0\" cellpadding=\"8\" cellspacing=\"1\" width = \"100%\">
      <tr><td class = \"type4\">Edit Menu Item</td></tr>
      <tr><td class = \"type5\">
        <form action=\"admin.php\">";
        $tempword = htmlspecialchars($menu_text);
echo "Menu Text: <br /><input type=\"text\" name=\"menu_text\" maxlength=\"60\" size=\"33\" 
value=\"$tempword\" />
        <br />
        Menu URL:<br /><input type=\"text\" name=\"menu_url\" maxlength=\"255\" size=\"33\" value=\"$update_url\" />
        <input type=\"hidden\" name=\"menu_id\" value=\"$menu_id\" />
        <input type=\"hidden\" name=\"op\" value=\"update_menu_item\" />
        <input type=\"submit\" value=\"Submit\" />
        </form></td></tr></table></td></tr></table>";

  include ("footer.php");
}

function update_menu_item ($menu_id, $menu_text, $menu_url)
{
	if($menu_url == "mod.php")
	$menu_url = "mod.php?mod=userpage";

	mysql_query("update menu set menu_text='$menu_text', menu_url='$menu_url'  where menu_id='$menu_id'");
}

function order_menu ($menu_id)
{
  include ("header.php");
  GraphicAdmin(0);

  $low_sub = ((floor($menu_id / 100)) * 100);
  $high_sub = ($low_sub + 99);

 $result_order = mysql_query ("select max(menu_order) from menu where menu_id >= '$low_sub' and menu_id <= '$high_sub'");
  list($max_order) = mysql_fetch_row($result_order);

echo "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width = \"100%\"><tr><td class=\"type0\">
      <table border=\"0\" cellpadding=\"8\" cellspacing=\"1\" width = \"100%\">
      <tr><td class = \"type4\" colspan=\"2\">Change Menu Item Order</td></tr>
      <tr><td class = \"type5\" colspan=\"2\">
      <table cellspacing=\"5\">";

 $result = mysql_query("select menu_id, menu_text, menu_url, menu_order, page_id from menu where menu_id >= '$low_sub' and menu_id <= '$high_sub' order by menu_order");

 while(list($menu_id, $menu_text, $menu_url, $menu_order, $page_id) = mysql_fetch_row($result)){

   echo "<tr><td align=\"center\">
<a href=\"admin.php?op=update_menu_order&amp;menu_id=$menu_id&amp;menu_order=$menu_order&amp;move=1\">
<img src=\"./images/menu/up.gif\" border=\"0\" alt=\"Move &quot;$menu_text&quot; up One Level\" /></a>
</td> <td>$menu_text</td><td align=\"center\">
<a href=\"admin.php?op=update_menu_order&amp;menu_id=$menu_id&amp;menu_order=$menu_order&amp;move=0\">
<img src=\"./images/menu/down.gif\" border=\"0\" alt=\"Move &quot;$menu_text&quot; down One Level\"/></a>
</td></tr>";     }

 echo "<tr><td>&nbsp;</td><td>&nbsp;</td><td><form action=\"admin.php\">
<input type=\"hidden\" name=\"op\" value=\"edit_menu\" /><input type=\"submit\" value=\"Done\" />
</form></td></tr></table></td></tr></table></td></tr></table>";

 include ("footer.php");

}


function update_menu_order ($menu_id, $menu_order, $move)
{
  $low_sub = ((floor($menu_id / 100)) * 100);
  $high_sub = ($low_sub + 99);

  $result_order = mysql_query ("select max(menu_order) from menu where menu_id >= '$low_sub' and menu_id <= '$high_sub'");
  list($max_order) = mysql_fetch_row($result_order);

  if ($move == 1){
    $updated_menu_order = ($menu_order - 1);
    if ($updated_menu_order < 0) {
      $updated_menu_order = 0;
    }

    $result = mysql_query ("select menu_id from menu where menu_order = '$updated_menu_order' and menu_id >='$low_sub' and menu_id <= '$high_sub'");
    list($id_old_order) = mysql_fetch_row($result);
    $menu_order = ($updated_menu_order + 1);

    if ($menu_order > $max_order) {
      $menu_order = $max_order;
    }
    mysql_query ("update menu set menu_order='$menu_order' where menu_id='$id_old_order'");
    mysql_query ("update menu set menu_order='$updated_menu_order' where menu_id='$menu_id'");
  }

  if ($move == 0){
    $updated_menu_order = ($menu_order + 1);
    if ($updated_menu_order > $max_order){
      $updated_menu_order = $max_order;
    }

    $result = mysql_query ("select menu_id from menu where menu_order = '$updated_menu_order' and menu_id >='$low_sub' and menu_id <= '$high_sub'");
    list($id_old_order) = mysql_fetch_row($result);
    $menu_order = ($updated_menu_order - 1);
    if ($menu_order < 0){
      $menu_order = 0;
    }

    mysql_query ("update menu set menu_order='$menu_order' where menu_id='$id_old_order'");
    mysql_query ("update menu set menu_order='$updated_menu_order' where menu_id='$menu_id'");
  }
}

/***************************************************************************
 * These functions are mainly for userpage use only. I moved them here to
 * get them out of the userpage.php file.   -Adam
 ***************************************************************************/

function choose_menu ($page_id) 
{
  include ("header.php");
 
  GraphicAdmin(0);  
  
  echo "<center>
	<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width = \"100%\">
	<tr>
	<td class=\"type0\">
	<table border=\"0\" cellpadding=\"8\" cellspacing=\"1\" width = \"100%\">
	<tr>
	<td class = \"type4\">Select Menu Placement</td>
	</tr>
	<tr>
	<td class = \"type5\">Please select where you would like this page to appear on the main menu by clicking the appropriate link.</td>
	</tr>
  ";

  $result = mysql_query("select menu_id, menu_text, menu_url, menu_active, menu_order from menu where menu_level = 1 order by menu_order");

  echo "
	<tr>
	<td class=\"type5\">[<a href=\"admin.php?op=page_menu_post&amp;page_id=$page_id\">Add Page to Top Level</a>]</td>
	</tr>
  ";

  while(list($menu_id, $menu_text, $menu_url, $menu_active, $menu_order) = mysql_fetch_row($result))
  {
     $low_sub = $menu_id * 100;  
     $high_sub = $low_sub + 99;

     echo "
<tr>
      <td class=\"type5\"><b>$menu_text</b><br />
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      [<a href=\"admin.php?op=sub_page_menu_post&amp;low_sub=$low_sub&amp;page_id=$page_id\">Add Page Under $menu_text</a>]
      </td>
</tr>
     ";

     $result_sub = mysql_query("select menu_id, menu_text, menu_url, menu_active, menu_order from menu where menu_level = 2 and menu_id >=  $low_sub and menu_id <=  $high_sub order by menu_order");

     while(list($menu_id, $menu_text, $menu_url, $menu_active, $menu_order) = mysql_fetch_row($result_sub))
     {
       $low_sub2 = $menu_id * 100; 
       $high_sub2 = $low_sub2 + 99;

       echo"
	<tr>
	<td class=\"type5\"><span class=\"onebiggerred\">&gt;&gt;</span>
	<b>$menu_text</b><br />
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	[<a href=\"admin.php?op=sub_page_menu_post&amp;low_sub=$low_sub2&amp;page_id=$page_id\">Add Page Under $menu_text</a>]
	</td>
	</tr>
       ";

     $result_sub2 = mysql_query("select menu_id, menu_text, menu_url, menu_active, menu_order from menu where menu_level = 3 and menu_id >=  $low_sub2 and menu_id <=  $high_sub2 order by menu_order");

     while(list($menu_id, $menu_text, $menu_url, $menu_active, $menu_order) = mysql_fetch_row($result_sub2))
     {
       echo"
	<tr>
	<td class=\"type5\"><span class=\"onebiggerred\">&gt;&gt;&gt;&gt;</span>
	<b>$menu_text</b>
	</td>
	</tr>
       ";
     }
   }    
 }

  echo "
</table>
</td></tr></table>
</center>
  ";

  include ('footer.php'); 
}

function get_menu_text ($menu_id)
{
        include ("header.php");
	GraphicAdmin(1);
	
	$result = mysql_query("select menu_text from menu where menu_id='$menu_id'");
	list($link) = mysql_fetch_row($result);

	echo "
	<table border=\"0\" bgcolor=\"#000000\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
	<tr>
	<td>
	<table border=\"0\" width=\"100%\" cellpadding=\"5\" cellspacing=\"1\">
	<tr>
	<td class=\"type4\">Menu Text:</td>
	</tr>
	<tr>
	<td class=\"type5\"><object><form method=\"post\" action=\"admin.php\">Please name this link:
        <input type=\"text\" name=\"link\" maxlength=\"60\" size=\"33\" value=\"$link\" />
        <input type=\"hidden\" name=\"op\" value=\"update_link_text\" />
        <input type=\"hidden\" name=\"menu_id\" value=\"$menu_id\" />
        <br /><input type=\"submit\" value=\"Submit Link Text\" />
        </form></object>
	</td>
	</tr>
	</table>
        </td>
	</tr>
	</table>
        ";
	include("footer.php");
}

function update_link_text($menu_id, $link)
{
        mysql_query("update menu set menu_text='$link' where menu_id='$menu_id'");
}

function page_menu_post ($page_id)
{

  include("header.php");

  mysql_query("lock table menu write");
  $result_id = mysql_query ("select max(menu_id) from menu where menu_id >= '0' and menu_id < '100'");
  list($menu_id) = mysql_fetch_row($result_id);

  $result_order = mysql_query ("select max(menu_order) from menu where menu_level='1'");
  list($menu_order) = mysql_fetch_row($result_order);

  $menu_text = "Type Link Name Here";

    $menu_id = $menu_id + 1;
  $menu_order = $menu_order + 1;

  mysql_query("insert into menu (menu_id, menu_text, menu_url, menu_level, menu_active, menu_order, page_id) values ('$menu_id', '$menu_text', 'mod.php?mod=userpage', '1', '1', '$menu_order', '$page_id')");

  mysql_query("unlock table");

  echo "
      <center>
      <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width = \"100%\"><tr>
      <td class=\"type0\">
      <table border=\"0\" cellpadding=\"8\" cellspacing=\"1\" width = \"100%\">
      <tr><td class = \"type4\">Edit Menu Item</td></tr>
      <tr><td class = \"type5\">

	Please give this page a link name for the menu:
        <form action=\"admin.php\">
	Menu Text: <br /><input type=\"text\" name=\"menu_text\" maxlength=\"60\" size=\"33\" value=\"$menu_text\" />
        <br />

        <input type=\"hidden\" name=\"menu_id\" value=\"$menu_id\" />
        <input type=\"hidden\" name=\"op\" value=\"update_page_menu\" />
        <input type=\"submit\" value=\"Submit\" />
        </td></tr></table></td></tr></table>";

  include("footer.php");

}

function sub_page_menu_post ($low_sub, $page_id)
{
  include ("header.php");
  $high_sub = $low_sub + 99;

  mysql_query("lock table menu write");
  $result_id = mysql_query ("select max(menu_id) from menu where menu_id >= '$low_sub' and menu_id <= '$high_sub'");
  list($menu_id) = mysql_fetch_row($result_id);

  $result_order = mysql_query ("select max(menu_order) from menu where menu_id >= '$low_sub' and menu_id <= '$high_sub'");
  list($menu_order) = mysql_fetch_row($result_order);

  if ($menu_id == ""){
    $menu_id = $low_sub;
    $menu_order = 0;

  }

  else{
    $menu_id = $menu_id + 1;
    $menu_order = $menu_order + 1;
  }

  if ($menu_id < 10000){
    mysql_query("insert into menu (menu_id, menu_text, menu_url, menu_level, menu_active, menu_order, page_id) values ('$menu_id', '$menu_text', 'mod.php?mod=userpage', '2', '1', '$menu_order', '$page_id')");
  }
  else {
    mysql_query("insert into menu (menu_id, menu_text, menu_url, menu_level, menu_active, menu_order, page_id) values ('$menu_id', '$menu_text', 'mod.php?mod=userpage', '3', '1', '$menu_order', '$page_id')");
  }

  mysql_query("unlock table");

  echo "
      <center>
      <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width = \"100%\"><tr>
      <td class=\"type0\">
      <table border=\"0\" cellpadding=\"8\" cellspacing=\"1\" width = \"100%\">
      <tr><td class = \"type4\">Edit Menu Item</td></tr>
      <tr><td class = \"type5\">

	Please give this page a link name for the menu:
        <form action=\"admin.php\">
	Menu Text: <br /><input type=\"text\" name=\"menu_text\" maxlength=\"60\" size=\"33\" value=\"$menu_text\" />
        <br />

        <input type=\"hidden\" name=\"menu_id\" value=\"$menu_id\" />
        <input type=\"hidden\" name=\"op\" value=\"update_page_menu\" />
        <input type=\"submit\" value=\"Submit\" />
        </td></tr></table></td></tr></table>";
  
  include ("footer.php");
}

function update_page_menu($menu_id, $menu_text)
{
   mysql_query("update menu set menu_text='$menu_text'  where menu_id='$menu_id'");
}

function menu_saved()
{
	include("header.php");
	GraphicAdmin(0);

	$title = "<b>Menu Item Saved!</b>";
	$content = "Your page has successfully beed saved to the menu!";
	thememainbox($title, $content);
	
	include("footer.php");
}
?>
