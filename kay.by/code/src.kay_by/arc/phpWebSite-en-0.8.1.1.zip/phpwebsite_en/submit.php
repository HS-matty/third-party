<?php

include("open_session.php");

if (!isset($mainfile)) { include("mainfile.php"); }

function defaultDisplay()
{
	include ('header.php');
	global $user, $cookie;
	
	echo "
<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
<tr>
	<td class=\"type0\">
<table border=\"0\" width=\"100%\" cellpadding=\"8\" cellspacing=\"1\">
<tr>
	<td class=\"type4\">Submit News</td>
</tr>
<tr>
	<td class=\"type5\">";

	if (isset($user)) getusrinfo($user);

	echo "
	<form action=\"submit.php\" method=\"post\">
	Your Name: ";

	if ($user)
	{
		cookiedecode($user);
		echo "<a href=\"user.php\">$cookie[1]</a> [ <a href=\"user.php?op=logout\">Logout</a> ]";
	} 
	else
	{
		echo "$anonymous";
		if ($login_switch == 1) echo " [ <a href=\"user.php\">New User</a> ]";
	}
?>
	<br />Title:
	<input type="text" name="subject" size="70" maxlength="80" /><br />
	Topic:&nbsp;<select name="topic">
	
<?PHP
	$toplist = mysql_query("select topicid, topictext from topics order by topictext");

        echo "<option value=\"\">Select Topic</option>
	";

        while(list($topicid, $topics) = mysql_fetch_row($toplist))
	{
		if ($topicid==$topic) { $sel = "selected=\"selected\" "; }
		echo "<option $sel value=\"$topicid\">$topics</option>\n";
		$sel = "";
        }
?>
	</select>
	<br />Content:
	(HTML is fine.)<br />
	<textarea cols="70" rows="12" name="story" wrap="virtual"></textarea><br />
	<input type="submit" name="op" value="Preview" /></form>
	</td>
</tr>
</table>
</td></tr></table>

<?PHP
	include ('footer.php');
}

function PreviewStory($name, $address, $subject, $story, $topic)
{
	global $user, $cookie;
	include ('header.php');

	if(substr_count($subject, "<?")) $subject = str_replace("<?", "<NOPHP", $subject);
	if(substr_count($story, "<?")) $story = str_replace("<?", "<NOPHP", $story);

	echo "
<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
<tr>
	<td class=\"type0\">
<table border=\"0\" width=\"100%\" cellpadding=\"8\" cellspacing=\"1\">
<tr>
	<td class=\"type4\">Preview</td>
</tr>
<tr>
	<td class=\"type5\">
	<br /><form action=\"submit.php\" method=\"post\">
	Your Name:";

	if($user)
	{
		cookiedecode($user);
		echo "<a href=\"user.php\">$cookie[1]</a> [ <a href=\"user.php?op=logout\">Logout</a> ]";
	}
	else
	{
		echo "$anonymous";
	}

	echo "
	<br />Title:<br />
	<input type=\"text\" name=\"subject\" size=\"70\" maxlength=\"80\" value=\"" . htmlspecialchars(stripslashes($subject)) . "\" />
	<br /><br />
<table border=\"0\" width=\"80%\" cellpadding=\"0\" cellspacing=\"0\">
<tr>
	<td class=\"type0\">
<table border=\"0\" width=\"100%\" cellpadding=\"8\" cellspacing=\"1\">
<tr>
	<td class=\"type5\">
	";
	
	if ($topic=="")
	{
		$topicimage="alltopics.gif";
		$warning = "<span class=\"onebiggerred\">Select Topic</span>";
	}
	else
	{
		$warning = "";
		$result = mysql_query("select topicimage from topics where topicid='$topic'");
		list($topicimage) = mysql_fetch_row($result);
	}

	echo "<img src=\"$tipath$topicimage\" border=\"0\" align=\"right\" />";

	$pre_subject = stripslashes(str_replace("<br />", "", $subject));
	$pre_story = stripslashes(str_replace("<br />", "", $story));

	$pre_subject = stripslashes(str_replace("\n", "<br />", $pre_subject));
	$pre_story = stripslashes(str_replace("\n", "<br />", $pre_story));

	themepreview($pre_subject, $pre_story);

	echo "</td></tr></table></td></tr></table>";
	echo "<br />$warning";
	?>
	<br />Topic:<select name="topic">
	<?PHP
	$toplist = mysql_query("select topicid, topictext from topics order by topictext");
	echo "<option value=\"\">Select Topic</option>\n";
        while(list($topicid, $topics) = mysql_fetch_row($toplist)) {
    	    if ($topicid==$topic) { $sel = "selected=\"selected\" "; }
            echo "<option $sel value=\"$topicid\">$topics</option>\n";
	    $sel = "";
        }
	?>
	</select>
	<br />Content:
	(HTML is fine.)<br />
	<textarea cols="70" rows="12" name="story" wrap="virtual"><?php echo stripslashes($pre_story); ?></textarea><br />
	<input type="submit" name="op" value="Preview"> <input type="submit" name="op" value="Ok!">
	</td></tr></table></td></tr></table></form>

	<?PHP
	include ('footer.php');
}

function submitStory($name, $address, $subject, $story, $topic) {
	global $user, $EditedMessage, $cookie;
	include ('header.php');
	echo "Thanks for your submission.";
	include ('footer.php');
	if ($user) {
		cookiedecode($user);
		$uid = $cookie[0];
		$name = $cookie[1];
	} else {
		$uid = -1;
		$name = $anonymous;
	}

	if(substr_count($subject, "<?")) $subject = str_replace("<?", "<NOPHP", $subject);
	if(substr_count($story, "<?")) $story = str_replace("<?", "<NOPHP", $story);
	
	$subject = addslashes($subject);
	$story = addslashes($story);

	$result = mysql_query("insert into queue values (NULL, '$uid', '$name', '$subject', '$story', now(), '$topic')");
	if(!$result) {
		echo mysql_errno(). ": ".mysql_error(). "<br />";
		exit();
	}
	if($notify) {
		mail($notify_email, $notify_subject, $notify_message, "From: $notify_from\nX-Mailer: PHP/" . phpversion());
	}
}

switch($op)
{
	case "Preview":
		PreviewStory($name, $address, $subject, $story, $topic);
		break;

	case "Ok!":
		SubmitStory($name, $address, $subject, $story, $topic);
		break;

	default:
		defaultDisplay();
		break;

}

?>
