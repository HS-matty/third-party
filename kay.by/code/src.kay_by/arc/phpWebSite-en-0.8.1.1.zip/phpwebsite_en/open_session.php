<?php

session_start();
if (!$PHPSESSID)
{
	if(phpversion() >= "4.1.0")
		{
		session_unregister("admintest");
		session_unregister("current_admin");
		}

	session_register("admintest");
	session_register("current_admin");
}
else if ((!$admintest) || (!$current_admin))
{
	if(phpversion() >= "4.1.0")
		{
		session_unregister("admintest");
		session_unregister("current_admin");
		}

	session_register("admintest");
	session_register("current_admin");
}

global $admintest, $current_admin;

?>
