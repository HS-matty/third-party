<?php

session_register("cmode");
session_register("cthold");
session_register("corder");

##########################################################################
#  File:        comments.php                                             #
#  Description: This file controls the creation, previewing, and editing #
#               of comments posted to an article.                        #
##########################################################################

##########################################################################
#  Function: modone()                                                    #
#  Author:   phpNuke developers                                          #
#  Purpose:  This function is used in conjunction with modtwo/modthree   #
#            to allow for the moderation of comments (ie: scoring, etc). #
##########################################################################
function modone()
{
	include("config.php");
	global $admintest, $security_hash;

	if((($admintest == $security_hash) && ($moderate == 1)) || ($moderate == 2))
	echo "<form action=\"comments.php\" method=\"post\">";
}

##########################################################################
#  Function: modtwo()                                                    #
#  Author:   phpNuke developers                                          #
#  Purpose:  This function is used in conjunction with modone/modthree   #
#            to allow for the moderation of comments (ie: scoring, etc). #
##########################################################################
function modtwo($tid, $score, $reason)
{
	include("config.php");
	global $admintest, $user, $security_hash;

	if(((($admintest==$security_hash) && ($moderate == 1)) || ($moderate == 2)) && ($user))
	{
		echo " | <select name=\"dkn$tid\">";

		for($i=0; $i<sizeof($reasons); $i++)
		echo "<option value=\"$score:$i\">$reasons[$i]</option>\n";

		echo "</select>";
	}
}

##########################################################################
#  Function: modthree()                                                  #
#  Author:   phpNuke developers                                          #
#  Purpose:  This function is used in conjunction with modone/modtwo     #
#            to allow for the moderation of comments (ie: scoring, etc). #
##########################################################################
function modthree($sid)
{
	include("config.php");

	global $admintest, $user, $security_hash;

	if(((($admintest==$security_hash) && ($moderate == 1)) || ($moderate ==2 )) && ($user))
	echo "<div align=\"center\"><input type=\"hidden\" name=\"sid\" value=\"$sid\">
	<input type=\"hidden\" name=\"op\" value=\"moderate\" />
	<input type=\"submit\" value=\"Moderate\" /></div></form>
	";
}



##########################################################################
#  Function: DisplayKids()                                               #
#  Author:   phpNuke developers                                          #
#  Purpose:  Displays the comments of a topic $tid.                      #
##########################################################################
function DisplayKids ($tid, $level=0, $dummy=0, $tblwidth=99)
{
	global $datetime, $user, $cookie, $cmode, $corder, $cthold;
	include ("config.php");
	$comments = 0;
	cookiedecode($user);

	$q = "select tid, pid, sid, date, name, email, url, host_name, subject, comment, score, reason from comments where pid = $tid";

	if ($corder==0) $q .= " order by tid ASC";
	if ($corder==1) $q .= " order by tid desc";
	if ($corder==2) $q .= " order by score desc";
	
	$result = mysql_query("$q");

	if ($cmode == 'flat')
	{
		while (list($r_tid, $r_pid, $r_sid, $r_date, $r_name, $r_email, $r_url, $r_host_name, $r_subject, $r_comment, $r_score, $r_reason) = mysql_fetch_row($result))
		{
			if($r_score >= $cthold)
			{
				if (!eregi("[a-z0-9]",$r_name)) $r_name = $anonymous;
				if (!eregi("[a-z0-9]",$r_subject)) $r_subject = "(No Subject)";
				echo "<a name=\"$r_tid\"></a>
				";
				echo "&nbsp;&nbsp;
				<table border=\"0\" cellpadding=\"3\" cellspacing=\"0\">
				<tr>
					<td class=\"type4\">";

				formatTimestamp($r_date);

				if ($r_email)
				{
					echo "<span class=\"italic\">$r_subject&nbsp;</span>";
					if(!$cookie[7])
					{
						echo "(Score:&nbsp; $r_score";
						if($r_reason>0) echo ", $reasons[$r_reason]";
						echo ")";
					}
					echo "<br />by: <a href=\"mailto:$r_email\">$r_name</a>($r_email) on: $datetime";
 				}
				else
				{
					echo "<span class=\"italic\">$r_subject</span>&nbsp;";
					if(!$cookie[7])
					{
						echo "(Score: $r_score";
						if($r_reason>0) echo ", $reasons[$r_reason]";
						echo ")";
					}
					echo "<br /> by: $r_name on: $datetime";
				}
			
				if ($r_name != $anonymous)
				echo "<br />(<a href=\"user.php?op=userinfo&amp;uname=$r_name\">User Info</a>) ";

				if (eregi("http://",$r_url))
				echo "<a href=\"$r_url\" target=\"window\">$r_url</a> ";

				echo "
					</td>
				</tr>
				<tr>
					<td class=\"type5\">";

				if(($cookie[10]) && (strlen($r_comment) > $cookie[10]))
				echo substr("$r_comment", 0, $cookie[10])."<br /><br />
	<a href=\"comments.php?sid=$r_sid&amp;tid=$r_tid&amp;mode=$cmode&amp;order=$corder&amp;thold=$cthold\">
	Read the rest of this comment...</a>
				";
				elseif(strlen($r_comment) > $commentlimit)
				echo substr("$r_comment", 0, $commentlimit)."<br /><br />
	<a href=\"comments.php?sid=$r_sid&amp;tid=$r_tid&amp;mode=$cmode&amp;order=$corder&amp;thold=$cthold\">
	Read the rest of this comment...</a>
				";
				else
				echo $r_comment;

				echo "
					</td>
				</tr>
				</table>
				<br />
				[<a href=\"comments.php?op=Reply&amp;pid=$r_tid&amp;sid=$r_sid&amp;mode=$cmode&amp;order=$corder&amp;thold=$cthold\">Reply</a>";
				modtwo($r_tid, $r_score, $r_reason);
				echo " ]<br />";
				DisplayKids($r_tid);
			}
		}
	}
	else if ($cmode == 'nested')
	{
		while (list($r_tid, $r_pid, $r_sid, $r_date, $r_name, $r_email, $r_url, $r_host_name, $r_subject, $r_comment, $r_score, $r_reason) = mysql_fetch_row($result))
		{
			if($r_score >= $cthold)
			{
				if (!eregi("[a-z0-9]",$r_name)) $r_name = $anonymous;
				if (!eregi("[a-z0-9]",$r_subject)) $r_subject = "(No Subject)";

				echo "<a name=\"$r_tid\"></a>
				&nbsp;&nbsp;<ul>
				<table border=\"0\" cellpadding=\"3\" cellspacing=\"0\">
				<tr>
					<td class=\"type4\">\n";

				formatTimestamp($r_date);

				if ($r_email)
				{
					echo "<span class=\"italic\">$r_subject&nbsp;</span>";
					if(!$cookie[7])
					{
						echo "(Score:&nbsp; $r_score";
						if($r_reason>0) echo ", $reasons[$r_reason]";
						echo ")";
					}
					echo "<br />by: <a href=\"mailto:$r_email\">$r_name</a>($r_email) on: $datetime";
 				}
				else
				{
					echo "<span class=\"italic\">$r_subject</span>&nbsp;";
					if(!$cookie[7])
					{
						echo "(Score: $r_score";
						if($r_reason>0) echo ", $reasons[$r_reason]";
						echo ")";
					}
					echo "<br /> by: $r_name on: $datetime";
				}
			
				if ($r_name != $anonymous)
				echo "<br />(<a href=\"user.php?op=userinfo&amp;uname=$r_name\">User Info</a>) ";

				if (eregi("http://",$r_url))
				echo "<a href=\"$r_url\" target=\"window\">$r_url</a> ";

				echo "
					</td>
				</tr>
				<tr>
					<td class=\"type5\">";

				if(($cookie[10]) && (strlen($r_comment) > $cookie[10]))
				{
					echo substr("$r_comment", 0, $cookie[10])."<br /><br />
					<a href=\"comments.php?sid=$r_sid&amp;tid=$r_tid&amp;mode=$cmode&amp;order=$corder&amp;thold=$cthold\">
					Read the rest of this comment...</a>\n";
				}
				elseif(strlen($r_comment) > $commentlimit)
				{
					echo substr("$r_comment", 0, $commentlimit)."<br /><br />
					<a href=\"comments.php?sid=$r_sid&amp;tid=$r_tid&amp;mode=$cmode&amp;order=$corder&amp;thold=$cthold\">
					Read the rest of this comment...</a>\n";
				}
				else
				echo $r_comment;

				echo "
					</td>
				</tr>
				</table>
				<br />
				[ <a href=\"comments.php?op=Reply&amp;pid=$r_tid&amp;sid=$r_sid&amp;mode=$cmode&amp;order=$corder&amp;thold=$cthold\">Reply</a>\n";
				
				modtwo($r_tid, $r_score, $r_reason);
				echo " ]<br />";
				DisplayKids($r_tid);
				echo "</ul>";
			}
		}
	}
	else
	{
		while (list($r_tid, $r_pid, $r_sid, $r_date, $r_name, $r_email, $r_url, $r_host_name, $r_subject, $r_comment, $r_score, $r_reason) = mysql_fetch_row($result))
		{
			if($r_score >= $cthold)
			{
				if(isset($level))
				{
					if (!$comments)
					echo "";
				}
				$comments++;
				if (!eregi("[a-z0-9]",$r_name)) $r_name = $anonymous;
				if (!eregi("[a-z0-9]",$r_subject)) $r_subject = "(No Subject)";
				formatTimestamp($r_date);

				echo "<span class=\"onebiggerred\">&gt;</span>
	<a href=\"comments.php?op=showreply&amp;tid=$r_tid&amp;sid=$r_sid&amp;pid=$r_pid&amp;mode=$cmode&amp;order=$corder&amp;thold=$cthold#$r_tid\">
	$r_subject</a> by: $r_name on: $datetime<br />
				";

				DisplayKids($r_tid, $level+1, $dummy+1);
			} 
		}
	}
	if ($level && $comments)
	echo "&nbsp;&nbsp;";
}

##########################################################################
#  Function: DisplayBabies()                                             #
#  Author:   phpNuke developers                                          #
#  Purpose:  Displays the replys to comments of a topic $tid.            #
##########################################################################
function DisplayBabies($tid, $level=0, $dummy=0)
{
	global $datetime;
	include ("config.php");
	$comments = 0;
	$result = mysql_query("select tid, pid, sid, date, name, email, url, host_name, subject, comment, score, reason from comments where pid = $tid order by date, tid");
	while (list($r_tid, $r_pid, $r_sid, $r_date, $r_name, $r_email, $r_url, $r_host_name, $r_subject, $r_comment, $r_score, $r_reason) = mysql_fetch_row($result))
	{
		if(isset($level))
		{
			if (!$comments)
			echo "&nbsp;&nbsp;";
		}
		$comments++;
		
		if (!eregi("[a-z0-9]",$r_name)) { $r_name = $anonymous; }
		if (!eregi("[a-z0-9]",$r_subject)) { $r_subject = "(No Subject)"; }

		formatTimestamp($r_date);

		echo "
	<a href=\"comments.php?op=showreply&amp;tid=$r_tid&amp;mode=$cmode&amp;order=$corder&amp;thold=$cthold\">$r_subject</a> 
	by: $r_name on: $datetime<br />
		";

		DisplayBabies($r_tid, $level+1, $dummy+1);
	} 
	if($level && $comments)
	echo "&nbsp;&nbsp;";
}

##########################################################################
#  Function: DisplayTopic()                                              #
#  Author:   phpNuke developers                                          #
#  Purpose:  Displays the article selected by the user. It also displays #
#            the comments and replys to those comments indirectly by     #
#            calling DisplayKids().                                      #
##########################################################################
function DisplayTopic($sid, $pid=0, $tid=0, $cmode="threaded", $corder=0, $cthold=0, $level=0, $nokids=0)
{
	global $hr, $user, $datetime, $cookie, $mainfile, $admintest, $cmode, $corder, $cthold;
	if($mainfile)
	{
		global $title;
		include ("config.php");
	}
	else
	{
		if(!isset($mainfile))
		{
			include("mainfile.php");
		}
		include("header.php");
	}
	$count_times = 0;
	cookiedecode($user);

	$q = "select tid, pid, sid, date, name, email, url, host_name, subject, comment, score, reason from comments where sid=$sid and pid=$pid";

	if($cthold != "") $q .= " and score>=$cthold";
	else $q .= " and score>=0";

	if ($corder==0) $q .= " order by tid ASC";
	if ($corder==1) $q .= " order by tid desc";
	if ($corder==2) $q .= " order by score desc";

	$something = mysql_query("$q");
	$num_tid = mysql_num_rows($something);
	modone();

	while($count_times < $num_tid)
	{
		list($tid, $pid, $sid, $date, $name, $email, $url, $host_name, $subject, $comment, $score, $reason) = mysql_fetch_row($something);

		if ($name == "") $name = $anonymous;
		if ($subject == "") $subject = "(No Subject)";

		echo "<a name=\"$tid\"></a>\n<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\"><tr><td class=\"type4\">";

		formatTimestamp($date);

		if ($email)
		{
			echo "<span class=\"italic\">$subject</span>$nbsp;";
			if(!$cookie[7])
			{
				echo "(Score: $score";
				if($reason>0) echo ", $reasons[$reason]";
				echo ")";
			}
			echo "<br /> by: <a href=\"mailto:$email\">$name</a> ($email) on: $datetime"; 
		}
		else
		{
			echo "<span class=\"italic\">$subject</span>&nbsp;";
			if(!$cookie[7])
			{
				echo "(Score $score";
				if($reason>0) echo ", $reasons[$reason]";
				echo ")";
			}
			echo "<br /> by: $name on: $datetime";
		}			
		
		
		if ($name != $anonymous) echo "<br />(<a href=\"user.php?op=userinfo&amp;uname=$name\">User Info</a>)";
		if (eregi("http://",$url)) echo "<a href=\"$url\" target=\"window\">$url</a>";
		
		if($admintest)
		{
		    $result= mysql_query("select host_name from comments where tid='$tid'");
		    list($host_name) = mysql_fetch_row($result);
		    echo "<br />(IP: $host_name)";
		}
		
		echo "</td></tr><tr><td class=\"type5\">";

		if(($cookie[10]) && (strlen($comment) > $cookie[10]))
		{
			echo substr("$comment", 0, $cookie[10])."<br /><br />
			<a href=\"comments.php?sid=$sid&amp;tid=$tid&amp;mode=$cmode&amp;order=$corder&amp;thold=$cthold\">
			Read the rest of this comment...</a>\n";
		}
		elseif(strlen($comment) > $commentlimit)
		{
			echo substr("$comment", 0, $commentlimit)."<br /><br />
			<a href=\"comments.php?sid=$sid&amp;tid=$tid&amp;mode=$cmode&amp;order=$corder&amp;thold=$cthold\">
			Read the rest of this comment...</a>\n";
		}
		else
		echo $comment;

		echo "</td></tr></table><br />
		[ <a href=\"comments.php?op=Reply&amp;pid=$tid&amp;sid=$sid&amp;mode=$cmode&amp;order=$corder&amp;thold=$cthold\">
		Reply</a>\n";
		
		if ($pid != 0)
		{
			list($erin) = mysql_fetch_row(mysql_query("select pid from comments where tid=$pid"));
			echo "| <a href=\"comments.php?sid=$sid&amp;pid=$erin&amp;mode=$cmode&amp;order=$corder&amp;thold=$cthold\">Parent</a>";
		}
		modtwo($tid, $score, $reason);
		
		if($admintest)
		echo " | <a href=\"admin.php?op=RemoveComment&amp;tid=$tid&amp;sid=$sid\">Delete</a> ]<br />";
		else
		echo " ]<br />";
		
		DisplayKids($tid, $cmode, $corder, $cthold, $level);

		echo "<br />";
		if($hr) echo "&nbsp;&nbsp;";
		$count_times += 1;
	}
	modthree($sid);
	if($pid==0)
	return array($sid, $pid, $subject);
	else
	include("footer.php");
}

##########################################################################
#  Function: singlecomment()                                             #
#  Author:   phpNuke developers                                          #
#  Purpose:  This function's purpose has yet to be determined.           #
##########################################################################
function singlecomment($tid, $sid)
{
        global $cmode, $corder, $cthold;

	if(!isset($mainfile))
	{
		include("mainfile.php");
	}

	include("header.php");
	global $user, $cookie, $datetime;

	$deekayen = mysql_query("select date, name, email, url, subject, comment, score, reason from comments where tid=$tid and sid=$sid");
	list($date, $name, $email, $url, $subject, $comment, $score, $reason) = mysql_fetch_row($deekayen);

	$titlebar = "<span class=\"italic\">$subject</span>&nbsp;\n";

	if($name == "") $name = $anonymous;
	if($subject == "") $subject = "(No Subject)";

	modone();

	echo "<table width=\"99%\" border=\"0\"><tr><td class=\"type4\">\n";

	formatTimestamp($date);

	if($email)
	echo "<span class=\"italic\">$subject</span><br />(Score: $score)<br />
	by:<a href=\"mailto:$email\">$name</a>($email)on: $datetime\n";
	else
	echo "<span class=\"italic\">$subject</span><br />(Score: $score)<br />
	by: $name on: $datetime\n";

	echo "</td></tr><tr><td class=\"type3\">$comment</td></tr></table><br />
	[ <a href=\"comments.php?op=Reply&amp;pid=$tid&amp;sid=$sid&amp;mode=$cmode&amp;order=$corder&amp;thold=$cthold\">
	Reply</a> | <a href=\"article.php?sid=$sid&amp;mode=$cmode&amp;order=$corder&amp;thold=$cthold\">
	Root</a>
	";

	modtwo($tid, $score, $reason);
	echo " ]";
	modthree($sid, $cmode, $corder, $cthold);

	include("footer.php");
}

##########################################################################
#  Function: reply()                                                     #
#  Author:   phpNuke developers                                          #
#            Edited by: Adam Morton, am26882@appstate.edu                #
#  Purpose:  This function gets the info from the user or admin who is   #
#            replying to an article and posts it to the database.        #
##########################################################################
function reply($pid, $sid)
{
	include("header.php");
	global $user, $cookie, $datetime;

	if($pid != 0)
	list($date, $name, $email, $url, $subject, $comment, $score) = mysql_fetch_row(mysql_query("select date, name, email, url, subject, comment, score from comments where tid=$pid"));
	else
	list($date, $subject, $temp_comment, $comment, $name, $notes) = mysql_fetch_row(mysql_query("select time, title, hometext, bodytext, informant, notes FROM stories where sid=$sid"));

	if($comment == "") $comment = $temp_comment;
	else $comment = $temp_comment . "<br />" . $comment;
	$titlebar = "$subject";
	if($name == "") $name = $anonymous;
	if($subject == "") $subject = "(No Subject)";

	echo "<table width=\"100%\" border=\"0\" cellspacing=\"0\">
<tr>
	<td class=\"type4\" width=\"100%\">
	";
	formatTimestamp($date);

	if($email)
	{
		echo "<span class=\"italic\">$subject</span>&nbsp;";
		if(!$temp_comment) echo"(Score: $score)";
		echo "<br /> by: <a href=\"mailto:$email\">$name</a> ($email) on: $datetime";
	}else
	{
		echo "<span class=\"italic\">$subject</span>&nbsp;";
		if(!$temp_comment) echo"(Score: $score)";
		echo "<br /> by: $name on: $datetime";
	}
	echo "</td></tr><tr><td class=\"type5\">$comment $notes</td></tr></table>&nbsp;";

	if(!isset($pid) || !isset($sid))
	{
		echo "Something is not right. This message is just to keep things from messing up down the road.";
		exit();
	}

	if($pid == 0)
	list($subject) = mysql_fetch_row(mysql_query("select title from stories where sid=$sid"));
	else
	list($subject) = mysql_fetch_row(mysql_query("select subject from comments where tid=$pid"));

	echo "<form action=\"comments.php\" method=\"post\">";
	echo "Your Name: ";

	if ($user)
	{
		cookiedecode($user);
		echo "<a href=\"user.php\">$cookie[1]</a> [ <a href=\"user.php?op=logout\">Logout</a> ]";
	}
	else
	echo "$anonymous"; $postanon=2;

	echo "<br /><br />Subject:";

	if (!eregi("Re:",$subject)) $subject = "Re: $subject";

	echo "<br />
	<input type=\"text\" name=\"subject\" size=\"55\" maxlength=\"60\" value=\"$subject\" /><br /><br />
	Comment:<br />
	<textarea cols=\"50\" rows=\"10\" name=\"comment\" wrap=\"virtual\"></textarea><br />
	Allowed HTML:<br />
	";

	while (list($key,)= each($AllowableHTML)) echo " &lt;".$key."&gt;";

	echo "<br /><br />";

	if ($user)
	echo "<input type=\"checkbox\" name=\"postanon\" />Post Anonymously<br /><br />";

	echo "
	<input type=\"hidden\" name=\"pid\" value=\"$pid\" />
	<input type=\"hidden\" name=\"sid\" value=\"$sid\" />
	<input type=\"submit\" name=\"op\" value=\"Preview\" />&nbsp;
	<input type=\"submit\" name=\"op\" value=\"Ok!\" />
	<select name=\"posttype\">
	<option value=\"exttrans\">Extrans (html tags to text)</option>
	<option value=\"html\">HTML Formatted</option>
	<option value=\"plaintext\" selected=\"selected\">Plain Old Text</option>
	</select>
	</form><br />
	";
		
	include("footer.php");
}

##########################################################################
#  Function: replyPreview()                                              #
#  Author:   phpNuke developers                                          #
#            Edited by Adam Morton, am26882@appstate.edu                 #
#  Purpose:  Lets the user preview his/her comment before posting and    #
#            make changes if needed.                                     #
##########################################################################
function replyPreview($pid, $sid, $subject, $comment, $postanon, $cmode, $corder, $cthold, $posttype)
{
	if(!isset($mainfile))
	{
		include("mainfile.php");
	}

	include("header.php");
	global $user, $cookie;
	cookiedecode($user);
	$subject = stripslashes($subject);
	$comment = stripslashes($comment);

	if (!isset($pid) || !isset($sid))
	{
		echo "Something is not right with passing a variable to this function. This message is just to keep things from messing up down the road";
		exit();
	}

	echo "
<table width=\"100%\" border=\"0\" cellspacing=\"0\">
<tr>
	<td class=\"type4\">
	<span class=\"italic\">$subject</span><br />
	by: ";
	
	if ($user)
	echo "$cookie[1]";
	else
	echo "$anonymous";

	echo " on: </td>
</tr>
<tr>
	<td class=\"type5\">";

	if($posttype=="exttrans") echo str_replace("\n", "<br />", htmlspecialchars($comment));
	elseif($posttype=="plaintext") echo str_replace("\n", "<br />", $comment);
	else echo $comment;

	echo "
</td></tr></table>
<form action=\"comments.php\" method=\"post\"><br />Your Name: ";

	if ($user) echo "<a href=\"user.php\">$cookie[1]</a> [ <a href=\"user.php?op=logout\">Logout</a> ]";
	else echo "$anonymous";

	echo "<br />
	Subject:<input type=\"text\" name=\"subject\" size=\"50\" maxlength=\"60\" value=\"$subject\" /><br />
	Comment:<br /><textarea cols=\"50\" rows=\"10\" name=\"comment\" wrap=\"virtual\">$comment</textarea><br />
	Allowed HTML:<br />";

	while (list($key,)= each($AllowableHTML)) echo " &lt;".$key."&gt;";

	echo "<br />";

	if ($postanon)
	echo "<br />
	<input type=\"checkbox\" name=\"postanon\" checked=\"checked\" />
	Post Anonymously<br /><br />
	";
	elseif($user)
	echo "<input type=\"checkbox\" name=\"postanon\" /><Post Anonymously<br />";

	echo "
	<input type=\"hidden\" name=\"pid\" value=\"$pid\" />
	<input type=\"hidden\" name=\"sid\" value=\"$sid\" />
	<input type=\"submit\" name=\"op\" value=\"Preview\" />&nbsp;
	<input type=\"submit\" name=\"op\" value=\"Ok!\" />
	<select name=\"posttype\"><option value=\"exttrans\"";

	if($posttype=="exttrans") echo" selected=\"selected\" ";
	echo  ">Extrans (html tags to text)</option><option value=\"html\"";;
	if($posttype=="html") echo" selected=\"selected\"";
	echo ">HTML Formatted</option><option value=\"plaintext\"";
	if(($posttype!="exttrans") && ($posttype!="html")) echo" selected=\"selected\"";
	echo ">Plain Old Text</option></select></form><br />";

	include("footer.php");
}

##########################################################################
#  Function: CreateTopic()                                               #
#  Author:   phpNuke developers                                          #
#            Edited by Adam Morton, am26882@appstate.edu                 #
#  Purpose:  Posts a new comment into the database then returns the user #
#            to the article he/she just posted to.                       #
##########################################################################
function CreateTopic ($postanon, $subject, $comment, $pid, $sid, $host_name, $posttype)
{

	global $cmode, $corder, $cthold;

	if(!isset($mainfile))
	{
		include("mainfile.php");
	}

	global $user, $userinfo, $EditedMessage, $cookie;
	$author = FixQuotes($author);
	$subject = htmlspecialchars($subject);

	$subject = FixQuotes(filter_text($subject, "nohtml"));
$comment = htmlspecialchars($comment);
	if($posttype=="exttrans")
	$comment = FixQuotes(str_replace("\n", "<br />", check_words($comment)));
	elseif($posttype=="plaintext")
	$comment = nl2br(FixQuotes(str_replace("\n", "<br />", filter_text($comment))));
	else
	$comment = nl2br(FixQuotes(filter_text($comment)));

	if($user) getusrinfo($user);
	if (($user) && (!$postanon))
	{
		getusrinfo($user);
		$name = $userinfo[uname];
		$email = $userinfo[femail];
		$url = $userinfo[url];
		$score = 1;
	}
	else
	{
		$name = ""; $email = ""; $url = "";
		$score = 0;
	}

	$ip = getenv("REMOTE_ADDR");

	//begin fake thread control
	list($fake) = mysql_fetch_row(mysql_query("select count(*) from stories where sid=$sid"));

	mysql_query("LOCK TABLES comments WRITE");

	//begin duplicate control
	list($tia) = mysql_fetch_row(mysql_query("select count(*) from comments where pid='$pid' and sid='$sid' and subject='$subject' and comment='$comment'"));

	//begin troll control
	if($user)
	list($troll) = mysql_fetch_row(mysql_query("select count(*) from comments where (score=-1) and (name='$userinfo[uname]') and (to_days(now()) - to_days(date) < 3)"));
	elseif(!$score)
	list($troll) = mysql_fetch_row(mysql_query("select count(*) from comments where (score=-1) and (host_name='$ip') and (to_days(now()) - to_days(date) < 3)"));

	if((!$tia) && ($fake == 1) && ($troll < 6))
	mysql_query("insert into comments values (NULL, '$pid', '$sid', now(), '$name', '$email', '$url', '$ip', '$subject', '$comment', '$score', '0')");
	else
	{
		mysql_query("UNLOCK TABLES");
		include("header.php");

		if($tia)
		echo "Duplicate.  = [Did you submit twice?<br /><br />
		<a href=\"article.php?sid=$sid&mode=$cmode&order=$corder&thold=$cthold\">Back to comments</a>
		";
		elseif($troll > 5) echo "This account or IP has been temporarily disabled.
		<br /><br /><a href=\"article.php?sid=$sid&mode=$cmode&order=$corder&thold=$cthold\">Back to comments</a>
		";
		elseif($fake == 0) echo "The topic you are trying to reply to does not exist.
		";
		include("footer.php");
		exit;
	}
	mysql_query("UNLOCK TABLES");
	mysql_query("update stories set comments=comments+1 where sid='$sid'");
	Header("Location: article.php?sid=$sid&mode=$cmode&order=$corder&thold=$cthold");
}

##########################################################################
#  Function: check_num_comments()                                        #
#  Author:   Adam Morton, am26882@appstate.edu                           #
#  Purpose:  This is basically advanced "troll" control. It checks how   #
#            many posts were submitted by a certain IP address and will  #
#            not allow a certain IP to post more than $max_user_comments #
#            to a particular article. $max_user_comments can be set by   #
#            the system admin in the config.php file.                    #
##########################################################################
function check_num_comments($sid)
{
	include("config.php");
	global $admintest;

	if(!isset($mainfile))
	{
		include("mainfile.php");
	}

	if($admintest==1)
		return;

	$ip = getenv("REMOTE_ADDR");
	$result = mysql_query("select * from comments where sid='$sid' and host_name='$ip'");
	$num_rows = mysql_num_rows($result);
	
	if($num_rows+1 > $max_user_comments)
	comment_error();
}

##########################################################################
#  Function: comment_error()                                             #
#  Author:   Adam Morton, am26882@appstate.edu                           #
#  Purpose:  If a user has posted more than the allowed number of times  #
#            to a particular article he/she is given this error.         #
##########################################################################
function comment_error()
{
	include ("header.php");

	echo "
<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
<tr>
	<td class=\"type0\">
<table border=\"0\" width=\"100%\" cellpadding=\"5\" cellspacing=\"1\">
<tr>
	<td class=\"type4bigger\"><font color=\"red\">Error!!</font></td>
</tr>
        ";

	echo "
	<tr>
        <td class=\"type5\" align=\"center\"><b>The following error has occurred:</b><br /><br />
	You have exceeded your maximum number of posts for this announcement.
	If you have any questions please contact the administrator of this site at the following address:
	<br /><br /><a href=\"mailto:$adminmail?subject=Max comments exceeded\">$adminmail</a>
        </td>
</tr>
</table>
</td></tr></table>
        ";

	include("footer.php");
	exit();
}

##########################################################################
#  Function: The SWITCH (not REALLY a function)                          #
#  Author:   phpNuke developers                                          #
#            Edited by: Adam Morton, am26882@appstate.edu                #
#  Purpose:  This switch statement takes the arguement $op passed to the #
#            comments page and decides which functions to call based on  #
#            that variable.                                              #
##########################################################################
switch($op)
{
	case "Reply":
	check_num_comments($sid);
	reply($pid, $sid, $cmode, $corder, $cthold);
	break;

	case "Preview":
	replyPreview ($pid, $sid, $subject, $comment, $postanon, $cmode, $corder, $cthold, $posttype);
	break;

	case "Ok!":
	CreateTopic($postanon, $subject, $comment, $pid, $sid, $host_name, $cmode, $corder, $cthold, $posttype);
	break;

	case "moderate":
	if($admintest==1)
	include("auth.inc.php");
	else
	if(!isset($mainfile))
	{
		include("mainfile.php");
	}
		
	if(($admintest) || ($cmoderate==2))
	{
		$__post = (phpversion() >= "4.1.0") ? $_POST : $HTTP_POST_VARS;
		while(list($tdw, $emp) = each($__post))
		{
			if (eregi("dkn",$tdw))
			{
				$emp = explode(":", $emp);
				if($emp[1] != 0)
				{
					$tdw = str_replace("dkn", "", $tdw);
					$q = "UPDATE comments SET";

					if(($emp[1] == 9) && ($emp[0]>=0))         #Overrated
					 $q .= " score=score-1 where tid=$tdw";
					elseif(($emp[1] == 10) && ($emp[0]<=4))    #Underrated
					 $q .= " score=score+1 where tid=$tdw";
					elseif(($emp[1] > 4) && ($emp[0]<=4))
					 $q .= " score=score+1, reason=$emp[1] where tid=$tdw";
					elseif (($emp[1] < 5) && ($emp[0] > -1))
					 $q .= " score=score-1, reason=$emp[1] where tid=$tdw";
					elseif (($emp[0] == -1) || ($emp[0] == 5))
					 $q .= " reason=$emp[1] where tid=$tdw";

					if(strlen($q) > 20) mysql_query("$q");
				}
			}
		}
	}
	Header("Location: article.php?sid=$sid&mode=$cmode&order=$corder&thold=$cthold");
	break;

	case "showreply":
	DisplayTopic($sid, $pid, $tid, $cmode, $corder, $cthold);
	break;

	default:
	if((isset($tid)) && (!isset($pid)))
		singlecomment($tid, $sid);
	elseif(($mainfile) xor (($pid==0) || (!isset($pid))))
		Header("Location: article.php?sid=$sid&mode=$cmode&order=$corder&thold=$cthold");
	else
	{
		if(!isset($pid)) $pid=0;
		DisplayTopic($sid, $pid, $tid);
	}
	break;
}

?>
