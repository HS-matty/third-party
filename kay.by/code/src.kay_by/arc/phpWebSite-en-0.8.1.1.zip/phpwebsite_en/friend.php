<?php
/**
 * Allows to send an announcement or the URL of the site to a friend.
 *
 * Allows to send the link of an announcement or the URL of the site to a 
friend.
 * Currently does not check for input (bad email, ...). Hopefully will be
 * fixed in next versions.
 *
 * @module
 * @modulegroup
 * @package phpWebSite
 */

include("open_session.php");

if(!isset($mainfile))
{
	/* Defines core functions. */
	include("mainfile.php");
}

/* Global configuration data */
include("config.php");

/* Generates page header */
include ("header.php");

function FriendSend($sid, $yname, $ymail, $fname, $fmail, $comments, $box_stuff)
{
	include("config.php");
	if (!ereg("^.+@.+\\..+$", $ymail))
	{
		$ymail = "";
	}
	if (!ereg("^.+@.+\\..+$", $fmail))
	{
		$fmail = "";
	}

	global $user, $cookie;
	if(!isset($sid))
	{
		exit();
	}
	$result=mysql_query("select title from stories where sid=$sid");
	list($title) = mysql_fetch_row($result);
	$box_stuff .= "
<br />
You will send the announcement <b>" . check_html($title, "nohtml") . "</b> to the following person:<br 
/><br />
<form action=\"friend.php\" method=\"post\">
<input type=\"hidden\" name=\"sid\" value=\"$sid\" />
	";

	if ($user)
	{
		cookiedecode($user);
		if ($user_dblocation)
		{
			@mysql_select_db("$user_dbname") or die ("Unable to select database");
			$result=mysql_query("select name, email from users where uname='$cookie[1]'");
			@mysql_select_db("$dbname") or die ("Unable to select database");
		}
		else
		{
			$result=mysql_query("select name, email from users where uname='$cookie[1]'");		
		}
		list($yname, $ymail) = mysql_fetch_row($result);
	}
	$box_stuff .= "
<table>
<tr>
	<td class=\"type5\"><b>Your name:*</b></td>
	<td class=\"type5\"><input type=\"text\" name=\"yname\" value=\"$yname\" /></td>
</tr>
<tr>
	<td class=\"type5\"><b>Your email:*</b></td>
	<td class=\"type5\"><input type=\"text\" name=\"ymail\" value=\"$ymail\" /></td>
</tr>
<tr>
	<td height=\"10\"></td>
	<td height=\"10\"></td>
</tr>
<tr>
	<td class=\"type5\"><b>Your friend name:*</b></td>
	<td class=\"type5\"><input type=\"text\" name=\"fname\" value=\"$fname\" /></td>
</tr>
<tr>
	<td class=\"type5\"><b>Your friend email:*</b></td>
	<td class=\"type5\"><input type=\"text\" name=\"fmail\" value=\"$fmail\" /></td>
</tr>
<tr>
	<td height=\"10\"></td>
	<td height=\"10\"></td>
</tr>
<tr>
	<td colspan=\"2\"><b>Your comments:</b></td>
</tr>
<tr>
	<td colspan=\"2\"><textarea name=\"comments\" rows=\"7\" cols=\"50\" wrap=\"virtual\">$comments</textarea></td>
</tr>
<tr>
	<td height=\"10\"></td>
	<td height=\"10\"></td>
</tr>
<tr>
	<td class=\"type5\"><input type=\"hidden\" name=\"op\" value=\"SendStory\" /><input type=\"submit\" value=\"Send\" /></td>
	<td class=\"type5\"></td>
</tr>
</table>
</form>
	";

	themesidebox("Send a announcement to a friend", $box_stuff);

	/* Generates page footer */
	include ("footer.php");
}


function SendStory($sid, $yname, $ymail, $fname, $fmail, $comments)
{
	global $sitename, $nuke_url;

	if (!$yname=="" && !$ymail=="" && ereg("^.+@.+\\..+$", $ymail) && !$fname=="" && !$fmail=="" && ereg("^.+@.+\\..+$", $fmail))
	{
		$result2=mysql_query("select title, time, topic from stories where sid=$sid");
		list($title, $time, $topic) = mysql_fetch_row($result2);

		$result3=mysql_query("select topictext from topics where topicid=$topic");
		list($topictext) = mysql_fetch_row($result3);

		$subject = "Interesting announcement at 
$sitename";
		if ($comments != "")
		{
			$message = "Hello $fname:\n\nYour friend $yname considered the following announcement ";
			$message .= "\n\nTitle: " . check_html($title, "nohtml") . "\nDate: $time\n";
			$message .= "Topic: $topictext\nURL: $nuke_url/article.php?sid=$sid\n\n";
			$message .= "$yname made the following comments:\n$comments\n\n";
			$message .= "You can read other interesting announcements at $sitename\n$nuke_url";
		}
		else
		{
			$message = "Hello $fname:\n\nYour friend $yname considered the following announcement ";
			$message .= "\n\n\nTitle: " . check_html($title, "nohtml") . "\nDate: $time\n";
			$message .= "Topic: $topictext\nURL: $nuke_url/article.php?sid=$sid\n\n";
			$message .= "You can read other interesting announcements at $sitename\n$nuke_url";
		}
		mail($fmail, $subject, $message, "From: \"$yname\" <$ymail>\nX-Mailer: PHP/" . phpversion());
		$title = urlencode($title);
		$fname = urlencode($fname);
		StorySent($title,$fname);
	}
	else
	{
		FriendSend($sid, $yname, $ymail, $fname, $fmail, $comments, "<center><span class=\"onebiggerred\">The fields marked with a * are mandatory</span></center>");
	}
}


function StorySent($title, $fname)
{
	$title = urldecode($title);
	$fname = urldecode($fname);

	$box_stuff = "The announcement <b>" . check_html($title, "nohtml") . "</b>
	has been successfully sent to $fname...<br /><br />Thanks!<br />";
	themesidebox("Announcement sent", $box_stuff);

	/* Generates page footer */
	include ("footer.php");
}


function RecommendSite($yname, $ymail, $fname, $fmail, $comments, $box_stuff)
{
	if (!ereg("^.+@.+\\..+$", $ymail))
	{
		$ymail = "";
	}
	if (!ereg("^.+@.+\\..+$", $fmail))
	{
		$fmail = "";
	}

	global $user, $cookie;
	$box_stuff .= "
<br />
<form action=\"friend.php\" method=\"post\">
<input type=\"hidden\" name=\"op\" value=\"SendSite\" />
	";

	if ($user)
	{
		cookiedecode($user);
		$result=mysql_query("select name, email from users where uname='$cookie[1]'");
		list($yname, $ymail) = mysql_fetch_row($result);
	}

	$box_stuff .= "
<table>
<tr>
	<td class=\"type5\"><b>Your name:*</b></td>
	<td class=\"type5\"><input type=\"text\" name=\"yname\" value=\"$yname\" /></td>
</tr>
<tr>
	<td class=\"type5\"><b>Your email:*</b></td>
	<td class=\"type5\"><input type=\"text\" name=\"ymail\" value=\"$ymail\" /></td>
</tr>
<tr>
	<td height=\"10\"></td>
	<td height=\"10\"></td>
</tr>
<tr>
	<td class=\"type5\"><b>Your friend name:*</b></td>
	<td class=\"type5\"><input type=\"text\" name=\"fname\" value=\"$fname\" /></td>
</tr>
<tr>
	<td class=\"type5\"><b>Your friend email:*</b></td>
	<td class=\"type5\"><input type=\"text\" name=\"fmail\" value=\"$fmail\" /></td>
</tr>
<tr>
	<td height=\"10\"></td>
	<td height=\"10\"></td>
</tr>
<tr>
	<td colspan=\"2\"><b>Your comments:</b></td>
</tr>
<tr>
	<td colspan=\"2\"><textarea name=\"comments\" rows=\"7\" cols=\"50\">$comments</textarea></td>
</tr>
<tr>
	<td height=\"10\"></td>
	<td height=\"10\"></td>
</tr>
<tr>
	<td class=\"type5\"><input type=submit value=\"Send\" /></td>
	<td class=\"type5\"></td>
</tr>
</table>
</form>
	";

	themesidebox("Recommend this site to a friend", $box_stuff);

	/* Generates page footer */
	include ("footer.php");
}


function SendSite($yname, $ymail, $fname, $fmail, $comments)
{
	global $sitename, $titletag, $nuke_url;

	if (!$yname=="" && !$ymail=="" && ereg("^.+@.+\\..+$", $ymail) && !$fname=="" && !$fmail=="" && ereg("^.+@.+\\..+$", $fmail))
	{
		$subject = "A friend recommends you to visit $sitename";
		if ($comments != "")
		{
			$message = "Hello $fname:\n\nYour friend $yname recommends you to visit $sitename.\n\n\n$sitename\n$titletag\nURL: $nuke_url\n\n$yname made the following comments: $comments\n\n";
		}
		else
		{
			$message = "Hello $fname:\n\nYour friend $yname recommends you to visit $sitename.\n\n\n$sitename\n$titletag\nURL: $nuke_url\n\n";
		}
		mail($fmail, $subject, $message, "From: \"$yname\" <$ymail>\nX-Mailer: PHP/" . phpversion());
		SiteSent($fname);
	}
	else
	{
		RecommendSite($yname, $ymail, $fname, $fmail, $comments, "<center><span class=\"onebiggerred\">The fields marked with a * are mandatory</span></center>");
	}
}


function SiteSent($fname)
{
	$box_stuff = "The site URL was successfully sent to $fname...<br /><br />Thanks!<br />";
	themesidebox("URL sent", $box_stuff);

	/* Generates page footer */
	include ("footer.php");
}


switch($op)
{
    case "SendStory":
    SendStory($sid, $yname, $ymail, $fname, $fmail, $comments);
    break;

    case "SendSite":
    SendSite($yname, $ymail, $fname, $fmail, $comments);
    break;

    case "FriendSend":
    FriendSend($sid, "", "", "", "", "", "");
    break;

    default:
    RecommendSite("", "", "", "", "", "");
    break;
}

?>
