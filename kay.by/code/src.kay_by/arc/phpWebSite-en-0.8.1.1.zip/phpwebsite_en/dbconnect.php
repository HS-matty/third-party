<?php

/*
 * Connects to the database using the parameters from above.
 * BE SURE TO CHANGE THE DATABASE PARAMS TO REFLECT YOUR DATABASE SETTINGS!
*/

function dbconnect()
{
	include ("config.php");
	mysql_connect($dbhost, $dbuname, $dbpass);
	@mysql_select_db("$dbname") or die ("Unable to select database");
}

dbconnect();
$dbconnect = 1;

?>
