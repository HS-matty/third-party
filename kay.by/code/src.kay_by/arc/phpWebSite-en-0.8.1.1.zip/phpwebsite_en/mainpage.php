<?php
/**
 * Create and edit data on phpWebSite main page.
 *
 * @author Adam Morton <am26882@appstate.edu>
 * @module 
 * @modulegroup administration
 * @package phpWebSite
 */

/**
 * Gets data from user to populate main page.
 */
function main_page_data()
{
  /**
   * Generates page header.
   */
	include("header.php");
	GraphicAdmin(0);
	$result = mysql_query("select main_title, main_text, main_image, main_image_active, alt, active from main_page_content");
	list($main_title, $main_text, $main_image, $main_image_active, $main_alt, $active) = mysql_fetch_row($result);

        $main_title = htmlspecialchars(stripslashes($main_title));
        $main_text = htmlspecialchars(stripslashes($main_text));
        $main_alt = htmlspecialchars(stripslashes($main_alt));

	$box_title = "Populate Main Page";
	$box_stuff = "<form action=\"admin.php\" method=\"post\" enctype=\"multipart/form-data\">

<table align=\"center\" cellspacing=\"10\">
<tr><td class=\"type5\" align=\"left\" colspan=\"2\">";

	if($active){ 
		$box_stuff .= "<input type=\"checkbox\" name=\"active\" value=\"1\" checked=\"checked\" />";
	}
	else{ 
		$box_stuff .= "<input type=\"checkbox\" name=\"active\" value=\"1\" />";
	}

	$box_stuff .= "Make this content active?
</td></tr>

<tr><td class=\"type5\" valign=\"top\" align=\"left\" width=\"50%\">
	Main Title: <br />
	<input type=\"text\" name=\"main_title\" value=\"$main_title\" maxlength=\"200\" size=\"33\" />
        <br />
        Main Text: <br />
	<textarea name=\"main_text\" cols=\"55\" rows=\"20\" wrap=\"virtual\">$main_text</textarea><br />
	Main Image: <br />";

	if($main_image != "none"){
		$box_stuff .= "<img src=\"$main_images_webdir$main_image\" alt=\"$main_alt\" /><br />
        	<input type=\"hidden\" name=\"old_main_image\" value=\"$main_image\" />
        	<input type=\"file\" name=\"main_image\" maxlength=\"60\" size=\"25\" />
        	<br />
        	Short Image Description:<br />
        	<input type=\"text\" name=\"main_alt\" maxlength=\"60\" size=\"33\" value=\"$main_alt\" />";
	}
	else{
		$box_stuff .= "<input type=\"file\" name=\"main_image\" maxlength=\"60\" size=\"25\" />
        	<br />
		<input type=\"hidden\" name=\"old_main_image\" value=\"0\" />
        	Short Image Description:<br />
        	<input type=\"text\" name=\"main_alt\" maxlength=\"60\" size=\"33\" value=\"$main_alt\" />";
	}

	if($main_image_active)
	{
		$box_stuff .= "<br /><input type=\"checkbox\" name=\"main_image_active\" value=\"1\" checked=\"checked\" />";
	}
	else
	{
		$box_stuff .= "<br /><input type=\"checkbox\" name=\"main_image_active\" value=\"1\" />";
	}

	$box_stuff .= "&nbsp;Make this image active?</td></tr><tr>
	<td class=\"type5bigger\" colspan=\"2\" align=\"left\">
	<input type=\"hidden\" name=\"op\" value=\"submit_main_page\" />
	<input type=\"submit\" value=\"Submit\" />
</td></tr>
</table>

	</form>";
themesidebox($box_title, $box_stuff);
	
  /**
   * Generates page footer.
   */
	include ('footer.php');
}

function update_main_page($main_title, $main_text, $main_image, $main_alt, $main_image_name, $main_image_active, $main_image_type, $main_image_size, $active)
{
  /**
   * Defines core functions.
   */
	include("config.php");

	if(substr_count($main_title, "<?")) $main_title = str_replace("<?", "<NOPHP", $main_title);
	if(substr_count($main_text, "<?")) $main_text = str_replace("<?", "<NOPHP", $main_text);
	if(substr_count($main_alt, "<?")) $main_alt = str_replace("<?", "<NOPHP", $main_alt);

	$main_title = addslashes($main_title);
	$main_text = addslashes($main_text);

	if($main_image != 'none')
	{
		if($main_image_size > $max_user_file_size)
		page_error("$image_name / $level : The image in the section is too large. <br />
	                  The largest allowable size is: $max_user_file_size bytes.<br />
		          Your file is: $main_image_size bytes.");

		$this_image_type = explode(";", $main_image_type);

		if(substr_count($allowed_types, $this_image_type[0]) > 0)
		{
			if(copy($main_image, $main_page_images.$main_image_name))
			mysql_query("update main_page_content set main_title='$main_title', main_text='$main_text', main_image='$main_image_name', main_image_active='$main_image_active', alt='$main_alt', active='$active'");
			else
			page_error("$main_image_name : The image did not load sucessfully.  Please try again.<br />");
		}
		else
		page_error("$image_name / $level : The image in the section has a wrong file type.<br />
	                  The allowed types are:$allowed_types<br />
			  You file is of type: $this_image_type[0]");
	}
	else
	{
		mysql_query("update main_page_content set main_title='$main_title', main_text='$main_text', main_image='$main_image_name', main_image_active='$main_image_active', alt='$main_alt', active='$active'");
	}
}

//Tests fields from main_page_data() for correctness.
function test_data($main_flag, $title, $text, $image, $alt)
{
	$alt = 1;

        if(!$title && $main_flag)
	  $type = "No title submitted!";
	else if(!$text && $main_flag)
	  $type = "No main text submitted! You must fill in the first TEXT field.";
	else if(($image != "none") && !$alt)
	  $type = "You must supply a small description for images (around 15-20 characters).";
        else
          $type = "none";

	if($type != "none")
	page_error($type);
}

//Produces an appropriate page error.
function page_error($type)
{
        include ("header.php");
	GraphicAdmin(0);

	echo "
<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
<tr>
	<td class=\"type0\">
<table border=\"0\" width=\"100%\" cellpadding=\"5\" cellspacing=\"1\">
<tr>
	<td class=\"type4\"><font color=\"red\">Data Error!!</font></td>
</tr>
<tr>
        <td class=\"type5\" align=\"center\"><b>The following error has occurred:</b>
	<br /><br />
	$type
	<br /><br />
        Please hit the back button on your browser and re-submit your data.
        </td>
</tr>
</table>
</td></tr></table>
        ";

	include("footer.php");
	exit();
}

function save_new_page()
{
	include ("header.php");
	GraphicAdmin(0);
	
	echo "
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
	<tr>
	<td class=\"type0\">
	<table border=\"0\" width=\"100%\" cellpadding=\"5\" cellspacing=\"1\">
	<tr>
	<td class=\"type4\">PAGE SAVED!</td>
	</tr>
	<tr>
	<td class=\"type5\" align=\"center\">
	<font size=\"4\"><b>Your page has been saved!</b></font>
	</td>
	</tr>
	</table>
        </td>
	</tr>
	</table>
        ";
	include("footer.php");
}
?>
