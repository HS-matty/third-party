<?php
  // to use this file add a line like this:
  // $names[]="badname";
  // This will disallow anyone who's name contains 'badname'.
  // This means that both "badname" and "bob badname" would be disallowed.

  // $names[]="";
?>