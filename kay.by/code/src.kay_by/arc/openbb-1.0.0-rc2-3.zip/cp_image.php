<?php
$images = 'selected';

if ($do == '') {
   $SI['templates'] = '50|143';
   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
	
	$smileygroups = '<select name="smileygroup">';

	 $query = new query($SQL, "SELECT id, name FROM smileysets");   
    while ($result = $query->getrow()) {

	$smileygroups .= '<option value="'.$query->field('id').'">'.$query->field('name').'</option>';
   }
	$smileygroups .= '</select>';


	$icons = '<select name="icon">';

	 $query = new query($SQL, "SELECT id, image FROM topicicons");   
    while ($result = $query->getrow()) {

	$icons .= '<option value="'.$query->field('id').'">'.$query->field('image').'</option>';
   }
	$icons .= '</select>';


	$smileys = '<select name="smiley">';

	 $query = new query($SQL, "SELECT id, smiley, image FROM smilies");   
    while ($result = $query->getrow()) {

	$smileys .= '<option value="'.$query->field('id').'">'.$query->field('smiley').' -  '.$query->field('image').'</option>';
   }
	$smileys .= '</select>';
   eval("\$include = \"".addslashes(addslashes($TI[143]))."\";"); 
   eval("\$output = \"".addslashes($TI[50])."\";");
   print stripslashes($output); flush;
   exit();  
} 

elseif ($do == 'addicon') {

   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
	

  if ($icon_type == 'image/pjpeg' || $icon_type == 'image/jpeg') { $type = '.jpg'; }
   if ($icon_type == 'image/gif') { $type = '.gif'; }
   
   if (!$type) {
      gen_error('Cannot upload the icon','Only GIF and JPG avatars are allowed.'); 
   }


   $query = new query($SQL,"SELECT id FROM topicicons ORDER BY id DESC LIMIT 1");
   $query->getrow();
   $id = $query->field('id') + 1;

   copy($icon,'images/openbb/icon'.$id.$type);

   new query($SQL, "INSERT INTO topicicons VALUES ('".$id."','icon".$id.$type."')");
   @header("Location: cp_image.php");
}

elseif ($do == 'removeicon') {

   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
	

   if ($icon != 0) {
   @unlink('images/openbb/icon'.$icon);
 
   new query($SQL, "DELETE FROM topicicons WHERE id = '".$icon."'");
   new query($SQL, "UPDATE topics SET icon = 0 WHERE icon = $icon");
   }
   @header("Location: cp_image.php");
}


elseif ($do == 'addsmiley') {

   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
	

  if ($smiley_type == 'image/pjpeg' || $smiley_type == 'image/jpeg') { $type = '.jpg'; }
   if ($smiley_type == 'image/gif') { $type = '.gif'; }
   
   if (!$type) {
      gen_error('Cannot upload the icon','Only GIF and JPG avatars are allowed.'); 
   }


   $query = new query($SQL,"SELECT id FROM smilies ORDER BY id DESC LIMIT 1");
   $query->getrow();
   $id = $query->field('id') + 1;

   copy($smiley,'images/openbb/smiley/'.$id.$type);

   new query($SQL, "INSERT INTO smilies VALUES ('".$id."','".$smileychar."','".$id.$type."','".$smileygroup."')");
   @header("Location: cp_image.php");
}



elseif ($do == 'removesmiley') {

   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
	

	$query = new query($SQL, "SELECT image FROM smilies WHERE id = '".$smiley."'");
	$query->getrow();

   @unlink('images/openbb/smiley/'.$query->field('image'));
 
   new query($SQL, "DELETE FROM smilies WHERE id = '".$smiley."'");
   @header("Location: cp_image.php");
}




elseif ($do == 'addgroup') {

   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
	

   $query = new query($SQL,"SELECT id FROM smileysets ORDER BY id DESC LIMIT 1");
   $query->getrow();
   $id = $query->field('id') + 1;


   new query($SQL, "INSERT INTO smileysets VALUES ('".$id."','".$name."')");
   @header("Location: cp_image.php");
}

elseif ($do == 'removegroup') {

   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);

   new query($SQL, "DELETE FROM smileysets WHERE id = $smileygroup");
   @header("Location: cp_image.php");
}

?>