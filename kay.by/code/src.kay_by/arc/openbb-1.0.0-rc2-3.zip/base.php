<?php
error_reporting(0);
/*
 *
 *  openbb, copyright (c)2001 iansoft
 *  public release beta 1.0.0
 *  http://www.iansoft.net/
 *
 *  Niels Van der Wildt <niels@iansoft.net>
 *  Kelly Hamlin <kelly@iansoft.net>
 *
 */

// ###############################
//           START INIT
// ###############################

$mtime1 = microtime();
$mtime1 = explode(" ",$mtime1); 
$start_of_openbb = $mtime1[1] + $mtime1[0]; 
define('NUKE','0');


// Base Settings
$php = '.php';                                 
include 'lib/functions'.$php;  
$true = 'can';
$false = 'cannot';

// Add No Cache Headers
@header("expires: wensday, 20 may 1987 16:50:00 gmt");       
@header("last-modified: " . gmdate("d, d m y h:i:s") . "gmt");
@header("cache-control: no-cache, must-revalidate");        
@header("pragma: no-cache");     

// Include Configuration files & Connect to DB
include 'lib/sqldata.php';                                                        
include 'lib/database/'.$database_server['type'].$php;
$SQL = new db;
$result = $SQL->open($database_server['database'], $database_server['hostname'], $database_server['username'], $database_server['password']);

// Need Table Prefix if PHP Nuke

define('OBB','BETA1');


if (NUKE) { $prefix = 'nuke_'; }

// Set Standart Expire (1 Year)
$expire=time() + 31536000;

if (!$result) { show_dberror('could not connect to the database server'); }
// Get Configuration from DB

if (isset($SI['settings'])) { $SI['settings'] .= ', cookiepath, boardurl, boardname, time1, time2, time3, usegzip, locked, lockedreason, gzlevel, pmauthor, sendpm, regpm, redirect, lastadd'; } else { $SI['settings'] = 'cookiepath, boardurl, boardname, locked, time1, time2, time3, usegzip, gzlevel, pmauthor, sendpm, regpm, redirect, lastadd'; }
$config = new query($SQL, "SELECT ".$SI['settings']." FROM ".$prefix."configuration");
if (!$config->getrow()) { show_dberror('could not get settings from database server'); }
$timeformat[1] = $config->field('time1');
$timeformat[2] = $config->field('time2');
$timeformat[3] = $config->field('time3');
$boardname = $config->field('boardname');
if ($config->field('usegzip')) { ob_start(); }


// GPC and SLASHES and register globals
while(list($mname,$mval) = each($HTTP_GET_VARS)) {
	if (is_string($mval) && !get_magic_quotes_gpc()) {
		$mval = addslashes($mval);
		$HTTP_GET_VARS[$mname] = $mval;
		$$mname = $mval;
	}
	if (!isset($$mname))
		$$mname = $mval;
}

if (!get_magic_quotes_gpc()) {
	while(list($mname,$mval) = each($HTTP_POST_VARS))
		if (is_string($mval)) {
			$mval = addslashes($mval);
			$HTTP_POST_VARS[$mname] = $mval;
			$$mname = $mval;	
		}
	while(list($mname,$mval) = each($HTTP_COOKIE_VARS))
		if (is_string($mval)) {
			$mval = addslashes($mval);
			$HTTP_COOKIE_VARS[$mname] = $mval;
			$$mname = $mval;
		}
}

// To be safe
set_magic_quotes_runtime(0);
// ###############################
//         SESSION MANAGEMENT
// ###############################

if ($HTTP_COOKIE_VARS['record']) { define('RECORD',$HTTP_COOKIE_VARS['record']); $isrec = 1; } else { $isrec = 0; }
define('USERIP',($HTTP_X_FORWARDED_FOR) ? $HTTP_X_FORWARDED_FOR : $REMOTE_ADDR);

// Reset Active in DB
if ($isrec) { $record = RECORD; } else { $record = ''; }
$query_active = new query($SQL, "SELECT member, record FROM ".$prefix."active WHERE record = '".$record."'");
if ($query_active->getrow() && $isrec != 0) {
   new query($SQL, "UPDATE ".$prefix."active SET lastaction = '".time()."', ip = '".USERIP."', location = '".$SI['ref']."' WHERE record = '".RECORD."'");

   if($member = $query_active->field('member')) {
      define('USERNAME',$member);
   } else { define('USERNAME',0); }
   $query_active->free(); 

} else {
   // Create new Record and Active DB Entry
  $query_lastid = new query($SQL, "SELECT record FROM ".$prefix."active ORDER BY record DESC LIMIT 1");
  $query_lastid->getrow();
  define('RECORD',uniqid((substr(time(),6,10))));
  $query_lastid->free();
   new query($SQL, "INSERT INTO ".$prefix."active VALUES ('', '".time()."', '".RECORD."', '".USERIP."', 'Viewing Index', '')");
   setcookie('record',RECORD,$expire,$config->field('cookiepath'));

}


// ###############################
//         DEFINE USERINFO
// ###############################
define('LASTACTION',$HTTP_COOKIE_VARS['lastaction']);
if (USERNAME != 'USERNAME') {
   if (NUKE) {
      $sq = new query($SQL, "SELECT id, usergroup, vargroup, templategroup, timeoffset, timezone, activated, banned, showavatar, showsig, showhistory, addowntopics, autosubscribe FROM ".$prefix."users WHERE uname = '".addslashes(USERNAME)."'");    
   } else {
      $sq = new query($SQL, "SELECT id, usergroup, vargroup, templategroup, timeoffset, timezone, activated, banned, showavatar, showsig, showhistory, addowntopics, autosubscribe FROM ".$prefix."profiles WHERE username = '".addslashes(USERNAME)."'");
   }
  
   $sq->getrow();
   define('MEMBER','1');
   define('USERID',$sq->field('id'));
   define('USERGROUP',$sq->field('usergroup'));
   define('VARGROUP',$sq->field('vargroup'));

   if (SCRIPTID == 'cp') {
      define('TEMPLATEGROUP',127);
   } else {
      define('TEMPLATEGROUP',$sq->field('templategroup'));
   }
   define('ACTIVATED',$sq->field('activated'));
   define('BANNED',$sq->field('banned'));
   define('SHOWAVATAR',$sq->field('showavatar'));
   define('SHOWSIG',$sq->field('showsig'));
   define('SHOWHISTORY',$sq->field('showhistory'));
   define('ADDOWNTOPICS',$sq->field('addowntopics'));
   define('AUTOSUBSCRIBE',$sq->field('autosubscribe'));

   $time = $sq->field('timeoffset');
   // + Get Timezone
   $timezone = $sq->field('timezone');
   if ($time == 0) { 
      $timezone = 'GMT'; 
   } else {
      if ($timezone > '-1') { $timezone = '+' . $timezone; }
      $timezone = 'GMT '.$timezone; 
   }

   // - Get Timezone

   define('TIMEZONE',$timezone);
   define('TIMEOFFSET',$sq->field('timeoffset'));
   if (!ACTIVATED && SCRIPTID != 'member/logout') {
    $quit_reason = 'Your account is not activated.'; $show_logout = 1;
   }
   if (BANNED) {
   $quit_reason = 'You are banned from this board.';
   }
   $sq->free();
} else {
  define_guest();
}



// ###############################
//           OPENBB LOAD
// ###############################
// Add BASE-template to Cachelist
if (isset($SI['templates'])) { 
   $SI['templates'] .= '|0|99|75|74'; 
   $templates = str_replace('|', '\',\'', $SI['templates']);
} else {  
   $templates = '0|74|75|99'; 
}

// Set Template Varset

$templatevars = new query($SQL, "SELECT org, rep FROM ".$prefix."vars WHERE groupid = ".VARGROUP."");


while ($templatevars->getrow()) {
	$tempvars[$templatevars->field('org')] = $templatevars->field('rep');
}

// Cache Templates - All in 1 Query!!
$query_templates = new query($SQL, "SELECT template, id FROM ".$prefix."templates WHERE groupid = ".TEMPLATEGROUP." AND (id IN ('".$templates."'))");
#$query_templates = new query($SQL, "SELECT template, id FROM ".$prefix."templates WHERE groupid = '".TEMPLATEGROUP."'");

$TC = 0;

while ($query_templates->getrow()) { 
   $TC++;
   $template = stripslashes($query_templates->field('template')); 
   $TI[$query_templates->field('id')] = $template;
}
$query_templates->free();

// Check if a new LastVisit cookie is needed      
if ((time() - LASTACTION) > 600) { 
   setcookie('lastvisit',LASTACTION,$expire,$config->field('cookiepath'));
   define('LASTVISIT',LASTACTION);
} elseif ($HTTP_COOKIE_VARS['lastvisit']) {
   define('LASTVISIT',$HTTP_COOKIE_VARS['lastvisit']);
} else {
   define('LASTVISIT','');	
   setcookie('lastvisit',time(),$expire,$config->field('cookiepath'));
}

// Renew Lastaction cookie
setcookie('lastaction',time(),$expire,$config->field('cookiepath'));

// Get Time
$time = gmdate($timeformat[2], (time() + TIMEOFFSET)); 
$offset = TIMEOFFSET;
$query_checkusergroup = new query($SQL, 'SELECT isadmin FROM '.$prefix.'usergroup WHERE id = '.USERGROUP);
$query_checkusergroup->getrow();

if ($query_checkusergroup->field('isadmin')) { define('ADMIN','1'); } else { define('ADMIN','0'); }
$query_checkusergroup->free();

// Select User Navigation
if (ADMIN) {
	 eval("\$navigation = \"".addslashes($TI[99])."\";");
} elseif (MEMBER) {
   eval("\$navigation = \"".addslashes($TI[75])."\";");
} else { 
   eval("\$navigation = \"".addslashes($TI[74])."\";");
}
/*if (ADMIN) {
   $navigation = addslashes($TI[99);
} elseif (MEMBER) {
   $navigation = addslashes($TI[75);
} else { 
   $navigation = addslashes($TI[74);
}*/

// Check if Forum Marker is set - If not, set it
/*
 * if ($HTTP_COOKIE_VARS['forummarker'] == '') { setcookie('forummarker',gen_cookie(0),$expire,$config->field('cookiepath')); }
 * if ($config->field('lastadd') > LASTVISIT) { setcookie('forummarker',gen_cookie(-2),$expire,$config->field('cookiepath')); } 
 */

if ($quit_reason && $show_logout) { gen_error($quit_reason,'Click <a href="member.php?action=logout ">here</a> to logout.'); } 
if ($quit_reason) { gen_error($quit_reason,''); }
if ($config->field('locked') == '1' && !ADMIN) { gen_error($config->field('lockedreason'),'Please come back later...'); }
$mtime1 = microtime();
$mtime1 = explode(" ",$mtime1); 
$base_end = ($mtime1[1] + $mtime1[0]) - $start_of_openbb;
$mtime1 = microtime();
$mtime1 = explode(" ",$mtime1); 
$start_of_file = $mtime1[1] + $mtime1[0]; 
?>
