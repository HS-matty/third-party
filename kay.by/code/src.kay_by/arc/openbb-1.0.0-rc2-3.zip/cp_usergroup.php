<?php
/*
 *
 *  openbb, copyright (c)2001 iansoft
 *  public release beta 1.0.0
 *  http://www.iansoft.net/
 *
 */
$usergroup = 'selected';

function write_cache_usergroups ($usergroup = -1) {
	global $SQL, $config;
  
	new query($SQL, "DELETE FROM ".$prefix."cache WHERE name LIKE 'forums:gid%'");
	
	if ($usergroups > -1)
		$query_groups = new query($SQL, "SELECT id, forum_cansee FROM ".$prefix."usergroup WHERE id = ".$usergroup." LIMIT 1");
	else
		$query_groups = new query($SQL, "SELECT id, forum_cansee FROM ".$prefix."usergroup");

	$query_forums = new query($SQL, "SELECT title, forumid, type, parent FROM ".$prefix."forum_display ORDER BY displayorder");

	while ($query_groups->getrow()) {

		$fcs_p = array();
		$fcs = array();
		$output = '';
		$usergroup = $query_groups->field('id');
		$fcs_default = $query_groups->field('forum_cansee');
		//$output .= '<select name="FID" onchange="window.location=(\'board.php?FID=\'+this.options[this.selectedIndex].value)">';
		$subcat = '-2';

		$query_fcs = new query($SQL, "SELECT forumid, forum_cansee FROM ".$prefix."forum_permissions WHERE uid = ".$usergroup);
		while ($query_fcs->getrow()) {
			$fcs[$query_fcs->field('forumid')] = $query_fcs->field('forum_cansee');
		}
		$query_fcs->free;
		
			
		$query_forums->seek(0);
		//$query_forums = new query($SQL, "SELECT title, forumid, type, parent FROM ".$prefix."forum_display ORDER BY displayorder");
		
		
		while ($query_forums->getrow()) {
			$type = $query_forums->field('type');
			if ($type == '1') { 
				$fcs_f = isset($fcs[$query_forums->field('forumid')]) ? $fcs[$query_forums->field('forumid')] : $fcs_default;
		
				if ($fcs_f == '1' && !in_array($query_forums->field('parent'), $fcs_p))
					$output .= '<option value=""></option><option value="'.$query_forums->field('forumid').'" $fs['.$query_forums->field('forumid').']>'.$query_forums->field('title').'</option>';
				else
					$fcs_p[] = $query_forums->field('forumid');        
				
				
				
				$subcat = '0';
			} elseif ($type == "2") { $stripes = ''; $s = $subcat + 2; while ($s != 0) { 
				$stripes .= '-'; $s--; 
			}
			
			$fcs_f = isset($fcs[$query_forums->field('forumid')]) ? $fcs[$query_forums->field('forumid')] : $fcs_default;
			if ($fcs_f == '1' && !in_array($query_forums->field('parent'), $fcs_p))
				$output .= '<option value="'.$query_forums->field('forumid').'" $fs['.$query_forums->field('forumid').']>'.$stripes.' '.$query_forums->field('title').'</option>';
			else
				$fcs_p[] = $query_forums->field('forumid');
			if ($subcat == '0') { $subcat++; } 
				$subcat++;
			} else { 
				$stripes = ''; $s = $subcat + 2; while ($s != 0) { $stripes .= '-'; $s--; }
				if ($type == '6') { $stripes .= '--'; }
        
				if ($type != 6) {
				$nav = $header . '<a href="board.php?FID='.$query_forums->field('forumid').'">'.$query_forums->field('title').'</a> ';
				$nestedheader = $nav . '> ';
				} else {
				$nav = $nestedheader . '<a href="board.php?FID='.$query_forums->field('forumid').'">'.$query_forums->field('title').'</a> ';
				}

				$fcs_f = isset($fcs[$query_forums->field('forumid')]) ? $fcs[$query_forums->field('forumid')] : $fcs_default;
				if ($fcs_f == '1' && !in_array($query_forums->field('parent'), $fcs_p))
					$output .= '<option value="'.$query_forums->field('forumid').'" $fs['.$query_forums->field('forumid').']>'.$stripes.' '.$query_forums->field('title').'</option>';
				else
					$fcs_p[] = $query_forums->field('forumid');
			}
		};
		
		//$output .= "</select>";
		new query($SQL, "INSERT INTO ".$prefix."cache (name, cache) values ('forums:gid$usergroup', '".addslashes($output)."')");
	}
	$query_forums->free;
	$query_groups->free;
}

if ($do == '') {
   $SI['templates'] = '141|50';
   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
	
		 $query = new query($SQL, "SELECT id, title FROM usergroup");   
	    while ($result = $query->getrow()) {

	$usergroups .= '<option value="'.$query->field('id').'">'.$query->field('title').'</option>';
   }
	
   eval("\$include = \"".addslashes(addslashes($TI[141]))."\";"); 
   eval("\$output = \"".addslashes($TI[50])."\";");
   print stripslashes($output); flush;
   exit();  
} 
elseif ($do == 'edit') {

   $SI['templates'] = '151|50|142';
   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);

$query = new query($SQL, "SELECT minposts, maxposts, title, image, id FROM usertitles WHERE usergroup = ".$id);
while (list($from,$to,$title,$image,$titleid) = $query->getrow()) {
	eval("\$include .= \"".addslashes($TI[151])."\";");
}


	$query = new query($SQL, "SELECT * FROM usergroup WHERE id = ".$id);   
	  $result = $query->getrow();
		 	while (list($key,$val) = each($result)) {
				if (!is_numeric($key) && $key != 'id') {
					if ($val == 1) { $val = 'checked'; }
					eval("\$".$key." = \"".$val."\";");
				}
			}
   $action = 'do_edit';
   eval("\$include = \"".addslashes(addslashes($TI[142]))."\";"); 
   eval("\$output = \"".addslashes($TI[50])."\";");
   print stripslashes($output); flush;
   exit();
} elseif ($do == 'do_edit') {
   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);

	while (list($key,$val) = each($HTTP_POST_VARS)) {
		if ($key != 'do' && $key != 'Submit' && $key != $id) {
			$update .= $key.' = \''.$val.'\', ';
		}
	}
	$update = substr($update,0,(strlen($update) - 2));
	new query($SQL, "UPDATE usergroup SET title = 'Unnamed Group', usertitle = '', isadmin = '0', index_canview = '0', search_cansearch = '0',  forum_canview = '0', forum_cansee = '0', thread_canview = '0', thread_canpost = '0', member_canregister = '0', member_canviewprofile = '0', custom = '0', design_canview = '0', design_canedit = '0', settings_canview = '0', settings_canchange = '0', member_memberlist = '0', member_whosonline = '0', thread_canprint = '0', index_canviewfaq = '0', ismoderator = '0', thead_canmail = '0', forums_canedit = '0', image = '', icon = '', myhome_canaccess = '0', myhome_myprofile = '0', myhome_mysettings = '0', myhome_readmsg = '0', myhome_newmsg = '0', pm_maxday = '0', myhome_delmsg = '0', thread_canreply = '0', avatar_cancustom = '0', myhome_dlmsg = '0', myhome_savemsg = '0', member_canmail = '0', poll_canvote = '0', flood = '0', myhome_favorites = '0', design_cancreateset = '0' WHERE id = $id");
	new query($SQL, "UPDATE usergroup SET $update WHERE id = '$id'");
	
	@header("location: cp_usergroup.php?do=edit&id=$id");
} elseif ($do == 'do_add') {
   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);

	$q = new query($SQL, "SELECT id from usergroup order by id desc limit 1");
	list($r) = $q->getrow();
	$keys = 'id, ';
	$values = ($r + 1).', ';
	
	while (list($key,$val) = each($HTTP_POST_VARS)) {
		if ($key != 'do' && $key != 'Submit' && $key != $id) {
			$keys .= $key.', ';
			$values .= '\''.$val.'\', ';
		}
	}
	$values = substr($values,0,(strlen($values) - 2));
	$keys = substr($keys,0,(strlen($keys) - 2));
	new query($SQL, "INSERT INTO usergroup ($keys) VALUES ($values)");
	@header("location: cp_usergroup.php");
} elseif ($do == 'add') {
   $SI['templates'] = '50|142';
   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
   $action = 'do_add';
   eval("\$include = \"".addslashes(addslashes($TI[142]))."\";"); 
   eval("\$output = \"".addslashes($TI[50])."\";");
   print stripslashes($output); flush;
   exit();  
} elseif ($do == 'forum') {
   $SI['templates'] = '50';
   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
 	$include .= '<br><br><div align="center"><form method="post" action="cp_usergroup.php?do=do_forum&name='.$name.'&id='.$id.'"><font size="1" face="verdana"><b>Editing Userpermissions for forum "'.$name.'"<br><br></b></font><select name="usergroup2">';
		 $query = new query($SQL, "SELECT id, title FROM usergroup");   
	    while ($query->getrow()) {

	$include .= '<option value="'.$query->field('id').'">'.$query->field('title').'</option>';
   }
   $include .= '</select><br><br><input type="submit" value="Ok"></form></div>';
   eval("\$output = \"".addslashes($TI[50])."\";");
   print stripslashes($output); flush;
   exit();  
} elseif ($do == 'do_forum') {

 $SI['templates'] = '50|144';
   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);

	if ($query = new query($SQL, "SELECT * FROM forum_permissions WHERE uid = '$usergroup2' and forumid = '$id'")) { 
	if ($result = $query->getrow()) {
		  	$action = 'forumedit';
	} else {
		$action = 'forumadd';
	}
	
	if ($result) {
 	while (list($key,$val) = each($result)) {
		if (!is_numeric($key) && $key != 'forumid' && $key != 'uid') {
		if ($val == 1) { $val = 'checked'; }
			eval("\$".$key." = \"".$val."\";");
		}
	}
}
}



   eval("\$include = \"".addslashes(addslashes($TI[144]))."\";"); 
   eval("\$output = \"".addslashes($TI[50])."\";");
   print stripslashes($output); flush;
   exit();  

} elseif ($do == 'forumadd') {

   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
	while (list($key,$val) = each($HTTP_POST_VARS)) {
		if ($key != 'do' && $key != 'Submit' && $key != 'id' && $key != 'usergroup2' && $key != 'name' && $key != 'imageField_x' && $key != 'imageField_y') {
			$keys .= $key.', ';
			$values .= '\''.$val.'\', ';
		}
	}
	$values = substr($values,0,(strlen($values) - 2));
	$keys = substr($keys,0,(strlen($keys) - 2));
	
	if ($keys) { $comma = ','; }
	$keys .= $comma.'uid,forumid';
	$values .= $comma.$usergroup2.','.$id;
	new query($SQL, "INSERT INTO forum_permissions ($keys) VALUES ($values)");
	write_cache_usergroups($usergroup2);
	$name=urlencode($name);
   @header("Location: cp_usergroup.php?do=forum&id=$id&name=$name");
   exit();  

} elseif ($do == 'forumremove') {

   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
   new query($SQL, "DELETE FROM forum_permissions WHERE forumid = '$id' and uid = '$usergroup2'");
   write_cache_usergroups($usergroup2);
   $name=urlencode($name);
   @header("Location: cp_usergroup.php?do=forum&id=$id&name=$name");
   exit();  

} elseif ($do == 'forumedit') {

   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
	
	

	while (list($key,$val) = each($HTTP_POST_VARS)) {
	if ($key != 'do' && $key != 'Submit' && $key != 'id' && $key != 'usergroup2' && $key != 'name' && $key != 'imageField_x' && $key != 'imageField_y') {
			$update .= $key.' = \''.$val.'\', ';
		}
	}
	
	$update = substr($update,0,(strlen($update) - 2));
	new query($SQL, "UPDATE forum_permissions SET forum_cansee = '0', forum_canview = '0', thread_canview = '0', thread_canpost = '0', ismoderator = '0', thread_canprint = '0', thead_canmail = '0', thread_canreply = '0', poll_canvote = '0' WHERE forumid = $id and uid = $usergroup2");
	new query($SQL, "UPDATE forum_permissions SET $update WHERE forumid = '$id' and uid = '$usergroup2'");
	write_cache_usergroups($usergroup2);
	$name=urlencode($name);
   @header("Location: cp_usergroup.php?do=forum&id=$id&name=$name");
   exit();  

} elseif ($do == 'editrank') {
   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
	new query($SQL, "UPDATE usertitles SET minposts = '$from', maxposts = '$to', title = '$title', image = '$image' WHERE id = '$rankid'");
	@header("Location: cp_usergroup.php?do=edit&id=$id");	
} elseif ($do == 'removerank') {
   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
	new query($SQL, "DELETE FROM usertitles WHERE id = '$rankid'");
	@header("Location: cp_usergroup.php?do=edit&id=$id");	
} elseif ($do == 'newrank') {
   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
	$q = new query($SQL, "select id from usertitles order by id desc limit 1");
	$q->getrow();
	$id2 = $q->field('id') + 1;
	new query($SQL, "INSERT INTO usertitles VALUES ('$id2','$from','$to','$title','$id','$image')");
	
	@header("Location: cp_usergroup.php?do=edit&id=$id");	
}




?>