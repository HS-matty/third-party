<?php
/*
 *
 *  OpenBB, Copyright (c)2001 Iansoft
 *  Internal Release Beta 5.0.0
 *  http://www.iansoft.net/
 *
 */

// ########### Script Parameters ###########
$SI['templates'] = '50,51,52';
$SI['permission'] = 'isadmin';
$SI['ref'] = 'Unknow';

// ########### Include base: process code/load libary's ###########
require 'base.php';

function get_group($group) {
  global $SQL;
  $q = new query($SQL, "SELECT title FROM ".$prefix."usergroup WHERE id = $group");
  $q->getrow();
  return $q->field('title');
}


$nav = ' &raquo; Members &raquo; Memberlist';
$query_users = new query($SQL, "SELECT username, posts, usergroup, joindate FROM ".$prefix."profiles ORDER BY posts DESC");
while ($query_users->getrow()) {
   $username = $query_users->field('username');
   $postcount = $query_users->field('postcount');
   $usergroup = get_group($query_users->field('usergroup'));
   $joindate = $query_users->field('joindate');
   eval("\$include .= \"".addslashes($TI[51])."\";"); 	
}
eval("\$include = \"".addslashes($TI[52])."\";"); 
eval("\$output = \"".addslashes($TI[50])."\";");
print stripslashes($output); flush;
exit();
?>