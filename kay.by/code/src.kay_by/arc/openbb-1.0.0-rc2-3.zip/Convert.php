<?php
error_reporting (E_ERROR | E_WARNING | E_PARSE);
$php = ".php";
include 'lib/sqldata.php';  

$BlazeBoard['host'] = 'localhost';
$BlazeBoard['user'] = '';
$BlazeBoard['pass'] = '';
$BlazeBoard['db'] = 'blaze';
$boardname = 'test';

$BB = mysql_connect($BlazeBoard['host'], $BlazeBoard['user'], $BlazeBoard['pass']);
mysql_select_db($BlazeBoard['db'], $BB);
if (!$BB) { print 'Could not connect to BlazeBoard Server'; exit(); }

$oBB = mysql_connect($database_server['hostname'], $database_server['username'], $database_server['password']);
mysql_select_db($database_server['database'], $oBB);
if (!$oBB) { print 'Could not connect to OpenBB Server'; exit(); }

$BB = $BlazeBoard['db'];
$oBB = $database_server['database'];

$header = '<a href="index.php">'.$boardname.'</a> > ';

$id = 1;

##################################
#	Get list of Categories from BB #
##################################
mysql_db_query($oBB, "DELETE FROM forum_display");
mysql_db_query($oBB, "DELETE FROM navigations");
mysql_db_query($oBB, "DELETE FROM cache");
mysql_db_query($oBB, "INSERT INTO navigations VALUES ('profile','".$header."'Profiles')");
mysql_db_query($oBB, "INSERT INTO navigations VALUES ('memberlist','".$header."'Memberlist')");
mysql_db_query($oBB, "INSERT INTO navigations VALUES ('online','".$header."'Who is online?')");
mysql_db_query($oBB, "INSERT INTO navigations VALUES ('usercp','".$header."'My Home')");
$BBcat = mysql_db_query($BB, "SELECT CID, category, displayorder FROM category");
while ($BBcat2 = mysql_fetch_object($BBcat)) {
	$newCID[$BBcat2->CID] = $id;
	mysql_db_query($oBB, "INSERT INTO forum_display VALUES ('".$id."', '".addslashes($BBcat2->category)."','','','','','','".$BBcat2->displayorder."','1','','','','','-1','')") or die ("Error:".mysql_error());
	$navCID[$BBcat2->CID] = $header . '<a href="index.php?CID='.$id.'">'.addslashes($BBcat2->category).'</a>';
	mysql_db_query($oBB, "INSERT INTO navigations VALUES('forum:".$id."', '".$navCID[$BBcat2->CID]."')");
	$id++;
}

##################################
# 	Get list of Forums from BB   #
##################################
$BBforum = mysql_db_query($BB, "SELECT FID, title, description, displayorder, replycount, threadcount, category FROM forum")  or die ("Error:".mysql_error());
while ($BBforum2 = mysql_fetch_object($BBforum)) {
	$newFID[$BBforum2->FID] = $id;
	mysql_db_query($oBB, "INSERT INTO forum_display VALUES ('".$id."', '".addslashes($BBforum2->title)."', '".addslashes($BBforum2->description)."', '".$BBforum2->replycount."','".$BBforum2->threadcount."','','','".$BBcat2->displayorder."','3','','','','','".$newCID[$BBforum2->category]."', '1')") or die ("Error:".mysql_error());
	$nav = $navCID[$BBforum2->category].' > <a href="index.php?FID='.$id.'">'.$BBforum2->title.'</a>';
	mysql_db_query($oBB, "INSERT INTO navigations VALUES('forum:".$id."', '".$nav."')");
	$id++;
}
##################################
# 				Fix displayorder 			 #
##################################
$i = 0;
$cat = mysql_db_query($oBB, "SELECT title, forumid FROM forum_display WHERE parent = '-1' ORDER BY type DESC");
$output = '<select name="FID" onchange="window.location=(\'board.php?FID=\'+this.options[this.selectedIndex].value)">';
while ($category = mysql_fetch_object($cat)) {
   $i++;
   mysql_db_query($oBB, "UPDATE forum_display SET displayorder = $i WHERE forumid = '".$category->forumid."'");
	 $output .= '<option value=""></option><option value="'.$category->forumid.'" $fs['.$category->forumid.']>'.$category->title.'</option>'; 
   $forum1 = mysql_db_query($oBB, "SELECT title, forumid FROM forum_display WHERE parent = '".$category->forumid."' ORDER BY type DESC");
   while ($forum = mysql_fetch_object($forum1)) {
      $i++;
      mysql_db_query($oBB, "UPDATE forum_display SET displayorder = $i WHERE forumid = '".$forum->forumid."'");
			$output .= '<option value="'.$forum->forumid.'" $fs['.$forum->forumid.']>--'.$forum->title.'</option>'; 
      $sub = mysql_db_query($oBB, "SELECT title, forumid FROM forum_display WHERE parent = '".$forum->forumid."' ORDER BY type DESC");
      while ($subforum = mysql_fetch_object($sub)) {
	      $i++;
	      mysql_db_query($oBB, "UPDATE forum_display SET displayorder = $i WHERE forumid = '".$subforum->forumid."'");
				$output .= '<option value=""></option><option value="'.$subforum->forumid.'" $fs['.$subforum->forumid.']>----'.$subforum->title.'</option>'; 
      }
   }
}
$output .= "</select>";
mysql_db_query($oBB, "INSERT INTO cache VALUES('forums', '".addslashes($output)."', '0')");

##################################
# 	Get list of Members from BB  #
##################################
mysql_db_query($oBB, "DELETE FROM profiles");
$members = 0;
$BBuser = mysql_db_query($BB, "SELECT username, password, register, signature, email, timeoffset, location, occupation, aim, homepage, biography, icq, show_email, status, avatar, post_num, cus_status FROM members")  or die ("Error:".mysql_error());
while ($BBuser2 = mysql_fetch_object($BBuser)) {
	if ($BBuser2->status == "Administrator") {
		$usergroup = "3";
	} elseif ($BBuser2->status == "Moderator") {
		$usergroup = "2";
	}	else {
		$usergroup = "1";
	}
	mysql_db_query($oBB, "INSERT INTO profiles VALUES (NULL, '".$BBuser2->username."', '".md5($BBuser2->password)."', '".$BBuser2->email."', '".$BBuser2->homepage."', '".$BBuser2->icq."', '".addslashes($BBuser2->aim)."', '', '".addslashes($BBuser2->location)."', '".addslashes($BBuser2->biography)."', '".$BBuser2->show_email."', '".$usergroup."', '".$BBuser2->post_num."', '".$BBuser2->register."', '".$BBuser2->timeoffset."', '', '".ereg_replace("images/avatars/", "", $BBuser2->avatar)."', '".addslashes($BBuser2->cus_status)."', '', '".addslashes($BBuser2->occupation)."', '', '0', '0', '', '', '', '1', '0', '".addslashes($BBuser2->signature)."', '', '', '', '0', '0')") or die ("Error:".mysql_error());
	$members++;
}

##################################
#  Get list of Threads from BB	 #
##################################
mysql_db_query($oBB, "DELETE FROM topics");
$BBthread = mysql_db_query($BB, "SELECT TID, title, lastpost, FID, replycount, postusername, dateline, icon, thread_lock, viewed_num FROM thread")  or die ("Error:".mysql_error());
$posts = 0;
while ($BBthread2 = mysql_fetch_object($BBthread)) {
	mysql_db_query($oBB, "INSERT INTO topics VALUES ('".$BBthread2->TID."', '".$newFID[$BBthread2->FID]."', '".addslashes($BBthread2->title)."', '".$BBthread2->dateline."', '".$BBthread2->postusername."', '".$BBthread2->lastpost."', '', '".$BBthread2->replycount."', '', '', '', '', '".$BBthread2->viewed_num."', '', '".$BBthread2->thread_lock."', '".$BBthread2->icon."', '', '', '', '', '')") or die ("Error:".mysql_error());
	$posts++;
}

##################################
# 	Get list of Posts from BB		 #
##################################
mysql_db_query($oBB, "DELETE FROM posts");
$BBpost = mysql_db_query($BB, "SELECT PID, TID, username, title, dateline, pagetext FROM post")  or die ("Error:".mysql_error());
$threads = 0;
while ($BBpost2 = mysql_fetch_object($BBpost)) {
	$FID = mysql_db_query($BB, "SELECT FID FROM thread WHERE TID = '".$BBpost2->TID."'");
	$FID = mysql_fetch_object($FID);
	$FID = $newCID[$FID->FID];
	mysql_db_query($oBB, "INSERT INTO posts VALUES ('".$BBpost2->PID."', '".$BBpost2->TID."', '".$BBpost2->username."', '".addslashes($BBpost2->pagetext)."', '".addslashes($BBpost2->title)."', '', '".$BBpost2->dateline."', '', '', '', '".$FID."', '', '', '', '')") or die ("Error:".mysql_error());
	$threads++;
}

##################################
# Get list of Moderators from BB #
##################################
$BBmods = mysql_db_query($BB, "SELECT FID, moderator FROM moderator")  or die ("Error:".mysql_error());
while ($BBmods2 = mysql_fetch_object($BBmods)) {
	mysql_db_query($oBB, "UPDATE forum_display SET moderators = '".$BBmods2->moderator.", ' WHERE forumid = '".$newFID[$BBmods2->FID]."'")  or die ("Error:".mysql_error());
}

mysql_db_query($oBB, "UPDATE configuration SET regmembers='$members', posts='$posts', threads='$threads'");

?>
<html>
<head>
<title>OpenBB Beta 1 Final</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#000000" vlink="#000000" alink="#000000">
<table width="75%" border="0" cellspacing="0" cellpadding="4" align="center" bgcolor="#0066CC">
  <tr> 
    <td> 
      <div align="center"><b></b></div>
      <div align="center"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">OpenBB 
        Setup</font></b></div>
    </td>
  </tr>
  <tr bgcolor="EFEFEF"> 
    <td> 
      <div align="center"> 
        <p align="left"><font face="Verdana" size="2">Your DB has been converted</font><br>
				<a href="index.php">Goto my Community</a></p>
      </div>
    </td>
  </tr>
</table>
</body>
</html>
<?
#displayIt($BB);
?>