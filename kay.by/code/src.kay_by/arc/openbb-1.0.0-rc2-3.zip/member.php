<?php

error_reporting (E_ERROR | E_WARNING | E_PARSE);

/*
 *
 *  openbb, copyright (c)2001 iansoft
 *  public release beta 1.0.0
 *  http://www.iansoft.net/
 *
 */
 
 // ###############################
//              VIEW PROFILE
// ###############################



if ($action == 'profile') {
 
   $SI['templates'] = '19|56';
   $SI['ref'] = 'Viewing profile ('.$UID.')';
   define('SCRIPTID','member/profile/display');
   require 'base.php';
   if (NUKE) {
      if(!isset($mainfile)) { include("mainfile.php"); }
      if (!eregi("modules.php", $PHP_SELF)) {
         die ("You can't access this file directly...");
      }
   }
   
   check_perm('member_canviewprofile',0);
   function get_usertitle($posts,$group,$user = '') {
     global $SQL, $FID;
    $query_usertitle = new query($SQL, "SELECT usertitle, custom FROM ".$prefix."usergroup WHERE id = $group");
    $query_usertitle->getrow();
     if ($query_usertitle->field('custom') == '1') {
        $o = $query_usertitle->field('usertitle');
        $query_usertitle = new query($SQL, "SELECT custom AS usertitle FROM ".$prefix."profiles WHERE id = '".$user."'");
        $query_usertitle->getrow();
        if ($query_usertitle->field('usertitle') == '') { $query_usertitle->free(); return $o; }
     }

     if ($query_usertitle->field('usertitle') == '') {
       $query_usertitle = new query($SQL, "SELECT usertitle FROM ".$prefix."forum_permissions WHERE forumid = '".$FID."' AND uid = '".$group."'");
        if (!$query_usertitle->getrow()) {
           $query_usertitle = new query($SQL, "SELECT usertitle, custom FROM ".$prefix."usergroup WHERE id = $group");
           $query_usertitle->getrow();
        }
     }

     if ($query_usertitle->field('usertitle') == '') {
        $query_usertitle = new query($SQL, "SELECT title AS usertitle FROM ".$prefix."usertitles WHERE (minposts - 1) < $posts AND (maxposts + 1) > $posts AND usergroup = $group");
        $query_usertitle->getrow();
     }
     $result = $query_usertitle->field('usertitle');
     $query_usertitle->free();
     return $result;
   }

   function get_group($group) {
     global $SQL;
     $q = new query($SQL, "SELECT title FROM ".$prefix."usergroup WHERE id = $group");
     $q->getrow();
     return $q->field('title');
   }
   $query_users = new query($SQL, "SELECT username, showemail, homepagedesc, msn, occupation, avatar, email, homepage, posts, joindate, icq, aim, yahoo, location, note, usergroup FROM ".$prefix."profiles WHERE id = '".$UID."'");
   if (!$query_users->getrow()) { gen_error('An invalid profile was requested.',''); }
   $user[name] = $query_users->field('username');
   
   if ($query_users->field('showemail')) {
      $user[email] = $query_users->field('email');
   } else {
      $user[email] = 'Send an E-mail';
   }
   
   $user[homepage] = $query_users->field('homepage');
   $user[posts] = $query_users->field('posts');
   $user[icq] = $query_users->field('icq');
   $user[aim] = $query_users->field('aim');
   $user[yim] = $query_users->field('yahoo');
   $user[wm] = $query_users->field('msn');
   $user[jointime] = (time() - $query_users->field('joindate')) / 86400;
   if ($user[jointime] < 1) { 
      $user[pratio] = $user[posts];
   } else {
      $rat = explode('.', ($user[posts] / $user[jointime]));
      $user[pratio] = $rat[0] .'.'. substr($rat[1],0,2);
   }
   if (ADMIN) { eval("\$admin = \"".addslashes($TI[56])."\";"); }
   $user[location] = $query_users->field('location');
   $user[notes] = $query_users->field('note');
   $user[homepagedesc] = $query_users->field('homepagedesc');
   $user[occupation] = $query_users->field('occupation');
   $user[groupid] = $query_users->field('usergroup');
   $user[group] = get_group($user[groupid]);
   $user[joindate] = gmdate($timeformat[1], ($query_users->field('joindate') + $offset));
   if($query_users->field('avatar') != '') { $avatar = '<img src="avatars/'.$query_users->field('avatar').'">'; } else { $avatar = ''; }
   $user[status] = get_usertitle($user[posts],$user[groupid], $UID);
   $query_users->free();
   $nav = getnav('profile') .' > '. $user[name];
   $title = 'Viewing Profile of '. $user[name];
   eval("\$include = \"".addslashes($TI[19])."\";"); 
   eval("\$output = \"".addslashes($TI[0])."\";"); 
   lose($output);
    
}
// ###############################
//              LOGIN
// ###############################
if ($action == 'login') {
   // ### 'Log in' Screen  
   if (!$send) { 
      $SI['ref'] = 'Logging In';
      $SI['templates'] = '16';
      define('SCRIPTID','member/login/display');
      require 'base.php';
      if (NUKE) {
         if(!isset($mainfile)) { include("mainfile.php"); }
         if (!eregi("modules.php", $PHP_SELF)) {
            die ("You can't access this file directly...");
         }
         if ($nuke_login_redirect) { @header("Location: $nuke_login_redirect"); }
      }
      if (MEMBER) { gen_error('Already logged in!',''); }

     $title = 'Logging In';
      eval("\$include = \"".addslashes($TI[16])."\";"); 
      eval("\$output = \"".addslashes($TI[0])."\";"); 
      lose($output);
    
   }

  // ### Set User to logged in
   elseif ($send) { 
      $redirect =  str_replace('|','&',$redirect);
      $SI['ref'] = 'Logging In';
      define('SCRIPTID','member/login/insert');
      require 'base.php';
      if (NUKE) {
         if(!isset($mainfile)) { include("mainfile.php"); }
        if (!eregi("modules.php", $PHP_SELF)) {
            die ("You can't access this file directly...");
         }
         if ($nuke_login_redirect) { @header('Location: '.$nuke_login_redirect.'?'.$nuke_login_username.'='.$username.'&'.$nuke_login_password.'='.$password); }
      }
      if (MEMBER) { gen_error('Already logged in!',''); }
  
     if ($username == '' ||  $password == '') { gen_error('Fill in all fields please!','Required information is missing.'); }
      $query_checkdata = new query($SQL, "SELECT password, invisible, username FROM profiles WHERE username = '".trim($username)."'");
      if (!$query_checkdata->getrow()) { gen_error('Username ('.$username.') does not exists!','Please check for typing mistakes. To register click <a href="member.php?action=register">here</a>.'); }
      if ($query_checkdata->field('password') != md5($password)) { gen_error('Wrong Password!','If you lost your password click <a href="member.php?action=forgotpasswd">here</a>.'); }
     $username = $query_checkdata->field('username');
      new query($SQL, "DELETE FROM ".$prefix."active WHERE member = '".addslashes($username)."'");
      new query($SQL, "UPDATE ".$prefix."active SET invisible = '".$query_checkdata->field('invisible')."', member = '".addslashes($username)."', lastaction = '".time()."' WHERE record = '".RECORD."'");

     setcookie('record',RECORD,$expire,$config->field('cookiepath'));
     $query_checkdata->free(); 

    if ($redirect) {
        gen_redirect('You are now logged in, redirecting you.', $redirect);  
     } else { 
        gen_redirect('You are now logged in, redirecting you to mainpage.', 'index.php');  
     }
   
   }
}

// ###############################
//              LOGOUT
// ###############################
if ($action == 'logout') {
  $SI['ref'] = 'Logging Out';
  define('SCRIPTID','member/logout');
  include 'base.php';
  
  if (!MEMBER) { gen_error('Not Logged In!','You can\'t logout if you aren\'t logged in!'); }
  
  if (NUKE) {
     if(!isset($mainfile)) { include("mainfile.php"); }
    if (!eregi("modules.php", $PHP_SELF)) {
        die ("You can't access this file directly...");
     }
    if ($nuke_logout_redirect) { @header('Location: '.$nuke_logout_redirect); }
  }
  
  setcookie('record',RECORD,$expire,$config->field('cookiepath'));
  new query($SQL, "UPDATE ".$prefix."active SET member = '' WHERE record = '".RECORD."'"); 
  gen_redirect('Succesfully logged out, we are taking you back to the mainpage.','index.php');
}
// ###############################
//              REGISTER
// ###############################


if ($action == 'register') {

   // ### Get User Information
   if (!$send) {
      $SI['ref'] = 'Registering a new Account';
	  $SI['templates'] = '15|46';
			
      define('SCRIPTID','member/register/display');
      include 'base.php';

      $q_conf = new query($SQL, "SELECT defaulttimezone FROM ".$prefix."configuration LIMIT 1");
      $q_conf->getrow();
      check_perm('member_canregister',0);
  
      if (NUKE) {
         if(!isset($mainfile)) { include("mainfile.php"); }
         if (!eregi("modules.php", $PHP_SELF)) {
            die ("You can't access this file directly...");
         }
          }
	  
	  $vis = 'checked';
      $hidemail = 'checked';

      if (SHOWAVATAR) {
         $showavatar = 'checked';
      } else {
         $dontshowavatar = 'checked';
      }
      if (SHOWSIG) {
         $showsignature = 'checked';
      } else {
         $dontshowsignature = 'checked';
      }
      if (SHOWHISTORY) {
         $showhistory = 'checked';
      } else {
         $dontshowhistory = 'checked';
      }
	  
      $avatarselector = '<select name="avatar" onchange="showavatar();">';
      $query_avatars = new query($SQL, "SELECT name, url, owner FROM ".$prefix."avatar");
      while($query_avatars->getrow()) {
         $av = $query_avatars->field('url');
         if (!isset($avatarimg)) { $avatarimg = 'avatars/'.$av; }
         if ($query_avatars->field('owner') == '') { 
            $avatarselector .= '<option value="'.$av.'">'.$query_avatars->field('name').'</option>'; 
         }
      }
	  $query_avatars->free();
	  
	  	  
	  
	  $designselector = '<select name="design">';
      $query_designs = new query($SQL, "SELECT title, id FROM ".$prefix."designs");
      while ($query_designs->getrow()) {
         if($query_designs->field('t') == TEMPLATEGROUP) {
            $designselector .= '<option value="'.$query_designs->field('id').'" selected>'.$query_designs->field('title').'</option>';
         } else {
            $designselector .= '<option value="'.$query_designs->field('id').'">'.$query_designs->field('title').'</option>';
         }
      }
	  $query_designs->free();
      $designselector .= '</select>';
      $title = 'Registering new user';
	$tmz = $q_conf->field('defaulttimezone');
	$q_conf->free;
	if ($tmz < 0)
		$tmz = str_replace('-', 'm', $tmz);
	else if ($tmz > 0)
		$tmz = 'p'.$tmz;
	unset ($timezone);
	$timezone[$tmz] = 'selected';
	
      eval("\$timezoneselector = \"".addslashes($TI[46])."\";"); 
      eval("\$include = \"".addslashes($TI[15])."\";"); 
      eval("\$output = \"".addslashes($TI[0])."\";");
      lose($output);
   }



   // ### Interprete User Information
   elseif ($send) {
      $SI['ref'] = 'Registering a new Account';
      $SI['settings'] = 'vmail, pmail, regtype, regpm, pmauthor';
			
      define('SCRIPTID','member/register/insert');
      include 'base.php';
  
      check_perm('member_canregister',0);
  
      if (NUKE) {
         if(!isset($mainfile)) { include("mainfile.php"); }
         if (!eregi("modules.php", $PHP_SELF)) {
            die ("You can't access this file directly...");
         }
      }
	  
	  $username = trim($username);
	  if ($pass == '' || $username == '' || $email == '' || $pass2 == '' || $email2 == '') {
         gen_error('Please fill in all required fields!','Press back and try again.');
      }
	  
	  if ($pass != $pass2) {
         gen_error('The passwords you entered do not match. Please press back, and try again.');
      }
      if ($email != $email2) {
         gen_error('The email addresses you entered do not match. Please press back, and try again.');
      }
	  $query_checkexists = new query($SQL, "SELECT id FROM ".$prefix."profiles WHERE username = '".$username."' OR username = '".getavatar_undo($username)."'");
      if ($query_checkexists->getrow()) {
         gen_error('That username already exists!','Go back and try another.');
      }
	  $query_checkexists->free();
	  
	  if ($timeoffset) {
	     $getoffset[1] = (substr($timeoffset, 1) * 3600);
         $getoffset[2] = substr($timeoffset, 0,1);
         $offset = $getoffset[2] . $getoffset[1];
      }
	  
      $type = $config->field('regtype');
      if ($type == 0) { $activated = 0; } else { $activated = 1; }
      if ($type == 1) { $pass = substr(md5(uniqid(microtime())),0,5); }
	  
	  $query_checkdesign = new query($SQL, "SELECT v, t FROM ".$prefix."designs WHERE id = $design");
      $query_checkdesign->getrow();
      $vargroup = $query_checkdesign->field('v'); 
	  $templategroup = $query_checkdesign->field('t'); 
	  $query_checkdesign->free();
	  
	  if($homepage && substr($homepage,0,7) != 'http://') { $homepage = 'http://' . $homepage; }
	  
	  $query_countmembers = new query($SQL, "SELECT id FROM ".$prefix."profiles ORDER BY id DESC LIMIT 1");
      $query_countmembers ->getrow();
      $totalmembers = $UID = $query_countmembers ->field('id') + 1;
	  
	  // Subtract: our Guest Dummy
	  $totalmembers--;
	  
      new query($SQL, "UPDATE ".$prefix."configuration SET regmembers = '".$totalmembers."', newestmember = '".$username."', newestmemberid = '".$UID."'");
      $query_countmembers->free();
	  
	  new query($SQL, "INSERT into ".$prefix."profiles (id, sig, avatar, msn, username, password, email, homepage, icq, aim, yahoo, location, note, showemail, occupation, homepagedesc, joindate, usergroup, timeoffset, timezone, templategroup, vargroup, invisible, activated, banned, showavatar, showsig, showhistory) VALUES ('".$UID."', '" . strip_tags($signature) . "', '" . htmlspecialchars($avatar) . "', '" . strip_tags($wm) . "', '" . htmlspecialchars($username) . "', '" . md5($pass) . "', '" . strip_tags($email) . "', '" . strip_tags($homepage) . "', '" . strip_tags($icq) . "', '" . strip_tags($aim) . "', '" . htmlspecialchars($yahoo) . "', '" . strip_tags($location) . "', '" . strip_tags($personal) . "', '".htmlspecialchars($showmail)."', '".strip_tags($occupation)."', '".strip_tags($homepagedesc)."', '".time()."', '1', '".$offset."', '".$timeoffset."','".$templategroup."','".$vargroup."', '".htmlspecialchars($invisible)."','".$activated."','0', '".$showavatars."', '".htmlspecialchars($showsignature)."', '".htmlspecialchars($showhistory)."')"); 

	      if ($config->field('sendpm') == 1) { send_pm($username, $config->field('pmauthor'), 'Welcome!', $config->field('regpm')); }
      $query_getadminmail = new query($SQL, 'SELECT email FROM '.$prefix.'profiles WHERE id = 1 LIMIT 1');
      $query_getadminmail->getrow(); 
      $admin = $query_getadminmail->field('email');
	  $query_getadminmail->free();

      if ($type == 0) {  
         $mailheaders = "From: $admin\n";
         $subject = 'Activation Mail';
         $url = $config->field('boardurl') . '/member.php?action=activate&s=' . md5(time()) . '&UID='.$UID;
         eval("\$message = \"".$config->field('vmail')."\";");
         mail($email, $subject, $message, $mailheaders);
         gen_msg('An email has been send with an activation link.','Please wait for further instructions.');  
      }
 
      if ($type == 1) {  
         $mailheaders = "From: $admin\n";
         $subject = 'Your Password';
         eval("\$message = \"".$config->field('pmail')."\";");
         mail($email, $subject, $message, $mailheaders);
         gen_msg('An email has been sent with your password.','Please wait for further instructions.');  
      }
	 
      if ($type == 2) {  gen_redirect('You are now registered, we are returning you to the mainpage.','index.php');  }   
   }  
 }  
      
if($action == 'forgotpasswd')
{
	// ### Get User Login
	if (!$send) 
	{      
		$SI['ref'] = 'Password Reset Procedure';
		$SI['templates'] = '194';
			
      		define('SCRIPTID','member/forgotpasswd/display');
	      	include 'base.php';

      		if (NUKE) 
		{
         		if(!isset($mainfile)) { include("mainfile.php"); }
         		if (!eregi("modules.php", $PHP_SELF)) 
			{
            			die ("You can't access this file directly...");
         		}
          	}
	  
      		eval("\$include = \"".addslashes($TI[194])."\";"); 
      		eval("\$output = \"".addslashes($TI[0])."\";");
      		lose($output);
   	}

	elseif($send)
	{
		$SI['ref'] = 'Password Reset Procedure';
		
      		define('SCRIPTID','member/forgotpasswd/process');
	      	include 'base.php';

      		if (NUKE) 
		{
         		if(!isset($mainfile)) { include("mainfile.php"); }
         		if (!eregi("modules.php", $PHP_SELF)) 
			{
            			die ("You can't access this file directly...");
         		}
          	}

     		if ($username == '') 
		{ 
			gen_error('Fill in all fields please!','Required information is missing.'); 
		}

		if ($act == "") {

      		$query_check_username = new query($SQL, "SELECT email, id, username FROM profiles WHERE username = '".trim($username)."'");
      		if (!$query_check_username->getrow()) 
		{ 
			gen_error('Username ('.$username.') does not exists!','Please check for typing mistakes. To retry click <a href="member.php?action=forgotpasswd">here</a>.'); 
		}
     		$id = $query_check_username->field('id');
		$email = $query_check_username->field('email');
		$query_check_username->free();

      		$query_getadminmail = new query($SQL, 'SELECT email FROM '.$prefix.'profiles WHERE id = 1 LIMIT 1');
	      	$query_getadminmail->getrow(); 
      		$admin = $query_getadminmail->field('email');
	  	$query_getadminmail->free();

		
		$url = $config->field('boardurl') . '/member.php?action=passwdsend&email=' . $email . '&id=' .$id;
        	$mailheaders = "From: $admin\n";
         	$subject = 'Validation For Password Reset';
		$message = "A request to generate a new password for " . $config->field('boardurl') . " has been recieved. To validate this request please click on the following link.\n\n" . $url . "\n\n If you did NOT request this please disregard this email and DO NOT click the above link.";
         	mail($email, $subject, $message, $mailheaders);
		gen_redirect('An email has been sent to validate this request.',$config->field('boardurl').'/'); 

		
		}

	}
}

if ($action == 'passwdsend') {

		include 'base.php';

		if ($email == '') {
			gen_error('Sorry, no email address was specified.','');
		}

		if ($id == '') {
			gen_error('Sorry, no user was specified.','');
		}

		$query_getusermail = new query($SQL, "SELECT email, id FROM profiles WHERE id = $id ");
	      	$query_getusermail->getrow(); 
		$theusername = $query_getusermail->field('id');
      		$useremail = $query_getusermail->field('email');
	  	$query_getusermail->free();

		if ($email !== $useremail) {
			gen_error('Sorry, this request does not pass through security checks.','');
		}


      		$query_getadminmail = new query($SQL, 'SELECT email FROM '.$prefix.'profiles WHERE id = 1 LIMIT 1');
	      	$query_getadminmail->getrow(); 
      		$admin = $query_getadminmail->field('email');
	  	$query_getadminmail->free();

		$newpasswd = crypt(time());
		new query($SQL, "UPDATE ".$prefix."profiles SET password='".md5($newpasswd)."' WHERE id= $id");

        	$mailheaders = "From: $admin\n";
         	$subject = 'Your New OpenBB Password';
		$message = "Hello.\n\n Your new password is ".$newpasswd.". You can now login again!";
         	mail($email, $subject, $message, $mailheaders);
         	gen_redirect('An email has been sent with your new password.',$config->field('boardurl').'/');  

}



if ($action == 'testpm') {
require('base.php');
$pmauth = $config->field('pmauthor');
$regpmsg = $config->field('regpm');

echo $pmauth;
echo regpmsg;

send_pm('action', $pmauth, 'Welcome!', $regpmsg); }


// ###############################
//              LIST MEMBERS
// ###############################

if ($action == 'list') {

  $SI['ref'] = 'Viewing Member List';
  $SI['settings'] = 'mlistperpage';
  $SI['templates'] = '17|18';
  define('SCRIPTID','member/list');
  include 'base.php';
  
  check_perm('member_memberlist',0);

  if (NUKE) {
     if(!isset($mainfile)) { include("mainfile.php"); }
     if (!eregi("modules.php", $PHP_SELF)) {
        die ("You can't access this file directly...");
     }
  }
  
  if ($sortorder == '') { $sortorder = 'username'; }
  if ($perpage == '') { $perpage = $config->field('mlistperpage'); }
  if ($reverse == 1) { $orderquery = 'DESC'; } else { $orderquery = 'ASC'; }
  
  $nav = getnav('memberlist');
  $prequery = 'SELECT username, email, homepage, posts, id FROM '.$prefix.'profiles WHERE '.$sortorder.' != \'\' ORDER BY '.$sortorder.' '.$orderquery;
 
  $query_count = new query($SQL, 'SELECT COUNT(username) AS count FROM '.$prefix.'profiles WHERE \''.$sortorder.'\' != \'\''); 
  $query_count->getrow();
  $totalrecords = $query_count->field('count');
  $query_count->free();
  
  $count = ($totalrecords / $perpage);
  $tmp2 = explode(".", $count);
  $pages = $tmp2[0];
  if (substr($tmp2[1],0,1) > 0) { $pages++; }
  if ($page == '') { $page = 1; }

  if ($page > 1) { $i = $page - 1; $pagelink .= '<a href="member.php?action=list&page='.$i.'&sortorder='.$sortorder.'&perpage='.$perpage.'&reverse='.$reverse.'">&lt;</a> &nbsp;&nbsp; '; $pagelink .= '&nbsp;&nbsp; <a href="member.php?action=list&page=1&sortorder='.$sortorder.'&perpage='.$perpage.'&reverse='.$reverse.'">&lt;&lt;</a> &nbsp;&nbsp; '; } else { $pagelink .= '&lt; &nbsp;&nbsp; '; $pagelink .= '&nbsp;&nbsp; &lt;&lt; &nbsp;&nbsp; '; }
  if ($page > 2) { $i = $page - 1; } else { $i = 0; }
  $tmp = 3;

  while ($tmp != 0) {
     $i++;
     $tmp--;
     if ($i <= $pages) {
        if ($i == $page) { $pagelink .= $i . '  &nbsp; '; } else { $pagelink .= '<a href="member.php?action=list&page='.$i.'&sortorder='.$sortorder.'&perpage='.$perpage.'&reverse='.$reverse.'">'.$i.'</a> &nbsp; ';}
     }
  }

  $i = $page + 1;

  if ($count > 1 && $page != $pages) { $pagelink .= '&nbsp;&nbsp; <a href="member.php?action=list&page='.$pages.'&sortorder='.$sortorder.'&perpage='.$perpage.'&reverse='.$reverse.'">&gt;&gt;</a> &nbsp;&nbsp; '; } else { $pagelink .= '&nbsp;&nbsp; &gt;&gt; &nbsp;&nbsp; '; }
  if ($count > 1 && $page != $pages && $i <= $pages) { $pagelink .= '&nbsp;&nbsp; <a href="member.php?action=list&page='.$i.'&sortorder='.$sortorder.'&perpage='.$perpage.'&reverse='.$reverse.'">&gt;</a> '; } else { $pagelink .= '&nbsp;&nbsp; &gt; '; }
  $start = (($page - 1)*$perpage);
  $page = $pages;
  if (($page * $perpage) == $count) { $page++; }

  $prequery .= ' LIMIT '.$start.','.$perpage; 
  $query_getmembers = new query($SQL, $prequery);
  while ($query_getmembers->getrow()) {
     $user[name] = $query_getmembers->field('username');
     $user[id] = $query_getmembers->field('id');
     $user[email] = $query_getmembers->field('email');
     $user[homepage] = $query_getmembers->field('homepage');
	 
	 if ($user[homepage]) {
	    $user[homepage] = '<a href="'.$user[homepage].'" target="_blank"><img src="{imagepath}/homepage.gif" border="0" alt="'.$user[homepage].'"></a>';
	 }
	 
	 if ($user[email]) {
	    $user[email] = '<a href="member.php?action=mail&UID='.$user[id].'"><img src="{imagepath}/email.gif" border="0"></a>';
	 }
	
     $user[posts] = $query_getmembers->field('posts');
     $user[joindate] = $query_getmembers->field('joindate');
     $user[joindate] = date("F d, Y",$user[joindate]+($timeoffset*3600));
     eval("\$include .= \"".addslashes($TI['17'])."\";"); 
  }
  
  $query_getmembers->free();
  
  $option_sortorder[$sortorder] = 'selected';
  $option_perpage[$perpage] = 'selected';
  $option_reverse[$reverse] = 'selected';
  
  $title = 'Viewing Member List';
  eval("\$include = \"".addslashes($TI['18'])."\";"); 
  eval("\$output = \"".addslashes($TI['0'])."\";"); 
  lose($output); 
  
}

// ########################
//          Activation Code
// ########################
if ($action == 'activate') {
   require 'base.php';
   $q = new query($SQL, "SELECT activated, joindate FROM profiles WHERE id = '".$UID."'");
   if (!$q->getrow()) { gen_error('Invalid activation URL!','Check the URL for typing mistakes.'); }
   if (md5($q->field('joindate')) != $s) { gen_error('Invalid activation URL!','Check the URL for typing mistakes.'); }
   if ($q->field('activated') == 1) { gen_error('This account has already been activated!',''); }
   new query($SQL, 'UPDATE profiles SET activated = \'1\' WHERE id = \''.$UID.'\'');
   gen_redirect('Your account has been activated, you can now login!','member.php?action=login');
}


// ###############################
//             LIST ONLINE MEMBERS
// ###############################

if ($action == 'online') {

  $SI['ref'] = 'Viewing Online Member List';
  $SI['templates'] = '33|34|132';
  define('SCRIPTID','member/online/display');
  include 'base.php';
  
  check_perm('member_whosonline',0);

  if (NUKE) {
     if(!isset($mainfile)) { include("mainfile.php"); }
     if (!eregi("modules.php", $PHP_SELF)) {
        die ("You can't access this file directly...");
     }
  }
  
  if ($sortorder == '') { $sortorder = 'member'; }
  if ($reverse == 1) { $orderquery = 'DESC'; } else { $orderquery = 'ASC'; }
  if (ADMIN) { $adminquery = ''; } else { $adminquery = 'AND invisible = \'0\''; }
  	  
  $nav = getnav('online');
  $prequery = 'SELECT member, lastaction, ip, location, invisible FROM '.$prefix.'active WHERE \''.time().'\' - lastaction < 600 '.$adminquery.' ORDER BY '.$sortorder.' '.$orderquery;
 
  $query_getmembers = new query($SQL, $prequery);
  while ($query_getmembers->getrow()) {
     if (ADMIN) { $ip = $query_getmembers->field('ip'); } else { $ip = '-------'; }
     $member = $query_getmembers->field('member');
     $location = $query_getmembers->field('location');
	 if ($query_getmembers->field('invisible')) { $invisible = $TI['132']; } else { $invisible = ''; }
     $lastaction = gmdate($timeformat[1], ($query_getmembers->field('lastaction') + $offset));
     eval("\$include .= \"".addslashes($TI['34'])."\";"); 
  }
  
  $query_getmembers->free();
  
  $option_sortorder[$sortorder] = 'selected';
  $option_perpage[$perpage] = 'selected';
  $option_reverse[$reverse] = 'selected';
  
  $title = 'Viewing Member List';
  eval("\$include = \"".addslashes($TI['33'])."\";"); 
  eval("\$output = \"".addslashes($TI['0'])."\";"); 
  lose($output); 
  
}


// ###############################
//                         EMAIL FORM
// ###############################

if ($action == 'mail') {
if ($send == 1) {

      $SI['ref'] = 'Sending a topic';
      define('SCRIPTID','member/mail/insert');
      require 'base.php';
	  
	 check_perm('member_canmail',0);
			
      $query_getadminmail = new query($SQL, 'SELECT email FROM '.$prefix.'profiles WHERE id = 1 LIMIT 1');
      $query_getadminmail->getrow(); 
      $admin = $query_getadminmail->field('email');
	  $query_getadminmail->free();
	  
	  $query_getuser = new query($SQL, "SELECT email FROM ".$prefix."profiles WHERE id = '".$UID."' LIMIT 1");
	  $query_getuser->getrow();
	  $email = $query_getuser->field('email');
	  $query_getuser->free();

      $mailheaders = "From: $admin\n";
      mail($email, stripslashes($subject), stripslashes($message), $mailheaders);
      gen_redirect('Mail has been send - Redirecting you to the mainpage','index.php');
	  
} else {

  $SI['ref'] = 'Sending an E-Mail';
  $SI['templates'] = '123';
  define('SCRIPTID','member/mail/display');
  include 'base.php';
  
  check_perm('member_canmail',0);

  if (NUKE) {
     if(!isset($mainfile)) { include("mainfile.php"); }
     if (!eregi("modules.php", $PHP_SELF)) {
        die ("You can't access this file directly...");
     }
  }
  if (!USERNAME) {
		gen_error('You must be logged in to perform this function.','<a href=member.php?action=login>Click here to login</a>.');
	} else {
	  $title = 'Sending an E-Mail';
	  eval("\$include = \"".addslashes($TI['123'])."\";"); 
	  eval("\$output = \"".addslashes($TI['0'])."\";");
	}
  lose($output); 
}
}



?>
