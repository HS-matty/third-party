<?php
/*
 *
 *  openbb, copyright (c)2001 iansoft
 *  public release beta 1.0.0
 *  http://www.iansoft.net/
 *
 */ 

// Avoid warnings
if (!isset($action)) { $action = ''; }
if (!isset($send)) { $send = ''; }

 
// ###############################
//         MY HOME
// ###############################
if ($action == '' || $action == 'home') {

   $SI['templates'] = '20|80|88|82|21|81|31|47|91';
   $SI['ref'] = 'In his/her Home';
   $SI['settings'] = 'comnews';
   define('SCRIPTID','myhome/home/display');
   require 'base.php';
   
   if (NUKE) {   
    if(!isset($mainfile)) { include("mainfile.php"); }
    if (!eregi("modules.php", $PHP_SELF)) {
       die ("You can't access this file directly...");
    }
   }
	  
   check_perm('myhome_canaccess',0);
   
   $frms = explode("|", $HTTP_COOKIE_VARS['forums']);
   $con = 1;
   while (list($key,$val) = each($frms)) {
      $prop = explode("=", $val);     
      $cookie_forums[$prop[0]] = $prop[1];
   }
   
   $rbg = '0';
   $count = 0;
   $query_getpm = new query($SQL, "SELECT send, subject, id, time, isread FROM ".$prefix."pmsg WHERE owner = '".addslashes(USERNAME)."' AND box = 'inbox' AND isread = '0' ORDER BY time DESC");
   while ($query_getpm->getrow()) {
   
      if ($rbg == 0) {
          $rowbg = '{primary}';
         $rbg = 1;
      } else {
          $rowbg = '{secondary}';
         $rbg = 0;
      } 
	  
	  $icon = 'msg-on.gif';
      $count++;
      $id = $query_getpm->field('id');
      $sender = $query_getpm->field('send');
      $isread = $query_getpm->field('isread');
      $subject = $query_getpm->field('subject');
      $time = $query_getpm->field('time');
      eval("\$pm .= \"".addslashes($TI[31])."\";");  
   }
   $query_getpm->free();
   if ($count == 0) { eval("\$pm = \"".addslashes($TI[81])."\";"); }  else { $count = 0; }
   
  $query_getfavorites = new query($SQL, "SELECT topicicons.image as icon, topics.lastposterid, favorites.email as subscribed, topics.dateline as dateline, topics.forumid, topics.id, topics.title, topics.smode, topics.mode, topics.lastposterid, topics.poster, topics.replies, topics.views, topics.lpdate, topics.posterid, topics.lpuser FROM ".$prefix."favorites, ".$prefix."topics, ".$prefix."topicicons WHERE favorites.threadid = topics.id AND favorites.username = '".addslashes(USERNAME)."' AND topics.icon = topicicons.id ORDER BY topics.lpdate DESC");
   while ($query_getfavorites->getrow()) { 
   	$dostatus = 1;  
	  $TID = $query_getfavorites->field('id');
    $FID = $query_getfavorites->field('forumid');
	  if ($cookie_forums[$FID.','.$TID]) {
    	$check[lastvisit] = $cookie_forums[$FID.','.$TID];
     } else {
      $check[lastvisit] = $cookie_forums[$FID];
     }
     $check[lastpost] = $query_getfavorites->field('lpdate');
     if ($check[lastpost] > $check[lastvisit] && $check[lastpost] != 0) { 
	   	$icon = 'topic-on.gif';
      $replies = $query_getfavorites->field('replies');
      $views = $query_getfavorites->field('views');
      $topicicon = $query_getfavorites->field('icon');
      $starter = $query_getfavorites->field('poster');
      $UID = $query_getfavorites->field('posterid');
      $lastpost[UID] = $query_getfavorites->field('lastposterid'); 
	  $date = gmdate($timeformat[3], ($query_getfavorites->field('dateline') + $offset));
	  
	  if ($query_getfavorites->field('subscribed')) {
	  $subscribe = '<a href="myhome.php?action=unsubscribe&TID='.$TID.'">Unsubscribe</a>';
	  } else {
	  $subscribe = '<a href="myhome.php?action=subscribe&TID='.$TID.'">Subscribe</a>';
	  }
	  
      if ($query_getfavorites->field('lpuser') != '') {
	  	 unset($lastpost);
        $lastpost[UID] = $query_getfavorites->field('lastposterid');
        $lastpost[poster] = $query_getfavorites->field('lpuser');
        $lastpost[date] = gmdate($timeformat[3], ($check[lastpost] + $offset));
        eval("\$lastpost = \"".addslashes($TI[47])."\";");
      } else {
	    	unset($lastpost);
	    	$lastpost[UID] = $UID;
			  $lastpost[date] = $date;
			  $lastpost[poster] = $starter;
        eval("\$lastpost = \"".addslashes($TI[91])."\";");
      }
     
      $dostatus = 1;
      $mode = $query_getfavorites->field('smode');

      if ($query_getfavorites->field('locked') == '1') { 
         $icon = 'lock.gif';
      } else { } 
   
      if ($mode == 0) {
         $title = $query_getfavorites->field('title');
         $mode = '';
      } else {
         $title = $query_getfavorites->field('title');
         $mode = $query_getfavorites->field('mode') . ': ';
      }
	  
      $count++;
      eval("\$favorites .= \"".addslashes($TI[80])."\";");    
   }
   }
   if ($count == 0) { eval("\$favorites = \"".addslashes($TI[82])."\";"); }
   $title = 'My Home';
   $comnews = $config->field('comnews');
   eval("\$ucpnav = \"".addslashes($TI[21])."\";"); 
   eval("\$include = \"".addslashes($TI[20])."\";"); 
   eval("\$output = \"".addslashes($TI[0])."\";"); 
   lose($output);
}



// ###############################
//         MY PROFILE
// ###############################
if ($action == 'profile') {
   if ($send != 1) {
   
   $SI['templates'] = '21|22';
   $SI['ref'] = 'Editing his/her profile';
   define('SCRIPTID','myhome/profile/display');
   require 'base.php';
   
    if (NUKE) {   
    if(!isset($mainfile)) { include("mainfile.php"); }
    if (!eregi("modules.php", $PHP_SELF)) {
       die ("You can't access this file directly...");
    }
   }
	  
   check_perm('myhome_myprofile',0);
   
   $query_fetchinfo = new query($SQL, "SELECT email, msn, icq, aim, yahoo, homepagedesc, occupation, location, note, homepage, invisible FROM ".$prefix."profiles WHERE username = '".addslashes(USERNAME)."'");
   $query_fetchinfo->getrow();
   $user[email] = stripslashes($query_fetchinfo->field('email'));
   $user[homepage] = stripslashes($query_fetchinfo->field('homepage'));
   $user[icq] = stripslashes($query_fetchinfo->field('icq'));
   $user[aim] = stripslashes($query_fetchinfo->field('aim'));
   $user[yahoo] = stripslashes($query_fetchinfo->field('yahoo'));
   $user[wm] = stripslashes($query_fetchinfo->field('msn'));
   $user[location] = stripslashes($query_fetchinfo->field('location'));
   $user[personal] = stripslashes($query_fetchinfo->field('note'));
   $user[homepagedesc] = stripslashes($query_fetchinfo->field('homepagedesc'));
   $user[occupation] = stripslashes($query_fetchinfo->field('occupation'));

   $query_fetchinfo->free();
   
   $title = 'My Home - Change my Profile';
   eval("\$ucpnav = \"".addslashes($TI[21])."\";"); 
   eval("\$include = \"".addslashes($TI[22])."\";"); 
   eval("\$output = \"".addslashes($TI[0])."\";"); 
   lose($output);
   
   } else {
   
   $SI['ref'] = 'Changing his/her profile';
   define('SCRIPTID','myhome/profile/insert');
   require 'base.php';
   
    if (NUKE) {   
    if(!isset($mainfile)) { include("mainfile.php"); }
    if (!eregi("modules.php", $PHP_SELF)) {
       die ("You can't access this file directly...");
    }
   }
	  
   check_perm('myhome_myprofile',0);
   
   if(substr($homepage,0,7) != 'http://' && $homepage != '') { $homepage = 'http://' . $homepage; }
   
   new query($SQL, "UPDATE ".$prefix."profiles SET msn = '".addslashes(strip_tags($wm))."', occupation = '".addslashes(strip_tags($occupation))."', homepagedesc = '".addslashes(strip_tags($homepagedesc))."', email = '".addslashes(strip_tags($email))."', homepage = '".addslashes(strip_tags($homepage))."', icq = '".addslashes(strip_tags($icq))."', aim = '".addslashes(strip_tags($aim))."', yahoo = '".addslashes(strip_tags($yahoo))."', location = '".addslashes(strip_tags($location))."', note = '".addslashes(strip_tags($personal))."', timeoffset = '".$offset."' WHERE username = '".addslashes(USERNAME)."'");
   gen_redirect('Your profile has been updated, redirecting you to your home.','myhome.php');
   
   }
}


// ###############################
//         MY SETTINGS
// ###############################
if ($action == 'settings') {
   if ($send != 1) {
   
   $SI['templates'] = '21|104|46|103';
   $SI['ref'] = 'Editing his/her settings';
   define('SCRIPTID','myhome/settings/display');
   require 'base.php';
   
    if (NUKE) {   
    if(!isset($mainfile)) { include("mainfile.php"); }
    if (!eregi("modules.php", $PHP_SELF)) {
       die ("You can't access this file directly...");
    }
   }
	  
   check_perm('myhome_mysettings',0);
   
   $query_fetchinfo = new query($SQL, "SELECT custom, showhistory, sig, avatar, templategroup, invisible, homepagedesc, occupation, location, showemail, showavatar, showsig, note, homepage, invisible, timezone, addowntopics, autosubscribe FROM ".$prefix."profiles WHERE username = '".addslashes(USERNAME)."'");
   $query_fetchinfo->getrow();
   $user[invisible] = $query_fetchinfo->field('invisible');
   $user[signature] = $query_fetchinfo->field('sig');

   if (get_perm('custom',0) == 1) { 
      $user[status] = $query_fetchinfo->field('custom');
	  eval("\$status = \"".addslashes($TI[103])."\";"); 
   }
   
   if ($query_fetchinfo->field('invisible') == '1') {
      $invis = 'checked';
   } else {
      $vis = 'checked';
   }
   
   if ($query_fetchinfo->field('addowntopics') == '1') {
      $addowntopics = 'checked';
   } else {
      $dontaddowntopics = 'checked';
   }
   
   if ($query_fetchinfo->field('autosubscribe') == '1') {
      $autosubscribe = 'checked';
   } else {
      $dontautosubscribe = 'checked';
   }
   
   if ($query_fetchinfo->field('showemail') == '1') {
      $showmail = 'checked';
   } else {
      $hidemail = 'checked';
   }
   if ($query_fetchinfo->field('showavatar') == '1') {
      $showavatar = 'checked';
   } else {
      $dontshowavatar = 'checked';
   }
   if ($query_fetchinfo->field('showsig') == '1') {
      $showsignature = 'checked';
   } else {
      $dontshowsignature = 'checked';
   }
   if ($query_fetchinfo->field('showhistory') == '1') {
      $showhistory = 'checked';
   } else {
      $dontshowhistory = 'checked';
   }
   if ($query_fetchinfo->field('timezone') != 0) {
      $tz = $query_fetchinfo->field('timezone');
      $tz = str_replace('.', '', $tz);
      $tz = str_replace('-', 'm', $tz);
      if (substr($tz, 0,1) != 'm') { $tz = 'p'.$tz; }
      $timezone = '';
      $timezone[$tz] = 'selected';
   } else {
      $timezone = '';
      $timezone[0] = 'selected';
   }
  
   eval("\$timezoneselector = \"".addslashes($TI[46])."\";"); 

$designselector = '<select name="design">';
$q = new query($SQL, "SELECT title, id FROM ".$prefix."designs");
while ($q->getrow()) {
   if($q->field('id') == $query_fetchinfo->field('templategroup')) {
      $designselector .= '<option value="'.$q->field('id').'" selected>'.$q->field('title').'</option>';
   } else {
      $designselector .= '<option value="'.$q->field('id').'">'.$q->field('title').'</option>';
   }
}
$q->free();
$designselector .= '</select>';
   $timezoneselector = stripslashes($timezoneselector);
   $avatarselector = '<select name="avatar" onchange="showavatar();">';
   if (strtolower(substr($query_fetchinfo->field('avatar'),0,7)) == 'http://')
     $avatarselector .= '<option value="URL" selected>Custom URL linked avatar</option>';
   $query_avatars = new query($SQL, "SELECT name, url FROM ".$prefix."avatar WHERE owner = '".addslashes(USERNAME)."' OR owner = ''");
   while($query_avatars->getrow()) {
      $av = $query_avatars->field('url');
      if (!isset($avatarimg)) { $avatarimg = 'avatars/'.$av; }
      if ($av == $query_fetchinfo->field('avatar')) {
         $avatarselector .= '<option value="'.$av.'" selected>'.$query_avatars->field('name').'</option>';
         $avatarimg = 'avatars/'.$av;
      } else {
         $avatarselector .= '<option value="'.$av.'">'.$query_avatars->field('name').'</option>'; 
      }
   }
   $query_fetchinfo->free();
   $query_avatars->free();
   
   $avatarselector .= '</select>';
   $title = 'My Home - Change my Settings';
   eval("\$ucpnav = \"".addslashes($TI[21])."\";"); 
   eval("\$include = \"".addslashes($TI[104])."\";"); 
   eval("\$output = \"".addslashes($TI[0])."\";"); 
   lose($output);
   
   } else {
   
   $SI['ref'] = 'Changing his/her settings';
   define('SCRIPTID','myhome/settings/insert');
   require 'base.php';
   
    if (NUKE) {   
    if(!isset($mainfile)) { include("mainfile.php"); }
    if (!eregi("modules.php", $PHP_SELF)) {
       die ("You can't access this file directly...");
    }
   }
	  
   check_perm('myhome_mysettings',0);
   
   if(substr($homepage,0,7) != 'http://' && $homepage != '') { $homepage = 'http://' . $homepage; }
   $getoffset[1] = (substr($timeoffset, 1) * 3600);
   $getoffset[2] = substr($timeoffset, 0,1);
   $offset = $getoffset[2] . $getoffset[1];
   
   $q = new query($SQL, "SELECT v,t FROM ".$prefix."designs WHERE id = $design");
   $q->getrow();
   
   if ($avatar == 'URL')
     $avatar = '';
   else
     $avatar = "avatar = '".$avatar."',";

   if (isset($status) && get_perm('custom',0) == 1) {
     $custom = "custom = '".htmlspecialchars($status)."',"; 
   } else {
     $custom = '';
   }
   new query($SQL, "UPDATE ".$prefix."profiles SET $custom showhistory = '".$showhistory."', sig = '".htmlspecialchars($signature)."', showemail = '".$showmail."', showsig = '".$showsignature."', showavatar = '".$showavatars."', templategroup = '".$q->field('t')."', vargroup = '".$q->field('v')."', $avatar timeoffset = '".$offset."', timezone = '".$timeoffset."', invisible = '".$invisible."', addowntopics = '".$addowntopics."', autosubscribe = '".$autosubscribe."' WHERE username = '".addslashes(USERNAME)."'");
   new query($SQL, "UPDATE ".$prefix."active SET invisible = '".$invisible."' WHERE record = '".RECORD."'");
   $q->free();
   gen_redirect('Your profile has been updated, redirecting you to your home.','myhome.php');
   
   }
}



// ###############################
//         MY AVATAR
// ###############################
if ($action == 'avatar') {
   if ($send != 1) {
   
   $SI['templates'] = '21|112';
   $SI['settings'] = 'avsize, avw, avh';
   $SI['ref'] = 'Uploading an Avatar';
   define('SCRIPTID','myhome/avatar/display');
   require 'base.php';
   
    if (NUKE) {   
    if(!isset($mainfile)) { include("mainfile.php"); }
    if (!eregi("modules.php", $PHP_SELF)) {
       die ("You can't access this file directly...");
    }
   }
	  
   $types = 'GIF & JPEG';
   $size = $config->field('avsize');
   $max_width = $config->field('avw');
   $max_height = $config->field('avh');
   check_perm('avatar_cancustom',0);
   
   $query_fetchinfo = new query($SQL, "SELECT avatar FROM ".$prefix."profiles WHERE username = '".addslashes(USERNAME)."'");
   $query_fetchinfo->fetch();
   $myav = $query_fetchinfo->field('avatar');
   $myavheight = $query_fetchinfo->field('avh');
   $myavwidth = $query_fetchinfo->field('avw');
   
   /*
   $avatarselector = '<select name="avatar" onchange="showavatar();">';
   $query_avatars = new query($SQL, "SELECT name, url FROM ".$prefix."avatar WHERE owner = '".addslashes(USERNAME)."' OR owner = ''");
   while($query_avatars->getrow()) {
      $av = $query_avatars->field('url');
      if (!isset($avatarimg)) { $avatarimg = 'avatars/'.$av; }
      if ($av == $myav) {
         $avatarselector .= '<option value="'.$av.'" selected>'.$query_avatars->field('name').'</option>';
         $avatarimg = 'avatars/'.$av;
      } else {
         $avatarselector .= '<option value="'.$av.'">'.$query_avatars->field('name').'</option>'; 
      }
   }
   $query_fetchinfo->free();
   */
   
   if (strtolower(substr($myav,0,7)) == 'http://')
     $avurl = $myav;

   $title = 'My Home - Upload Custom Avatar';
   eval("\$ucpnav = \"".addslashes($TI[21])."\";");
   eval("\$include = \"".addslashes($TI[112])."\";"); 
   eval("\$output = \"".addslashes($TI[0])."\";"); 
   lose($output);
  
   } else {
   
   $SI['settings'] = 'avsize,avw,avh';
   $SI['ref'] = 'Uploading an Avatar';
   define('SCRIPTID','myhome/avatar/insert');
   require 'base.php';
   
    if (NUKE) {   
    if(!isset($mainfile)) { include("mainfile.php"); }
    if (!eregi("modules.php", $PHP_SELF)) {
       die ("You can't access this file directly...");
    }
   }
   
   $uploaded = is_uploaded_file($avatar);

   if ($uploaded) {
   $size = $config->field('avsize');
   check_perm('avatar_cancustom',0);
   if ($avatar_size  > $size) { gen_error('Cannot upload your Avatar','The maxium size of the avatar is '.$size.' bytes.'); }
  
   if ($avatar_type == 'image/pjpeg' || $avatar_type == 'image/jpeg') { $type = '.jpg'; }
   if ($avatar_type == 'image/gif') { $type = '.gif'; }
   
   if (!$type) {
      gen_error('Cannot upload your Avatar','Only GIF and JPG avatars are allowed.'); 
   }

   if (file_exists('avatars/'.getavatar(USERNAME).'.gif')) { unlink('avatars/'.getavatar(USERNAME).'.gif');   }
   if (file_exists('avatars/'.getavatar(USERNAME).'.jpg')) { unlink('avatars/'.getavatar(USERNAME).'.jpg');   } 
   if (!copy($avatar, 'avatars/'.getavatar(USERNAME).$type))
		gen_error('Error', 'This server does not support uploading, please contact the administrator for more info');

     list($width, $height) = GetImageSize('avatars/'.getavatar(USERNAME).$type);	
   } else {
     if (!$avurl)
		gen_error('Error', 'Please either upload or specify a URL');
	 if (strtolower(substr($avurl,0,7))!='http://')
		gen_error('Error', 'URL must begin with http://');
     if (substr($avurl, -4) == '.jpg') { $type = '.jpg'; }
     if (substr($avurl, -4) == '.gif') { $type = '.gif'; }
   
     if (!$type) {
       gen_error('Cannot upload your Avatar','Only GIF and JPG avatars are allowed.'); 
     }
     
     list($width, $height) = GetImageSize($avurl);   
   }


   if (($heigth > $config->field('avh')) || ($width > $config->field('avw'))) { 
      if ($uploaded) @unlink($avatar, 'avatars/'.getavatar(USERNAME).$type);
      gen_error('Cannot upload/link your Avatar','Your avatar can only be '.$config->field('avw').' by '.$config->field('avh')." big. (Detected: $width X $height)");   
   }
   
   if ($uploaded) { 
   new query($SQL, "DELETE FROM avatar WHERE owner = '".addslashes(USERNAME)."'");
   $query = new query($SQL,'SELECT id FROM avatar ORDER BY id DESC LIMIT 1');
   $query->getrow();
   $id = $query->field('id') + 1;
   $query->free();
   new query($SQL, "INSERT INTO avatar VALUES ('".$id."','My Avatar','".addslashes(getavatar(USERNAME)).$type."','".addslashes(USERNAME)."')");
   new query($SQL, "UPDATE profiles SET avatar = '".addslashes(getavatar(USERNAME)).$type."' WHERE username = '".addslashes(USERNAME)."'");
   } else {
   new query($SQL, "UPDATE profiles SET avatar = '".$avurl."' WHERE username = '".addslashes(USERNAME)."'");

   }

   gen_redirect('Your new avatar is uploaded and set as your default avatar','myhome.php?action=settings');  
   }
}

// ###############################
//         MY MESSAGES
// ###############################
if ($action == 'messages') {
   
   $SI['templates'] = '21|30|31|107';
   $SI['ref'] = 'Viewing his/her messages';
   define('SCRIPTID','myhome/messages/display');
   require 'base.php';
   
    if (NUKE) {   
    if(!isset($mainfile)) { include("mainfile.php"); }
    if (!eregi("modules.php", $PHP_SELF)) {
       die ("You can't access this file directly...");
    }
   }
	  
   check_perm('myhome_readmsg',0);
   
   if (!isset($box)) { $box = 'inbox'; }
   
   $rbg = '0';
   $count = 0;
   
      $query_getpm = new query($SQL, "SELECT send, accept, subject, id, time, userid, isread FROM ".$prefix."pmsg WHERE owner = '".addslashes(USERNAME)."' AND box = '".$box."' ORDER BY time DESC");

   
   while ($query_getpm->getrow()) {
   
      if ($rbg == 0) {
          $rowbg = '{primary}';
         $rbg = 1;
      } else {
          $rowbg = '{secondary}';
         $rbg = 0;
      } 
	  
      $count++;
	  
	  if ($query_getpm->field('isread')) { $icon = 'msg-off.gif'; } else { $icon = 'msg-on.gif'; }
	  
      $id = $query_getpm->field('id');
	  $UID = $query_getpm->field('userid');

      $sender = $query_getpm->field('send');	  
	  if ($sender == USERNAME) {
	     $sender = $query_getpm->field('accept');	
	  }
	  
	  
	  
      $isread = $query_getpm->field('isread');
      $subject = $query_getpm->field('subject');
      $time = $query_getpm->field('time');
      eval("\$include .= \"".addslashes($TI[31])."\";");  
   }

   $query_getpm->free();
   
   if ($count == 0) { eval("\$include = \"".addslashes($TI[107])."\";");   }
   
   $title = 'My Home - Viewing Messages: '.$box;
   eval("\$ucpnav = \"".addslashes($TI[21])."\";"); 
   eval("\$include = \"".addslashes($TI[30])."\";"); 
   eval("\$output = \"".addslashes($TI[0])."\";"); 
   lose($output);
  
}



// ###############################
//         MY MESSAGES ( READ MSG )
// ###############################
if ($action == 'readmsg') {
   
   $SI['templates'] = '21|71';
   $SI['ref'] = 'Viewing his/her messages';
   define('SCRIPTID','myhome/readmsg/display');
   require 'base.php';
   
    if (NUKE) {   
    if(!isset($mainfile)) { include("mainfile.php"); }
    if (!eregi("modules.php", $PHP_SELF)) {
       die ("You can't access this file directly...");
    }
   }
	  
   check_perm('myhome_readmsg',0);


   $query_fetchpm = new query($SQL, "SELECT accept, box, send, message, time, subject FROM ".$prefix."pmsg WHERE id = '".$id."' AND owner = '".addslashes(USERNAME)."'");
   $query_fetchpm->getrow();
   new query($SQL, "UPDATE ".$prefix."pmsg SET isread = '1' WHERE id = '".$id."' AND (accept = '".addslashes(USERNAME)."' OR send = '".addslashes(USERNAME)."')");
   
   
   $sender = $query_fetchpm->field('send');
   
   if ($query_fetchpm->field('box') == 'inbox') {
     new query($SQL, "UPDATE ".$prefix."pmsg SET box = 'sent items' WHERE id = (".$id." + 1) AND send = '".$sender."'");
   }
   
   $time = $query_fetchpm->field('time');
   $date = gmdate($timeformat[1], ($query_fetchpm->field('time') + $offset));
   $subject = $query_fetchpm->field('subject');
   require 'lib/codeparse.php';
   $message = codeparse($query_fetchpm->field('message'), '1', '0', $sender);

   $title = 'My Home - Viewing Private Message \''.$subject.'\'';  
   $query_fetchpm->free();

   eval("\$ucpnav = \"".addslashes($TI[21])."\";"); 
   eval("\$include = \"".addslashes($TI[71])."\";"); 
   eval("\$output = \"".addslashes($TI[0])."\";");
   lose($output);
  
}


// ###############################
//         MY MESSAGES ( NEW MSG )
// ###############################
if ($action == 'newmsg') {
   
   if ($send != 1 || isset($preview)) {
   
   $SI['templates'] = '21|69|94|122';
   $SI['ref'] = 'Writing a new message';
   $SI['settings'] = 'parseurl, dsmiley';
   define('SCRIPTID','myhome/newmsg/display');
   require 'base.php';
   
    if (NUKE) {   
    if(!isset($mainfile)) { include("mainfile.php"); }
    if (!eregi("modules.php", $PHP_SELF)) {
       die ("You can't access this file directly...");
    }
   }
	  
   check_perm('myhome_newmsg',0);

   if (isset($replyto)) {
      $query_fetchpm = new query($SQL, "SELECT accept, box, send, message, subject FROM ".$prefix."pmsg WHERE id = '".$replyto."' AND owner = '".addslashes(USERNAME)."'");
      $query_fetchpm->getrow();
      $to = $query_fetchpm->field('send');
	  
	  if (strtoupper(substr($query_fetchpm->field('subject'),0,4)) != 'RE: ')
		$subject = 'RE: ' . $query_fetchpm->field('subject');
		else 
		$subject = $query_fetchpm->field('subject');
	  
      $message = '[quote]'. $query_fetchpm->field('message') .'[/quote]';
      $query_fetchpm->free();
   }
   
   if (isset($PID)) {
      $query_fetchpost = new query($SQL, "SELECT message, poster, threadid FROM ".$prefix."posts WHERE id = '".$PID."'");
      $query_fetchpost->getrow();
      $to = $query_fetchpost->field('send');
	  
      $subject = 'RE: '.$config->field('boardurl').'/read.php?TID='.$query_fetchpost->field('threadid').'#'.$PID;

	  
      $message = '[quote]'. $query_fetchpost->field('message') .'[/quote]';
	  $to = $query_fetchpost->field('poster');
      $query_fetchpost->free();
   }
   
   
   if (isset($forward)) {
      $query_fetchpm = new query($SQL, "SELECT accept, box, message, send, time, subject FROM ".$prefix."pmsg WHERE id = '".$forward."' AND owner = '".addslashes(USERNAME)."'");
      $query_fetchpm->getrow();
	  
	  if (strtoupper(substr($query_fetchpm->field('subject'),0,4)) != 'FW: ')
       $subject = 'FW: ' . $query_fetchpm->field('subject');
      else
       $subject = $query_fetchpm->field('subject');

	  
      $message = '[quote]';
	  $message .= '[i]Recieved from '.$query_fetchpm->field('send').' at '.gmdate($timeformat[1], ($query_fetchpm->field('time') + $offset)).'[/i]';  
	  $message .= $query_fetchpm->field('message') .'[/quote]';
      $query_fetchpm->free();
   }
   
   if (isset($preview)) {
      $to = $reciever;  
	  $oldmsg = $message;
      if ($parseurl == 'CHECKED') { $a = 1; } else { $a = 0; }
      if ($disablesmilies == 'CHECKED') { $b = 1; } else { $b = 0; }
	  include 'lib/codeparse.php';
      $message = codeparse($message, $a, $b, USERNAME);
	  eval("\$preview = \"".addslashes($TI[122])."\";");
	  $message  = $oldmsg;
   }
   
	  $query_getsmileyset = new query($SQL,'SELECT id, name FROM '.$prefix.'smileysets');
	  while ($query_getsmileyset->getrow()) {
	     $smileyset[id] = $query_getsmileyset->field('id');
		 $smileyset[name] = $query_getsmileyset->field('name');
		 eval("\$smilies .= \"".addslashes($TI[94])."\";"); 
	  }
	  $query_getsmileyset->free();
	  
      if ($config->field('parseurl')) { $parseurl = 'CHECKED'; }
      if ($config->field('dsmiley')) { $disablesmilies = 'CHECKED'; }
      if ($parseurl == 'yes' && $preview == 1) { $parseurl = 'CHECKED'; } elseif ($preview == 1) { $parseurl = ''; }
      if ($disablesmilies == 'yes' && $preview == 1) { $disablesmilies = 'CHECKED'; } elseif ($preview == 1) { $disablesmilies = ''; }

   $title = 'My Home - Writing Private Message';  
   eval("\$ucpnav = \"".addslashes($TI[21])."\";"); 
   eval("\$include = \"".addslashes($TI[69])."\";"); 
   eval("\$output = \"".addslashes($TI[0])."\";");
   lose($output);
   
   } else {
   
   // ## SEND IT!
   
   $SI['ref'] = 'Sending a new message';
   define('SCRIPTID','myhome/newmsg/insert');
   require 'base.php';
   
      if ($reciever == '') {
      gen_error("An error occured while sending the message","You must specify a reciever that will recieve your message, go back and correct this.");
   }

   if ($message == '') {
      gen_error("An error occured while sending the message","You must specify a message that will be send to the reciever(s), go back and correct this.");
   }

   if ($subject == '') {
      gen_error("An error occured while sending the message","You must specify a subject for your message, go back and correct this.");
   }

   $q = new query($SQL, "SELECT id FROM ".$prefix."profiles WHERE username = '".$reciever."'");
   if (!$q->getrow()) {
      gen_error("An error occured while sending the message","The reciever doesn't exists, go back and correct this.");
   }
   $uid = $q->field('id');

   
   $qr = new query($SQL, "SELECT lastpm, totalpm FROM ".$prefix."profiles WHERE username = '".addslashes(USERNAME)."'");
   $qr->getrow();

      $q = new query($SQL, "SELECT pm_maxday FROM ".$prefix."usergroup WHERE id = '".USERGROUP."'");
    $q->getrow();

   if ($q->field('pm_maxday') == '-1') { $max = '9999'; } else { $max = $q->field('pm_maxday'); }

   $days_since_last_pm = (time() - $qr->field('lastpm')) / 86400;
   $expire = gmdate($timeformat[1], ($qr->field('lastpm') + OFFSET + 86400));
   if ($qr->field('totalpm') > $max && $days_since_last_pm < 1) {
      gen_error("An error occured while sending the message","You have reached your maximum message limit for today, please wait untill $expire.");
   }

   new query($SQL, "UPDATE ".$prefix."profiles SET lastpm = '".time()."', totalpm = (totalpm + 1) WHERE username = '".addslashes(USERNAME)."'");
   $qr->free();

    send_pm($reciever, USERNAME, $subject, $message, 0, USERID, $uid);
   gen_redirect('Your message has been sent.','myhome.php?action=messages');
   
   }
  
}



// ###############################
//         MY MESSAGES ( DELETE MSG )
// ###############################
if ($action == 'delmsg') {
   
   $SI['ref'] = 'Deleting his/her messages';
   define('SCRIPTID','myhome/delmsg/insert');
   require 'base.php';
   
    if (NUKE) {   
    if(!isset($mainfile)) { include("mainfile.php"); }
    if (!eregi("modules.php", $PHP_SELF)) {
       die ("You can't access this file directly...");
    }
   }
	  
   check_perm('myhome_delmsg',0);


  if ($id == 'all' && $box != 'recycle bin') {
     new query($SQL, "UPDATE ".$prefix."pmsg SET box = 'recycle bin' WHERE box = '".$box."' AND owner = '".addslashes(USERNAME)."'");
  } elseif ($id == 'all' && $box == 'recycle bin') {
     new query($SQL, "DELETE FROM ".$prefix."pmsg WHERE box = '".$box."' AND owner = '".addslashes(USERNAME)."'");
  } elseif ($box != 'recycle bin') {
     new query($SQL, "UPDATE ".$prefix."pmsg SET box = 'recycle bin' WHERE box = '".$box."' AND owner = '".addslashes(USERNAME)."' AND id = '".$id."'");
  } elseif ($box == 'recycle bin') {
     new query($SQL, "DELETE FROM ".$prefix."pmsg WHERE box = '".$box."' AND owner = '".addslashes(USERNAME)."' AND id = '".$id."'");
  }
  
  
   gen_redirect('The message(s) is/are deleted. Redirecting you to the Message Box','myhome.php?action=messages&box='.$box);
  
}



// ###############################
//         MY MESSAGES ( DOWNLOAD MSG )
// ###############################
if ($action == 'downloadmsg') {
   
   $SI['ref'] = 'Downloading one of his/her messages';
   $SI['templates'] = '115';
   define('SCRIPTID','myhome/downloadmsg/display');
   require 'base.php';
   
    if (NUKE) {   
    if(!isset($mainfile)) { include("mainfile.php"); }
    if (!eregi("modules.php", $PHP_SELF)) {
       die ("You can't access this file directly...");
    }
   }
	  
   check_perm('myhome_dlmsg',0);

   @header('Content-Type: text/plain');
   
   $query_fetchpm = new query($SQL, "SELECT accept, box, send, message, time, subject FROM ".$prefix."pmsg WHERE id = '".$id."' AND owner = '".addslashes(USERNAME)."'");
   $query_fetchpm->getrow();
   $from = $query_fetchpm->field('send');
   
   $time = $query_fetchpm->field('time');
   $date = gmdate($timeformat[1], ($time + $offset));
   $subject = $query_fetchpm->field('subject');
   require 'lib/codeparse.php';
   $message = $query_fetchpm->field('message');

   $query_fetchpm->free();

   eval("\$result = \"".addslashes($TI[115])."\";"); 
   print stripslashes($result);
}


// ###############################
//         MY MESSAGES ( SAVE MSG )
// ###############################
if ($action == 'savemsg') {
   
   $SI['ref'] = 'Saving one of his/her messages';
   define('SCRIPTID','myhome/savemsg/display');
   require 'base.php';
   
    if (NUKE) {   
    if(!isset($mainfile)) { include("mainfile.php"); }
    if (!eregi("modules.php", $PHP_SELF)) {
       die ("You can't access this file directly...");
    }
   }
	  
   check_perm('myhome_savemsg',0);

   
   new query($SQL, "UPDATE ".$prefix."pmsg SET box = 'saved items' WHERE id = '".$id."' AND owner = '".addslashes(USERNAME)."'");


   gen_redirect('Your message has been saved - redirecting you','myhome.php?action=messages&box=saved items');
}



// ###############################
//         FAVORITES
// ###############################
if ($action == 'favorites') {
   
   $SI['ref'] = 'Viewing his/her favorites';
   $SI['templates'] = '21|80|82|47|91|88';
   define('SCRIPTID','myhome/favorites/display');
   require 'base.php';
   
    if (NUKE) {   
    if(!isset($mainfile)) { include("mainfile.php"); }
    if (!eregi("modules.php", $PHP_SELF)) {
       die ("You can't access this file directly...");
    }
   }
	  
   check_perm('myhome_favorites',0);
   
   $frms = explode("|", $HTTP_COOKIE_VARS['forums']);
   $con = 1;
   while (list($key,$val) = each($frms)) {
      $prop = explode("=", $val);     
      $cookie_forums[$prop[0]] = $prop[1];
   }

   
   $query_getfavorites = new query($SQL, "SELECT topicicons.image as icon, topics.lastposterid, favorites.email as subscribed, topics.dateline as dateline, topics.forumid, topics.id, topics.title, topics.smode, topics.mode, topics.lastposterid, topics.poster, topics.replies, topics.views, topics.lpdate, topics.posterid, topics.lpuser FROM ".$prefix."favorites, ".$prefix."topics, ".$prefix."topicicons WHERE favorites.threadid = topics.id
   AND favorites.username = '".addslashes(USERNAME)."' AND topics.icon = topicicons.id ORDER BY topics.lpdate DESC");
   while ($query_getfavorites->getrow()) { 
      $dostatus = 1;

	  $TID = $query_getfavorites->field('id');
      $replies = $query_getfavorites->field('replies');
      $views = $query_getfavorites->field('views');
      $topicicon = $query_getfavorites->field('icon');
      $starter = $query_getfavorites->field('poster');
      $UID = $query_getfavorites->field('posterid');
      $lastpost[UID] = $query_getfavorites->field('lastposterid'); 
      $FID = $query_getfavorites->field('forumid');
	  $date = gmdate($timeformat[3], ($query_getfavorites->field('dateline') + $offset));
	  

      if ($cookie_forums[$FID.','.$TID]) {
         $check[lastvisit] = $cookie_forums[$FID.','.$TID];
      } else {
         $check[lastvisit] = $cookie_forums[$FID];
      }


	  if ($query_getfavorites->field('subscribed')) {
	  $subscribe = '<a href="myhome.php?action=unsubscribe&TID='.$TID.'">Unsubscribe</a>';
	  } else {
	  $subscribe = '<a href="myhome.php?action=subscribe&TID='.$TID.'">Subscribe</a>';
	  }
	  
      $check[lastpost] = $query_getfavorites->field('lpdate');
       if ($check[lastpost] > $check[lastvisit] && $check[lastpost] != 0) { $icon = 'topic-on.gif'; } else { $icon = 'topic-off.gif'; }
   
      if ($query_getfavorites->field('lpuser') != '') {
	  	 unset($lastpost);
         $lastpost[UID] = $query_getfavorites->field('lastposterid');
         $lastpost[poster] = $query_getfavorites->field('lpuser');
         $lastpost[date] = gmdate($timeformat[3], ($check[lastpost] + $offset));
         eval("\$lastpost = \"".addslashes($TI[47])."\";");
      } else {
	     unset($lastpost);
	     $lastpost[UID] = $UID;
		 $lastpost[date] = $date;
		 $lastpost[poster] = $starter;
         eval("\$lastpost = \"".addslashes($TI[91])."\";");
      }
     
      $dostatus = 1;
      $mode = $query_getfavorites->field('smode');

      if ($query_getfavorites->field('locked') == '1') { 
         $icon = 'lock.gif';
      } else { } 
   
      if ($mode == 0) {
         $title = $query_getfavorites->field('title');
         $mode = '';
      } else {
         $title = $query_getfavorites->field('title');
         $mode = $query_getfavorites->field('mode') . ': ';
      }
	  
      $count++;
      eval("\$include .= \"".addslashes($TI[80])."\";");    
   }
   if ($count == 0) { eval("\$include = \"".addslashes($TI[82])."\";"); }
    $title = 'My Favorites';
   eval("\$ucpnav = \"".addslashes($TI[21])."\";"); 
   eval("\$include = \"".addslashes($TI[88])."\";"); 
   eval("\$output = \"".addslashes($TI[0])."\";");
   lose($output);
 
} elseif ($action == 'unsubscribe') {
   
   $SI['ref'] = 'Unsubscribing from a Topic';
   define('SCRIPTID','myhome/favorites/unsubscribe');
   require 'base.php';
   
    if (NUKE) {   
    if(!isset($mainfile)) { include("mainfile.php"); }
    if (!eregi("modules.php", $PHP_SELF)) {
       die ("You can't access this file directly...");
    }
   }
	  
   check_perm('myhome_favorites',0);
   
   if (!$TID) { gen_error('Required information is missing!','Please include the Topic ID of the favorite you wish to remove'); }
   
   new query($SQL, "UPDATE ".$prefix."favorites SET email = '0' WHERE username = '".addslashes(USERNAME)."' AND threadid = '".$TID."'");
   gen_redirect('You are now unsubscribed from this topic, redirecting you to your favorites','myhome.php?action=favorites');
} elseif ($action == 'subscribe') {
   
   $SI['ref'] = 'Subscribing to a Topic';
   define('SCRIPTID','myhome/favorites/subscribe');
   require 'base.php';
   
    if (NUKE) {   
    if(!isset($mainfile)) { include("mainfile.php"); }
    if (!eregi("modules.php", $PHP_SELF)) {
       die ("You can't access this file directly...");
    }
   }
	  
   check_perm('myhome_favorites',0);
   
   if (!$TID) { gen_error('Required information is missing!','Please include the Topic ID of the favorite you wish to remove'); }
   
   $query_check  = new query($SQL, "SELECT email FROM ".$prefix."favorites WHERE username = '".addslashes(USERNAME)."' AND threadid = '".$TID."'");
   if (!$query_check->getrow()) {
      gen_error('You can only Subscribe to Topics wich are in your favorites.','To add this topic to your favorites, <a href="myhome.php?action=createfavorite&TID='.$TID.'">click here</a>');
   }
   $query_check->free();
   new query($SQL, "UPDATE ".$prefix."favorites SET email = '1' WHERE username = '".addslashes(USERNAME)."' AND threadid = '".$TID."'");
   gen_redirect('You are now Subscribed to this topic, redirecting you to your favorites','myhome.php?action=favorites');
   
   
} elseif ($action == 'createfavorite') {


   
   $SI['ref'] = 'Adding a Topic to his/her favorites';
   define('SCRIPTID','myhome/favorites/create');
   require 'base.php';
   
    if (NUKE) {   
    if(!isset($mainfile)) { include("mainfile.php"); }
    if (!eregi("modules.php", $PHP_SELF)) {
       die ("You can't access this file directly...");
    }
   }
	  
   check_perm('myhome_favorites',0);
   
   if (!$TID) { gen_error('Required information is missing!','Please include the Topic ID of the favorite you wish to remove'); }
   
   $query_check  = new query($SQL, "SELECT email FROM ".$prefix."favorites WHERE username = '".addslashes(USERNAME)."' AND threadid = '".$TID."'");
   if ($query_check->getrow()) {
      gen_error('This topic already exists in your favorites.','To remove this topic from your favorites, <a href="myhome.php?action=deletefavorite&TID='.$TID.'">click here</a>');
   }
   
   $query_check  = new query($SQL, "SELECT forumid FROM ".$prefix."topics WHERE id = '".$TID."'");
   if (!$query_check->getrow()) {
      gen_error('This topic does not exists.','Go back and try again');
   }
   $FID = $query_check->field('forumid');
   $query_check->free();
   
   if (AUTOSUBSCRIBE) { $email = 1; } else { $email = 0; }
   new query($SQL, "INSERT INTO ".$prefix."favorites VALUES('".addslashes(USERNAME)."','".$FID."','".$TID."','".$email."','1')");
   gen_redirect('This topic is now added to your favorites, redirecting you to your favorites','myhome.php?action=favorites');
   
   
   
} elseif ($action == 'deletefavorite') {
   
   $SI['ref'] = 'Removing a Topic from his/her favorites';
   define('SCRIPTID','myhome/favorites/delete');
   require 'base.php';
   
    if (NUKE) {   
    if(!isset($mainfile)) { include("mainfile.php"); }
    if (!eregi("modules.php", $PHP_SELF)) {
       die ("You can't access this file directly...");
    }
   }
	  
   check_perm('myhome_favorites',0);
   
   if (!$TID) { gen_error('Required information is missing!','Please include the Topic ID of the favorite you wish to remove'); }
   
   $query_check  = new query($SQL, "SELECT email FROM ".$prefix."favorites WHERE username = '".addslashes(USERNAME)."' AND threadid = '".$TID."'");
   if (!$query_check->getrow()) {
      gen_error('This topic does not exists in your favorites.','To add this topic to your favorites, <a href="myhome.php?action=createfavorite&TID='.$TID.'">click here</a>');
   }
   
   $query_check->free();
   
   new query($SQL, "DELETE FROM ".$prefix."favorites WHERE username = '".addslashes(USERNAME)."' AND threadid = '".$TID."'");
   gen_redirect('This topic has been deleted from your favorites, redirecting you to your favorites','myhome.php?action=favorites');

} elseif ($action == 'chpass') {
   $SI['templates'] = '21|150';
   $SI['ref'] = 'Changing his/her pass';
   define('SCRIPTID','myhome/chpass');
   require 'base.php';
   
    if (NUKE) {   
    if(!isset($mainfile)) { include("mainfile.php"); }
    if (!eregi("modules.php", $PHP_SELF)) {
       die ("You can't access this file directly...");
    }
   }
	  
   check_perm('myhome_mysettings',0);

   eval("\$ucpnav = \"".addslashes($TI[21])."\";"); 
   eval("\$include = \"".addslashes($TI[150])."\";"); 
   eval("\$output = \"".addslashes($TI[0])."\";");
   lose($output);

   
 
} elseif ($action == 'do_chpass') {
   $SI['ref'] = 'Changing his/her pass';
   define('SCRIPTID','myhome/chpass/send');
   require 'base.php';
   
    if (NUKE) {   
    if(!isset($mainfile)) { include("mainfile.php"); }
    if (!eregi("modules.php", $PHP_SELF)) {
       die ("You can't access this file directly...");
    }
   }

   check_perm('myhome_mysettings',0);
if ($conf != $new) { gen_error('Cannot change Password','Both passwords does not match'); }
 new query($SQL,"UPDATE profiles SET password = '".md5($new)."' WHERE username = '".addslashes(USERNAME)."'");
 gen_redirect('Password has been changed, redirecting to My Settings','myhome.php?action=settings');

   
 
}
?>