<?php
/*
 *
 *  openbb, copyright (c)2001 iansoft
 *  public release beta 1.0.0
 *  http://www.iansoft.net/
 *
 */ 

// ###############################
//         POST NEW THREAD
// ###############################

$action = $HTTP_GET_VARS['action'];
$post = $HTTP_GET_VARS['post'];
$preview = $HTTP_POST_VARS['preview'];
$remthread = $HTTP_POST_VARS['remove'];

if ($action == 'post') {
   // ### 'Post New Topic' Screen  
  
    
    if (!$post || $preview) {

      $SI['ref'] = 'Posting New Topic';
      $SI['templates'] = '13|55|45|86|94';
      $SI['settings'] = 'parseurl, dsmiley';
      define('SCRIPTID','post/newthread/screen');
      require 'base.php';
	  
	  $templategroup = TEMPLATEGROUP;
	  
      if (NUKE) {   
         if(!isset($mainfile)) { include("mainfile.php"); }
         if (!eregi("modules.php", $PHP_SELF)) {
            die ("You can't access this file directly...");
         }
      }
      
      if (!$FID) { gen_error('No Forum specified!','Go back and try again.'); }
       check_perm('thread_canpost',1,$usergroup);
      if ($config->field('parseurl')) { $parseurl = 'checked'; }
      if ($config->field('dsmiley')) { $disablesmilies = 'checked'; }
      if ($parseurl == 'yes' && $preview == 1) { $parseurl = 'checked'; } elseif ($preview == 1) { $parseurl = ''; }
      if ($disablesmilies == 'yes' && $preview) { $disablesmilies = 'checked'; } elseif ($preview) { $disablesmilies = ''; }
	  $query_geticons = new query($SQL, 'SELECT id, image FROM '.$prefix.'topicicons WHERE id != 0 ORDER BY id');
          if ($preview) {
            $selectedicon = $HTTP_POST_VARS['icon'];
          }
	  while ($query_geticons->getrow()) {
             if ($preview) {
               if ($query_geticons->field('id') == $selectedicon) {
                 $icons .= '<input type="radio" name="icon" value="'.$query_geticons->field('id').'" checked> <img src="{imagepath}/'.$query_geticons->field('image').'"> ';
               } else {
                 $icons .= '<input type="radio" name="icon" value="'.$query_geticons->field('id').'"> <img src="{imagepath}/'.$query_geticons->field('image').'"> ';
               }
             } else {
               $icons .= '<input type="radio" name="icon" value="'.$query_geticons->field('id').'"> <img src="{imagepath}/'.$query_geticons->field('image').'"> ';
             }
	  }

      if ($preview) {
         $iconselected == 'checked';
         include 'lib/codeparse.php';
         if ($parseurl == 'CHECKED') { $a = 1; } else { $a = 0; }
         if ($disablesmilies == 'CHECKED') { $b = 1; } else { $b = 0; }
         $temp = $message;
         $message = codeparse($message, $a, $b, USERNAME);
         eval("\$preview = \"".addslashes($TI[86])."\";");
		 $message = $temp;
      }
     $nav = getnav('forum:'.$FID) . ' > New Topic';

     if (MEMBER) {
         $username = USERNAME;
         eval("\$include = \"".addslashes($TI[55])."\";"); 
      } else { 
         eval("\$include = \"".addslashes($TI[45])."\";"); 
      }

	  $query_getsmileyset = new query($SQL,'SELECT id, name FROM '.$prefix.'smileysets');
	  while ($query_getsmileyset->getrow()) {
	     $smileyset[id] = $query_getsmileyset->field('id');
		 $smileyset[name] = $query_getsmileyset->field('name');
		 eval("\$smilies .= \"".addslashes($TI[94])."\";"); 
	  }
	  $query_getsmileyset->free();
	  
      $title = 'Posting New Topic';
      eval("\$include = \"".addslashes($TI[13])."\";"); 
      eval("\$output = \"".addslashes($TI[0])."\";"); 
      lose($output);
    
   }

   // ### Insert New Thread Into DB
   elseif ($post) {
      if ($poll == 1) {
	  
	        $SI['ref'] = 'Creating a Poll';
			$SI['templates'] = '124';
            define('SCRIPTID','post/newthread/poll');
            require 'base.php';

           if (NUKE) {   
              if(!isset($mainfile)) { include("mainfile.php"); }
              if (!eregi("modules.php", $PHP_SELF)) {
                 die ("You can't access this file directly...");
              }
           }
		   
	  $title = 'Poll Creation';
      eval("\$include = \"".addslashes($TI[124])."\";"); 
      eval("\$output = \"".addslashes($TI[0])."\";"); 
	  lose($output);
	  }
	  
      $SI['ref'] = 'Posting New Thread';
      define('SCRIPTID','post/newthread/insert');
      require 'base.php';

      if (NUKE) {   
         if(!isset($mainfile)) { include("mainfile.php"); }
         if (!eregi("modules.php", $PHP_SELF)) {
            die ("You can't access this file directly...");
         }
      }

	  
  
	  
      if (!$FID) { gen_error('No Forum specified!','Go back to the index page and try again.'); }
      if (!$message) { gen_error('No Message specified!','Go back and try again.');  }
      if (!$subject) { gen_error('No Subject specified!','Go back and try again.');  }

      if (!MEMBER && $username) {
         $query_member = new query($SQL, "SELECT password FROM ".$prefix."profiles WHERE username = '$username'");
         $query_member->getrow(); 
         if (strcasecmp($query_member->field('password'), md5($password))) { $query_member->free(); gen_error('Invalid user information.','<a href=member.php?action=login>Click here to login</a>.'); }
         $realuser = $username;
         $query_member->free();
      }
	  
	  if (isset($poll)) {
	      $query_getpoll = new query($SQL,"SELECT id FROM ".$prefix."polls ORDER BY id DESC LIMIT 1");
		  $query_getpoll->getrow();
		  $pollid = $query_getpoll->field('id') + 1; 
		  new query($SQL,"INSERT INTO polls VALUES ('".$pollid."', '".$option1."', '".$option2."', '".$option3."', '".$option4."', '".$option5."', '".$option6."', '".$option7."', '".$option8."', '".$option9."', '".$option10."', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '')");
	      $query_getpoll->free();
	   }
	  
	  if (!MEMBER && !$realuser) { $realuser = 'Guest'; }
      elseif (!$realuser) { $realuser = USERNAME; }
	  
	  if ($realuser == 'Guest') { $gquery = 1; $realuser = ''; } else { $gquery = 0; }
    
	  if (!$gquery) {
         $query_getgroup = new query($SQL, "SELECT usergroup, id FROM ".$prefix."profiles WHERE username = '".addslashes($realuser)."'");
         $query_getgroup->getrow();
         $usergroup = $query_getgroup->field('usergroup');	
	     $UID = $query_getgroup->field('id');	
	     $query_getgroup->free();
	  } else { 
	     $UID = 0; 
		 $usergroup = 0; 
      }

      check_perm('thread_canpost',1,$usergroup);
	  
	  $check_flood = new query($SQL, "SELECT flood FROM ".$prefix."usergroup WHERE id = '".$usergroup."'");
	  $check_flood->getrow();
	  if ($lastpost = $HTTP_COOKIE_VARS['lastpost']) { 
	     $left = (time() - $lastpost);
	     if ($left <= $check_flood->field('flood')) {
		    $left = $check_flood->field('flood') - $left;
		    gen_error('Flood limit is activated.','Sorry, but a flood limit is activated. You have to wait another '.$left.' seconds before you can post again.');
		 } 
	  }
	  $check_flood->free();
	  setcookie('lastpost',time(),$expire,$config->field('cookiepath')); 
  
      $query_seekid = new query($SQL, "SELECT id FROM ".$prefix."topics ORDER by id DESC LIMIT 1");
      $query_seekid->getrow();
      $TID = $query_seekid->field('id') + 1;
      $query_seekid->free();

      $query_seekid = new query($SQL, "SELECT id FROM ".$prefix."posts ORDER by id DESC LIMIT 1");
      $query_seekid->getrow();
      $PID = $query_seekid->field('id') + 1;
      $query_seekid->free();
	  
	  $query_getparent = new query($SQL, "SELECT parent FROM ".$prefix."forum_display WHERE forumid = $FID");
	  $query_getparent->getrow();
	  $parent = $query_getparent->field('parent');
	  $query_getparent->free();

      new query($SQL, "INSERT INTO ".$prefix."topics VALUES ($TID, $FID, '".strip_tags($subject)."', '".time()."', '".addslashes($realuser)."', '".time()."', '', '0', '0', '', '', '', '0', '".$UID."', '0','".$icon."','".$UID."', '".$gquery."','".$gquery."','".$pollid."','".strip_tags($description)."')");


      if ($parseurl == 'yes') { $parseurl = 1; } else {$parseurl = 0; }
      if ($disablesmilies == 'yes') { $dsmiley = 1; } else {$dsmiley = 0; }

      new query($SQL, "INSERT INTO ".$prefix."posts (dsmiley, parseurl, id, threadid, poster, message, title, dateline, isstarter, forumid, ip, guest) VALUES ('".$dsmiley."', '".$parseurl."', $PID, $TID, '".addslashes($realuser)."', '".htmlspecialchars($message)."', '".strip_tags($subject)."', '".time()."', 1, '".$FID."', '".USERIP."','".$gquery."')");
  
	  if (strlen($subject) > 25) { $threadtitle = substr($subject, 0, 22) . '...'; } else { $threadtitle = $subject; }
      new query($SQL, "UPDATE ".$prefix."forum_display SET postcount = (postcount + 1), threadcount = (threadcount + 1), lastposter = '".addslashes($realuser)."', lastpost = '".time()."', lastthread = '".strip_tags($threadtitle)."', lastthreadid = '".$TID."', lastposterid = '".$UID."', guest = '".$gquery."' WHERE forumid = $FID OR forumid = $parent");

			if (ADDOWNTOPICS && !AUTOSUBSCRIBE)	{
			   new query($SQL, "INSERT INTO ".$prefix."favorites VALUES('".addslashes(USERNAME)."','".$FID."','".$TID."','0','1')");
			} elseif (ADDOWNTOPICS && AUTOSUBSCRIBE)	{
				new query($SQL, "INSERT INTO ".$prefix."favorites VALUES('".addslashes(USERNAME)."','".$FID."','".$TID."','1','1')");
			}
			

      if (!$gquery) {
         new query($SQL, "UPDATE ".$prefix."profiles SET posts = (posts + 1) WHERE username = '".addslashes($realuser)."'");
      }

      new query($SQL, "UPDATE ".$prefix."configuration SET posts = (posts + 1), threads = (threads + 1)");

      gen_redirect('Your topic has been posted, redirecting you to it.','read.php?TID='.$TID); 
    } 
}

// ###############################
//         REPLY TO THREAD
// ###############################
if ($action == 'reply') {
   // ### 'Reply to Thread' Screen  
   if (!$post || $preview) {

      $SI['ref'] = 'Replying to Topic';
      $SI['templates'] = '11|55|45|86|94|84|85';
      $SI['settings'] = 'parseurl, dsmiley, boardurl';
      define('SCRIPTID','post/reply/screen');
      require 'base.php';
	  
	  $templategroup = TEMPLATEGROUP;
	  	 
      if (NUKE) {   
         if(!isset($mainfile)) { include("mainfile.php"); }
         if (!eregi("modules.php", $PHP_SELF)) {
            die ("You can't access this file directly...");
         }
      }
	  

	  if (!$TID) { gen_error('No Topic specified!','Go back and try again.'); }
	 
	  
	  $query_getinfo = new query($SQL, "SELECT locked, title, forumid FROM ".$prefix."topics WHERE id = '".$TID."'");
	  if (!$query_getinfo->getrow()) { gen_error('Invalid Topic!','Go back and try again.'); }
	  
	  define('LOCK',$query_getinfo->field('locked'));
	  define('TOPICTITLE',$query_getinfo->field('title'));
	  $FID = $query_getinfo->field('forumid');
	  
	  $query_getinfo->free();
	  
	  if (LOCK) { gen_error('Topic is locked.','Sorry, you cannot reply anymore.'); }
	  
      if ($config->field('parseurl')) { $parseurl = 'CHECKED'; }
      if ($config->field('dsmiley')) { $disablesmilies = 'CHECKED'; }
      if ($parseurl == 'yes' && $preview) { $parseurl = 'CHECKED'; } elseif ($preview) { $parseurl = ''; }
      if ($disablesmilies == 'yes' && $preview) { $disablesmilies = 'CHECKED'; } elseif ($preview) { $disablesmilies = ''; }

      include 'lib/codeparse.php';
      if ($preview) { 
         if ($parseurl == 'CHECKED') { $a = 1; } else { $a = 0; }
         if ($disablesmilies == 'CHECKED') { $b = 1; } else { $b = 0; }
         $temp = $message;
         $message = codeparse($message, $a, $b, USERNAME);
         eval("\$preview = \"".addslashes($TI[86])."\";");
		 $message = $temp;
      }
	 
      $nav = getnav('forum:'.$FID) . '> <a href="read.php?TID='.$TID.'">'.TOPICTITLE.'</a> > Reply';
 check_perm('thread_canreply',1,$usergroup);
      if (MEMBER) {
          $username = USERNAME;
          eval("\$include = \"".addslashes($TI[55])."\";"); 
       } else { 
          eval("\$include = \"".addslashes($TI[45])."\";"); 
       }
	   
	   
	   if ((!isset($PID) || $PID == '') && !$preview) {
          $quote = '';
       } else {
	      if (!$preview) {
             $query_getpostinfo = new query($SQL, "SELECT message, poster FROM ".$prefix."posts where id = '".$PID."'");
             $query_getpostinfo->getrow();
             $info = '[i]Orginally posted by '.$query_getpostinfo->field('poster').'[/i]

             ';
             $quote = '[quote]'.$info.$query_getpostinfo->field('message').'[/quote]';
		     $query_getpostinfo->free();
	       } else {
		   $quote = $message;		   
		   }
       }
	   
   
      if (SHOWHISTORY) {
         if ($reverse == 1) { $query = 'ASC'; } else { $query = 'DESC'; }
         $historycount = 0;
         $query_threads = new query($SQL, "SELECT parseurl, dsmiley, poster, message, title FROM ".$prefix."posts WHERE threadid = $TID ORDER BY id $query LIMIT 15");    
         while($query_threads->getrow()) {
            $historycount++;
            $poster = $query_threads->field('poster');
            $title = $query_threads->field('title');
            $message = codeparse($query_threads->field('message'), $query_threads->field('parseurl'), $query_threads->field('dsmiley'), $poster);
            eval("\$history .= \"".addslashes($TI[85])."\";"); 
         }
		 $query_threads->free();
         eval("\$history = \"".addslashes($TI[84])."\";"); 
      }

	  $query_getsmileyset = new query($SQL,'SELECT id, name FROM '.$prefix.'smileysets');
	  while ($query_getsmileyset->getrow()) {
	     $smileyset[id] = $query_getsmileyset->field('id');
		 $smileyset[name] = $query_getsmileyset->field('name');
		 eval("\$smilies .= \"".addslashes($TI[94])."\";"); 
	  }

	  $query_getsmileyset->free();
	   
       $title = 'Replying to Topic \''.TOPICTITLE.'\'';
       eval("\$include = \"".addslashes($TI[11])."\";"); 
       eval("\$output = \"".addslashes($TI[0])."\";"); 
       lose($output);
     
    }
	

   // ### Insert New Reply Into DB
   elseif ($post) {
  
      $SI['ref'] = 'Posting New Reply';
	  $SI['templates'] = '152';
      define('SCRIPTID','post/reply/insert');
      require 'base.php';

      if (NUKE) {   
         if(!isset($mainfile)) { include("mainfile.php"); }
         if (!eregi("modules.php", $PHP_SELF)) {
            die ("You can't access this file directly...");
         }
      }

      if (!$TID) { gen_error('No Forum specified!','Go back to the index page and try again.'); }
      if (!$message) { gen_error('No Message specified!','Go back and try again.');  }

      if (!MEMBER && $username) {
         $query_member = new query($SQL, "SELECT password FROM ".$prefix."profiles WHERE username = '$username'");
         $query_member->getrow(); 
         if (strcasecmp($query_member->field('password'), md5($password))) { $query_member->free(); gen_error('Invalid user information.','<a href=member.php?action=login>Click here to login</a>.'); }
         $realuser = $username;
         $query_member->free();
      }
	  
	  if (!MEMBER && !$realuser) { $realuser = 'Guest'; }
      if (MEMBER) { $realuser = USERNAME; }
	  
	  if ($realuser == 'Guest') { $gp = 1; $realuser = ''; } else { $gp = 0; }
   
	  $query_seekreply= new query($SQL, "SELECT replies, forumid, title, locked FROM ".$prefix."topics WHERE id = '".$TID."'");
      $query_seekreply->getrow();
      $newreplycount = $query_seekreply->field('replies') + 1;
	  if ($query_seekreply->field('locked') == '1') { gen_error('Topic is locked.','Sorry, you cannot reply anymore.'); }
	  $FID = $query_seekreply->field('forumid');
	  $topictitle = addslashes($query_seekreply->field('title'));
      $query_seekreply->free();
	  
	  $query_getparent = new query($SQL, "SELECT parent FROM ".$prefix."forum_display WHERE forumid = $FID");
	  $query_getparent->getrow();
	  $parent = $query_getparent->field('parent');
	  $query_getparent->free();
	  
	  
	  if (!$gp) {
        $query_getgroup = new query($SQL, "SELECT id, usergroup FROM ".$prefix."profiles WHERE username = '".addslashes($realuser)."'");
        $query_getgroup->getrow();
        $usergroup = $query_getgroup->field('usergroup');	
        $UID = $query_getgroup->field('id');	
	    $query_getgroup->free();
      } else { 
	     $UID = 0;
		 $usergroup = 0;
	  }

      check_perm('thread_canreply',1,$usergroup);
	  
	  $check_flood = new query($SQL, "SELECT flood FROM ".$prefix."usergroup WHERE id = '".$usergroup."'");
	  $check_flood->getrow();
	  if ($lastpost = $HTTP_COOKIE_VARS['lastpost']) { 
	     $left = (time() - $lastpost);
	     if ($left <= $check_flood->field('flood')) {
		    $left = $check_flood->field('flood') - $left;
		    gen_error('Flood limit is activated.','Sorry, but a flood limit is activated. You have to wait another '.$left.' seconds before you can post again.');
		 } 
	  }
	  $check_flood->free();
	  setcookie('lastpost',time(),$expire,$config->field('cookiepath')); 
	  
      $query_seekid = new query($SQL, "SELECT id FROM ".$prefix."posts ORDER by id DESC LIMIT 1");
      $query_seekid->getrow();
      $PID = $query_seekid->field('id') + 1;
      $query_seekid->free();
	  

      if ($parseurl == 'yes') { $parseurl = 1; }
      if ($disablesmilies == 'yes') { $dsmiley = 1; } else { $dsmiley = 0; }

      new query($SQL, "INSERT INTO ".$prefix."posts (dsmiley, parseurl, id, threadid, poster, message, title, dateline, isstarter, forumid, ip, guest) VALUES ('".$dsmiley."', '".$parseurl."', $PID, $TID, '".addslashes($realuser)."', '".htmlspecialchars($message)."', '".strip_tags($subject)."', '".time()."', 0, '".$FID."', '".USERIP."', '".$gp."')");
      new query($SQL, "UPDATE ".$prefix."topics SET replies = '".$newreplycount."', lastposterid= '".$UID."', lpuser = '".addslashes($realuser)."', lpdate = '".time()."', lastguest = '".$gp."' WHERE  id = '".$TID."'");



  
	  if (strlen($topictitle) > 25) { $threadtitle = substr($topictitle, 0, 22) . '...'; } else { $threadtitle = $topictitle; }
      new query($SQL, "UPDATE ".$prefix."forum_display SET postcount = (postcount + 1),  lastposter = '".addslashes($realuser)."', lastpost = '".time()."', lastthread = '".strip_tags($threadtitle)."', lastthreadid = '".$TID."', lastposterid = '".$UID."', guest = '".$gp."' WHERE forumid = '".$FID."' OR forumid = '".$parent."'");
      if (!$gp) {
         new query($SQL, "UPDATE ".$prefix."profiles SET posts = (posts + 1) WHERE username = '".addslashes($realuser)."'");
      }

      $query_seekcount = new query($SQL, "SELECT posts FROM ".$prefix."configuration");
      $query_seekcount->getrow();
      $postcount = $query_seekcount->field('posts') + 1;
      new query($SQL, "UPDATE ".$prefix."configuration SET posts = $postcount");
      $query_seekcount->free();
	  
	  $query_notify = new query($SQL, "SELECT profiles.email, profiles.username AS username from ".$prefix."favorites, ".$prefix."profiles where profiles.username = favorites.username and favorites.threadid = '$TID' and favorites.visit = '1' and favorites.email = '1' AND profiles.username != '".addslashes(USERNAME)."'");
	  $query_getadminmail = new query($SQL, "SELECT email FROM ".$prefix."profiles WHERE id = 1 LIMIT 1");
    $query_getadminmail->getrow(); 
    $admin = $query_getadminmail->field('email');
	  $title = $topictitle;
		$url_of_board = $config->field('boardurl'); 
	  $url = $url_of_board.'/read.php?TID='.$TID.'&action=lastpost';
	  $poster = $realuser;
	  $unsubscribe_url = $url_of_board.'/myhome.php?action=unsubscribe&TID='.$TID;
	  eval("\$subscribe_mail = \"".addslashes($TI[152])."\";"); 
	  while ($query_notify->fetch()) {
		  $username = $query_notify->field('username');
	      $email = $query_notify->field('email');
		  mail($email, "Reply to topic '$topictitle'", $subscribe_mail, "From: $admin");
	  }
      new query($SQL, "UPDATE ".$prefix."favorites SET visit = '0' WHERE threadid = '$TID'");
      gen_redirect('Your reply has been posted, redirecting you to it.','read.php?TID='.$TID.'&page='.$page.'#'.$PID); 
    }
}

// ###############################
//         DISPLAY SMILIES
// ###############################
if ($action == 'smilies') { 
   include 'lib/sqldata.php';                                                        
   include 'lib/database/'.$database_server['type'].'.php';
   $SQL = new db;
   $result = $SQL->open($database_server['database'], $database_server['hostname'], $database_server['username'], $database_server['password']);

   $query_gettemplate = new query($SQL, "SELECT template, id FROM ".$prefix."templates WHERE id = 93 OR id = 92 AND groupid = '".$templategroup."'");
   while ($query_gettemplate->getrow()) {
    $template[$query_gettemplate->field('id')] =  $query_gettemplate->field('template');
   }   
   $query_gettemplate->free();
   
   $set = $HTTP_GET_VARS['set'];

   if ($set == 'all') {
       $query_getsmilies = new query($SQL, "SELECT smiley, image FROM ".$prefix."smilies");
   } else {
      $query_getsmilies = new query($SQL, "SELECT smiley, image FROM ".$prefix."smilies WHERE groupid = $set LIMIT 12");
   }
   
   while ($query_getsmilies->getrow()) {
      $smiley[code] = $query_getsmilies->field('smiley');
	  $smiley[image] = $query_getsmilies->field('image');
	  eval("\$include .= \"".addslashes($template[93])."\";");
   }
   $include = stripslashes($include);
   eval("\$output = \"".addslashes($template[92])."\";");
   $output = stripslashes($output);
   print stripslashes($output); flush;
}

// ###############################
//         SEND TO FRIEND
// ###############################
if ($action == 'mail') { 

   if ($send == '1') {
   
      $SI['ref'] = 'Sending a topic';
      define('SCRIPTID','post/mail/insert');
      require 'base.php';
	  
	 check_perm('thead_canmail',1);
			
      $query_getadminmail = new query($SQL, 'SELECT email FROM ".$prefix."profiles WHERE id = 1 LIMIT 1');
      $query_getadminmail->getrow(); 
      $admin = $query_getadminmail->field('email');

      $email = $sendtoemail;
      $name = $sendtoname;
      $from = $sender;
      $mailheaders = "From: $admin\n";
      $subject = $emailsubject;
      $message = $emailmessage;
      mail($email, $subject, $message, $mailheaders);
      gen_redirect('Your friend has been notified.',"read.php?TID=$TID");
	  
   } else {
   
         $SI['ref'] = 'Sending a topic';
         $SI['templates'] = '43|44';
         define('SCRIPTID','post/mail/screen');
         require 'base.php';
		 
	     check_perm('thead_canmail',1);
	  
         $threadurl = $config->field('boardurl').'/read'.$php.'?TID='.$TID;
         $sender = USERNAME;
		 $username = USERNAME;
	     eval("\$msg = \"".addslashes($TI[44])."\";");

         $title = 'Send to Friend';
         eval("\$include = \"".addslashes($TI[43])."\";"); 
         eval("\$output = \"".addslashes($TI[0])."\";");
         lose($output);
  }
}


// ###############################
//         EDIT POST
// ###############################
if ($action == 'edit') { 

   if ($send != '1') {
   
      $SI['ref'] = 'Editing a post';
	  $SI['templates'] = '24|94';
      define('SCRIPTID','post/edit/display');
      require 'base.php';
	  
	  if (!isset($PID) || $PID == '') {
        gen_error('No Post specified!','Go back and try again.');
      } 
   
      $query_getinfo = new query($SQL, "SELECT topics.description as description, posts.dsmiley as dsmiley, posts.parseurl as parseurl, posts.message as message, posts.threadid as topicid, posts.forumid as forumid, posts.title as title, posts.poster as poster, topics.title as topic FROM ".$prefix."posts, ".$prefix."topics WHERE posts.threadid = topics.id AND posts.id = $PID");
	  $query_getinfo->getrow();
	  
      $subject = $query_getinfo->field('title');
	  $description= $query_getinfo->field('description');
      $message = $query_getinfo->field('message');  
	  $FID = $query_getinfo->field('forumid');
	  $TID = $query_getinfo->field('topicid');

	  if ($query_getinfo->field('parseurl') == '1') { $parseurl = 'checked'; }
	  if ($query_getinfo->field('dsmiley') == '1') { $disablesmilies = 'checked'; } 
	  
	  if ($query_getinfo->field('poster') == USERNAME && USERNAME != 'Guest') {
	     $canedit = 1;
	  } else {
	  
	     $query_mods = new query($SQL, "SELECT moderators FROM ".$prefix."forum_display WHERE forumid = '".$FID."'");
         $query_mods->getrow();

         $mods = explode(',', str_replace(' ', '', trim($query_mods->field('moderators'))));
         if (in_array(USERNAME,$mods) && USERNAME != '') { define('MODERATOR',1); $ismod = 1; }
	     if (!$ismod) { 
            if (get_forumperm('ismoderator',$FID)) { define('MODERATOR',1); } else { define('MODERATOR',0); }
         } 
	  }
	  if (MODERATOR || ADMIN) { $canedit = 1; }
	  if (!$canedit) { gen_error('No Access!','You cannot edit this post.'); }
	
      $nav = getnav('forum:'.$FID) . '> <a href="read.php?TID='.$TID.'">'.$query_getinfo->field('topic').'</a> > Edit Post';  
	  $query_getinfo->free();
	  
      $query_getsmileyset = new query($SQL,'SELECT id, name FROM '.$prefix.'smileysets');
      while ($query_getsmileyset->getrow()) {
         $smileyset[id] = $query_getsmileyset->field('id');
	     $smileyset[name] = $query_getsmileyset->field('name');
         eval("\$smilies .= \"".addslashes($TI[94])."\";"); 
      }
      $query_getsmileyset->free();
   
	  $title = 'Edit Post';
      eval("\$include = \"".addslashes($TI[24])."\";"); 
      eval("\$output = \"".addslashes($TI[0])."\";");
      lose($output);
	  
   } else {
      $SI['ref'] = 'Editing a post';
	  $SI['templates'] = '24';
      define('SCRIPTID','post/edit/display');
      require 'base.php';
	  
	  if (!isset($PID) || $PID == '') {
        gen_error('No Post specified!','Go back and try again.');
      } 
   
      if ($delete == 'yes') { include 'lib/delete.php'; $FID = deletepost($PID); }
	  else {
	     if ($message == '') { gen_error('No message specified!',''); }
	    $query_getinfo = new query($SQL, "SELECT posts.isstarter as istopic, posts.threadid as topicid, posts.title as posttitle, topics.title as topictitle, posts.forumid as forumid FROM ".$prefix."posts, ".$prefix."topics WHERE posts.threadid = topics.id AND posts.id = $PID");
	    $query_getinfo->getrow();
		
		$TID = $query_getinfo->field('topicid');
		$FID = $query_getinfo->field('forumid');
		
		if ($query_getinfo->field('istopic') && $subject == '') { gen_error('No Subject specified!',''); }
		
		// If Topic, then (possible) update title too!
		if ($query_getinfo->field('istopic') == '1') { 
		   new query($SQL, "UPDATE ".$prefix."topics SET lpdate = '".time()."', title = '".strip_tags($subject)."', description = '".strip_tags($description)."' WHERE id = '".$TID."'"); 
			new query($SQL, "UPDATE ".$prefix."forum_display SET lastthread = '".strip_tags($subject)."' WHERE forumid = $FID");
		}
		
		// Now Update the Post

      if ($parseurl == 'yes') { $parseurl = 1; } else {$parseurl = 0; }
      if ($disablesmilies == 'yes') { $dsmiley = 1; } else {$dsmiley = 0; }
		new query($SQL, "UPDATE ".$prefix."posts SET lastupdate = '".time()."', lastupdateby = '".addslashes(USERNAME)."', title = '".strip_tags($subject)."', dsmiley = '".$dsmiley."', parseurl = '".$parseurl."', message= '".htmlspecialchars($message)."' WHERE id = $PID");
		
		// Check if the post/topic is lastpost
		$query_getlast = new query($SQL, "SELECT lastthread FROM ".$prefix."forum_display WHERE forumid = ".$FID);
		$query_getlast->getrow();
		

		
		$query_getlast->free();
		$query_getinfo->free();
		
		
	 }
	
    if ($delete) {
	   gen_redirect('Your topic has been removed!','board.php?FID='.$FID);
	} else {
	   gen_redirect('Your post has been updated!','read.php?TID='.$TID.'&page='.$page.'#'.$PID);
	}
	    
  }
}




// ###############################
//         VOTE TO A POLL
// ###############################
if ($action == 'vote') { 
  
      $SI['ref'] = 'Voting on a poll';
	  $SI['templates'] = '24|94';
      define('SCRIPTID','post/vote/insert');
      require 'base.php';
	  
	  if (NUKE) {   
  if(!isset($mainfile)) { include("mainfile.php"); }
   if (!eregi("modules.php", $PHP_SELF)) {
     die ("You can't access this file directly...");
  }
}


	  if (!isset($poll) || $poll == '') {
        gen_error('No Poll specified!','Go back and try again.');
      } 
	  
	  
	  
	  check_perm('poll_canvote',1);
	  if (!MEMBER) { gen_error('Only members can vote!','Click <a href="member.php?action=register">Here</a> to register yourself.'); }
	   
	  
	   
	  $query_poll = new query($SQL, "SELECT total FROM polls WHERE id = '".$poll."'");
	  if (!$query_poll->getrow()) { gen_error('The selected poll does not exist.','Go back and try again please'); }
	  
	  $array = explode(',',$query_poll->field('total'));
	  if (in_array(USERNAME,$array)) { gen_error('You already voted on this poll.','You can only vote once on every poll'); }

	  if ($query_poll->field('total') != '') {
	     $total = $query_poll->field('total').','.addslashes(USERNAME);
	  } else {
	     $total = addslashes(USERNAME);
	  }
	  
	  new query($SQL,"UPDATE polls SET total = '".$total."', answer".$choice." =  (answer".$choice." + 1) WHERE id = '".$poll."'");
      gen_redirect('Your vote has been noted, thank you.','read.php?TID='.$TID);
}
?>