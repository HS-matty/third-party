<?php
/*
 *
 *  OpenBB, Copyright (c)2001 Iansoft
 *  Internal Release Beta 5.0.0
 *  http://www.iansoft.net/
 *
 */
$email = 'selected';
if (!isset($do) || $do == '') {  
   $SI['templates'] = '128|50';
   $SI['ref'] = 'Forum CP';
   define('SCRIPTID','cp');
   require 'base.php';
   check_perm('isadmin',0);
    $query = new query($SQL, "SELECT id, title FROM usergroup WHERE id != 0");   
   while ($result = $query->getrow()) {
   $usergroups .= '<option value="'.$query->field('id').'">'.$query->field('title').'</option>';
   }
   eval("\$include = \"".addslashes($TI[128])."\";"); 
   eval("\$output = \"".addslashes($TI[50])."\";");
   print stripslashes($output); flush;
   exit();
   
}  elseif ($do == 'mail') {
   $SI['templates'] = '127|50|145';
   $SI['ref'] = 'Forum CP';
   define('SCRIPTID','cp');
   require 'base.php';
   check_perm('isadmin',0);
   $where = '';
   function add_to_where ($val) {
   global $where;
   if ($where) { $where .= ' AND '.$val; } else {
   $where = $val;
   }
   }
   
   if ($usergroup != '') { add_to_where('usergroup = \''.$usergroup.'\''); }
   if ($postless) { add_to_where('posts < '.$postless); }
   if ($postmore) { add_to_where('posts > '.$postmore); }
   if ($ls == 'longer' && $days) { $total = $days * 86400; add_to_where('('.time().' - joindate) > '.$total); }
   if ($ls == 'shorter' && $days) { $total = $days * 86400; add_to_where('('.time().' - joindate) < '.$total); }  
   
   if ($where) { $where = 'WHERE '.$where;}
   $query_getusers = new query($SQL, "SELECT email FROM profiles $where");   
   while ($result_getusers = $query_getusers->getrow()) {
   $list .= $result_getusers->field('email').',';
   }
   $list = substr($list,0,(strlen($list) - 1));
   
   if ($mailtype == 'mailform') {
      eval("\$include = \"".addslashes($TI[127])."\";"); 
   } else {
      eval("\$include = \"".addslashes($TI[145])."\";"); 
   }
   eval("\$output = \"".addslashes($TI[50])."\";");
   print stripslashes($output); flush;
   exit();

}
?>