<?php
/*
 *
 *  openbb, copyright (c)2001 iansoft
 *  public release beta 1.0.0
 *  http://www.iansoft.net/
 *
 */
$users = 'selected';

if ($do == '') {
   $SI['templates'] = '50|52';
   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
   eval("\$include = \"".addslashes($TI[52])."\";"); 
   eval("\$output = \"".addslashes($TI[50])."\";");
   print stripslashes($output); flush;
   exit();  
} elseif ($do == 'edit') {
   $SI['templates'] = '50|51';
   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
	 $query = "SELECT id, username, password, email, homepage, note, icq, aim, yahoo, location, note, showemail, usergroup, posts, joindate, timeoffset, timezone, avatar, custom, homepagedesc, occupation, msn, templategroup, vargroup, totalpm, lastpm, invisible, activated, banned, sig, showavatar, showsig, showhistory FROM profiles WHERE username = '$username'";
	 $query_users = new query($SQL, $query) or $SQL->error();
	 $user = $query_users->getrow();
	 if ($user['username'] == '') {
  		 $include = '<font size="2" face="verdana"><b><center>That user does not exist!</center></b></font>';
  		 eval("\$output = \"".addslashes($TI[50])."\";");
  		 print stripslashes($output); flush;
  		 exit();
	 }
	 
	 ($user['banned'] == "0") ? ($notbanned = "CHECKED") : ($banned = "CHECKED");
	/* ($user[invisible] == "0") ? ($vis = "CHECKED") : ($invis = "CHECKED");
	 ($user[showemail] == "0") ? ($hidemail = "CHECKED") : ($donthidemail = "CHECKED");
	 ($user[showavatar] == "0") ? ($dontavatar = "CHECKED") : ($showavatar = "CHECKED");
	 ($user[showsig] == "0") ? ($dontshowsignature = "CHECKED") : ($showsignature = "CHECKED");
	 ($user[showhistory] == "0") ? ($dontshowhistory = "CHECKED") : ($showhistory = "CHECKED");
	 ($user[addowntopics] == "0") ? ($dontaddowntopics = "CHECKED") : ($addowntopics = "CHECKED");
	 ($user[autosubscribe] == "0") ? ($dontautosubscribe = "CHECKED") : ($autosubscribe = "CHECKED"); */
	 $query = new query($SQL, "SELECT id, title FROM usergroup WHERE id != 0");   
	    while ($result = $query->getrow()) {
		 if ($user['usergroup'] == $result['id']) { 
   $usergroups .= '<option value="'.$query->field('id').'" selected>'.$query->field('title').'</option>';
	} else {
	$usergroups .= '<option value="'.$query->field('id').'">'.$query->field('title').'</option>';
	}
   }
   eval("\$include = \"".addslashes($TI[51])."\";"); 
   eval("\$output = \"".addslashes($TI[50])."\";");
   print stripslashes($output); flush;
   exit();  
  } elseif ($do == 'do_edit') {
   $SI['ref'] = 'Forum Control Panel';
   define('SCRIPTID','cp');
   require 'base.php';
	check_perm('isadmin',0);
	new query($SQL, "UPDATE profiles SET usergroup = '".$usergroup."', banned = '".$banned."', homepage = '".$homepage."', email = '".$email."', icq = '".$icq."', aim = '".$aim."', yahoo = '".$yahoo."', msn = '".$wm."', occupation = '".$occupation."', note = '".$personal."', location = '".$location."', homepage = '".$homepage."', homepagedesc = '".$homepagedesc."' WHERE username = '".$username."'");
	@header("Location: cp_users.php");
  }
?>