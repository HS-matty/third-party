Open Bulletin Board
Release Candidate 2 (pre9 10Nov2k1 4:10 PM GMT+11)
-------------------

INSTALL and UPGRADE
-------------------

To new install or upgrade from beta1 or RC1, just upload the new files, overwriting the old ones and run setup.php (or any page in fact), then follow the instructions there!

NEW STUFF IN RC2
----------------

too many to list, but just to name a few:
- templates changed and lots of fixes and new stuff in design manager
- forum order
- more stable setup and upgrade
- extensive search functions
- lost password feature
- tons of bug fixes

see docs/log.txt for more


CREDITS
-------

Thanks to the iansoft/obb team and the RC2 bug reporters for making this release possible and the openbb community for their patience and continuous support for OpenBB!


-splash (obb1 lead)
10 NOV 2001