<?php

?>

<html><head><title>OpenBB RC2 setup</title>
	<style><!--
		body,td,p {font-family: Verdana, Arial, helvetica; font-size: 10pt }
		textarea {font-size: 10pt; font-family: Verdana, Arial, helvetica; }
		input.button {font-size: 10pt; font-family: Verdana, Arial, helvetica; border-style: outset; border-width: 1; background-color: #324C69; color: #FFFFFF }
		option.headopt { background-color: #CCFFFF }
	--></style>
	</head><body bgcolor="#F5F5F5">

<center>

<table border="0" cellpadding="0" cellspacing="0" width="98%" style="border-collapse: collapse; border-left: 1px solid #000000; border-right-style: solid; border-right-width: 1; border-top-style: solid; border-top-width: 1; border-bottom-style: solid; border-bottom-width: 1" bordercolor="#111111">

  <tr>

    <td width="100%" bgcolor="#FFFFFF" align=left>

    <img border="0" src="setup/obb1rc2setup.gif" width="397" height="85"><table border="0" cellpadding="6" cellspacing="0" width="100%">

      <tr>

        <td width="100%">

        <p>&nbsp;<br><!--



<?php

print '--'.'>';

if (1 != 1) {

	print ' --><b>Sorry, PHP does not appear to be installed or enabled. OpenBB requires a server that has both <a href="http://www.php.net/">PHP</a> and a <a href="http://www.mysql.com/">mySQL</a> or PostgreSQL database installed.</b><!-- ';

}




///////////////////////////////////////



define('OBB_VER', '1.0RC2');

define('PHPEXT', '.php');

$SETUPSCRIPT = 1;

$src = array(

	'pakdbstruct' => 'setup/dbstruct.ob',

	'paktmpl' => 'setup/tmplset.ob',

	'paktmpla' => 'setup/tmplset_admin.ob',

	'pakforums' => 'setup/forums.ob',

	'paksmilies' => 'setup/smilies.ob',

	'pakusergroups' => 'setup/usergroups.ob',

	'paktitles' => 'setup/titles.ob'

);



include 'setup/setupfuncs.php';



if (file_exists('lib/sqldata.php') && $step != 'sql') {

	include 'lib/sqldata.php';

	if (file_exists('lib/database/'.$database_server['type'].'.php'))

		include 'lib/database/'.$database_server['type'].'.php';

}



// setup protection


if ($database_server['setup_obb_version'] == OBB_VER && $database_server['setup_reopenpass'] != md5($unlockpass) && isset($database_server['setup_reopenpass'])) {

	if ($unlockpass != '' && md5($unlockpass) != $database_server['setup_reopenpass']) {
		print "<b>Sorry, wrong pass. Please try again</b><br>";
	}
	?><b>Setup locked</b><p>OBB Setup has detected that you had ran this setup before.<br>
	In order to protect this script from unauthorized access, please enter the unlock password you typed when you last installed.
	<form method="post" action="<?php print $PHP_SELF; ?>">
        <table border="0" cellpadding="1" cellspacing="2"width="100%">

          <tr>

            <td width="39%">Unlock password</td>

            <td width="61%"><input type="text" name="unlockpass" size="20" value="<?php print $unlockpass; ?>"></td>

          </tr>
          <tr>

            <td width="61%"><input type="submit" class=button value="Check"></td>

          </tr>
        </table>
    </form>	
	<b>if you cannot remember, delete lib/sqldata.php and this lock will disappear.</b>
	<?php exit;
}

switch($step) {
case 'install':

?><b>New Installation</b></p>
	<p>New install will delete these tables if they exists:

	<p><?php $tables = dbstruct_get_tables($src[pakdbstruct]); 

	for ($i=0; $i<count($tables); $i++)

		print $tables[$i].'<br>';

	?>

	<p>If you have any tables of the same name you want to keep please backup/rename them.

	<p><form method="post" action="<?php print $PHP_SELF; ?>?step=dodbstruct&inew=1">

		<input type="hidden" name="unlockpass" value="<?php print $unlockpass; ?>">

        <input class=button type="submit" value="Next">
        </form>

<?php

break;
case 'upgrade':

?><b>Upgrade</b></p>
	<p>This option upgrades your current OBB and makes it into oBB 1 RC2

	<p>Upgrade notes:

	<ul><li>You can only upgrade if you have beta1 or RC1

	<li>Running this when you have RC2 installed already will cause problems.

	<li>You will <b>not</b> be able to save your admin templates, this step will delete and renew them.

	<li>In case of problems, please backup your current DB.

	<li>This step <b>will not delete</b> any users, posts, topics, polls, etc except admin templates and some obsolete templates.

	</ul>

	<p><form method="post" action="<?php print $PHP_SELF; ?>?step=dodbstruct">

		<input type="hidden" name="unlockpass" value="<?php print $unlockpass; ?>">

        <input class=button type="submit" value="Next">
        </form>

<?php

break;
case 'custom':

?><b>Please choose an option below:</b></p>
	<p><form method="post" action="<?php print $PHP_SELF; ?>?step=install">

		<input type="hidden" name="unlockpass" value="<?php print $unlockpass; ?>">

        <input class=button type="submit" value="New Install">
        <br>

	Choose this option if you're using oBB for the first time, or if you want to start over.

	Note that this option will delete all existing oBB tables.

	</form>

	<p><form method="post" action="<?php print $PHP_SELF; ?>?step=upgrade">

	<input type="hidden" name="unlockpass" value="<?php print $unlockpass; ?>">

	<input class=button type="submit" value="Upgrade"><br>

	Choose this option if you currently have oBB 1.0 beta or RC1.

	This option will upgrade all existing oBB tables and do necessary changes for RC2.

	</form>

<?php

break;
case 'userdatasetup':
	db_connect();

	if (empty($cname) || empty($curl) || empty($ccpath) || empty($auser) || empty($apass) || empty($aemail)) {
		print "Please fill in all fields";
		exit;
	}
	
	query("INSERT INTO configuration (boardname, cookiepath, boardurl, regmembers, posts, threads, newestmember, mlistperpage, time1, time2, time3, maxmemdate, maxmembers, comnews, redirect, usegzip, gzlevel, regtype, sendpm, pmauthor, regpm, vmail, pmail, templategroup, vargroup, showsig, showavatar, showhistory, parseurl, dsmiley, lastadd, locked, newestmemberid, modimg, lockedreason, redirtype, avsize, avw, avh, totalviews, defaulttimezone, defaulttimeoffset, tlistperpage, plistperpage) 
	VALUES ('".addslashes($cname)."','".$ccpath."','".$curl."', '1', '0', '0', '".addslashes($auser)."', '25', 'F j Y, H:i', 'H:i', 'd-m-y H:i:s', 0, 0, 'We are now running OpenBB RC2', 1,'0',1,'2','0','".addslashes($auser)."', 'Welcome to my board!','Hello, to continue the registration process visit: $url','Hello, your password is $pass You can now login!',0,0,'1','1','1','1','0','0','0','1','stars4.gif','','0','5000','75','75','0','0','0', '20', '10')");
	
	query("INSERT INTO smileysets VALUES ('1','Default Smilies')");

	query("INSERT INTO avatar VALUES (0, 'none', 'blank.gif', '')");
	
	query("INSERT INTO cache VALUES ('forums','<option value=\"\"></option><option value=\"1\" \$fs[1]>Category</option><option value=\"2\" \$fs[2]>-- General Chat</option>','')");

	query("INSERT INTO navigations VALUES ( 'profile', '<a href=\"index.php\">".$cname."</a> > Profiles')");
	query("INSERT INTO navigations VALUES ( 'memberlist', '<a href=\"index.php\">".$cname."</a> > Memberlist')");
	query("INSERT INTO navigations VALUES ( 'online', '<a href=\"index.php\">".$cname."</a> > Who is online?')");
	query("INSERT INTO navigations VALUES ( 'usercp', '<a href=\"index.php\">".$cname."</a> > My Home')");

	$fp3=fopen($src[pakforums],'r');
	$rawforums=fread($fp3,filesize($src[pakforums]));
	fclose($fp3);
	$forums = explode("@18�@", $rawforums);
	$id = 0;
	while (list($key,$val) = each($forums)) {
		$prop = explode("@17�@", $val);
		$id++;
		query("INSERT INTO forum_display VALUES ( '".$id."', '".$prop[0]."', '".$prop[1]."', '".$prop[2]."', '".$prop[3]."', '".$prop[4]."', '".$prop[5]."', '".$prop[6]."', '".$prop[7]."', '".$prop[8]."', '".$prop[9]."', '".$prop[10]."', '".$prop[11]."', '".$prop[12]."','0',$id)");
		query("INSERT INTO navigations VALUES ( 'forum:".$id."', '<a href=\"index.php\">".$cname."</a> > ".$prop[14]."')");
	}

	query("INSERT INTO profiles VALUES ( '1', '".$auser."', '".md5($apass)."', '".$amail."', '".$curl."', '', '', '', '', '', '0', '3', '', '".time()."', '0', '0', 'blank.gif', 'Admin', 'An OpenBB Powered Site', 'Webmaster', '', '0', '0', '0', '0', '0', '1','0','','1','1','1','1','1')");
	query("INSERT INTO profiles VALUES ( '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','','','','','','','','')");

	$fp5=fopen($src['paksmilies'],'r');
	$rawsmilies=fread($fp5,filesize($src['paksmilies']));
	fclose($fp5);
	$smilies = explode("@18�@", $rawsmilies);
	$id = 0;
	while (list($key,$val) = each($smilies)) {
		$prop = explode("@17�@", $val);
		$id++;
		query("INSERT INTO smilies VALUES ( '".$id."', '".$prop[0]."', '".$prop[1]."', '1')");
	}

	$fp7=fopen($src['pakusergroups'],'r');
	$rawgroups=fread($fp7,filesize($src['pakusergroups']));
	fclose($fp7);
	$groups = explode("@18�@", $rawgroups);
	$id = 0;
	while (list($key,$val) = each($groups)) {
		$prop = explode("@17�@", $val);
		$id++;
		query("INSERT INTO usergroup VALUES ( '".($id - 1)."', '".$prop[0]."', '".$prop[1]."', '".$prop[2]."', '".$prop[3]."', '".$prop[4]."', '".$prop[5]."', '".$prop[6]."', '".$prop[7]."', '".$prop[8]."', '".$prop[9]."', '".$prop[10]."', '".$prop[11]."', '".$prop[12]."', '".$prop[13]."', '".$prop[14]."', '".$prop[15]."', '".$prop[16]."', '".$prop[17]."', '".$prop[18]."', '".$prop[19]."', '".$prop[20]."', '".$prop[21]."', '".$prop[22]."', '".$prop[23]."', '".$prop[24]."', '".$prop[25]."', '".$prop[26]."', '".$prop[27]."', '".$prop[28]."', '".$prop[29]."', '".$prop[30]."', '".$prop[31]."', '".$prop[32]."', '".$prop[33]."', '".$prop[34]."', '".$prop[35]."', '".$prop[36]."', '".$prop[37]."', '".$prop[38]."', '".$prop[39]."', '".$prop[40]."')");
	}

	$fp8=fopen($src['paktitles'],'r');
	$rawtitles=fread($fp8,filesize($src['paktitles']));
	fclose($fp8);
	$titles = explode("@18�@", $rawtitles);
	$id = '-1';
	while (list($key,$val) = each($titles)) {
		$prop = explode("@17�@", $val);
		$id++;
		query("INSERT INTO usertitles VALUES ('".$id."','".$prop[0]."', '".$prop[1]."', '".$prop[2]."', '".$prop[3]."', '".$prop[4]."')");
	}

	query("INSERT INTO topicicons VALUES ('0','icon0.gif')");
	
	tmpl_setup($src[paktmpl], 'Standard OpenBB', 0, 0);
	tmpl_setup($src[paktmpla], '', 127);

	print '<b>The forum data has been entered...</b>';
	print "<form method=\"post\" action=\"$PHP_SELF?step=finish\">

		<input type=\"hidden\" name=\"unlockpass\" value=\"$unlockpass\">

        <input class=button type=\"submit\" value=\"Next\">
        </form>";

break;
case 'userdata':

?><b>Please complete the following fields:</b></p>

<form method="post" action="<?php print $PHP_SELF; ?>?step=userdatasetup">

<table border="0" cellpadding="1" cellspacing="2"width="100%">

          <tr>

            <td width="39%"><font face="Verdana"><b>Community Name:<br>

            </b><font size="1">The name of your community</font></font></td>

            <td width="61%"><input type="text" name="cname" size="20"></td>

          </tr>

          <tr>

            <td width="39%"><font face="Verdana"><b>URL to Community:<br>

            </b><font size="1">This the URL to your board, starting with http://</font></font></td>

            <td width="61%"><input type="text" name="curl" size="20" value="http://"></td>

          </tr>

          <tr>

            <td width="39%"><font face="Verdana"><b>Cookiepath:<br>

            </b><font size="1">If you don't know, just leave it as it is.</font></font></td>

            <td width="61%"><input type="text" name="ccpath" size="20" value="/"></td>

          </tr>

          <tr>

            <td width="100%" style="font-family: Verdana, Tahoma, Arial, Helvetica; font-size: 9pt" colspan="2">&nbsp; </td>

            </tr>

          <tr>

            <td width="100%" colspan="2"><font face="Verdana"><b>Setup admin<br>

            </b><font size="1">Enter details for the new forum administrator</font></font></td>

            </tr>

          <tr>

            <td width="39%"><b>Username:</b></td>

            <td width="61%"><input name="auser" size="20"></td>

          </tr>

          <tr>

            <td width="39%"><b>Password:</b></td>

            <td width="61%"><input type="text" name="apass" size="20"></td>

          </tr>

          <tr>

            <td width="39%"><b>Email:</b></td>

            <td width="61%"><input type="text" name="aemail" size="20"></td>

          </tr>

          <tr>

            <td width="39%">&nbsp;</td>

            <td width="61%"><input type="hidden" name="unlockpass" value="<?php print $unlockpass?>">

        <input class=button type="submit" value="Next"></td>

          </tr>

        </table>

        </td>

      </tr>

    </table>
    
        </form><?php
	
	
break;
case 'finish';

// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// Begin Cache Routines ( Hmmmmmm, Needs Quite A Bit Of Work )

/* require 'base.php';
function write_cache () {
  global $SQL, $config;
  $defheader = '<a href="index.php">'.$config->field('boardname').'</a> > ';
  $header = $defheader;
  $query_forums = new query($SQL, "SELECT title, forumid, type, parent FROM ".$prefix."forum_display ORDER BY displayorder");
  // $output .= '<select name="FID" onchange="window.location=(\'board.php?FID=\'+this.options[this.selectedIndex].value)">';
  $subcat = '-2';
  while ($query_forums->getrow()) {
     $type = $query_forums->field('type');
     if ($type == '1') { 
	    $header = $defheader;
        $output .= '<option value=""></option><option value="'.$query_forums->field('forumid').'" $fs['.$query_forums->field('forumid').']>'.
        $query_forums->field('title').'</option>'; 
        $subcat = '0';
        $th = $header . '<a href="index.php?CID='.$query_forums->field('forumid').'">'.$query_forums->field('title').'</a>';
        new query($SQL, "UPDATE ".$prefix."navigations SET output = '".addslashes($th)."' WHERE id = 'forum:".$query_forums->field('forumid')."'");
        $header .= '<a href="index.php?CID='.$query_forums->field('forumid').'">'.$query_forums->field('title').'</a> > ';
     } elseif ($type == "2") { $stripes = ''; $s = $subcat + 2; while ($s != 0) { 
        $stripes .= '-'; $s--; 
     } 
     $th = $header . '<a href="index.php?CID='.$query_forums->field('forumid').'">'.$query_forums->field('title').'</a>';
     new query($SQL, "UPDATE ".$prefix."navigations SET output = '".addslashes($th)."' WHERE id = 'forum:".$query_forums->field('forumid')."'");
     $header .= '<a href="index.php?CID='.$query_forums->field('forumid').'">'.$query_forums->field('title').'</a> > ';
     $output .= '<option value="'.$query_forums->field('forumid').'" $fs['.$query_forums->field('forumid').']>'.$stripes.' '.$query_forums->field('title').'</option>'; 
     if ($subcat == '0') { $subcat++; } 
        $subcat++;  
     } else { 
        $stripes = ''; $s = $subcat + 2; while ($s != 0) { $stripes .= '-'; $s--; }
		if ($type == '6') { $stripes .= '--'; }
        
		if ($type != 6) {
		   $nav = $header . '<a href="board.php?FID='.$query_forums->field('forumid').'">'.$query_forums->field('title').'</a> ';
		   $nestedheader = $nav . '> ';
	    } else {
		    $nav = $nestedheader . '<a href="board.php?FID='.$query_forums->field('forumid').'">'.$query_forums->field('title').'</a> ';
		}
		
		
		
        new query($SQL, "UPDATE ".$prefix."navigations SET output = '".addslashes($nav)."' WHERE id = 'forum:".$query_forums->field('forumid')."'");
        $output .= '<option value="'.$query_forums->field('forumid').'" $fs['.$query_forums->field('forumid').']>'.$stripes.' '.$query_forums->field('title').'</option>'; 
     }	
  }
  //$output .= "</select>";
  $defheader = addslashes($defheader);
  new query($SQL, "UPDATE ".$prefix."cache SET cache = '".addslashes($output)."' WHERE name = 'forums'");
  new query($SQL, "UPDATE ".$prefix."navigations SET output = '".$defheader.'Profiles'."' WHERE id = 'profile'");
  new query($SQL, "UPDATE ".$prefix."navigations SET output = '".$defheader.'Memberlist'."' WHERE id = 'memberlist'");
  new query($SQL, "UPDATE ".$prefix."navigations SET output = '".$defheader.'Who is online?'."' WHERE id = 'online'");
  new query($SQL, "UPDATE ".$prefix."navigations SET output = '".$defheader.'My Home'."' WHERE id = 'usercp'");
}

write_cache(); */

// End Cache Routines
// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	 /* print "<i>Hang on a sec, we are resetting the cache.</i><br><br>"; */
	print '<b>Congratulations, you openbb setup/upgrade has finished!</b>';
	?><p><a href="./">Visit your board</a><br><br><B>NOTE: If you get items outside of your dropdowns please reset the board cache.</b><?php
	
break;
case 'douptmpl':

	db_connect();



	for($i=0; $i<count($loadtmpls); $i++)
		if ($loadtmpls[$i] == '-' || empty($loadtmpls[$i]))
			unset($loadtmpls[$i]);



	tmpl_setup($src[paktmpl], 'Standard OpenBB', 0, $keepvars, $loadtmpls);



	print '<b>The specified templates have been replaced</b>';
	print "<form method=\"post\" action=\"$PHP_SELF?step=finish\">

		<input type=\"hidden\" name=\"unlockpass\" value=\"$unlockpass\">

        <input class=button type=\"submit\" value=\"Next\">
        </form>";
	
break;
case 'uptmpl':

	print '<b>Upgrade Templates:</b><br>Please select the templates you want to replace (with RC2 ones).
	<p><b>Notes:</b>
	<ul><li>All the admin templates have been replace in the last step as said.
	<li>New templates, such as search, will be added automatically.
	<li>If you do not upgrade some templates, you might loose its functionality</ul>';
	print "<form method=\"post\" action=\"$PHP_SELF?step=douptmpl\">";
	?>
	<select size="7" name="loadtmpls[]" multiple style="font-family: Verdana; font-size: 8pt; border: 1px solid #C0C0C0; ">

  <option value="all" selected>All templates</option>

<option value="0">Base</option>

<option value="74">Guest Navigation</option>

<option value="75">Member Navigation</option>

<option value="99">Admin Navigation</option>

<option value="16">Login</option>

<option value="15">Register</option>

<option value="194">Forgot Password</option>

<option value="6">Error</option>

<option value="12">Redirect</option>

<option value="36">Forum Selector</option>

<option value="46">Timezone Selector</option>

<option value="43">Send to friend</option>

<option value="44">Send to friend Email</option>

<option value="83">Signature</option>

<option value="123">Email Form</option>

<option value="96">FAQ</option>

<option value="1">Main</option>

<option value="65">Welcome back message</option>

<option value="66">Login</option>

<option value="67">Logout</option>

<option value="29">Private Messaging</option>

<option value="2">Category</option>

<option value="4">Subcategory</option>

<option value="73">Standalone Forum</option>

<option value="3">Forum</option>

<option value="48">Link to topic</option>

<option value="57">Active Members, Guests</option>

<option value="59">Active Guests</option>

<option value="120">Last Post</option>

<option value="121">Last Post (Guest)</option>

<option value="5">Main</option>

<option value="7">Topic</option>

<option value="117">Topic (Guest)</option>

<option value="27">Link to topic</option>

<option value="8">No Topics</option>

<option value="47">Lastpost</option>

<option value="118">Lastpost (Guest)</option>

<option value="91">No Lastpost</option>

<option value="119">No Lastpost (Guest)</option>

<option value="133">Nested Forum Header</option>

<option value="134">Nested Forum Row</option>

<option value="135">Page Link</option>

<option value="136">Current Page</option>

<option value="139">Moderators</option>

<option value="9">Main</option>

<option value="10">Post</option>

<option value="116">Post (Guest)</option>

<option value="126">Poll</option>

<option value="125">Poll Row</option>

<option value="130">Poll (Cannot Vote)</option>

<option value="131">Poll Row (Cannot Vote)</option>

<option value="102">Usergroup Icon</option>

<option value="35">Moderator</option>

<option value="137">Page Link</option>

<option value="138">Current Page</option>

<option value="25">Main</option>

<option value="26">Post</option>

<option value="13">Main</option>

<option value="124">Post Poll</option>

<option value="11">Main</option>

<option value="84">Thread History</option>

<option value="85">Thread History Row</option>

<option value="18">Main</option>

<option value="17">Row</option>

<option value="19">Main</option>

<option value="56">Admin menu</option>

<option value="33">Main</option>

<option value="34">Row</option>

<option value="132">Invisible Marker</option>

<option value="41">View IP</option>

<option value="28">Move Thread</option>

<option value="32">Link Thread</option>

<option value="24">Edit Post</option>

<option value="45">'Log in' field</option>

<option value="55">'Logged in as' field</option>

<option value="86">Post Preview</option>

<option value="94">Smiley Set Row</option>

<option value="92">Smiley Template</option>

<option value="93">Smiley Row</option>

<option value="53">Login</option>

<option value="20">My Home</option>

<option value="21">Navigation</option>

<option value="22">My Profile</option>

<option value="104">My Settings</option>

<option value="103">My Settings - Status</option>

<option value="88">My Favorites</option>

<option value="152">Favorite Update Mail</option>

<option value="82">No New Favorites</option>

<option value="30">My Messages</option>

<option value="31">My Messages - Row</option>

<option value="81">No New Messages</option>

<option value="107">No Messages in Box</option>

<option value="71">Read Message</option>

<option value="69">New Message</option>

<option value="115">Download Message</option>

<option value="122">Message Preview</option>

<option value="112">Custom Avatar</option>

<option value="150">Change Password</option>

  </select>

  <p><input type="checkbox" name="keepvars" value="1"> Keep current template variables

	<?php

	print "

		<input type=\"hidden\" name=\"unlockpass\" value=\"$unlockpass\">

        <input class=button type=\"submit\" value=\"Next\">
        </form>";
	
break;
case 'dodbstruct':

	db_connect();



	if ($inew) {

		print '<b>Setting up DB structure:</b>';

		// delete all tables

		print "<p>Search and deleting existing tables... ";

		$tables = dbstruct_get_tables($src[pakdbstruct]); 

		for ($i=0; $i<count($tables); $i++) {

			if ($i == 0)

				$deltables = $tables[$i];

			else

				$deltables .= ', '.$tables[$i];

		}

		$sql = "DROP TABLE IF EXISTS $deltables";

		query($sql);

		print "<b>Done</b>";

		

		print "<p>Now setting up tables... ";
		dbstruct_setup($src[pakdbstruct]);

		print "<b>Done</b>";

		

		$nextstep = 'userdata';

		$donemsg = 'OpenBB database tables are now <b>installed</b>';

	} else {
		print '<b>Upgrading DB:</b>';
		
		print "<p>Search and fixing duplicate ids:<blockquote>";
		print "<p>in Posts... ";

		// get the highest ID
		$result = query('SELECT id FROM posts ORDER BY id DESC LIMIT 1');
		$row = fetch($result);
		$newid = $row['id'] + 1;
		
		// now search and replace
		$lastid = -1;
		$founds = 0;
		$result = query('SELECT id, poster FROM posts ORDER BY id ASC');
		while($row = fetch($result)) {
			if ($lastid == $row['id']) {
				// needs new ID
				query("UPDATE posts SET id = $newid WHERE id=$row[id] AND poster='".addslashes($row[poster])."' LIMIT 1");
				$newid++;
				$founds++;
			}
			$lastid = $row['id'];
		}
		
		// 
		
		print "<b>Done ($founds found)</b>";
		print "<p>in Topics... ";
		
		// get the highest ID
		$result = query('SELECT id FROM topics ORDER BY id DESC LIMIT 1');
		$row = fetch($result);
		$newid = $row['id'] + 1;
		
		// now search and replace
		$lastid = -1;
		$founds = 0;
		$result = query('SELECT id, poster FROM topics ORDER BY id ASC');
		while($row = fetch($result)) {
			if ($lastid == $row['id']) {
				// needs new ID
				query("UPDATE topics SET id = $newid WHERE id=$row[id] AND poster='".addslashes($row[poster])."' LIMIT 1");
				$newid++;
				$founds++;
			}
			$lastid = $row['id'];
		}

		print "<b>Done ($founds found)</b>";
		print "<p>in Polls... ";

		// get the highest ID
		$result = query('SELECT id FROM polls ORDER BY id DESC LIMIT 1');
		$row = fetch($result);
		$newid = $row['id'] + 1;
		
		// now search and replace
		$lastid = -1;
		$founds = 0;
		$result = query('SELECT id, total FROM polls ORDER BY id ASC');
		while($row = fetch($result)) {
			if ($lastid == $row['id']) {
				// needs new ID
				query("UPDATE polls SET id = $newid WHERE id=$row[id] AND total='".addslashes($row[total])."' LIMIT 1");
				$newid++;
				$founds++;
			}
			$lastid = $row['id'];
		}
		print "<b>Done ($founds found)</b></blockquote>";
		
		
		print "<p>Now upgrading DB tables... ";
			dbstruct_setup($src[pakdbstruct]);

		print "<b>Done</b>";


		// strip slashes for templates
		print "<p>strip-slashing current templates... ";
			$result = query('SELECT * FROM templates');
			while($row = fetch($result)) {
				// brute force deslashing
				$tmpl = str_replace('\\', '', $row['template']);
				query("UPDATE templates SET template = '".addslashes($tmpl)."' WHERE id=$row[id] AND groupid=$row[groupid]");
			}
		print "<b>Done</b>";

		print "<p>Updating admin design set... ";
			// query("UPDATE templates SET groupid = 127 WHERE id IN (50, 38, 39, 100, 42, 101, 140, 52, 51, 89, 61, 62, 63, 64, 76, 77, 78, 90, 127, 128, 79, 141, 142, 151, 144, 145, 146, 143)");
			query("DELETE FROM templates WHERE (groupid = 127) OR (id IN (50, 38, 39, 100, 42, 101, 140, 52, 51, 89, 61, 62, 63, 64, 76, 77, 78, 90, 127, 128, 79, 141, 142, 151, 144, 145, 146, 143))");
			tmpl_setup($src[paktmpla], '', 127);
		print "<b>Done</b>";

		print "<p>Removing obsolete templates... ";
			query("DELETE FROM templates WHERE id IN (23, 37, 40, 41, 48, 49, 54, 147, 148, 149)");
		print "<b>Done</b>";

		print "<p>Removing duplicate templates... ";
		$lastid = -1;
		$lastgid = -1;
		$founds = 0;
		$result = query('SELECT id, template, groupid FROM templates ORDER BY groupid ASC, id ASC');
		while($row = fetch($result)) {
			if ($lastid == $row['id'] && $lastgid == $row['groupid']) {
				// needs new ID
				query("DELETE FROM templates WHERE id=$row[id] AND template='".addslashes($row[template])."' AND groupid=$row[groupid] LIMIT 1");
				$founds++;
			}
			$lastid = $row['id'];
			$lastgid = $row['groupid'];
		}
		print "<b>Done ($founds found)</b></blockquote>";



		$nextstep = 'uptmpl';
		$donemsg = 'OpenBB database tables are now <b>upgraded</b>.';
	}
	
	print "<p>$donemsg";
	print "<form method=\"post\" action=\"$PHP_SELF?step=$nextstep\">

		<input type=\"hidden\" name=\"unlockpass\" value=\"$unlockpass\">

        <input class=button type=\"submit\" value=\"Next\">
        </form>";
break;

case 'sql':

if ($do) {


	// test DB connection
	include "lib/database/$type.php";
	
	if (!$sqlerror = testdbconn($db, $server, $user, $pass)) {
	
	$conf = '<'.'?'.'php '.'
	$database_server[\'type\'] = \''.$type.'\';
	$database_server[\'hostname\'] = \''.$server.'\';
	$database_server[\'username\'] = \''.$user.'\';
	$database_server[\'password\'] = \''.$pass.'\';
	$database_server[\'database\'] = \''.$db.'\';
	$database_server[\'setup_obb_version\'] = \''.OBB_VER.'\';
	$database_server[\'setup_reopenpass\'] = \''.md5($unlockpass).'\';
	'.'?'.'>';

	if (fwritable('lib/sqldata.php')) {
		$fp=fopen('lib/sqldata.php','w');
		fwrite($fp,$conf);
		fclose($fp);
		print "Configuration was successful. The database connection settings has been setup.
		<p><form method=\"post\" action=\"$PHP_SELF?step=custom\">

		<input type=\"hidden\" name=\"unlockpass\" value=\"$unlockpass\">

        <input class=button type=\"submit\" value=\"Next\">
        </form>";
	} else {
		print "Cannot write to file 'lib/sqldata.php'. You must have forgotten to CHMOD 777 it.<br>To complete this step,
		Copy and paste the following text into lib/sqldata.php (replacing the existing content):<p>
		<textarea rows=9 name=a cols=72 style=\"font-size: 9pt\">$conf</textarea><p>To this before clicking next.<br>&nbsp;<br>
		<form method=\"post\" action=\"$PHP_SELF?step=custom\">

		<input type=\"hidden\" name=\"unlockpass\" value=\"$unlockpass\">

        <input class=button type=\"submit\" value=\"Next\">
        </form>";
	}
	} else {
		$smsg = 'An error occured while trying to connect to the DB. ('.$sqlerror.') Please verify your setup configurations.';
	}

}
if ($smsg || !$do) {

$types[$type] = 'selected';

?><?php print $smsg ?><br><b>This is the part where you setup your SQL database:</b></p>
	<form method="post" action="<?php print $PHP_SELF; ?>?step=sql">
        <table border="0" cellpadding="1" cellspacing="2"width="100%">

          <tr>

            <td width="39%">DB Server software</td>

            <td width="61%"><select name="type">

                          <option value="mysql" <?php print $types[mysql]?>>MySQL</option>

                          <option value="postgresql" <?php print $types[postgresql]?>>PostgreSQL</option>

                 </select></td>

          </tr>

          <tr>

            <td width="39%">Host (server address)</td>

            <td width="61%"><input type="text" name="server" size="20" value="localhost"></td>

          </tr>

          <tr>

            <td width="39%">Username</td>

            <td width="61%"><input type="text" name="user" size="20" value="<?php print $user ?>"></td>

          </tr>

          <tr>

            <td width="39%">Password</td>

            <td width="61%"><input type="password" name="pass" size="20"></td>

          </tr>

          <tr>

            <td width="39%">Database Name</td>

            <td width="61%"><input type="text" name="db" size="20" value="<?php print $db ?>"></td>

          </tr>

          <tr>

            <td width="39%">Setup lock: In order to prevent this script from unauthorized access, please specify a password for later re-setting up.</td>

          </tr>

          <tr>

            <td width="39%">Setup lock password:</td>

            <td width="61%"><input type="text" name="unlockpass" size="20" value="<?php print $unlockpass; ?>"></td>

          </tr>

          <tr>

            <td width="39%">&nbsp;<input type="hidden" name="do" value="1"></td>

            <td width="61%">

        <input class=button type="submit" value="Next">
        </td>

          </tr>

        </table>
       </form><?php


}

break;
case 'check':
	
	// php ver check
	$phpver = phpversion();
	$phpveri = substr($phpver, 0, strpos($phpver, '.'));
	if ($phpver >= 4) {
		$phpvernote = "version $phpver detected, <b>OK</b>";
	} else {
		$phpvernote = "version $phpver detected, setup <font color='#FF0000'><b>not recommended</b></font>";
	}

	// chmod check
	if (fwritable('lib/sqldata.php')) {
		$sqlchmodnote = 'Test: <b>OK</b>, writable';
	} else {
		$sqlchmodnote = 'Test: <b>failed</b> to open lib/sqldata.php for writing';	
	}

	?>
	<b>Before installing OpenBB..</b></p>

        <p>Please check the following:</p>

        <p>To setup OpenBB, this server needs to have installed:

        <ul><li>PHP 4 (<?php print $phpvernote ?>)<li>MySQL Database</li></ul>

        <p>Make sure you've done the following before you continue:<br>

        <ul><li>Make writable: lib/sqldata.php, i.e. CHMOD 777 (<?php print $sqlchmodnote ?>)<li>Make writable: avatars/ folder, i.e. CHMOD 777

        <li>Make writable: images/ folder, i.e. CHMOD 777</ul>

        <p><form method="post" action="<?php print $PHP_SELF; ?>?step=sql">

        <input class=button type="submit" value="Next">
        <input type="hidden" name="unlockpass" value="<?php print $unlockpass; ?>">
        </form>
        <?php
	
	
break;
default:

	$filesize=filesize('docs/license.txt');
	$fp=fopen('docs/license.txt','r');
	$txt_license=fread($fp,$filesize);
	fclose($fp);
	
	?>
	<b>Welcome to Open Bulletin Board 1.0 RC2 setup</b></p>

        <p>This wizard will guide you through a fresh new install 

        of OpenBB or an upgrade of your existing OpenBB.</p>

        <p><b>License agreement</b></p>

        <form method="POST" action="">

        <pre><?php print $txt_license; ?></pre>

        </form>

        <p>By using OpenBB, you agree to the terms above

        <p><form method="post" action="<?php print $PHP_SELF; ?>?step=check">

        <input class=button type="submit" value="I agree">
        <input type="hidden" name="unlockpass" value="<?php print $unlockpass; ?>">
        </form>
        <?php
}

print '<'.'!'.'--';
?>--></td>

      </tr>

    </table>

    <p>&nbsp;</td>

  </tr>

</table>

</center></body></html>