<?php
/*
 *
 *  OpenBB, Copyright (c)2001 Iansoft
 *  Internal Release Beta 5.0.0
 *  http://www.iansoft.net/
 *
 */
$settings = 'selected';
if (!isset($do) || $do == '') {  
      @header('Location: cp.php?do=settings');
}  elseif ($do == 'updatesettings') {
   $SI['templates'] = '37|50';
   $SI['ref'] = 'Forum Cp';
   define('SCRIPTID','cp');
   $tmpbn = $boardname;
   require 'base.php';
   $boardname = $tmpbn;
   check_perm('settings_canchange',0);
   if ($timeoffset) {
	  $getoffset[1] = (substr($timeoffset, 1) * 3600);
      $getoffset[2] = substr($timeoffset, 0,1);
      $offset = $getoffset[2] . $getoffset[1];
   }
   new query($SQL, "UPDATE ".$prefix."configuration SET parseurl = '".$parseurl."', dsmiley = '".$disablesmilies."', showavatar = '".$showavatars."', showsig = '".$showsignature."', showhistory = '".$showhistory."', regtype = '".$regtype."',  pmail = '".$pmail."',  vmail = '".$vmail."', sendpm = '".$sendpm."', pmauthor = '".$pmauthor."', regpm = '".$regpm."', comnews = '".$comnews."', boardname = '".$boardname."', boardurl = '".$boardurl."', mlistperpage = '".$mlistperpage."', locked = '".$HTTP_POST_VARS['locked']."', lockedreason = '".$HTTP_POST_VARS['lockedreason']."', usegzip = '".$usegzip."', gzlevel = '".$gzlevel."', redirect = '".$redirect."', time1 = '".$time1."', time2 = '".$time2."', time3 = '".$time3."', defaulttimezone = $timeoffset, defaulttimeoffset = $offset, tlistperpage = $tlistperpage, plistperpage = $plistperpage");
   @header('Location: cp.php?do=settings&msg='.urlencode('Settings have been updated'));
} elseif ($do == 'settings') {
   $SI['templates'] = '38|50|46';
   $SI['ref'] = 'Forum Cp';
   define('SCRIPTID','cp');
   require 'base.php';
   $nav = ' &raquo; Board Configuration &raquo; General Configuration';

   
   check_perm('isadmin',0);

   $q = new query($SQL, "SELECT showsig, showavatar, locked, showhistory, parseurl, dsmiley, boardname, regtype, vmail, pmail, sendpm, pmauthor, regpm, comnews, boardurl, mlistperpage, lockedreason, gzlevel, usegzip, redirect, time1, time2, time3, defaulttimezone, plistperpage, tlistperpage FROM ".$prefix."configuration LIMIT 1");
   $q->getrow();
   $boardname = $q->field('boardname');
   $boardurl = $q->field('boardurl');
   $time1 = $q->field('time1');
   $time2 = $q->field('time2');
   $time3 = $q->field('time3');
   $comnews = $q->field('comnews');
   $pmauthor = $q->field('pmauthor');
   $regpm = $q->field('regpm');
   $vmail = $q->field('vmail');
   $pmail = $q->field('pmail');
   $regtype[$q->field('regtype')] = 'checked';
   
   $lockedreason = $q->field('lockedreason');
   
   $gzlevel = $q->field('gzlevel');
   
   if ($q->field('locked') == 1) { $islocked = 'checked'; } else { $unlocked = 'checked'; }
   
   if ($q->field('redirect') == 1) { $redir = 'checked'; } else { $direct = 'checked'; }
   if ($q->field('usegzip') == 1) { $gzip = 'checked'; } else { $nogzip = 'checked'; }
   
   if ($q->field('sendpm') == 1) { $sendpm = 'checked'; }
   if ($q->field('showsig') == 1) { $showsignature = 'checked'; } else { $dontshowsignature = 'checked'; }
   if ($q->field('showavatar') == 1) { $showavatar = 'checked'; } else { $dontshowavatar = 'checked'; }
   if ($q->field('showhistory') == 1) { $showhistory = 'checked'; } else { $dontshowhistory = 'checked'; }
   if ($q->field('parseurl') == 1) { $parseurl = 'checked'; } else { $dontparseurl = 'checked'; }
   if ($q->field('dsmiley') == 1) { $disablesmilies = 'checked'; } else { $dontdisablesmilies = 'checked'; }
   $g[$q->field('gzlevel')] = 'selected';
   $o[$q->field('mlistperpage')] = 'selected';
   $ot[$q->field('tlistperpage')] = 'selected';
   $op[$q->field('plistperpage')] = 'selected';
   $tmz = $q->field('defaulttimezone');
   if ($tmz < 0)
		$tmz = str_replace('-', 'm', $tmz);
	else if ($tmz > 0)
		$tmz = 'p'.$tmz;
   unset ($timezone);
   $timezone[$tmz] = "selected";

   eval("\$timezoneselector = \"".addslashes(template(46,0))."\";");
   eval("\$include = \"".addslashes($TI[38])."\";"); 
   eval("\$output = \"".addslashes($TI[50])."\";");
   lose($output);
   exit();

} elseif ($do == 'avatars') {
   $SI['templates'] = '79|50';
   $SI['ref'] = 'Forum Cp';
   define('SCRIPTID','cp');
   require 'base.php';
   
   check_perm('cp_avatars',0);


   $avatarselector = '<select name="avatar">';

   $query_avatars = new query($SQL, "SELECT name, url FROM ".$prefix."avatar");
   while($query_avatars->getrow()) {
         $avatarselector .= '<option value="'.$query_avatars->field('url').'">'.$query_avatars->field('name').'</option>'; 
   }

   $avatarselector .= '</select>';

   eval("\$include = \"".addslashes($TI[79])."\";"); 
   eval("\$output = \"".addslashes($TI[50])."\";");
   lose($output);

}



?>
