<?php
/*
 *
 *  OpenBB, Copyright (c)2001 Iansoft
 *  Internal Release Beta 5.0.0
 *  http://www.iansoft.net/
 *
 */
 $design = 'selected';
$nav = ' &raquo; Designer &raquo; Design';
if ($do == '') {

$SI['templates'] = '50|39|100';
$SI['ref'] = 'Forum CP';
define('SCRIPTID','cp');
require 'base.php';

check_perm('design_canview',0);


$gid=floor($gid);
if ($gid == '') { $gid = 0; }
$q = new query($SQL, "SELECT title, id FROM ".$prefix."designs");
while ($q->getrow()) {
   if($q->field('id') == $gid) {
      $designset .= '<option value="'.$q->field('id').'" selected>'.$q->field('title').'</option>';
   } else {
      $designset .= '<option value="'.$q->field('id').'">'.$q->field('title').'</option>';
   }
}
$q->free();

$query_getvars = new query($SQL,"SELECT org, rep FROM ".$prefix."vars WHERE groupid = '".$gid."'");
while ($query_getvars->getrow()) {
   $var[name] = $query_getvars->field('org');
   $var[value] = $query_getvars->field('rep');
   eval("\$varinclude .= \"".addslashes($TI[100])."\";"); 
}

eval("\$include = \"".addslashes($TI[39])."\";"); 
eval("\$output = \"".addslashes($TI[50])."\";");
lose($output);
} elseif ($do == 'templates') {

$SI['templates'] = '50|42';
$SI['ref'] = 'Forum CP';
define('SCRIPTID','cp');
require 'base.php';

check_perm('design_canview',0);


if ($gid == '') { $gid = 0; }
$query_gettemplates = new query($SQL, "SELECT template FROM ".$prefix."templates WHERE id = $tid AND groupid = $gid");
$query_gettemplates->getrow();
$inside = htmlspecialchars($query_gettemplates->field('template'));
$query_gettemplates->free();
eval("\$include = \"".addslashes($TI[42])."\";"); 
eval("\$output = \"".addslashes($TI[50])."\";");
lose($output);

} elseif ($do == 'acedit') {

$SI['ref'] = 'Forum CP';
define('SCRIPTID','cp');
require 'base.php';

check_perm('design_canedit',0);

if ($gid == '') { $gid = 1; }
new query($SQL, "UPDATE ".$prefix."templates SET template = '".$inside."' WHERE id = $tid AND groupid = $gid");
if ($gid == 127) { $gid = $realgid; }
@header('Location: cp_templates.php?gid='.$gid.'#templates');
} elseif ($do == 'newvar') {

$SI['templates'] = '50|101';
$SI['ref'] = 'Forum CP';
define('SCRIPTID','cp');
require 'base.php';
check_perm('design_canedit',0);
if ($gid == '') { $gid = 0; }
eval("\$include = \"".addslashes($TI[101])."\";"); 
eval("\$output = \"".addslashes($TI[50])."\";");
lose($output);

} elseif ($do == 'donewvar') {

$SI['ref'] = 'Forum CP';
define('SCRIPTID','cp');
require 'base.php';
check_perm('design_canedit',0);

if ($gid == '') { $gid = 0; }

if ($varname == '' || $varvalue == '') { gen_error('Missing Parameters','Return and try again please!'); }

new query($SQL, 'INSERT INTO '.$prefix.'vars VALUES (\''.$gid.'\',\''.$varname.'\',\''.$varvalue.'\')');

@header('Location: cp_templates.php?gid='.$gid.'#templates');

} elseif ($do == 'updatevars') {

$SI['ref'] = 'Forum CP';
define('SCRIPTID','cp');
require 'base.php';
check_perm('design_canedit',0);

if ($gid == '') { $gid = 0; }


while(list($key, $val) = each($HTTP_POST_VARS)) { 
if ($key != 'imageField_y' && $key != 'imageField_x' && $key != 'submit') {
   $key = str_replace('_',' ',$key);
   new query($SQL, 'UPDATE '.$prefix.'vars SET rep = \''.$val.'\' WHERE org = \''.$key.'\'  AND groupid = '.$gid);
}
}

@header('Location: cp_templates.php?gid='.$gid.'#templates');

} elseif ($do == 'newset') {

$SI['templates'] = '50|140';
$SI['ref'] = 'Forum CP';
define('SCRIPTID','cp');
require 'base.php';
check_perm('design_cancreateset',0);

$q = new query($SQL, "SELECT title, id FROM ".$prefix."designs");
$designselector = '<select name="baseon">';
while ($q->getrow()) {
   $designselector .= '<option value="'.$q->field('id').'">'.$q->field('title').'</option>';
 
}
$designselector .= '</select>';
$q->free();


eval("\$include = \"".addslashes($TI[140])."\";"); 
eval("\$output = \"".addslashes($TI[50])."\";");
lose($output);

} elseif ($do == 'donewset') {

$SI['ref'] = 'Forum CP';
define('SCRIPTID','cp');
require 'base.php';
check_perm('design_cancreateset',0);

$q = new query($SQL, "SELECT id FROM ".$prefix."designs ORDER BY id DESC LIMIT 1");
$q->fetch();
$gid = $q->field('id')+1;


if (is_uploaded_file($import)) {
$fd = fopen($import, 'r');
$data = fread ($fd, filesize ($import));
fclose($fd);

	$spl[1] = '@18�@';
	$spl[2] = '@17�@';
	$spl[3] = '@16�@';
list($header, $tdata, $vdata) = explode($spl[1],$data);

new query($SQL, "INSERT INTO designs VALUES ('".$setname."','".$gid."','".$gid."','".$gid."')");

list($pname, $psig, $pdate, $pother) = explode($spl[2], $header);

// check header
if ($psig != 'OBB_USERPACK_TEMPLATESET')
	gen_error('Invalid OBB pack signature', 'Invalid OBB pack signature. Possible reasons maybe the file is corrupted or is not a template pack.');

// now import the data

$tmpls = explode($spl[2], $tdata);
$vars = explode($spl[2], $vdata);

foreach ($tmpls as $tmpl) {
	list($tid, $rtmpl) = explode($spl[3], $tmpl);
	new query($SQL, "INSERT INTO templates VALUES ('".$tid."','".addslashes($rtmpl)."','".$gid."')");
}

foreach ($vars as $var) {
	list($vorg, $vrep) = explode($spl[3], $var);
	new query($SQL, "INSERT INTO vars VALUES ('".$gid."','".$vorg."','".addslashes($vrep)."')");
}

} else {
new query($SQL, "INSERT INTO designs VALUES ('".$setname."','".$gid."','".$gid."','".$gid."')");

$query_getold = new query($SQL, "SELECT template, id FROM templates WHERE groupid = '".$baseon."'");
while ($query_getold->getrow()) {
   new query($SQL, "INSERT INTO templates VALUES ('".$query_getold->field('id')."','".addslashes($query_getold->field('template'))."','".$gid."')");
}
$query_getold->free();

$query_getold = new query($SQL, "SELECT org, rep FROM vars WHERE groupid = '".$baseon."'");
while ($query_getold->getrow()) {
   new query($SQL, "INSERT INTO vars VALUES ('".$gid."','".$query_getold->field('org')."','".addslashes($query_getold->field('rep'))."')");
}
$query_getold->free();

}

@header('Location: cp_templates.php?gid='.$gid.'#templates');

} elseif ($do == 'delset') {

$SI['templates'] = '50';
$SI['ref'] = 'Forum CP';
define('SCRIPTID','cp');
require 'base.php';
check_perm('design_cancreateset',0);

$q = new query($SQL, "SELECT title, id FROM ".$prefix."designs WHERE id=$gid LIMIT 1");
$q->fetch();
$include = "<center><font face='$tempvars[fontface]' size=2><b>Are you sure you want to delete template set '".$q->field('title')."'?</b>";
$include .= "<br>&nbsp;<br><a href='$PHP_SELF?do=dodelset&gid=$gid'>Yes</a> &nbsp;&nbsp;<a href='$PHP_SELF?gid=$gid'>No, go back</a></font></center>";
eval("\$output = \"".addslashes($TI[50])."\";");
lose($output);

} elseif ($do == 'dodelset') {
	
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('design_cancreateset',0);
	
	if ($gid == 0 || $gid == 127)
		gen_error("Error deleting", "Cannot delete default and admin templates (id: 0,127)");

	new query($SQL, "DELETE FROM ".$prefix."designs WHERE id=$gid");
	new query($SQL, "DELETE FROM ".$prefix."templates WHERE groupid=$gid");

	@header('Location: cp_templates.php');
} elseif ($do == 'exportset') {
	// send the user the template set
	$SI['ref'] = 'Forum CP';
	define('SCRIPTID','cp');
	require 'base.php';
	check_perm('design_cancreateset',0);

	if (!isset($gid))
		$gid=0;
	header('Content-Type: application/obbpack-stream');
	header('Pragma: no-cache');
	header('Content-Disposition: filename=new_export.ob;');
	
	$spl[1] = '@18�@';
	$spl[2] = '@17�@';
	$spl[3] = '@16�@';
	


    $query = new query($SQL, "SELECT title FROM designs WHERE id=$gid");
	$query->fetch();
	$title = $query->field('title');
	$query->free;
	$query = new query($SQL, "SELECT id, template FROM templates WHERE groupid=$gid");
	while($query->fetch())
		$data .= $query->field('id').$spl[3].$query->field('template').$spl[2];
	
	$query = new query($SQL, "SELECT org, rep FROM vars WHERE groupid=$gid");
	while($query->fetch())
		$vdata .= $query->field('org').$spl[3].$query->field('rep').$spl[2];


	$vdata = substr($vdata, 0, strlen($vdata) - strlen($spl[2]));
	$data = substr($data, 0, strlen($data) - strlen($spl[2]));
	
	$header = $title."$spl[2]OBB_USERPACK_TEMPLATESET$spl[2]".mktime();
	
	$senddata = $header.$spl[1].$data.$spl[1].$vdata;
	
	print $senddata;
} elseif ($do == 'templaterestore') {
	// restore this template
	$SI['ref'] = 'Forum CP';
	define('SCRIPTID','cp');
	require 'base.php';
	if ($gid == '') { $gid = 0; }
	
	check_perm('design_canedit',0);
	
	if ($gid == 127)
		$default_template_file = 'setup/tmplset_admin.ob';
	else
		$default_template_file = 'setup/tmplset.ob';


	if (!file_exists($default_template_file))
		gen_error('Setup default not found', 'Default template file ('.$default_template_file.') not found. Please double check.');
	$fd = fopen($default_template_file, 'r');
	$data = fread ($fd, filesize ($default_template_file));
	fclose($fd);
	$spl[1] = '@18�@';
	$spl[2] = '@17�@';
	$spl[3] = '@16�@';

	list($header, $tdata, $vdata) = explode($spl[1],$data);

	list($pname, $psig, $pdate, $pother) = explode($spl[2], $header);
	// check header
	if ($psig != 'OBB_USERPACK_TEMPLATESET')
		gen_error('Invalid OBB pack signature', 'Invalid OBB pack signature ('.$psig.'). Possible reasons maybe the file is corrupted or is not a template pack.');

	// now import the data

	$tmpls = explode($spl[2], $tdata);

	foreach ($tmpls as $tmpl) {
		list($dtid, $rtmpl) = explode($spl[3], $tmpl);
		if ($dtid == $tid) break;
	}
	if ($dtid != $tid)
		gen_error('Template not found', 'Template ID '.$tid.' not found in default template set file.');
	new query($SQL, "UPDATE ".$prefix."templates SET template = '".$rtmpl."' WHERE id = $tid AND groupid = $gid");
	if ($gid == 127) { $gid = $realgid; }
	@header('Location: cp_templates.php?do=templates&tid='.$tid.'&gid='.$gid);
}
?>
