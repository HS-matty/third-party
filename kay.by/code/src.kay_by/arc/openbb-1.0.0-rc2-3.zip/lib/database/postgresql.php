<?php 
class db {

  var $id;
 

  function open($database, $host, $user, $password, $pconnect = 1, $port = 5432) {

    if ($user) { $up = 'user='.$user;  }
	if ($password) { $up .= ' password='.$password; }
   
    if ($pconnect) {
       $this->id=pg_connect ("host=$host port=$port dbname=$database $up");
    } else {
       $this->id=pg_pconnect ("host=$host port=$port dbname=$database $up");
    }
    return $this->id;
  }

  function error() {    global $lastquery;
    print '<font face="verdana" size="5">OpenBB SQL</font><br><br><font face="verdana" size="2">An Error has occured, please contact the system administrator.</font><br><br><br><hr><font face="verdana" size="1">';
    if (!$error) { print pg_errormessage($this->id); } else { print $error; }
	print '<br>Query:<br>'.$lastquery;	print '</font>';
	exit();
  }

  function errorcheck() {
    global $lastquery;        if (mysql_error($this->id)) {
		print '<font face="verdana" size="5">OpenBB SQL</font><br><br><font face="verdana" size="2">An Error has occured, please contact the system administrator.</font><br><br><br><hr><font face="verdana" size="1">';
		print mysql_error($this->id);
		print '<br>Query:<br>'.$lastquery;
		print '</font>';
		exit();	}
  }    function error2() {
    return pg_errormessage($this->id);
  } 
     
  function close() {
    $result=@pg_close($this->id);
    return $result;
  } 
};

class query {

  var $result;
  var $row;  var $rc;

  function query(&$db, $query="") {
      global $lastquery;
	  $lastquery = $query;      $rc = 0;
      $this->result = pg_exec($db->id, $query);      $db->errorcheck();
  }
  
  function getrow() {
    if ($this->result) {
      $this->row=pg_fetch_array($this->result, $rc);      $rc++;
    } else {
      $this->row=0;
    }
    return $this->row;
  }
   
   
  function fetch() {
    if ($this->result) {
      $this->row=pg_fetch_array($this->result, $rc);      $rc++;
    } else {
      $this->row=0;
    }
    return $this->row;
  }    function seek($row) {    $rc = $row;
    return TRUE;  }
   
  function field($field) {
    return $this->row[$field];
  }

  function free() {
    return @pg_freeresult($this->result);
  }

};

// new pgdb functions (for oBB2) //
// these are used by setup, for easy porting to obb2 //function db_connect() {
	global $dbname, $database_server, $PGSQLID;

	if ($database_server['username']) { $up = 'user='.$database_server['username'];  }
	if ($database_server['password']) { $up .= ' password='.$database_server['password']; }
	$PGSQLID = pg_connect ("host=$database_server[hostname] port=5432 dbname=$database_server[database] $up");
	$dbname = $database_server['database'];
}

// test DB connectivity
function testdbconn($database, $host, $user, $password) {
	if ($user) { $up = 'user='.$user;  }
	if ($password) { $up .= ' password='.$password; }

	if (pg_connect ("host=$host port=5432 dbname=$database $up")) {
		pg_close($db);
		return 0;
	} else {		return 'Error with connection; No additional info available';//pg_errormessage();	}}

function query($query) {
	global $PGSQLID, $PGSQLQP;
	$PGSQLQP[$queryid] = 0;
	$qres = pg_exec($PGSQLID, $query);	
	if ($err = pg_errormessage($PGSQLID)) {
		die('<b>DB ERROR: '.$err.'; Setup halted</b><br>'.$query);
	}
	return $qres;
}

function fetch($queryid) {
	global $PGSQLQP;
	$PGSQLQP[$queryid]++;
	return pg_fetch_array($queryid, $PGSQLQP[$queryid]-1);	
}

function free($queryid) {
	return pg_freeresult($queryid);
}
?>
