<?php 
class db {

  var $id;

  function db() { }
  
  function getq() { return $this->queries; }
  
  function open($database, $host, $user, $password, $pconnect = 1) {
  
    if ($pconnect) {
       $this->id=mysql_pconnect($host, $user, $password); 
    } else {
       $this->id=mysql_connect($host, $user, $password); 
    }

    if ($this->id) {
       $result=mysql_select_db($database);
       if (!$result) { $this->error('<b>Fatal Error</b>: Could not find database on the server'); }
    }
    return $this->id;
  }

  function error($error = 0) {
    global $lastquery;
    print '<font face="verdana" size="5">OpenBB SQL</font><br><br><font face="verdana" size="2">An Error has occured, please contact the system administrator.</font><br><br><br><hr><font face="verdana" size="1">';
    if (!$error) { print mysql_error($this->id); } else { print $error; }
	print '<br>Query:<br>'.$lastquery;
	print '</font>';
	exit();
  }
      function errorcheck() {
    global $lastquery;        if (mysql_error($this->id)) {
		print '<font face="verdana" size="5">OpenBB SQL</font><br><br><font face="verdana" size="2">An Error has occured, please contact the system administrator.</font><br><br><br><hr><font face="verdana" size="1">';
		print mysql_error($this->id);
		print '<br>Query:<br>'.$lastquery;
		print '</font>';
		exit();	}
  }
	 
  function error2() {
    return mysql_error($this->id);
  } 
  
  function close() {
    $result=@mysql_close($this->id);
    return $result;
  } 
};

class query {

  var $result;
  var $row;

  function query(&$db, $query="") {
      global $lastquery;
	  $lastquery = $query;
      $this->result=mysql_query($query, $db->id);      $db->errorcheck();
	  #$db->queries .= '<br>'.$query;
  }
  
  function getrow() {
    if ($this->result) {
      $this->row=mysql_fetch_array($this->result);
    } else {
      $this->row=0;
    }
    return $this->row;
  }
   
   
  function fetch() {
    if ($this->result) {
      $this->row=mysql_fetch_array($this->result);
    } else {
      $this->row=0;
    }
    return $this->row;
  }    function seek($row) {    return mysql_data_seek($this->result, $row);  }
   
  function field($field) {
    return $this->row[$field];
  }

  function free() {
    return @mysql_free_result($this->result);
  }

}

// new db functions (from oBB2) //
// these are used by setup, for easy porting to obb2 //

    function db_connect() {
	global $dbname, $database_server;
	mysql_connect($database_server['hostname'],$database_server['username'],$database_server['password']);
	mysql_select_db($database_server['database']);
	$dbname = $database_server['database'];
}

// test DB connectivity
function testdbconn($database, $host, $user, $password) {
	$db=@mysql_connect($host, $user, $password); 

	if ($db) {
		$result=@mysql_select_db($database);
		$err=mysql_error();		mysql_close($db);
		return $err;
	} else {		return mysql_error();	}	mysql_close($db);
	return 0;
  }

function query($query) {
	$qres = mysql_query($query);	
	if ($err = mysql_error()) {
		die('<b>DB ERROR: '.$err.'; Setup halted</b><br>'.$query);
	}
	//print $query.';';
	return $qres;
}

function fetch($queryid) {
	return mysql_fetch_array($queryid);
}

function free($queryid) {
	return mysql_free_result($queryid);
}

?>