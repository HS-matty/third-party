<?php
/*
 *
 *  OpenBB, Copyright (c)2001 Iansoft Corporation
 *  functions.php - All global functions
 *  Protected by the GPL (docs/gpl.txt)
 *
 */

// Function to show DB error (Templates are unavaible)
function show_dberror ($error = "unknow error occured") {
  print "an database error has occured.<br><i>".$error."</i><br>contact your system administrator for more information."; 
  exit();
}

// Strip invalid characters from avatar
function getavatar ($av) {

$chars['['] = '489';
$chars[']'] = '984';

$av = strtr($av, $chars);
return $av;	
}

// Add invalid characters to avatar
function getavatar_undo ($av) {

$chars['489'] = '[';
$chars['984'] = ']';

$av = strtr($av, $chars);
return $av;	
}


// Generate GZIP
 function do_gzip($level = 3) {
    global $HTTP_ACCEPT_ENCODING, $config;
	
	if (!$config->field('usegzip')) { return; }
	
    if (!function_exists('gzcompress')) {
       print('gzcompress not found. - zlib needs to be installed for GZip Compression');
    }
    if (!function_exists('crc32')) {
        print('crc32() not found - PHP 4.0.1 or higher is needed for GZip Compression');
    }

		
    if (connection_status() !== 0) return;
    if (strpos($HTTP_ACCEPT_ENCODING, 'gzip') == false) return;
    if (strpos($HTTP_ACCEPT_ENCODING, 'x-gzip') == false) {
        $encoding = 'gzip';
    } else {
        $encoding = 'x-gzip';
    }

	$level = $config->field('gzlevel');
	
    $contents = ob_get_contents();
    if ($contents === false) return;
	
    $gzdata = "\x1f\x8b\x08\x00\x00\x00\x00\x00";
    $size = strlen($contents);
    $crc = crc32($contents);
    $gzdata .= gzcompress($contents, $level);
    $gzdata = substr($gzdata, 0, strlen($gzdata) - 4); 
    $gzdata .= pack("V",$crc) . pack("V", $size);

	ob_end_clean();
    @Header('Content-Encoding: ' . $encoding);
    @Header('Vary: Accept-Encoding');
    @Header('Content-Length: ' . strlen($gzdata));
	
    echo $gzdata;
    }


// Gen Output
function lose ($output) {
  global $SQL, $start_of_openbb, $debugkey, $base_end, $start_of_file, $TC, $SI, $gid; 
  //$output = stripslashes($output);
  //$output = stripslashes($output);
  $output = str_replace('\\\'', '\'', $output);
  
  if (SCRIPTID != 'cp') { // Template Editor in CP gets vars executed
     $query_vars = new query($SQL, "SELECT org, rep FROM vars WHERE groupid = '".VARGROUP."'");
     while ($query_vars->getrow()) { 
        $output = str_replace('{'.$query_vars->field('org').'}',$query_vars->field('rep'), $output); 
     }
     $query_vars->free();
  }
 
  print $output; do_gzip(); flush;

  $mtime1 = microtime();
  $mtime1 = explode(" ",$mtime1); 
  if (md5($debugkey) == 'c88a65120330cfc69d5dbe1916fc8cd2') {
     print '<hr><font face="verdana" size="1" color="white">';
     print 'Template Cache List: '. $SI['templates'];
     print '<br>Template Cache Queries: '. $TC;
     print '<br><br>Base Execution: '.$base_end;
     print '<br>File Execution: '.(($mtime1[1] + $mtime1[0]) - $start_of_file);
     print '<br>Total Execution: ';
     print ($mtime1[1] + $mtime1[0]) - $start_of_openbb; 
     print '<br><br>Queries:';
     print $SQL->getq();
     print '</font>';
 }

  $SQL->close();
  exit();
}

// Permission Check
function check_perm($permissions,$advanced,$usergroup = 0) {
  global $FID, $SQL, $config, $REQUEST_URI;
  $permission = explode(',',$permissions);
  if(ADMIN) { $permission = $permission[1]; } else { $permission = $permission[0]; }
  
   if ($usergroup == 0) { $usergroup = USERGROUP; }
 
     if ($permission) {

     if ($advanced) {

        
          
        $query_forums = new query($SQL, 'SELECT '.$permissions.' FROM forum_permissions WHERE forumid = \''.$FID.'\' and uid =  \''.$usergroup.'\'');
        
           if (!$query_forums->getrow()) {
           $query_forums = new query($SQL, "SELECT ".$permissions." FROM usergroup WHERE id = '".$usergroup."'");
           $query_forums->getrow();
        }
           if (!ADMIN) { if (!$query_forums->field($permission)) { 
           if ($usergroup == 0 || !$usergroup) {
              $redirect = str_replace('&','|',substr($REQUEST_URI, strlen($config->field('cookiepath'))));
              $query_forums->free();
              @header("Location: ".$config->field('boardurl')."/member.php?action=login&redirect=$redirect");
              $config->free();
              $SQL->close();
              exit();
           } else {
              $query_forums->free();
              $config->free();
              gen_error('No Access!','You have no access to this part of the boards!');
           }
        }
     } 
   }    else {
        $query_normal = new query($SQL, "SELECT ".$permission." FROM usergroup WHERE id = '".USERGROUP."'");
        $query_normal->getrow(); 
        if (!$query_normal->field($permission)) {
           if (!ADMIN) { 
           if (!MEMBER) {
              $redirect = str_replace('&','|',substr($REQUEST_URI, strlen($config->field('cookiepath'))));
              $query_normal->free();
              @header("Location: ".$config->field('boardurl')."/member.php?action=login&redirect=$redirect");
              $config->free();
              $SQL->close();
              exit();
           } else {
              $query_normal->free();
              $config->free();
              gen_error('No Access!','You have no access to this part of the boards.');
           }
        }
     }
  }
 }
  return $query_forums;
}


function get_forumperm($permission,$FID) {
  global $FID, $SQL;


        $query_forums = new query($SQL, 'SELECT '.$permission.' FROM forum_permissions WHERE forumid = \''.$FID.'\' and uid =  \''.USERGROUP.'\'');
        if (!$query_forums->getrow()) {
           $query_forums = new query($SQL, "SELECT ".$permission." FROM usergroup WHERE id = '".USERGROUP."'");
           $query_forums->getrow();
        }

        if (!$query_forums->field($permission)) { 
           if (!MEMBER) {
              $query_forums->free();
              return 0;
           } else {
              $query_forums->free();
              return 0;
           }
        }
if ($query_forums->field($permission) == 1 || ADMIN) { return 1; } else { return 0; }
}

function get_perm($permission) {
  global $SQL;


           $query_forums = new query($SQL, "SELECT ".$permission." FROM usergroup WHERE id = '".USERGROUP."'");
           $query_forums->getrow();

        if (!$query_forums->field($permission)) { 
           if (!MEMBER) {
              $query_forums->free();
              return 0;
           } else {
              $query_forums->free();
              return 0;
           }
        }
if ($query_forums->field($permission) == 1 || ADMIN) { return 1; } else { return 0; }
}


// Get template
function template($id, $gid = TEMPLATEGROUP) {
  global $TI, $SQL, $TQ, $NC;
  $query_template = new query($SQL, 'SELECT template FROM templates WHERE id = \''.$id.'\' AND groupid = \''.$gid.'\'');
  $query_template->getrow();
  $output = $query_template->field('template');
  return $output;
}

// Define Guest Stats
function define_guest() {
   global $SQL, $timezone;
   $sq = new query($SQL, "select vargroup, templategroup, showavatar, showsig, showhistory, defaulttimeoffset, defaulttimezone from configuration");
   $sq->getrow();
   define('MEMBER','0');
   define('USERGROUP',0);
   define('VARGROUP',$sq->field('vargroup'));
   define('TEMPLATEGROUP',$sq->field('templategroup'));
   define('ACTIVATED',1);
   define('BANNED',0);
   define('SHOWAVATAR',$sq->field('showavatar'));
   define('SHOWSIG',$sq->field('showsig'));
   define('SHOWHISTORY',$sq->field('showhistory'));
   $timezone = $sq->field('defaulttimezone');
   $time = $sq->field('defaulttimeoffset');
   if ($time == 0) {
      $timezone = 'GMT';
   } else {
      if ($timezone > '-1') { $timezone = '+' . $timezone; }
      $timezone = 'GMT '.$timezone;
   }
   define('TIMEZONE',$timezone);
   define('TIMEOFFSET',$time);
   $sq->free();
}

// Get Navigation
function getnav($id) {
  global $SQL, $navigation;
  $query_nav = new query($SQL, "SELECT output FROM navigations WHERE id = '$id'");
  $query_nav->getrow();
  $output = $query_nav->field('output');
  $query_nav->free();
  return $output;
}

// Return error
function gen_error($error, $errordescription) {
  global $navigation, $tempvars, $boardname, $title;
  $title = 'Error occured'; 
  eval("\$include = \"".addslashes(template(6))."\";");
  eval("\$output = \"".addslashes(template(0))."\";");
  lose($output);
}

// Return message
function gen_msg($error, $errordescription) {
  global $navigation, $tempvars, $boardname;
  $title = 'Message';
  eval("\$include = \"".addslashes(template(6))."\";");
  eval("\$output = \"".addslashes(template(0))."\";");
  lose($output);
}

// Send PM
function send_pm($to,$from,$sub,$msg, $sysmsg = 1, $uid = 1, $touid = 0) {
  global $SQL;
  $query_pm = new query($SQL, "SELECT id FROM pmsg ORDER BY id DESC LIMIT 1");
  $query_pm->getrow();
  $id = $query_pm->field('id') + 1;
  $query_pm->free();
  new query($SQL, "INSERT INTO pmsg VALUES ('".$from."','".$to."','".$msg."', '".time()."', '0', '".$id."', '".$sub."','inbox', '".$uid."', '".$to."')");
  
  if (!$sysmsg) {
  new query($SQL, "INSERT INTO pmsg VALUES ('".$from."','".$to."','".$msg."', '".time()."', '0', '".($id + 1)."', '".$sub."','outbox', '".$touid."', '".$from."')");  
  }
}

// Return redirect
function gen_redirect($description, $url) {
  global $config, $SQL, $navigation, $tempvars;
   if ($config->field('redirect') == 1) {
      eval("\$include = \"".addslashes(template(12))."\";"); 
      eval("\$output = \"".addslashes(template(0))."\";");
      lose($output);
   } else {
      $SQL->close();
      @header("Location: $url");
   }
}

// Generate Forum Cookie
function gen_cookie ($forum, $a=0) {
 
  if (($forum == 0) || ($forum == '-1')) { // Generate New Cookie
     global $SQL, $config, $expire;

     $query = new query($SQL, "SELECT forumid FROM forum_display ORDER BY displayorder");

     while ($query->getrow()) {
        setcookie('forum:'.$query->field('forumid'),0,$expire,$config->field('cookiepath'));
     }

     $query->free();



  } elseif ($forum == '-2') { // Mark Read
     global $SQL, $config, $expire, $HTTP_COOKIE_VARS;

     $query = new query($SQL, "SELECT forumid FROM forum_display ORDER BY displayorder");

     while ($query->getrow()) {
        setcookie('forum:'.$query->field('forumid'),time(),$expire,$config->field('cookiepath'));
		$HTTP_COOKIE_VARS['forum:'.$query->field('forumid')] = time();
     }

     $query->free();

  } else {


    if ($a != 0) { $t = $a; } else { $t = time(); }

    $frms = explode(",", $HTTP_COOKIE_VARS['forummarker']);
    $con = 1;

    while (list($key,$val) = each($frms)) {
       $prop = explode(":", $val);
       
       if ($prop[0] == $forum) {
          $total .= $prop[0].':'.$t.',';
       } else { 
          $total .= $val.',';
       }
    }

   $cookie = $total;
   $cookie = substr($cookie, 0, (strlen($cookie) - 1));

  }

  return $cookie;
}
?>