<?php
// Delete Post
// Niels Van der Wildt, 9/7/2001
// Part of OpenBB

function deletepost ($PID) { 
      global $SQL;
	  

      $query_getinfo = new query($SQL, "SELECT posts.dateline as date, posts.isstarter as istopic, topics.replies as replies, posts.threadid as topicid, posts.forumid as forumid, posts.poster as poster FROM posts, topics WHERE posts.threadid = topics.id AND posts.id = $PID");
	  $query_getinfo->getrow();
	  
	  $FID = $query_getinfo->field('forumid');
	  $TID = $query_getinfo->field('topicid');

	  
	  if ($query_getinfo->field('poster') == USERNAME && USERNAME != 'Guest') {
	     $canedit = 1;
	  } else {
	  

	     $query_mods = new query($SQL, "SELECT moderators FROM forum_display WHERE forumid = '".$FID."'");
         $query_mods->getrow();

         $mods = explode(',', str_replace(' ', '', trim($query_mods->field('moderators'))));
         if (in_array(USERNAME,$mods) && USERNAME != '') { define('MODERATOR',1); $ismod = 1; }
	     if (!$ismod) { 
            if (get_forumperm('ismoderator',$FID)) { define('MODERATOR',1); } else { define('MODERATOR',0); }
         } 
	  }
	  if (MODERATOR) { $canedit = 1; }
	  if (!$canedit) { gen_error('No Access!','You cannot edit this post.'); }  
	  
	 if ($query_getinfo->field('istopic')) {
	  // * First: The post is the thread starter, delete all signs of the thread and all posts
	  // Stage 1.1: Check if the topic is the last topic 
	  
	 $check_lastpost = new query($SQL, 'SELECT lastpost, lastposter, lastthreadid FROM forum_display WHERE forumid = \''.$FID.'\'');
	 $check_lastpost->getrow(); 

 if ($check_lastpost->field('lastthreadid') == $TID) { 
	 // Stage 2.2: Find the 2nd last topic and set this as lastpost
	  $check_previous = new query($SQL, 'SELECT posts.dateline as id, posts.threadid as TID, posts.poster as poster, posts.title as title, topics.title as topictitle, profiles.id as UID FROM posts, topics, profiles WHERE topics.id != '.$TID.' AND topics.forumid = '.$FID.' AND posts.threadid = topics.id AND posts.poster = profiles.username ORDER BY posts.dateline DESC LIMIT 1');
	   $check_previous->getrow();
	   if ($check_previous->field('title')) { $title = $check_previous->field('title');} else { $title = $check_previous->field('topictitle'); } 
  if ($check_previous->field('title')) { $title = $check_previous->field('title'); } else { $title = $check_previous->field('topictitle'); }
      new query($SQL,'UPDATE forum_display SET lastpost = \''.$check_previous->field('id').'\', lastposter = \''.$check_previous->field('poster').'\', lastposterid = \''.$check_previous->field('UID').'\', lastthreadid = \''.$check_previous->field('TID').'\', lastthread = \''.$title.'\' WHERE forumid = '.$FID);
	   $check_previous->free();
	 } 
     $check_lastpost->free();

	 
	 // Stage 2.3: Subtract x from the forums postcount, also form total postcount -- 1 from forums threadcount, also from total threadcount
	 new query($SQL, 'UPDATE forum_display SET postcount = (postcount - ('.$query_getinfo->field('replies').' + 1)), threadcount = (threadcount - 1) WHERE forumid = '.$FID);
	 new query($SQL, 'UPDATE configuration SET threads = (threads - 1), posts = (posts - ('.$query_getinfo->field('replies').' + 1))');
	 
	 // Stage 2.4: Investigate every post: subtract a post from author and remove it
	 $query_posts = new query($SQL, "SELECT id, poster FROM posts WHERE threadid = $TID");
	 $subtract = array();
	 while ($query_posts->getrow()) {
	    $subtract[$query_posts->field('poster')]++;
		$remove .= $query_posts->field('id') . ',';
	 }

	 $remove = substr($remove,0,(strlen($remove) - 1));
	 new query($SQL, "DELETE FROM posts WHERE (id IN ($remove))");
	 while(list($key, $val) = each($subtract)) { 
	   new query($SQL, "UPDATE profiles SET posts = (posts - $val) WHERE username = '".addslashes($key)."'"); 
	 }
	 new query($SQL, "DELETE FROM topics WHERE id = '".$TID."'");
	 } else { 	 // *****************************************************************************************
	 // * Second: The post is not thread starter, remove it with all signs of it
	 // Stage 2.1: Check if the post is the last post
	 $check_lastpost = new query($SQL, 'SELECT lastpost, lastposter, lastthreadid FROM forum_display WHERE forumid = \''.$FID.'\'');
	 $check_lastpost->getrow();
	 
	 
	 if ($check_lastpost->field('lastpost') == $query_getinfo->field('date') && $check_lastpost->field('lastthreadid') == $TID && $check_lastpost->field('lastposter') == $query_getinfo->field('poster')) {
	 // Stage 2.2: Find the 2nd last post and set this as lastpost
	   $check_previous = new query($SQL, 'SELECT posts.dateline as id, posts.threadid as TID, posts.poster as poster, posts.title as title, topics.title as topictitle, profiles.id as UID FROM posts, topics, profiles WHERE posts.id != '.$PID.' AND topics.forumid = '.$FID.' AND posts.threadid = topics.id AND posts.poster = profiles.username ORDER BY posts.dateline DESC LIMIT 1 ');
	   $check_previous->getrow();
	   if ($check_previous->field('title')) { $title = $check_previous->field('title'); } else { $title = $check_previous->field('topictitle'); }
        new query($SQL,'UPDATE forum_display SET lastpost = \''.$check_previous->field('id').'\', lastposter = \''.$check_previous->field('poster').'\', lastposterid = \''.$check_previous->field('UID').'\', lastthreadid = \''.$check_previous->field('TID').'\', lastthread = \''.$title.'\' WHERE forumid = '.$FID);
	   $check_previous->free();
	 }
   	 $check_lastpost->free();
	 
	 // Stage 2.3: Subtract 1 from the posters postcount & from forums postcount, also form total postcount
	 new query($SQL, 'UPDATE profiles SET posts = (posts - 1) WHERE username = \''.addslashes($query_getinfo->field('poster')).'\'');
	 new query($SQL, 'UPDATE forum_display SET postcount = (postcount - 1) WHERE forumid = '.$FID);
	 new query($SQL, 'UPDATE configuration SET posts = (posts - 1)');
	 
	 // Stage 2.4: Subtract 1 from the topics reply count and get new lastpost if the post is the last reply
	 new query($SQL, 'UPDATE topics SET replies = (replies - 1) WHERE id = \''.$TID.'\'');
	 $query_getlastreply = new query($SQL, 'SELECT posts.isstarter as isthread, posts.dateline as lpdate, posts.poster as lpuser, profiles.id as lastposterid FROM posts, profiles WHERE threadid = '.$TID.' AND posts.id != '.$PID.'  AND profiles.username = posts.poster ORDER BY dateline DESC LIMIT 1');
	 $query_getlastreply->getrow();
	 if ($query_getlastreply->field('isthread')) {
	    new query($SQL, "UPDATE topics SET lpdate = '', lpuser = '', lastposterid = '' WHERE id = ".$TID);
	} else {
	    new query($SQL, 'UPDATE topics SET lpdate = \''.$query_getlastreply->field('lpdate').'\', lpuser = \''.addslashes($query_getlastreply->field('lpuser')).'\', lastposterid = \''.$query_getlastreply->field('lastposterid').'\' WHERE id = '.$TID);
	}
	 $query_getlastreply->free();	
		 
	// Stage 2.5: Remove Post
	new query($SQL, 'DELETE FROM posts WHERE id = '.$PID);
   }
   
gen_redirect('Your topic has been removed!','board.php?FID='.$FID);
}
?>

