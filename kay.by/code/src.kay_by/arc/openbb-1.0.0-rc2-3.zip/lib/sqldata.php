<?php 

if ($SETUPSCRIPT != 1) {	print "<font face=\"Trebuchet MS, Verdana, Arial, Helvetica\"><b>Welcome to OpenBB</b><br>You might want to run <a href=\"setup.php\">setup.php</a> first, before doing anything else ;)";
	exit;
}
?>