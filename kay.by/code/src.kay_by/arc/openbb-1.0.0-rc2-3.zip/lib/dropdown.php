<?php
function forum_dropdown($name, $a = 0, $where = '') {
  global $SQL;
  if ($name == 'forumid') {
     $name = 'FID';
     $outh = '<select name="FID" onchange="window.location=(\'board.php?FID=\'+this.options[this.selectedIndex].value)">';
     $outt = '</select>';     $q = new query($SQL, "SELECT cache FROM cache WHERE name = 'forums:gid".USERGROUP."' LIMIT 1");
     $q->getrow();
     if ($q->field('cache') != '') {		return $outh.$q->field('cache').$outt;	 }
     $q = new query($SQL, "SELECT cache FROM cache WHERE name = 'forums' LIMIT 1");
     $q->getrow();
     return $outh.$q->field('cache').$outt;
  } else if ($name == 'search') {
     $name = 'FID';
     $outh = '<select name="forums[]" size=8 multiple>';     $outh .= '<option value="all" selected>All forums</option>';
     $outt = '</select>';     $q = new query($SQL, "SELECT cache FROM cache WHERE name = 'forums:gid".USERGROUP."' LIMIT 1");
     $q->getrow();
     if ($q->field('cache') != '') {		return $outh.$q->field('cache').$outt;	 }
     $q = new query($SQL, "SELECT cache FROM cache WHERE name = 'forums' LIMIT 1");
     $q->getrow();
     return $outh.$q->field('cache').$outt;
  } else { 
     global $fs;
     $query_forums = new query($SQL, "SELECT title, forumid, type FROM forum_display $where ORDER BY displayorder");
     $output .= "<select name=\"".$name."\">";
     if ($a == 1) { $output .= '<option value="-1" '.$fs[-1].'>None (Stand Alone)</option><option value=\"\"></option>'; }
       $subcat = '-2';
     while ($query_forums->getrow()) {
        $type = $query_forums->field('type');
        if ($type == "1") { 
        $output .= "<option value=\"\"></option><option value=\"".$query_forums->field('forumid')."\" ".$fs[$query_forums->field('forumid')].">".$query_forums->field('title')."</option>\n\n"; 
        $subcat = '0'; 
     } elseif ($type == "2") { $stripes = ''; $s = $subcat + 2; while ($s != 0) { 
        $stripes .= '-'; $s--; 
     } 
     $output .= "\n<option value=\"".$query_forums->field('forumid')."\" ".$fs[$query_forums->field('forumid')].">".$stripes." ".$query_forums->field('title')."</option>\n"; 
     if ($subcat == '0') { $subcat++; } 
     $subcat++;  
  } else { 
     $stripes = ''; $s = $subcat + 2; while ($s != 0) { $stripes .= '-'; $s--; }
     $output .= "<option value=\"".$query_forums->field('forumid')."\" ".$fs[$query_forums->field('forumid')].">".$stripes." ".$query_forums->field('title')."</option>\n"; 
  }
  }
  $output .= "</select>";
  return $output;
  }
  } ?>