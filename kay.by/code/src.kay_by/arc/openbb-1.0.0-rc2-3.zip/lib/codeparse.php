<?php
$mecol = '#EE4100';

$smiley_pattern = array();
$smiley_replacement = array();	
$smiley = array();

$query_smilies = new query($SQL, "SELECT smiley, image FROM smilies");
while ($query_smilies->getrow()) {
   $smiley[trim($query_smilies->field('smiley'))] =  '<img src="{imagepath}/smiley/'.$query_smilies->field('image').'" border="0" alt="'.$query_smilies->field('smiley').'" />';
}
$query_smilies->free();
$pattern = array();
$replacement = array();	
	
$pattern[0] = "#\[url\]([a-z]+?://){1}(.*?)\[/url\]#si";
$pattern[1] = "#\[url\](.*?)\[/url\]#si";
$pattern[2] = "#\[url=([a-z]+?://){1}(.*?)\](.*?)\[/url\]#si";
$pattern[3] = "#\[url=(.*?)\](.*?)\[/url\]#si";
$pattern[4] = "#\[email\](.*?)\[/email\]#si";
$pattern[6] = "#\[img\](.*?)\?(.*?)\[/img\]#si";
$pattern[10] = "#\[link=([0-9]+?)\](.*?)\[/link\]#si";
$pattern[11] = "#\[realaudio](.*?)\[/realaudio\]#si";
$pattern[12] = "#\[email=(.*?)\](.*?)\[/email\]#si";
$pattern[13] = "#\[img=(.*?)\?(.*?)\](.*?)\[/img\]#si";
$pattern[14] = "#\[img=(.*?)\](.*?)\[/img\]#si";
$pattern[15] = "#\[img\](.*?)\[/img\]#si";
$pattern[16] = "#/me (.*?)#si";
$pattern[17] = "#\[color=(.*?)\](.*?)\[/color\]#si";
$pattern[18] = "#\[colour=(.*?)\](.*?)\[/colour\]#si";
$pattern[19] = "#\[font=(.*?)\](.*?)\[/font\]#si";
$pattern[20] = "#\[size=(.*?)\](.*?)\[/size\]#si";
$pattern[21] = "#\[center\](.*?)\[/center\]#si";
$pattern[22] = "#\[glow tcolor=(.*?), fcolor=(.*?), size=(.*?)\](.*?)\[/glow\]#si";

$replacement[0] = '<a href="\1\2" target="_blank">\1\2</a>';
$replacement[1] = '<a href="http://\1" target="_blank">\1</a>';
$replacement[2] = '<a href="\1\2" target="_blank">\3</a>';
$replacement[3] = '<a href="\1" target="_blank">\2</a>';	
$replacement[4] = '<a href="mailto:\1">\1</a>';	
$replacement[6] = '<img src="\1" border="0" alt="\1" />';	
$replacement[10] = '<table><tr> <td style="height : 2; width : 10"><img src="{imagepath}/post.gif" style= "width : 16; height : 16"></td><td height="2"> <font size="2"><a href="read.php?TID=\1">\2</a></font></td></tr></table>';	
$replacement[11] = '<embed src="\\1" type="audio/x-pn-realaudio-plugin" nojava="true" controls="VolumePanel" style="height : 80px; width : 227px;" autostart="true" loop="100">';
$replacement[12] = '<a href="mailto:\1">\2</a>';
$replacement[13] = '<img src="\1" border="0" alt="\3" />';	
$replacement[14] = '<img src="\1" border="0" alt="\2" />';
$replacement[15] = '<img src="\1" border="0" alt="\1" />';
$replacement[16] = '<font color="#ff9933">\1</font>';
$replacement[17] = '<font color="\1">\2</font>';
$replacement[18] = '<font color="\1">\2</font>';
$replacement[19] = '<font face="\1">\2</font>';
$replacement[20] = '<font size="\1">\2</font>';
$replacement[21] = '<center>\1</center>';
$replacement[22] = '<table style="filter:glow(color=\'\1\', strength=1)"><tr><td><font color="\2", size="\3">\4</font></td></tr></table>';

$markup['[b]'] = '<b>';
$markup['[/b]'] = '</b>';
$markup['[u]'] = '<u>';
$markup['[/u]'] = '</u>';
$markup['[i]'] = '<i>';
$markup['[/i]'] = '</i>';
$markup['[B]'] = '<b>';
$markup['[/B]'] = '</b>';
$markup['[U]'] = '<u>';
$markup['[/U]'] = '</u>';
$markup['[I]'] = '<i>';
$markup['[/I]'] = '</i>';
$markup['[quote]'] = '<blockquote><span class="12px">Quote:</span><hr>';
$markup['[/quote]'] = '<hr></blockquote>';

function codeparse ($code, $parseurl, $dsmiley, $username = 'User') {
global $SQL, $config, $smiley, $pattern, $replacement, $markup, $mecol;

        if ($dsmiley != 1) {
           $code = strtr($code, $smiley);
		}
	  
        if ($parseurl != 0) {
	   
		$code = preg_replace("#(\n|^| )([a-z]{3,7})://([^, \n\r]+)#i", "\\1<a href=\"\\2://\\3\" target=\"_blank\">\\2://\\3</a>", $code);	
		$code = preg_replace('#(\n|^| )www\.([a-z0-9\-]+)\.([^, \n\r]+)#i', "\\1<a href=\"http://www.\\2.\\3\">www.\\2.\\3</a>", $code);
		/*   $code = preg_replace("#([a-z]+?)://([^, \n\r]+)\n#i", "<a href=\"\\1://\\2\" target=\"_blank\">\\1://\\2</a>\n", $code);
	   $code = preg_replace("# ([a-z]+?)://([^, \n\r]+)#i", " <a href=\"\\1://\\2\" target=\"_blank\">\\1://\\2</a>", $code);	   

 	   $code = preg_replace("# www\.([a-z0-9\-]+)\.([a-z0-9\-.\~]+)((?:/[^, \n\r]*)?) #i", " <a href=\"http://www.\\1.\\2\\3\">www.\\1.\\2\\3</a> ", $code);
 	   $code = preg_replace("# \nwww\.([a-z0-9\-]+)\.([a-z0-9\-.\~]+)((?:/[^, \n\r]*)?) #i", "\n <a href=\"http://www.\\1.\\2\\3\">www.\\1.\\2\\3</a> ", $code);
           $code = preg_replace("# ([a-z0-9\-_.]+?)@([^, \n\r]+) #i", " <a href=\"mailto:\\1@\\2\">\\1@\\2</a> ", $code);           */
        }

if((eregi('\[', $code) && eregi('\]', $code)) || eregi('/me', $code) || eregi('%', $code)) {
        $code=str_replace("\\'", "'", $code);
        $code=str_replace("'", "\'", $code);
  
        $code = strtr($code, $markup);
		
        $code = " " . $code;


	    $code = str_replace("%me%", '<font color="'.$mecol.'">'.$username.'</font>', $code);
        if ($you = USERNAME) {
           $code = str_replace("%you%", '<font color="'.$mecol.'">'.$you.'</font>', $code);
        } else {
           $code = str_replace("%you%", '<font color="'.$mecol.'">you</font>', $code); 
        }

    $replacement[16] = '<font color="'.$mecol.'">* '.$username.' \1</font>';

	$code = preg_replace($pattern, $replacement, $code);
	$code = substr($code, 1);
}
        return nl2br($code);
}
?>