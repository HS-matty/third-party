<?php
/*
 *
 *  openbb, copyright (c)2001 iansoft
 *  public release beta 1.0.0
 *  http://www.iansoft.net/
 *
 */
$forummanager = 'selected';
function write_cache () {
  global $SQL, $config;
  $defheader = '<a href="index.php">'.$config->field('boardname').'</a> > ';
  $header = $defheader;
  $query_forums = new query($SQL, "SELECT title, forumid, type, parent FROM ".$prefix."forum_display ORDER BY displayorder");
  // $output .= '<select name="FID" onchange="window.location=(\'board.php?FID=\'+this.options[this.selectedIndex].value)">';
  $subcat = '-2';
  while ($query_forums->getrow()) {
     $type = $query_forums->field('type');
     if ($type == '1') { 
	    $header = $defheader;
        $output .= '<option value=""></option><option value="'.$query_forums->field('forumid').'" $fs['.$query_forums->field('forumid').']>'.
        $query_forums->field('title').'</option>'; 
        $subcat = '0';
        $th = $header . '<a href="index.php?CID='.$query_forums->field('forumid').'">'.$query_forums->field('title').'</a>';
        new query($SQL, "UPDATE ".$prefix."navigations SET output = '".addslashes($th)."' WHERE id = 'forum:".$query_forums->field('forumid')."'");
        $header .= '<a href="index.php?CID='.$query_forums->field('forumid').'">'.$query_forums->field('title').'</a> > ';
     } elseif ($type == "2") { $stripes = ''; $s = $subcat + 2; while ($s != 0) { 
        $stripes .= '-'; $s--; 
     } 
     $th = $header . '<a href="index.php?CID='.$query_forums->field('forumid').'">'.$query_forums->field('title').'</a>';
     new query($SQL, "UPDATE ".$prefix."navigations SET output = '".addslashes($th)."' WHERE id = 'forum:".$query_forums->field('forumid')."'");
     $header .= '<a href="index.php?CID='.$query_forums->field('forumid').'">'.$query_forums->field('title').'</a> > ';
     $output .= '<option value="'.$query_forums->field('forumid').'" $fs['.$query_forums->field('forumid').']>'.$stripes.' '.$query_forums->field('title').'</option>'; 
     if ($subcat == '0') { $subcat++; } 
        $subcat++;  
     } else { 
        $stripes = ''; $s = $subcat + 2; while ($s != 0) { $stripes .= '-'; $s--; }
		if ($type == '6') { $stripes .= '--'; }
        
		if ($type != 6) {
		   $nav = $header . '<a href="board.php?FID='.$query_forums->field('forumid').'">'.$query_forums->field('title').'</a> ';
		   $nestedheader = $nav . '> ';
	    } else {
		    $nav = $nestedheader . '<a href="board.php?FID='.$query_forums->field('forumid').'">'.$query_forums->field('title').'</a> ';
		}
		
		
		
        new query($SQL, "UPDATE ".$prefix."navigations SET output = '".addslashes($nav)."' WHERE id = 'forum:".$query_forums->field('forumid')."'");
        $output .= '<option value="'.$query_forums->field('forumid').'" $fs['.$query_forums->field('forumid').']>'.$stripes.' '.$query_forums->field('title').'</option>'; 
     }	
  }
  //$output .= "</select>";
  $defheader = addslashes($defheader);
  new query($SQL, "UPDATE ".$prefix."cache SET cache = '".addslashes($output)."' WHERE name = 'forums'");
  new query($SQL, "UPDATE ".$prefix."navigations SET output = '".$defheader.'Profiles'."' WHERE id = 'profile'");
  new query($SQL, "UPDATE ".$prefix."navigations SET output = '".$defheader.'Memberlist'."' WHERE id = 'memberlist'");
  new query($SQL, "UPDATE ".$prefix."navigations SET output = '".$defheader.'Who is online?'."' WHERE id = 'online'");
  new query($SQL, "UPDATE ".$prefix."navigations SET output = '".$defheader.'My Home'."' WHERE id = 'usercp'");
}

function write_cache_usergroups ($usergroup = -1) {
	global $SQL, $config;
  
	new query($SQL, "DELETE FROM ".$prefix."cache WHERE name LIKE 'forums:gid%'");
	
	if ($usergroups > -1)
		$query_groups = new query($SQL, "SELECT id, forum_cansee FROM ".$prefix."usergroup WHERE id = ".$usergroup." LIMIT 1");
	else
		$query_groups = new query($SQL, "SELECT id, forum_cansee FROM ".$prefix."usergroup");

	$query_forums = new query($SQL, "SELECT title, forumid, type, parent FROM ".$prefix."forum_display ORDER BY displayorder");

	while ($query_groups->getrow()) {

		$fcs_p = array();
		$fcs = array();
		$output = '';
		$usergroup = $query_groups->field('id');
		$fcs_default = $query_groups->field('forum_cansee');
		// $output .= '<select name="FID" onchange="window.location=(\'board.php?FID=\'+this.options[this.selectedIndex].value)">';
		$subcat = '-2';

		$query_fcs = new query($SQL, "SELECT forumid, forum_cansee FROM ".$prefix."forum_permissions WHERE uid = ".$usergroup);
		while ($query_fcs->getrow()) {
			$fcs[$query_fcs->field('forumid')] = $query_fcs->field('forum_cansee');
		}
		$query_fcs->free;
		
			
		$query_forums->seek(0);
		//$query_forums = new query($SQL, "SELECT title, forumid, type, parent FROM ".$prefix."forum_display ORDER BY displayorder");
		
		
		while ($query_forums->getrow()) {
			$type = $query_forums->field('type');
			if ($type == '1') { 
				$fcs_f = isset($fcs[$query_forums->field('forumid')]) ? $fcs[$query_forums->field('forumid')] : $fcs_default;
		
				if ($fcs_f == '1' && !in_array($query_forums->field('parent'), $fcs_p))
					$output .= '<option value=""></option><option value="'.$query_forums->field('forumid').'" $fs['.$query_forums->field('forumid').']>'.$query_forums->field('title').'</option>';
				else
					$fcs_p[] = $query_forums->field('forumid');        
				
				
				
				$subcat = '0';
			} elseif ($type == "2") { $stripes = ''; $s = $subcat + 2; while ($s != 0) { 
				$stripes .= '-'; $s--; 
			}
			
			$fcs_f = isset($fcs[$query_forums->field('forumid')]) ? $fcs[$query_forums->field('forumid')] : $fcs_default;
			if ($fcs_f == '1' && !in_array($query_forums->field('parent'), $fcs_p))
				$output .= '<option value="'.$query_forums->field('forumid').'" $fs['.$query_forums->field('forumid').']>'.$stripes.' '.$query_forums->field('title').'</option>';
			else
				$fcs_p[] = $query_forums->field('forumid');
			if ($subcat == '0') { $subcat++; } 
				$subcat++;
			} else { 
				$stripes = ''; $s = $subcat + 2; while ($s != 0) { $stripes .= '-'; $s--; }
				if ($type == '6') { $stripes .= '--'; }
        
				if ($type != 6) {
				$nav = $header . '<a href="board.php?FID='.$query_forums->field('forumid').'">'.$query_forums->field('title').'</a> ';
				$nestedheader = $nav . '> ';
				} else {
				$nav = $nestedheader . '<a href="board.php?FID='.$query_forums->field('forumid').'">'.$query_forums->field('title').'</a> ';
				}

				$fcs_f = isset($fcs[$query_forums->field('forumid')]) ? $fcs[$query_forums->field('forumid')] : $fcs_default;
				if ($fcs_f == '1' && !in_array($query_forums->field('parent'), $fcs_p))
					$output .= '<option value="'.$query_forums->field('forumid').'" $fs['.$query_forums->field('forumid').']>'.$stripes.' '.$query_forums->field('title').'</option>';
				else
					$fcs_p[] = $query_forums->field('forumid');
			}
		};
		
		// $output .= "</select>";
		new query($SQL, "INSERT INTO ".$prefix."cache (name, cache) values ('forums:gid$usergroup', '".addslashes($output)."')");
	}
	$query_forums->free;
	$query_groups->free;
}

function reindex($forum, $parent, $type) {
  global $SQL;
  
  // #####################################
  // First: Gather info about the Parent
  // #####################################
  // Types
  // a: 1 or 3
  // b: 4 or 6
  // ab: 2

  if ($parent == '-1') { $parents = 'NONE'; $newtype = 'z'; } elseif ($parent == $forum) { $parents = 'ERROR'; $ecode = 'Parent('.$parent.') = Forum('.$forum.')'; } else {
    $q = new query($SQL, "SELECT type, parent FROM ".$prefix."forum_display WHERE forumid = '".$parent."'") or $SQL->error();
    $q->getrow();
    $a = $q->field('type');
    $b = $q->field('parent');
    if (($a == 3) && ($b == '-1')) { $parents = 'STANDALONE_FORUM'; $newtype = 'b'; } 
    if (($a == 3) && ($b != '-1')) { $parents = 'FORUM'; $newtype = 'b'; } 
    if (($a == 1) && ($b == '-1')) { $parents = 'CATEGORY'; $newtype = 'a'; } 
    if ($a == 2) { $parents = 'SUBCATEGORY'; $newtype = 'ab'; }     
    if ($a == 4) { $parents = 'INSIDE_CATEGORY'; $newtype = 'b'; }
    if ($a == 5) { $parents = 'INSIDE_SUBCATEGORY'; $newtype = 'ba'; }
    if ($a == 6) { $parents = 'INSIDE_FORUM'; $newtype = 'b'; }
  }


  // #####################################
  // Second: Assign type to forum
  // #####################################
  if ($parents == 'ERROR') { die('Error has occured: '.$ecode); }
  if (($newtype == z) && ($type == 1)) { $realtype = '1'; }
  if (($newtype == z) && ($type == 2)) { $realtype = '3'; }
  if (($newtype == a) && ($type == 1)) { $realtype = '2'; }
  if (($newtype == a) && ($type == 2)) { $realtype = '3'; }
  if (($newtype == b) && ($type == 1)) { $realtype = '4'; }
  if (($newtype == b) && ($type == 2)) { $realtype = '6'; }
  if (($newtype == ab) && ($type == 1)) { $realtype = '5'; }
  if (($newtype == ab) && ($type == 2)) { $realtype = '6'; }
  new query($SQL, "UPDATE ".$prefix."forum_display SET type = '".$realtype."' WHERE forumid = '".$forum."'");


 /* // #####################################
  // Third: Assign order to forum
  // #####################################  
  $i = 0;
  $q = new query($SQL, "SELECT forumid FROM ".$prefix."forum_display WHERE parent = '-1' ORDER BY type DESC");
  while ($q->getrow()) {
     $i++;
     new query($SQL, "UPDATE ".$prefix."forum_display SET displayorder = $i WHERE forumid = '".$q->field('forumid')."'");
     $q2 = new query($SQL, "SELECT forumid FROM ".$prefix."forum_display WHERE parent = '".$q->field('forumid')."' ORDER BY type DESC");
     while ($q2->getrow()) {
        $i++;
        new query($SQL, "UPDATE ".$prefix."forum_display SET displayorder = $i WHERE forumid = '".$q2->field('forumid')."'");
        $q3 = new query($SQL, "SELECT forumid FROM ".$prefix."forum_display WHERE parent = '".$q2->field('forumid')."' ORDER BY type DESC");
        while ($q3->getrow()) {
        $i++;
        new query($SQL, "UPDATE ".$prefix."forum_display SET displayorder = $i WHERE forumid = '".$q3->field('forumid')."'");
        }
     }
  }
 */}

// new reorder routine, this will modify the displayorder according to the forum[user]order

function reorder () {
	global $SQL;
	$i = 0;
	$q = new query($SQL, "SELECT forumid FROM ".$prefix."forum_display WHERE parent = -1 AND type = 3 ORDER BY forumorder ASC");
	while ($q->getrow()) {
		$i++;
		new query($SQL, "UPDATE ".$prefix."forum_display SET displayorder = $i WHERE forumid = '".$q->field('forumid')."'");
	}
	$q->free;
  
	$q = new query($SQL, "SELECT forumid, title, type, displayorder FROM ".$prefix."forum_display WHERE parent = -1 AND type = 1 ORDER BY forumorder ASC");
	while ($q->getrow()) {
		$i++;
		new query($SQL, "UPDATE ".$prefix."forum_display SET displayorder = $i WHERE forumid = '".$q->field('forumid')."'");
		$q2 = new query($SQL, "SELECT forumid, title, type, displayorder FROM ".$prefix."forum_display WHERE parent = '".$q->field('forumid')."' ORDER BY forumorder ASC");
		while ($q2->getrow()) {
			$i++;
			new query($SQL, "UPDATE ".$prefix."forum_display SET displayorder = $i WHERE forumid = '".$q2->field('forumid')."'");
			$q3 = new query($SQL, "SELECT forumid, title, type, displayorder FROM ".$prefix."forum_display WHERE parent = '".$q2->field('forumid')."' ORDER BY forumorder ASC");
			while ($q3->getrow()) {
				$i++;
				new query($SQL, "UPDATE ".$prefix."forum_display SET displayorder = $i WHERE forumid = '".$q3->field('forumid')."'");
			}
		}
	}
}
function inc_admin_forum_row($type, $title, $id) {
global $include, $TI, $tempvars;
	switch($type) {
	case 1: 
		eval("\$include .= \"".addslashes($TI[62])."\";"); 
		break;
	case 2: 
		eval("\$include .= \"".addslashes($TI[63])."\";"); 
		break;
	case 3: 
		eval("\$include .= \"".addslashes($TI[64])."\";"); 
		break;
	case 4: 
		eval("\$include .= \"".addslashes($TI[76])."\";"); 
		break;
	case 5: 
		eval("\$include .= \"".addslashes($TI[77])."\";"); 
		break;
	case 6: 
		eval("\$include .= \"".addslashes($TI[78])."\";"); 
		break;
	}
}
if ($do == '') {
   $SI['templates'] = '50|37';
   $SI['ref'] = 'Forum Cp';
   define('SCRIPTID','cp');
   require 'base.php';
   write_cache();
   write_cache_usergroups();
   @header('Location: cp.php?do=settings&msg='.urlencode('The cache has been reset...'));
   
   
   
} elseif ($do == 'forums') {
   $SI['templates'] = '50|61|62|63|64|76|77|78';
   $SI['ref'] = 'Forum Cp';
   define('SCRIPTID','cp');
   require 'base.php';
   
   check_perm('forums_canedit',0);

   $query_forums = new query($SQL, "SELECT forumid, title, type,forumorder FROM ".$prefix."forum_display ORDER BY displayorder"); 
while ($query_forums->getrow()) { 
$id = $query_forums->field('forumid'); 
$title = $query_forums->field('forumorder')." - ".$query_forums->field('title');

	  // Top level category
      if ($query_forums->field('type') == 1) { 
         eval("\$include .= \"".addslashes($TI[62])."\";"); 
      }
 
      // sub category
      if ($query_forums->field('type') == 2) { 
         eval("\$include .= \"".addslashes($TI[63])."\";"); 
      }
 
      // normal forum
      if ($query_forums->field('type') == 3) { 
         eval("\$include .= \"".addslashes($TI[64])."\";");  
      }

      // unknown
      if ($query_forums->field('type') == 4) { 
        eval("\$include .= \"".addslashes($TI[76])."\";");  
      }
      
      // sub-sub cat
      if ($query_forums->field('type') == 5) { 
         eval("\$include .= \"".addslashes($TI[77])."\";");  
      }
      // normal sub-forum
      if ($query_forums->field('type') == 6) { 
         eval("\$include .= \"".addslashes($TI[78])."\";");  
      }
   }

   eval("\$include = \"".addslashes($TI[61])."\";"); 
   eval("\$output = \"".addslashes($TI[50])."\";");
   lose($output);


   
} elseif ($do == 'configure') {
   $SI['templates'] = '50|89';
   $SI['ref'] = 'Forum Cp';
   define('SCRIPTID','cp');
   require 'base.php';
   
   check_perm('forums_canedit',0);

   $query_forums = new query($SQL, "SELECT title, description, type, moderators, parent, forumorder FROM ".$prefix."forum_display WHERE forumid = '".$id."'"); 
$query_forums->getrow(); 
$title = $query_forums->field('title'); 
$description = $query_forums->field('description'); 
$moderators = $query_forums->field('moderators'); 
$displayorder = $query_forums->field('forumorder');
 
   if ($query_forums->field('type') == 3 || $query_forums->field('type') == 6) {
       $forum = 'selected';
   } else {
      $category = 'selected';
   }

   
   $where = 'WHERE type < 4 AND forumid != '.$id;
   include 'lib/dropdown.php';
   $fs[$query_forums->field('parent')] = 'selected'; 
   eval("\$forumselector = \"".addslashes(forum_dropdown('parent','1',$where))."\";"); 

   eval("\$include = \"".addslashes($TI[89])."\";"); 
   eval("\$output = \"".addslashes($TI[50])."\";");
   lose($output);
} elseif ($do == 'doconf') {
   $SI['permission'] = 'isadmin';
   $SI['ref'] = 'Unknow';
   require 'base.php';

   if (($parent == '') || ($title == '') || ($type == '') || ($displayorder == '')) { gen_error('Forum add', 'Fill in Title, Choose a parent, fill in a forum order and Select a type (forum or category) please!'); }
   new query($SQL, "UPDATE ".$prefix."forum_display SET title = '".$title."', description = '".$description."', moderators = '".$moderators."', parent = '".$parent."', forumorder = ".$displayorder." WHERE forumid = '".$id."'");
   
   reindex($id, $parent, $type);
   write_cache();
   reorder();
   write_cache_usergroups();
   $q = new query($SQL, "SELECT forumid, type FROM ".$prefix."forum_display WHERE parent = $id");
   while($q->getrow()) {
      if (($q->field('type') == 3) || ($q->field('type') == 6)) { $type = 2; } else { $type = 1; }
      reindex($q->field('forumid'), $id, $type);
   }

  @header("Location: cp_forums.php?do=forums");
} elseif ($do == 'remove') {
   $SI['ref'] = 'Forum Cp';
   define('SCRIPTID','cp');
   require 'base.php';
   
   check_perm('forums_canedit',0);



   new query($SQL, "UPDATE ".$prefix."forum_display SET parent = '-1' WHERE parent = '".$id."'");
   new query($SQL, "DELETE ".$prefix."from forum_display WHERE forumid = '".$id."'");
   new query($SQL, "DELETE ".$prefix."from navigations WHERE id = 'forum:".$id."'");
   reorder();
   write_cache();
   write_cache_usergroups();

  @header("Location: cp_forums.php?do=forums");
} elseif ($do == 'new') {
   $SI['templates'] = '50|90';
   $SI['ref'] = 'Forum Cp';
   define('SCRIPTID','cp');
   require 'base.php';

   $where = 'WHERE type < 4';
   include 'lib/dropdown.php';
   $forumselector = forum_dropdown('parent','1',$where);

   eval("\$include = \"".addslashes($TI[90])."\";"); 
   eval("\$output = \"".addslashes($TI[50])."\";");
   lose($output);
} elseif ($do == 'donew') {
   $SI['ref'] = 'Forum Cp';
   define('SCRIPTID','cp');
   require 'base.php';

   if (($parent == '') || ($title == '') || ($type == '')) { gen_error('Forum add', 'Fill in Title, Choose a parent and Select a type (forum or category) please!'); }
   $q = new query($SQL, "SELECT forumid FROM ".$prefix."forum_display ORDER BY forumid DESC LIMIT 1");
   
   $q->getrow();
   $id = $q->field('forumid') + 1;
   if ($displayorder == '') {
      $q = new query($SQL, "SELECT forumorder FROM ".$prefix."forum_display WHERE parent = $parent ORDER BY displayorder DESC LIMIT 1");
   
      $q->getrow();
      $displayorder = $q->field('forumorder') + 1;
   }
      
   new query($SQL, "INSERT INTO ".$prefix."forum_display (forumid, title, description, moderators, parent, forumorder) VALUES ('".$id."', '".$title."','".$description."','".$moderators."','".$parent."',".$displayorder.")");
   new query($SQL, "INSERT INTO ".$prefix."navigations VALUES ('forum:$id','')");
   reindex($id, $parent, $type);
   reorder();
   write_cache();
   write_cache_usergroups();

  @header("Location: cp_forums.php?do=forums");
} elseif ($do == 'templaterestore') {
   

  @header("Location: cp_forums.php?do=forums");
}
?>