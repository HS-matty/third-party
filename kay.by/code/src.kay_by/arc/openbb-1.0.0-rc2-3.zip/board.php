<?php
/*
 *
 *  openbb, copyright (c)2001 iansoft
 *  public release beta 1.0.0
 *  http://www.iansoft.net/
 *
 *  Niels Van der Wildt <niels@iansoft.net>
 *  Kelly Hamlin <kelly@iansoft.net>
 *
 */


// ###############################
//           START INIT
// ###############################


define('SCRIPTID','board/display');
$SI['settings'] = 'tlistperpage, plistperpage';
$SI['templates'] = '5|7|36|47|91|27|8|75|119|118|117|133|134|2|3|120|121|135|136|139';
$SI['ref'] = 'Loading Board <a href="board.php?FID='.$FID.'">'.$FID.'</a>';
require 'base.php';

if (NUKE) {   
  if(!isset($mainfile)) { include("mainfile.php"); }
   if (!eregi("modules.php", $PHP_SELF)) {
     die ("You can't access this file directly...");
  }
}

  $privilege = check_perm('forum_canview,thread_canpost,thread_canreply',1);
   $frms = explode("|", $HTTP_COOKIE_VARS['forums']);
   $con = 1;
   while (list($key,$val) = each($frms)) {
      $prop = explode("=", $val);     
      $cookie_forums[$prop[0]] = $prop[1];
   }
   if ($cookie_forums['lastforum'] && $cookie_forums['lastforum'] != $FID) {
      $ltime = $cookie_forums['lasttime'];
	  $cookie_forums[$cookie_forums['lastforum']] = $ltime;
      $cookie_forums['lastforum'] = '';
   }

// ###############################
//        CHECK FOR ERRORS
// ###############################
if (!$FID) { gen_error('No Forum specified!','Go back to the index page and try again.'); }


$query_forum = new query($SQL, "SELECT moderators, title, threadcount, type FROM ".$prefix."forum_display WHERE forumid = $FID");
if (!$query_forum->getrow()) {
   gen_error('Invalid Board!','Go back to the index page and try again.');
}
if ($query_forum->field('type') != 3 && $query_forum->field('type') != 6) { @header("Location: index.php?CID=".$FID);       }



// ###############################
//            GAIN INFO
// ###############################

$FNAME = $query_forum->field('title');
new query($SQL, "UPDATE ".$prefix."active SET location = 'Viewing Board <a href=\"board.php?FID=$FID\">".addslashes($FNAME)."</a>' WHERE record = '".RECORD."'");


$forum_lastvisit = $cookie_forums[$FID];
$nav = getnav('forum:'.$FID);
$mod_forum = $query_forum->field('moderators');
if (!empty($mod_forum)) {
	$moderators = explode("," , trim($query_forum->field('moderators')));
	$mod_num = count($moderators);
	$mod_id = 0;
	while ($mod_id < $mod_num) {
		$get_id = new query($SQL, "SELECT id FROM ".$prefix."profiles WHERE username = '".$moderators[$mod_id]."'");
		$get_id->getrow();
		$id = $get_id->field('id');
		$moderator .= "<a href=\"member.php?action=profile&UID=$id\">$moderators[$mod_id]</a>, ";
		$mod_id++;
	}
	$moderators = $moderator;
} else {
	$moderators = "None";
}
if ($moderators) { eval("\$moderators = \"".addslashes($TI[139])."\";"); }

// ### Start Page System ###
$tlistperpage = $config->field('tlistperpage');
$count = ($query_forum->field('threadcount') / $tlistperpage);
$pages = ceil($count);
$query_forum->free();

if ($page == '') { 
   $page = 1; 
}
$topics = 0;
$start = (($page - 1)*$tlistperpage);



// ###############################
//           NESTED FORUMS
// ###############################
$fid = $FID;
$query_forums = new query($SQL, "SELECT guest, forumid, lastpost, lastthread, lastposterid, lastposter, lastthreadid, title, description, type, postcount, threadcount, moderators FROM ".$prefix."forum_display WHERE type = 6 AND parent = '".$FID."' ORDER BY displayorder");
while ($query_forums->getrow()) {

     $nested = 1;
     $FID = $query_forums->field('forumid');
	 $lg = $query_forums->field('guest');
     $forumname = $query_forums->field('title');
     $description = $query_forums->field('description');
		 if (!isset($moderators)) {
			$moderators = explode("," , trim($query_forum->field('moderators')));
			$mod_num = count($moderators);
			$mod_id = 0;
			while ($mod_id < $mod_num) {
				$get_id = new query($SQL, "SELECT id FROM ".$prefix."profiles WHERE username = '".$moderators[$mod_id]."'");
				$get_id->getrow();
				$id = $get_id->field('id');
				$moderator .= "<a href=\"member.php?action=profile&UID=$id\">$moderators[$mod_id]</a>, ";
				$mod_id++;
			}
			$moderators = $moderator;
		 }
	 if ($cookie_forums[$FID] == '') { $cookie_forums[$FID] = time(); }

     $posts = $query_forums->field('postcount');
     $threads = $query_forums->field('threadcount');
     $check[lastpost] = $query_forums->field('lastpost');
     if (!($check[lastvisit] = $cookie_forums[$FID])) { $check[lastvisit] = 0; }
	 if ($check[lastpost] > $check[lastvisit] && $check[lastpost] != 0) { $icon = 'on.gif'; } else { $icon = 'off.gif'; }
		
     if ($FID == $lastforum) { $check[lastvisit] = $ltime; }
	     unset ($lastpost);
         $lastpost[poster] = $query_forums->field('lastposter');
         $lastpost[date] = gmdate($timeformat[3], ($check[lastpost] + $offset));
         $lastpost[TID] = $query_forums->field('lastthreadid'); // Lastpost threadid
         $lastpost[UID] = $query_forums->field('lastposterid'); // Lastpost Postid
         $lastpost[title] = $query_forums->field('lastthread'); // Lastpost Postid
     
		   
		 if ($lg) {
		    eval("\$lastpost = \"".addslashes($TI[121])."\";");
		 } else {
		    eval("\$lastpost = \"".addslashes($TI[120])."\";");
		 }
             eval("\$include .= \"".addslashes($TI[134])."\";");  
     }

    $query_forums->free();
	
if ($nested) {
   eval("\$nested = \"".addslashes($TI[133])."\";"); 
}
$include = '';
$FID = $fid;

	

// ###############################
//           LIST TOPICS
// ###############################

$query_topics = new query($SQL, "SELECT topics.description as description, topics.pollid as poll, topics.lastguest as wasguest, topics.guest as isguest, topics.dateline as dateline, topics.id as id, topicicons.image as topicicon, topics.title as title, topics.lpuser as lpuser, topics.lpdate as lpdate, topics.locked as locked, topics.poster as poster, topics.posterid as UID, topics.lastposterid as lastposterid, topics.replies as replies, topics.mode as mode, topics.smode as smode, topics.toforumid as toforumid, topics.totopic as totopic, topics.views as views FROM ".$prefix."topics, ".$prefix."topicicons WHERE forumid = $FID AND topics.icon = topicicons.id ORDER by smode DESC, lpdate DESC LIMIT $start,$tlistperpage");

while ($query_topics->getrow()) {
  unset($lastpost);
   $TID = $query_topics->field('id');
   $replies = $query_topics->field('replies');
   $views = $query_topics->field('views');
   $topicicon = $query_topics->field('topicicon');
   $starter = $query_topics->field('poster');
   $description = $query_topics->field('description');
   $gp = $query_topics->field('isguest');
   $gp2 = $query_topics->field('wasguest');
   $poll =  $query_topics->field('poll');
   $UID = $query_topics->field('UID');
   $threadimage = 'images/blank.gif';
   $posttime = gmdate($timeformat[3], ($query_topics->field('dateline') + $offset));
   
   $lastpost[UID] = $query_topics->field('lastposterid');


$plistperpage = $config->field('plistperpage');
//print "$replies >= $plistperpage";
   if ($replies >= $plistperpage) {
      $count = (($replies + 1) / $plistperpage);
      //$tmp2 = explode(".", $count);
      $pages2 = ceil($count);
      //if (!$tmp2[1] || substr($tmp2[1],0,1) > 0) { $pages2++; }
      $tmp = $pages2;
      $i = 0;
      $pagelink = '';
      if ($pages2 > 5)
        $tmp = 3;
      while ($tmp != 0) {
         $i++;
         $tmp--;
         if($s = $query_topics->field('toforumid') && $s2 = $query_topics->field('totopic')) {
            $pagelink .= '<a href="read.php?TID='.$s2.'&page='.$i.'"><font color="#000000">'.$i.'</font></a> ';
         } else {
            $pagelink .= '<a href="read.php?TID='.$TID.'&page='.$i.'"><font color="#000000">'.$i.'</font></a> ';
         }
      }
if ($pages2 > 5)
	$pagelink .= '... <a href="read.php?TID='.$TID.'&page='.$pages2.'">Last</a>';
      $multipage = '( '.$pagelink.' )';
   } else { 
      $multipage = ''; 
   }


   $check[lastpost] = $query_topics->field('lpdate');
   if ($cookie_forums[$FID.','.$TID]) {
     $check[lastvisit] = $cookie_forums[$FID.','.$TID];
   } else {
     $check[lastvisit] = $forum_lastvisit;
   }
   
   if ($check[lastpost] > $check[lastvisit] && $check[lastpost] != 0) { $icon = 'topic-on'; } else { $icon = 'topic-off'; }
   
   if ($query_topics->field('lpuser') != '') {
      $lastpost[poster] = $query_topics->field('lpuser');
      $lastpost[date] = gmdate($timeformat[3], ($check[lastpost] + $offset));
	  
	  if (!$gp2) {
         eval("\$lastpost = \"".addslashes($TI[47])."\";");
	  } else {
         eval("\$lastpost = \"".addslashes($TI[118])."\";");	  }
    } 

      else {

      if($gp2 == '1') { 
      $lastpost[date] = gmdate($timeformat[3], ($check[lastpost] + $offset));
      eval("\$lastpost = \"".addslashes($TI[118])."\";"); }
  
      else {
      $lastpost[poster] = $query_topics->field('poster');
	  $lastpost[UID] = $UID;
      $lastpost[date] = $posttime;
	  if (!$gp) {
         eval("\$lastpost = \"".addslashes($TI[91])."\";");
	  } else {
         eval("\$lastpost = \"".addslashes($TI[119])."\";");	  
	  }
   }
   }
   if ($poll) { $icon .= '-poll'; }
     
   $dostatus = 1;
   $mode = $query_topics->field('smode');
   
   if ($query_topics->field('locked') == '1') { 
      $icon .= '-lock';
   } else { } 
   
   if ($mode == 0) {
      $title = $query_topics->field('title');
      if ($poll) {
	     $mode = 'Poll:';
	  } else {
	     $mode = '';
      }
   } else {
      $title = $query_topics->field('title');
      $mode = $query_topics->field('mode') . ': ';
   }

   $icon .= '.gif';
   if ($s = $query_topics->field('toforumid')) {
      $newforumid = $s;
      $TID = $query_topics->field('totopic');
      // TODO: template ID 27, remake the moved topic link
      // leave only one step traceable
      eval("\$include .= \"".addslashes($TI[27])."\";"); 
   } else {  
    if (!$gp) {
       eval("\$include .= \"".addslashes($TI[7])."\";"); 
	} else {
       eval("\$include .= \"".addslashes($TI[117])."\";"); 
	}
   }
   $topics++; 
}



if ($topics == 0) { 
   eval("\$include .= \"".addslashes($TI[8])."\";"); 
}


$query_topics->free();


if (!$pages) { $pages = 1; }
$pagelink = '';
$tmp = $pages;
$pagenumber = 0;

while ($tmp != 0) {
   $pagenumber++;
   $tmp--;
   if ($pagenumber == $page) { 
        if ($page == 1) {
		   $prevlast = 1;
		} else {
		    $previouspage = $page - 1;
		}
        eval("\$pagelink .= \"".addslashes($TI[136])."\";");  
		$getnext = 1;
	} else {
	    if ($getnext) { 
		   $getnext = 0;
		   $nextpage = $pagenumber;
		}
	    eval("\$pagelink .= \"".addslashes($TI[135])."\";"); 
	}
}

if ($prevlast) { 
   $prevlast = 0;
   $previouspage = $pagenumber;
}

if ($getnext) { 
   $getnext = 0;
   $nextpage = 1;
}

// ###############################
//             FINALIZE
// ###############################

if ($privilege->field('thread_canpost') || ADMIN) { $priv[newtopic] = $true; } else { $priv[newtopic] = $false; }
if ($privilege->field('thread_canreply') || ADMIN) { $priv[reply] = $true; } else { $priv[reply] = $false; }

$cookie_forums['lasttime'] = time();
$cookie_forums['lastforum'] = $FID;
   while (list($key,$val) = each($cookie_forums)) {
   if ($key != '') {
      $cookie .= $key . '='. $val . '|';
   }
   }
   setcookie('forums',$cookie,$expire,$config->field('cookiepath')); 
   
require 'lib/dropdown.php';
$fs[$FID] = 'selected';

eval("\$selectbox = \"".addslashes(forum_dropdown('forumid'))."\";"); 
eval("\$forumnav = \"".addslashes($TI[36])."\";");
 
$title = 'Viewing Board: '.$FNAME;

eval("\$include = \"".addslashes($TI[5])."\";"); 
eval("\$output = \"".addslashes($TI[0])."\";");

lose($output);
?>