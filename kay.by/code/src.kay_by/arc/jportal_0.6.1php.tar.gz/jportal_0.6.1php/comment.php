<?
include ("admin/config.php");

function write_comment($id,$parent){
include ("themes/header.php");
$title = ""._ADD_COMMENT."";
open_table($title);
echo "<table align=\"center\" width=\"100%\">
<tr>
	<td valign=\"top\" width=\"100%\">
	<form action=\"comment.php?op=add&id=".$id."\" method=\"POST\"> 
	<span class=\"text\" size=\"2\">"._TITLE."&nbsp;&nbsp;</span>
	<input type=\"text\" name=\"comment[title]\" size=\"20\">
	<input type=\"hidden\" name=\"comment[aid]\"  value=\"".$id."\" size=\"20\">
	<input type=\"hidden\" name=\"comment[parent]\" value=\"$parent\">
	<input type=\"hidden\" name=\"comment[date]\" value=\"".date("d.m. Y")."\"  size=\"20\"><br><br>
	<span class=\"text\" size=\"2\">"._TEXT."</span> 
	<textarea name=\"comment[text]\" rows=\"10\" cols=\"30\"></textarea><br><br> 
	<span class=\"text\" size=\"2\">"._NAME."&nbsp;&nbsp;</span>
	<input type=\"text\" name=\"comment[name]\" size=\"20\"><br><br>
	<span class=\"text\" size=\"2\">"._EMAIL."&nbsp;&nbsp;&nbsp;&nbsp;</span>
	<input type=\"text\" name=\"comment[email]\" size=\"20\"> <br><br>
	<input type=\"hidden\" name=\"task\" value=\"add\">
        <input class=\"button\" type=\"submit\" size=\"12\" value=\""._SEND."\" name=\"submit\">
</form></td>
</tr></table>"; 
close_table();
include ("themes/footer.php");
}

function add_comment($comment, $id){
	global $DBhost,$DBuser, $DBpass; 
	include ("themes/header.php");
	$title = ""._COMMENT_OK."";
	open_table($title);
	mysql_connect($DBhost,$DBuser, $DBpass); 
	mysql_select_db("$DBname"); 
	
	$sql = "INSERT INTO comments (aid, parent, name, email, title, text, date) VALUES ('$comment[aid]','$comment[parent]' ,'$comment[name]', '$comment[email]', '$comment[title]', '$comment[text]', '$comment[date]')"; 
	$sql1 = "UPDATE articles SET comment_counter=comment_counter+1 WHERE id=$comment[aid]";
	mysql_query($sql)or die("ERROR, try it again...".mysql_error()); 
	mysql_query($sql1)or die("ERROR, try it again...".mysql_error()); 
	echo "<center><span class=\"text\"><a href=\"articles.php?op=read&id=".$id."\">"._BACK_TO_ARTICLE."</a></span></center>";
	close_table();
	include ("themes/footer.php");
}

function view_comment($id){
	include ("admin/config.php");
	include ("tree.php");
	function comments_sdir(){echo "\n<dir>\n";}
        function comments_edir(){echo "</dir>\n";}
	function comments_make($spaces,$vysl){
//			echo str_repeat(" ",$spaces);
//			echo "".$vysl["text"]."\n";
//			echo "
//<b><span class=\"text\">".$vysl["title"]."".
//" by ".$vysl["name"]." (".$vysl["date"].")</span><a href=\"comment.php?op=write&parent=".$vysl["id"]."&id=".$vysl["aid"]."\">"._REPLY."</a></b>\n<br><span class=\"text\">".$vysl["text"]."</span><br>\n";
//
//			echo str_repeat(" ",$spaces);
//			echo "<b><span class=\"text\">".$vysl["title"]." by ".$vysl["name"]." (".$vysl["date"].")</span><br>\n";
			echo "<b><span class=\"text\">".$vysl["title"]."</b>".
"<b> by ".$vysl["name"]." (".$vysl["date"].")<a href=\"comment.php?op=write&parent=".$vysl["id"]."&id=".$vysl["aid"]."\">"._REPLY."</a></span></b>\n";


	}
	

	//takto by  to melo fungovat ale config musi byt includovat mimo funkce
	//global $DBhost, $DBuser, $DBpass,$DBname; 
	echo "\n\n<!-- comments -->\n";
	$database_server = mysql_connect("$DBhost","$DBuser","$DBpass"); 
	mysql_select_db($DBname); 
	echo mysql_error();	
	$op[sdir]=comments_sdir;
        $op[edir]=comments_edir;
        $op[make]=comments_make;
        $op[table]="comments";
        $op[want]="*";
//	echo "<div align=left>";
	gettree($op, $id);
//	echo "</div>";
	
	echo "\n\n<!-- end of comments -->\n";
}

function view_all_comment($id){
	function comments_sdir(){echo "\n<dir>\n";}
        function comments_edir(){echo "</dir>\n";}
	function comments_make($spaces,$vysl){
/*			echo str_repeat(" ",$spaces);
			echo "".$vysl["text"]."\n";
*/			echo "
<b><span class=\"text\">".$vysl["title"]."".
" by ".$vysl["name"]." (".$vysl["date"].")<a href=\"comment.php?op=write&parent=".$vysl["id"]."&id=".$vysl["aid"]."\">"._REPLY."</a></span></b>\n<br><span class=\"text\"><p ALIGN=justify>".$vysl["text"]."</p></span>\n";

	}
														
	include ("admin/config.php");
	include ("tree.php");
	include ("themes/header.php");
	$title = ""._ALL_COMMENT."";
	open_table($title);
	$database_server = mysql_connect("$DBhost","$DBuser","$DBpass"); 
	mysql_select_db("$DBname", $database_server); 

	$op[sdir]=comments_sdir;
        $op[edir]=comments_edir;
        $op[make]=comments_make;
        $op[table]="comments";
        $op[want]="*";
	gettree($op, $id);
	
	
	close_table();										
	include ("themes/footer.php");
}

switch($op) {
    case "add":
    	add_comment($comment, $id);
	break;
    case "view":
	view_all_comment($id);
	break;
    case "write":
    	if(!isset($parent))
		$parent=0;
    	write_comment($id,$parent);
	break;
}
?>

