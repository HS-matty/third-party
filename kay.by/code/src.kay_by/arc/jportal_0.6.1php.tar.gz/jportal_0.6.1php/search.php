<?

switch($op){
	case "search":
	include ("themes/header.php");
	include ("function/search.inc");
	what_search($query, $type);
	include ("themes/footer.php");
	break;
}

?>
