<? 
switch ($op) {

case "main":
    include ("admin/config.php");
    include ("themes/header.php");
    include ("function/download.inc");
    section_a();
    include ("themes/footer.php");
    break;

    case "download":
    include ("function/download.inc");
    down_up($id, $url);
    break;
    
    case "down_section":
    include ("admin/config.php");
    include ("themes/header.php");
    include ("function/download.inc");
    section($id, $section);
    include ("themes/footer.php");
    break; 
}
?> 
