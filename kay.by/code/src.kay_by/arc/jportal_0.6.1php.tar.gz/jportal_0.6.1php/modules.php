<? 
//simple modules system//
include ("admin/config.php");
include ("function/language/lang.".$lang."");

switch($op){
    case "load":
    include ("themes/header.php");
    include ("function/modules.inc");
    modules($modules_name);
    include ("themes/footer.php"); 
break;
}

?>
