<? 
switch ($op) {

case "main":
    include ("admin/config.php");
    include ("themes/header.php");
    include ("function/guestbook.inc");
    guest_book();
    include ("themes/footer.php");
    break;

case "add_to_book":
    include ("admin/config.php");
    include ("themes/header.php");
    include ("function/guestbook.inc");
    add_book();
    include ("themes/footer.php");
    break; 

case "create_book":    
    include ("admin/config.php");
    include ("themes/header.php");
    include ("function/guestbook.inc");
    create_book($book);
    include ("themes/footer.php");
    break; 
}
?> 
