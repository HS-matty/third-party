<?
include ("admin/config.php");
include ("function/language/lang.$lang");
$database_server = mysql_connect("$DBhost","$DBuser","$DBpass"); 
mysql_select_db("$DBname", $database_server); 

echo "<center><b>"._INSTALL_MESS."$jportal_vs</b></center><br>";

print ""._ART_TABLE.".....";
$articles = MySQL_Query("Create table articles (id int(4) NOT NULL auto_increment, section_id int(4) NOT NULL, autor varchar(255) default NULL, title varchar(255) default NULL, counter bigint(21) unsigned NOT NULL default '0', comment_counter bigint(21) unsigned NOT NULL default '0', short text, text text, date text, PRIMARY KEY  (id))");
$insert = MySQL_Query("INSERT INTO articles VALUES ('1', '1', 'jow(IK)', 'Prvni clanek v JpoRtaLu v0.6', '65', '', 'Tak tohle je kratky text v nove verzi JpoRtaLu...',  'Tohle je dlouhy neboli hlavni text clanku...', '3. 11. 2001')");
if (!$articles && !$insert) {
  echo ""._TABLE_ERROR."\n";
  echo MySQL_Error();
  echo "<br>";
} 
else
{
print ""._OK."<br>";
}

print ""._DOWN_TABLE.".....";
$download = MySQL_Query("CREATE TABLE down ( id int(4) NOT NULL auto_increment, section_id int(4) NOT NULL, title varchar(60) NOT NULL, url varchar(120) NOT NULL, counter bigint(21) unsigned NOT NULL default '0', descript text, vers varchar(60) NOT NULL, PRIMARY KEY (id))");
$insert = MySQL_Query("INSERT INTO down VALUES ('1', '1', 'JpoRtaL v0.6', 'http://portalky.3web.cz/download/jportal_v06.zip', '', 'Nova verze portaloveho systemu JpoRtaL ve verzi 0.6', '0.6')");
if (!$download && !$insert) {
  echo ""._TABLE_ERROR."\n";
  echo MySQL_Error();
  echo "<br>";
} 
else
{
print ""._OK."<br>";
}

print ""._LINKS_TABLE.".....";
$links = MySQL_Query("CREATE TABLE links (id int(4) NOT NULL auto_increment, section_id int(4) NOT NULL, title varchar(60) NOT NULL default '', descript blob, url varchar(120) NOT NULL default '', PRIMARY KEY  (id))");
$insert = MySQL_Query("INSERT INTO links VALUES ('1', '1', 'JpoRtaL.homepage', 'Domovska stranka projektu JpoRtaL...', 'http://portalky.3web.cz')");
if (!$links && !$insert) {
  echo ""._TABLE_ERROR."\n";
  echo MySQL_Error();
  echo "<br>";
} 
else
{
print ""._OK."<br>";
}

print ""._NEWS_TABLE.".....";
$news = MySQL_Query("CREATE TABLE shortnews (id int(4) NOT NULL auto_increment, title varchar(60) NOT NULL default '', text text, PRIMARY KEY  (id))");
$insert = MySQL_Query("INSERT INTO shortnews VALUES ('1', 'Kratke novinky', 'Tak tady muzete psat kratke novinky...')");
if (!$news && !$insert) {
  echo ""._TABLE_ERROR."\n";
  echo MySQL_Error();
  echo "<br>";
} 
else
{
print ""._OK."<br>";
}

print ""._COMM_TABLE.".....";
$comm = MySQL_Query("CREATE TABLE comments (id int(4) NOT NULL auto_increment, aid int(3) DEFAULT '0' NOT NULL, parent int, date varchar(20) NOT NULL,  name varchar(80) NOT NULL, email varchar(80) NOT NULL, title varchar(80) NOT NULL, text text NOT NULL, PRIMARY KEY (id), UNIQUE id (id))");
if (!$comm) {
  echo ""._TABLE_ERROR."\n";
  echo MySQL_Error();
  echo "<br>";
} 
else
{
print ""._OK."<br>";
}

print ""._USERS_TABLE.".....";
$user = MySQL_Query("CREATE TABLE users (id int(4) NOT NULL auto_increment, date varchar(20) NOT NULL, name varchar(80) NOT NULL, pass varchar(80) NOT NULL, email varchar(80) NOT NULL, title varchar(80) NOT NULL, userkey varchar(80), text text NOT NULL, PRIMARY KEY (id), UNIQUE id (id))");
$insert = MySQL_Query("INSERT INTO users VALUES ('1', '', 'admin', 'password', 'admin@yoursite.com', 'Administrator', '', 'Tady muzete vlozit kratky textik o uzivateli...')");
if (!$user && !$insert) {
  echo ""._TABLE_ERROR."\n";
  echo MySQL_Error();
  echo "<br>";
} 
else
{
print ""._OK."<br>";
}

print ""._SECTION_TABLE.".....";
$art_section = MySQL_Query("CREATE TABLE article_section (id int(4) NOT NULL auto_increment, name text NOT NULL, image text NOT NULL, descript text NOT NULL, PRIMARY KEY (id))");
$down_section = MySQL_Query("CREATE TABLE down_section (id int(4) NOT NULL auto_increment, name text NOT NULL, descript text NOT NULL, PRIMARY KEY (id))");
$link_section = MySQL_Query("CREATE TABLE link_section (id int(4) NOT NULL auto_increment, name text NOT NULL, descript text NOT NULL, PRIMARY KEY (id))");
$art_insert = MySQL_Query("INSERT INTO article_section VALUES ('1', 'JpoRtaL', '', 'Clanky o JpoRtaLu...')");
$down_insert = MySQL_Query("INSERT INTO down_section VALUES ('1', 'JpoRtaL', 'Nove verze a update pro JpoRtaL v0.6')");
$link_insert = MySQL_Query("INSERT INTO link_section VALUES ('1', 'Odkazy na...', 'Odkazy na zajimave projektiky...')");
if (!$art_section && !$down_section && !$link_section && !$art_insert && !$down_insert && !$link_insert) {
  echo ""._TABLE_ERROR."\n";
  echo MySQL_Error();
  echo "<br>";
} 
else
{
print ""._OK."<br>";
}

print ""._BLOCK_TABLE.".....";
$block = MySQL_Query("CREATE TABLE blocks (id int(11) NOT NULL auto_increment, position char(1) NOT NULL default '', type char(1) default '0', row int(11) default NULL, title varchar(50) default NULL, content text, PRIMARY KEY  (id), UNIQUE id (id))");
$insert = MySQL_Query("INSERT INTO blocks VALUES ('2', 'L', '', '2', 'Ostatni', '<a href=modules.php?op=load&modules_name=kontakt>Kontakt</a><br><a href=modules.php?op=load&modules_name=license>GNU licence</a>')");
if (!$block && !$insert) {
  echo ""._TABLE_ERROR."\n";
  echo MySQL_Error();
  echo "<br>";
} 
else
{
print ""._OK."<br>";
}

print ""._GUESTBOOK_TABLE.".....";
$guestbook = MySQL_Query("CREATE TABLE guestbook (id int(11) NOT NULL auto_increment, title varchar(50) default NULL, date text, autor varchar(50) default NULL, email varchar(50) default NULL, web varchar(50) default NULL, text text, PRIMARY KEY  (id), UNIQUE id (id))");
$insert = MySQL_Query("INSERT INTO guestbook VALUES ('1', 'Test', '18. 11. 2001', 'autor', 'test@email.cz', 'http://web.xx', 'Tady muzete napsat co chcete:))')");
if (!$guestbook && !$insert) {
  echo ""._TABLE_ERROR."\n";
  echo MySQL_Error();
  echo "<br>";
} 
else
{
print ""._OK."<br>";
}

print ""._OPTION_TABLE.".....";
$option = MySQL_Query("CREATE TABLE options (id int(4) NOT NULL auto_increment, counter varchar(255) NOT NULL, PRIMARY KEY (id), UNIQUE id (id))");
$insert = MySQL_Query("INSERT INTO options VALUES ('1', '0')");
if (!$option && !$insert) {
  echo ""._TABLE_ERROR."\n";
  echo MySQL_Error();
  echo "<br>";
} 
else
{
print ""._OK."<br>";
}

echo "<br><center><b>".ALL_OK." -> <a href=index.php?op=new>"._FINISH."</a></b></center>";

?> 
