<? 
switch ($op) {

case "main":
    include ("admin/config.php");
    include ("themes/header.php");
    include ("function/links.inc");
    link_section_a();
    include ("themes/footer.php");
    break;

    case "links_section":
    include ("admin/config.php");
    include ("themes/header.php");
    include ("function/links.inc");
    link_section($id, $section);
    include ("themes/footer.php");
    break; 
}
?> 
