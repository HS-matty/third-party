<?
/*
	nevim jak se to bude lepe hodit jsetli pres class neob array
	pres class:
		nadefinujes si class neco jako je to dole ale pred zavolanim musis pouzit $a=new Comments; a pak volat funkci gettree($a);
	pres array (pole):
		nadefinujes pole $op[sdir]=funkce; 

	podle toho ktery chces to musis v gettree upravit bud $op->sdir(); nebo $op[sdir]();
	 promenne:
	    want--ktere sloupecky chces z database vyzvednout(musi tam byt id,prent)
	    table--no comment
	 funkce make se vola s parametry (spaces,vysl)
	   spaces -- hloubka (je to potreba???) 
	     vysl -- pole s vyzvednutyma sloupeckama  

*/

	function gettree($op, $id, $parent=0, $spaces=1){
		$query=mysql_query("select ".$op[want]." from ".$op[table]." where parent=$parent and aid=$id order by id") or die("Fuck mysql\n");
		if(mysql_num_rows($query)==0)
			return;
		$op[sdir]();
		while($vysl=mysql_fetch_array($query)){
			$op[make]($spaces,$vysl);
			gettree($op, $id, $vysl["id"],$spaces+1);
		}
		$op[edir]();
		
	}
	
?>
