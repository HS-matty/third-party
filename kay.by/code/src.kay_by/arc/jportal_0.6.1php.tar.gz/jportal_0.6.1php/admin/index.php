<?
include ("config.php");
include ("modules/language/lang.".$lang."");
include ("function/login.inc");

mysql_connect($DBhost,$DBuser,$DBpass);
mysql_select_db($DBname);

switch(login()){	
	case 1:/*not login*/
    		echo "<center><span class=\"text\">A username and password with administrative privileges are required for access to these pages.</span></center>\n";
		exit;
	case 2:/*bad logname or password*/
                echo "<center><span class=\"text\">Invalid username or password.</span></center>\n";
		exit;
}

$filename="modules/".basename($op).".php";
if(!file_exists($filename)){
	unset($filename);
}

$notext=isset($notext)?TRUE:FALSE;

if(!$notext){
	include("function/admin_menu.inc");
	if(!isset($op)){
		include ("modules/mainfile.php");
	}
}
if(isset($filename)){
	include ($filename);
}elseif(!$notext&&isset($op)){
	/*bad operation*/
	echo "Bad operation, I don't know what do you want to do, Sorry<br>\n";	
}	
if(!$notext){
	include ("function/footer.inc");
}
?>
