<?php
/**********************/
/*   JpoRtaL v 0.6    */
/*    config file     */
/**********************/

/****************/
/*MySQL database*/
/****************/

$DBhost = "localhost";
$DBuser = "root";
$DBname = "pokus";
$DBpass = "linux";

/*************/
/*Site config*/
/*************/

$site_name = "JpoRtaL";
$site_url = "http://www.yourdomain.com";
$char_set = "iso-8859-2";
$webmaster_mail = "webmaster@yourdomain.com";
$admin_mail = "admin@yourdomain.com";
$date = date("d.m. Y"); //date format
$copyright = "(c)2001 by jow&martin";
$lang = "en"; 
$theme = "template";
$slogan = "your slogan here";
$start_date = "October 2001";
$jportal_vs = "0.6.1";
$comment_ok = "1"; //follow comments (1 = yes, 0= no)
$footer1 = "This site powered JpoRtaL v$jportal_vs. JpoRtaL is portal system under <a href=\"doc/gnu_$lang.html\">GNU/GPL licence</a>.";
$footer2 = "Copyright (c) 2001 by jow&martin. All rights reserved.";

/*max articles on index page*/
$index_articles = "10";

/*max shortnews on index page*/
$index_news = "5";

?>
