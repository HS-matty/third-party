<table>
<?
	$sql="SELECT COUNT(*) AS count FROM articles";
	$result=mysql_query($sql);
	$record=mysql_fetch_array($result);
?>
<tr>
<td><span class="text">Po�et �l�nk�</span></td>
<td><span class="text"><?echo $record[count];?></span></td>
</tr>

<?
	$sql="SELECT COUNT(*) AS count FROM article_section";
	$result=mysql_query($sql);
	$record=mysql_fetch_array($result);
?>
<tr>
<td><span class="text">Po�et rubrik</span></td>
<td><span class="text"><?echo $record[count];?></span></td>
</tr>
</table>


<table>
<th><span class="text">��slo</th> <th><span class="text">jm�no</span></th> <th><span class="text">�l�nk�</span></th> <th><span class="text">popis</span></th>
<?
	$sql="SELECT article_section.*, COUNT(articles.section_id) AS count FROM article_section, articles WHERE article_section.id=articles.section_id GROUP BY articles.section_id";
	if(!$result=mysql_query($sql))
		mysql_error();
	while($record=mysql_fetch_array($result)){
		echo    "<tr>\n".
			"<td><span class=\"text\">$record[id]</span></td>\n".
			"<td><span class=\"text\">$record[name]</span></td>\n".
			"<td><span class=\"text\">$record[count]</span></td>\n".
			"<td><span class=\"text\">$record[descript]</span></td>\n".
			"</tr>\n";
	}
?>
</table>
