<?
##################
#      user      #
#       by       #
#  jow & martin  #
#  under GNU/GPL #
##################

function user_add(){
echo "<form action=\"index.php?op=users&subop=create\" method=\"POST\"> 
<center><table cellSpacing=\"0\" cellPadding=\"0\" width=\"546\" border=\"0\" height=\"111\"> 
<br><center><span class=\"velky\">"._USERS."</span></center>
<hr align=\"center\" size=\"1\" width=\"600\" color=\"#FFFFFF\" noshade><br>
<tbody> 
<tr> 
<td width=\"40\" height=\"23\"><span class=\"text\" size=\"2\">"._NAME_U."</span></td> 
<td width=\"502\" height=\"33\"><input type=\"text\" name=\"user[name]\" size=\"20\">
<select name=\"user[title]\"><option value=\"Super User\">Super User</option><option value=\"User\">User</option>
</select>
</td> 
</tr> 
<tr> 
<td width=\"40\" height=\"23\"><span class=\"text\" size=\"2\">"._PASS_U."</span></td> 
<td width=\"502\" height=\"33\"><input type=\"text\" name=\"user[pass]\" size=\"20\">
</td> 
</tr> 
<tr> 
<td width=\"40\" height=\"23\"><span class=\"text\" size=\"2\">"._EMAIL_U."</span></td> 
<td width=\"502\" height=\"33\"><input type=\"text\" name=\"user[email]\" size=\"20\">
</td> 
</tr>
<tr> 
<td width=\"40\" height=\"23\"><span class=\"text\">"._TEXT_U."</span></td> 
<td width=\"502\" height=\"33\"><textarea name=\"user[text]\" rows=\"6\" cols=\"60\"></textarea></td> 
</tr> 
<tr> 
<td colSpan=\"2\" width=\"544\" height=\"46\">&nbsp;
        <br><input class=\"button\" type=\"submit\" maxLength=\"12\" size=\"12\" value=\""._SEND_U."\" name=\"submit\"><br><br>
        <hr align=\"center\" size=\"1\" width=\"600\" color=\"#FFFFFF\" noshade>";
echo "</td> 
</tr> 
</tbody> 
</form>"; 
$sql = "SELECT * FROM users ORDER by id DESC LIMIT 0, 10"; 
$result = mysql_query($sql); 
while ($record = mysql_fetch_array($result)) { 
echo "<span class=\"text\">".$record["id"].". <a href=\"mailto: ".$record["email"]."\">".$record["name"]."</a>-".$record["title"]." |<a href=\"index.php?op=users&subop=del&id=".$record["id"]."\">"._DEL."</a></span><br><br>";
}
echo "</table>";
}


function user_create($user){

$sql = "INSERT INTO users (id, name, pass, title, text, email) VALUES ('$user[id]', '$user[name]',  '$user[pass]', '$user[title]', '$user[text]', '$user[email]')"; 

mysql_query($sql)or die("ERRO, try it again.."); 

	echo "<link rel=\"stylesheet\"  href=\"styles.css\" type=\"text/css\">";
	echo "<br><span class=\"text\"><center>"._USERCOMPLETE.".<br></center></span>"; 
}


function user_del($id){

$sql = "DELETE FROM users WHERE id=$id"; 

mysql_query($sql);
if(mysql_errno()!=0)
	echo mysql_error(); 
else{
	echo "<link rel=\"stylesheet\"  href=\"styles.css\" type=\"text/css\">";
	echo "<br><span class=\"text\"><center>"._USERDELETE.".<br></center></span>"; 
}
}
switch($subop){
	case "create":
		user_create($user);
		break;
	case "del":
		user_del($id);
		break;
	default:
		user_add();
		break;

}
?>


