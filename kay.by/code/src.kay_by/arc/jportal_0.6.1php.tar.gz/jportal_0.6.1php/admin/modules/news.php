<?
##################
#    shortnews   # 
#       by       #
#  jow & martin  #
#  under GNU/GPL #
##################

function news_add(){
echo "<form action=\"index.php?op=news&subop=create\" method=\"POST\"> 
<center><table cellSpacing=\"0\" cellPadding=\"0\" width=\"546\" border=\"0\" height=\"111\"> 
<br><center><span class=\"velky\">"._NEWS."</span></center>
<hr align=\"center\" size=\"1\" width=\"600\" color=\"#FFFFFF\" noshade><br>
<tbody> 
<tr> 
<td width=\"40\" height=\"23\"><span class=\"text\" size=\"2\">"._TITLE_N."</span></td> 
<td width=\"502\" height=\"33\"><input type=\"text\" name=\"news[title]\" size=\"20\">
<input type=\"hidden\" name=\"news[id]\" size=\"20\"></td> 
</tr> 
<tr> 
<td width=\"40\" height=\"23\"><span class=\"text\">"._TEXT."</span></td> 
<td width=\"502\" height=\"33\"><textarea name=\"news[text]\" rows=\"6\" cols=\"60\"></textarea></td> 
</tr> 
<tr> 
<td colSpan=\"2\" width=\"544\" height=\"46\">&nbsp;
        <br><input class=\"button\" type=\"submit\" maxLength=\"12\" size=\"12\" value=\""._SEND_N."\" name=\"submit\"><br><br>
        <hr align=\"center\" size=\"1\" width=\"600\" color=\"#FFFFFF\" noshade>";
echo "</td> 
</tr> 
</tbody> 
</form>"; 
$sql = "SELECT * FROM shortnews ORDER by id DESC LIMIT 0, 10"; 
$result = mysql_query($sql); 
while ($record = mysql_fetch_array($result)) { 
echo "<span class=\"text\">".$record["id"].". ".$record["title"]." |<a href=\"index.php?op=news&subop=del&id=".$record["id"]."\">"._DEL."</a></span><br><br>";
}
echo "</table>";
}


function news_create($news){

$sql = "INSERT INTO shortnews (id, title, text) VALUES ('$news[id]', '$news[title]', '$news[text]')"; 

mysql_query($sql)or die("ERRO, try it again.."); 

	echo "<link rel=\"stylesheet\"  href=\"styles.css\" type=\"text/css\">";
	echo "<br><span class=\"text\"><center>"._NEWSCOMPLETE.".<br></center></span>"; 
}


function news_del($id){

$sql = "DELETE FROM shortnews WHERE id=$id"; 

mysql_query($sql);
if(mysql_errno()!=0)
	echo mysql_error(); 
else{
	echo "<link rel=\"stylesheet\"  href=\"styles.css\" type=\"text/css\">";
	echo "<br><span class=\"text\"><center>"._NEWSDELETE.".<br></center></span>"; 
}
}
switch($subop){
	case "create":
		news_create($news);
		break;
	case "del":
		news_del($id);
		break;
	default:
		news_add();
		break;

}
?>
