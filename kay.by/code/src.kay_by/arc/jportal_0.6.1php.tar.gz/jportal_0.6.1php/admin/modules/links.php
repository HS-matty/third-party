<?
function form_section(){
?>
<form action="index.php?op=links&subop=add_section" method="POST"> 
<center><table cellSpacing="0" cellPadding="0" width="546" border="0" height="111"> 
<br><center><span class="velky"><?echo _SECTION_L;?></span></center>
<hr align="center" size="1" width="600" color="#FFFFFF" noshade><br>
<tbody> 
<tr> 
<td width="40" height="23"><span class="text"><?echo _TITLE_S;?></span></td> 
<td width="502" height="33"><input type="text" name="section[name]" size="20">
<input type="hidden" name="section[id]" size="20">
</td> 
</tr> 
<tr> 
<td width="40" height="23"><span class="text"><?echo _DESCRIPTION_S;?></span></td> 
<td width="502" height="33"><textarea name="section[descript]" rows="6" cols="60"></textarea></td> 
</tr>
<td colSpan="2" width="544" height="46">&nbsp;
        <br><input class="button" type="submit" maxLength="12" size="12" value="<?echo _SEND_S;?>" name="submit"><br><br>
</td> 
</tr> 
</tbody> 
</form>
<?
$sql = "SELECT * FROM link_section ORDER by id DESC LIMIT 0, 10"; 
$result = mysql_query($sql); 
while ($record = mysql_fetch_array($result)) { 
echo "<span class=\"text\">".$record["id"].". ".$record["name"]." |<a href=\"index.php?op=links&subop=del_section&id=".$record["id"]."\">"._DEL."</a></span><br><br>";
}
echo "</table></center>"; 
}##end of form_section

function form_link($link){
?>
<form action="index.php?op=links&subop=<?echo ($link[id])?"update":"create";?>" method="POST"> 
<center><table cellSpacing="0" cellPadding="0" width="546" border="0" height="111"> 
<br><span class="velky"><center><?echo _LINK;?></center></span>
<hr align="center" size="1" width="600" color="#FFFFFF" noshade><br>
<tbody> 
<tr> 
<td width="40" height="23"><span class="text"><?echo _TITLE_L;?></span></td> 
<td width="502" height="33"><input type="text" name="link[title]" value="<?echo $link[title];?>" size="20">
<input type="hidden" name="notext" value="1">
<input type="hidden" name="link[id]" value="<?echo $link[id];?>" size="20">
<select name="link[section_id]">
<?
$sql = "SELECT * FROM link_section ORDER by id"; 
$result = mysql_query($sql); 
while ($record = mysql_fetch_array($result)) { 
	echo "<option ";
	if($record[id]==$link[section_id])
		echo "SELECTED ";
	echo "value=\"".$record["id"]."\">".$record["name"]."</option>";
} 
?>
</select>
</td></tr> 
<tr> 
<td width="40" height="23"><span class="text"><?echo _URL_L;?></span></td> 
<td width="502" height="33"><input type="text" name="link[url]" value=<?echo ($link[url])?$link[url]:"http://";?> size="20"></td> 
</tr> 
<tr> 
<td width="40" height="23"><span class="text"><?echo _DESCRIPTION_L;?></span></td> 
<td width="502" height="33"><textarea name="link[descript]" rows="5" cols="60"><?echo $link[descript];?></textarea></td>
</tr><br>
<tr> 
<td colSpan="2" width="544" height="46">
        <br><input class="button" type="submit" maxLength="12" size="12" value="<?echo _SEND_L;?>" name="submit"><br><br>
<hr align="center" size="1" width="600" color="#FFFFFF" noshade>
</td> 
</tr> 
</tbody> 
</form> 
<?
$sql = "SELECT * FROM links ORDER by id DESC LIMIT 0, 10"; 
$result = mysql_query($sql); 
while ($record = mysql_fetch_array($result)) { 
	echo "<span class=\"text\">".$record["id"].". ".$record["title"].
	"|<a href=\"index.php?op=links&subop=del&id=".$record["id"]."\">"._DEL."</a>".
	"|<a href=\"index.php?op=links&subop=edit&id=".$record["id"]."\">"._EDIT."</a>".
	"</span><br><br>";
}
echo "</table></center>";
}##end of form_section

function link_add($view=all,$mess=FALSE,$id=FALSE){
if($mess) 
	echo "<br><span class=\"text\"><center>$mess</center></span><br>";
switch($view){
	case editlink:
		$query="SELECT * FROM links WHERE id=$id";
		$result=mysql_query($query);
		$link=mysql_fetch_array($result);
	case all:
	case links:
		form_link($link);
		if($view!=all)
			break;
	case section:
		form_section();
}
}##end of link_add

function link_create($link){
$sql = "INSERT INTO links (id, section_id, title, url, descript) VALUES ('$link[id]', '$link[section_id]', '$link[title]', '$link[url]', '$link[descript]')"; 

if(!mysql_query($sql)){
	include ("function/admin_menu.inc");
	echo "I have some problems with database<br>\n".mysql_error();	
	echo(" try it again..."); 
	include ("function/footer.inc");
}else{
	header("Location: index.php?op=links&subop=create_ok");
}
}##edn of link_create

function link_update($link){
$sql = "UPDATE links SET section_id='$link[section_id]', title='$link[title]', url='$link[url]', descript='$link[descript]' WHERE id='$link[id]'"; 

if(!mysql_query($sql)){
	include ("function/admin_menu.inc");
	echo "I have some problems with database<br>\n".mysql_error();	
	echo(" try it again..."); 
	include ("function/footer.inc");
}else{
	header("Location: index.php?op=links&subop=update_ok");
}
}##edn of link_update


function section_create($section){

$sql = "INSERT INTO link_section (id, name, descript) VALUES ('$section[id]', '$section[name]', '$section[descript]')"; 

mysql_query($sql)or die("ERROR, try it again..."); 

echo "<link rel=\"stylesheet\"  href=\"styles.css\" type=\"text/css\">";
echo "<br><span class=\"text\"><center>"._SECTIONCOMPLETE."<br></center></span>"; 
}

function section_del($id){

$sql = "DELETE FROM link_section WHERE id=$id";
$sql1 = "DELETE FROM links WHERE section_id=$id";  

mysql_query($sql)or die("ERROR, try it again..."); 
mysql_query($sql1)or die("ERROR, try it again..."); 

echo "<link rel=\"stylesheet\"  href=\"styles.css\" type=\"text/css\">";
echo "<br><span class=\"text\"><center>"._SECTIONDELETE.".<br></center></span>"; 
}

function delete_link($id){
$sql = "DELETE FROM links WHERE id=$id"; 
$sql1 = "SELECT * FROM links WHERE id=$id"; 
$result = mysql_query($sql1); 
while ($record = mysql_fetch_array($result)) { 
$sql2 = "UPDATE link_section SET link_count=link_count-1  WHERE id = ".$record["section_id"]."";
} 

mysql_query($sql)or die("ERROR, try it again..."); 
mysql_query($sql2)or die("ERROR, try it again..."); 

echo "<link rel=\"stylesheet\"  href=\"styles.css\" type=\"text/css\">";
echo "<br><span class=\"text\"><center>"._LINKDELETE."<br></center></span>"; 
}

switch($subop){
	case "create":
		link_create($link);
		break;
	case "create_ok":
		link_add(all,_LINKCOMPLETE);
		break;
	case "add_section":
		section_create($section);
		break;
	case "del":
		delete_link($id);
		break;
	case "del_section":
		section_del($id);
		break;
	case "edit":
		link_add(editlink,FALSE,$id);
		break;
	case "update":
		link_update($link);
		break;
	case "update_ok":
		link_add(all,_LINKUPDATED);
		break;
	default:
		link_add();
		break;
}
?>
