<?
function download_add(){
echo "<form action=\"index.php?op=download&subop=add_section\" method=\"POST\"> 
<center><table cellSpacing=\"0\" cellPadding=\"0\" width=\"546\" border=\"0\" height=\"111\"> 
<br><center><span class=\"velky\">"._SECTION_D."</span></center>
<hr align=\"center\" size=\"1\" width=\"600\" color=\"#FFFFFF\" noshade><br>
<tbody> 
<tr> 
<td width=\"40\" height=\"23\"><span class=\"text\">"._TITLE_S."</span></td> 
<td width=\"502\" height=\"33\"><input type=\"text\" name=\"section[name]\" size=\"20\">
<input type=\"hidden\" name=\"section[id]\" size=\"20\">
</td> 
</tr> 
<tr> 
<td width=\"40\" height=\"23\"><span class=\"text\">"._DESCRIPTION_S."</span></td> 
<td width=\"502\" height=\"33\"><textarea name=\"section[descript]\" rows=\"6\" cols=\"60\"></textarea></td> 
</tr>
<td colSpan=\"2\" width=\"544\" height=\"46\">&nbsp;
        <br><input class=\"button\" type=\"submit\" maxLength=\"12\" size=\"12\" value=\""._SEND_S."\" name=\"submit\"><br><br>";
echo "</td> 
</tr> 
</tbody> 
</form>";
$sql = "SELECT * FROM down_section ORDER by id DESC LIMIT 0, 10"; 
$result = mysql_query($sql); 
while ($record = mysql_fetch_array($result)) { 
echo "<span class=\"text\">".$record["id"].". ".$record["name"]." |<a href=\"index.php?op=download&subop=del_section&id=".$record["id"]."\">"._DEL."</a></span><br><br>";
}
echo "</table></center>"; 

echo "<form action=\"index.php?op=download&subop=create\" method=\"POST\"> 
<center><table cellSpacing=\"0\" cellPadding=\"0\" width=\"546\" border=\"0\" height=\"111\"> 
<br><center><span class=\"velky\">"._DOWNLOAD."</span></center>
<hr align=\"center\" size=\"1\" width=\"600\" color=\"#FFFFFF\" noshade><br>
<tbody> 
<tr> 
<td width=\"40\" height=\"23\"><span class=\"text\">"._TITLE_D."</span></td> 
<td width=\"502\" height=\"33\"><input type=\"text\" name=\"download[title]\" size=\"20\">
<input type=\"hidden\" name=\"download[id]\" size=\"20\">";
$sql = "SELECT * FROM down_section ORDER by id"; 
$result = mysql_query($sql); 
echo "<select name=\"download[section_id]\">";
while ($record = mysql_fetch_array($result)) { 
echo "<option value=\"".$record["id"]."\">".$record["name"]."</option>";
}
echo "</select>";
echo "</td> 
</tr> 
<tr> 
<td width=\"40\" height=\"23\"><span class=\"text\">"._URL_D."</span></td> 
<td width=\"502\" height=\"33\"><input type=\"text\" name=\"download[url]\" value=\"http://\" size=\"40\"></td> 
</tr> 
<tr> 
<td width=\"40\" height=\"23\"><span class=\"text\">"._VERS_D."</span></td> 
<td width=\"502\" height=\"33\"><input type=\"text\" name=\"download[vers]\" size=\"10\"></td> 
</tr>
<tr> 
<td width=\"40\" height=\"23\"><span class=\"text\">"._DESCRIPTION_D."</span></td> 
<td width=\"502\" height=\"33\"><textarea name=\"download[descript]\" rows=\"6\" cols=\"60\"></textarea></td> 
</tr>
<td colSpan=\"2\" width=\"544\" height=\"46\">&nbsp;
        <br><input class=\"button\" type=\"submit\" maxLength=\"12\" size=\"12\" value=\""._SEND_D."\" name=\"submit\"><br><br>
        <hr align=\"center\" size=\"1\" width=\"600\" color=\"#FFFFFF\" noshade>
</td> 
</tr> 
</tbody> 
</form>";
$sql = "SELECT * FROM down ORDER by id DESC LIMIT 0, 10"; 
$result = mysql_query($sql); 
while ($record = mysql_fetch_array($result)) { 
echo "<span class=\"text\">".$record["id"].". ".$record["title"]."|<a href=\"index.php?op=download&subop=del&id=".$record["id"]."\">"._DEL."</a></span><br><br>";
}
echo "</table></center>";
} 


function download_create($download){

$sql = "INSERT INTO down (id, section_id, title, url, vers, descript) VALUES ('$download[id]', '$download[section_id]', '$download[title]', '$download[url]', '$download[vers]', '$download[descript]')"; 
$sql1 = "UPDATE down_section SET file_count=file_count+1 WHERE id = '$download[section_id]'";

mysql_query($sql)or die("ERROR, try it again..."); 
mysql_query($sql1)or die("ERROR, try it again..."); 

echo "<link rel=\"stylesheet\"  href=\"styles.css\" type=\"text/css\">";
echo "<br><span class=\"text\"><center>"._DOWNCOMPLETE."<br></center></span>"; 
}

function section_create($section){

$sql = "INSERT INTO down_section (id, name, descript) VALUES ('$section[id]', '$section[name]', '$section[descript]')"; 

mysql_query($sql)or die("ERROR, try it again..."); 

echo "<link rel=\"stylesheet\"  href=\"styles.css\" type=\"text/css\">";
echo "<br><span class=\"text\"><center>"._SECTIONCOMPLETE."<br></center></span>"; 
}

function section_del($id){

$sql = "DELETE FROM down_section WHERE id=$id";
$sql1 = "DELETE FROM down WHERE section_id=$id";  

mysql_query($sql)or die("ERROR, try it again..."); 
mysql_query($sql1)or die("ERROR, try it again..."); 

echo "<link rel=\"stylesheet\"  href=\"styles.css\" type=\"text/css\">";
echo "<br><span class=\"text\"><center>"._SECTIONDELETE.".<br></center></span>"; 
}

function download_del($id){
$sql = "DELETE FROM down WHERE id=$id"; 
$sql1 = "SELECT * FROM down WHERE id=$id"; 
$result = mysql_query($sql1); 
while ($record = mysql_fetch_array($result)) { 
$sql2 = "UPDATE down_section SET file_count=file_count-1  WHERE id = $record[section_id]";
} 

mysql_query($sql)or die("ERROR, try it again..."); 
mysql_query($sql2)or die("ERROR, try it again..."); 

echo "<link rel=\"stylesheet\"  href=\"styles.css\" type=\"text/css\">";
echo "<br><span class=\"text\"><center>"._DOWNDELETE.".<br></center></span>"; 
}

switch($subop){
	case "create":
		download_create($download);
		break;
	case "add_section":
		section_create($section);
		break;
	case "del":
		download_del($id);
		break;
	case "del_section":
		section_del($id);
	break;
	default:
		download_add();
		break;

}
?>
