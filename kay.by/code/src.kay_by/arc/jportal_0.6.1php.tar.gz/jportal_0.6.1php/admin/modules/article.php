<?
function form_article($article){
?>

<center>
<form action="index.php?op=article&subop=<?echo ($article[id])?"update_article":"create";?>" method="POST"> 
<table cellSpacing="0" cellPadding="0" width="546" border="0" height="111"> 
<span class="velky"><center><?echo _ART;?></center></span>
<hr align="center" size="1" width="600" color="#FFFFFF" noshade>
<tbody> 
<tr> 
<td width="40" height="23"><span class="text"><?echo _TITLE_A;?></span></td> 

<td width="502" height="33">
<input type="text" name="article[title]" value="<?echo $article[title];?>" size="20">
<input type="hidden" name="notext" value="1">
<input type="hidden" name="article[id]" value="<?echo $article[id];?>" size="20">
<input type="hidden" name="article[date]" value="<?echo ($article[date])?$article[date]:date("d.m. Y");?>" size="20">
<select name="article[section_id]">
<?
$sql = "SELECT * FROM article_section ORDER BY id"; 
$result = mysql_query($sql); 
while ($record = mysql_fetch_array($result)) { 
	echo "\n<option ";
	if($record[id]==$article[section_id])
		echo "SELECTED ";
	echo "value=\"".$record["id"]."\">".$record["name"]."</option>";
} 
?>
</select>
</td></tr> 
<tr>
<td width="40" height="23"><span class="text"><?echo _AUTOR_A;?></span></td> 
<td width="502" height="33"><input type="text" name="article[autor]" value="<?echo $article[autor];?>" size="20"></td> 
</tr> 
<tr> 
<td width="40" height="23"><span class="text"><? echo _SHORT_A;?></span></td> 
<td width="502" height="33"><textarea name="article[short]" rows="5" cols="60"><?echo $article[short];?></textarea></td>
</tr><br>
<tr> 
<td width="40" height="23"><span class="text"><? echo _TEXT_A;?></span></td> 
<td width="502" height="33"><textarea name="article[text]" rows="5" cols="60"><?echo $article[text];?></textarea></td>
</tr><br>
<tr> 
<td colSpan="2" width="544" height="46">
<br><input class="button" type="submit" maxLength="12" size="12" value="<? echo _SEND_A;?>" name="submit"><br><br>
<hr align="center" size="1" width="600" color="#FFFFFF" noshade>
</td> 
</tr> 
</tbody> 
</form> 
</center>
<?
$sql = "SELECT * FROM articles ORDER by id DESC LIMIT 0, 10"; 
$result = mysql_query($sql); 
while ($record = mysql_fetch_array($result)) { 
	echo "\n<span class=\"text\">".$record["id"].". ".$record["title"]."|<a href=\"index.php?op=article&subop=del&id=".$record["id"]."\">"._DEL."</a>
|<a href=\"index.php?op=article&subop=edit_article&id=".$record["id"]."\">"._EDIT."</a></span><br><br>";
}
}##end of function form_article

function form_section($section){
?>
<!--start of sections-->
<form action="index.php?op=article&subop=<?echo ($section[id])?"update_section":"add_section";?>" method="POST"> 
<input type="hidden" name="notext" value="1">
<center><table cellSpacing="0" cellPadding="0" width="546" border="0" height="111"> 
<br><center><span class="velky"><? echo _SECTION_A;?></span></center>
<hr align="center" size="1" width="600" color="#FFFFFF" noshade><br>
<tbody> 
<tr> 
<td width="40" height="23"><span class="text"><? echo _TITLE_S;?></span></td> 
<td width="502" height="33"><input type="text" name="section[name]" value="<?echo $section[name];?>" size="20">
<input type="hidden" name="section[id]" value="<?echo $section[id];?>" size="20">
</td> 
</tr> 
<tr> 
<td width="40" height="23"><span class="text"><? echo _DESCRIPTION_S;?></span></td> 
<td width="502" height="33"><textarea name="section[descript]" rows="6" cols="60"><?echo $section[descript];?></textarea></td> 
</tr>
<td colSpan="2" width="544" height="46">&nbsp;
        <br><input class="button" type="submit" maxLength="12" size="12" value="<? echo _SEND_S;?>" name="submit"><br><br>
</td> 
</tr> 
</tbody> 
</form>
<?
$sql = "SELECT * FROM article_section ORDER by id DESC LIMIT 0, 10"; 
$result = mysql_query($sql); 
while ($record = mysql_fetch_array($result)) { 
echo "<span class=\"text\">".$record["id"].". ".$record["name"].
" |<a href=\"index.php?op=article&subop=del_section&notext=1&id=".$record["id"]."\">"._DEL."</a>".
" |<a href=\"index.php?op=article&subop=edit_section&id=".$record["id"]."\">"._EDIT."</a>".
"</span><br><br>";
}
echo "</table></center>";
echo "</table></center>\n<!-- end of sections-->"; 
}##end of function form_section

function articles_create($article) {
$sql = "INSERT INTO articles (id, section_id, autor, title, short, text, date) VALUES ('$article[id]', '$article[section_id]', '$article[autor]', '$article[title]',  '$article[short]', '$article[text]', '$article[date]')"; 

if(!mysql_query($sql)){
	include ("function/admin_menu.inc");
	echo "I have some problems with database<br>\n".mysql_error();	
	echo(" try it again..."); 
	include ("function/footer.inc");
}else{
	header("Location: index.php?op=article&subop=create_ok");
}
}##end of articles_create

function update_article($article) {
$sql = "UPDATE articles SET section_id='$article[section_id]', autor='$article[autor]', title='$article[title]', short='$article[short]', text='$article[text]', date='$article[date]' WHERE id='$article[id]'";
//$sql2 = "SELECT section_id FROM articles where id='$article[id]'";

if(!mysql_query($sql)){
	include ("function/admin_menu.inc");
	echo "I have some problems with database<br>\n".mysql_error();	
	echo(" try it again..."); 
	include ("function/footer.inc");
}else{
	header("Location: index.php?op=article&subop=update_ok");
}
}##end of update_article



function link_add($view=all,$mess=FALSE,$id=FALSE){
if($mess) 
	echo "<br><span class=\"text\"><center>$mess</center></span><br>";
switch($view){
	case editarticle:
		$query="SELECT * FROM articles WHERE id=$id";
		$result=mysql_query($query);
		$article=mysql_fetch_array($result);
	case editsection:
		$query="SELECT * FROM article_section WHERE id=$id";
		$result=mysql_query($query);
		$section=mysql_fetch_array($result);
}
switch($view){
	case all:
	case editarticle:
		form_article($article);
		if($view!=all)
			break;
	case section:
	case editsection:
		form_section($section);
}
}

function section_create($section){

$sql = "INSERT INTO article_section (id, name, descript) VALUES ('$section[id]', '$section[name]', '$section[descript]')"; 

if(!mysql_query($sql)){
	include ("function/admin_menu.inc");
	echo "I have some problems with database<br>\n".mysql_error();	
	echo(" try it again..."); 
	include ("function/footer.inc");
}else{
	header("Location: index.php?op=article&subop=add_ok");
}
}


function section_update($section){

$sql = "UPDATE article_section SET name='$section[name]', descript='$section[descript]' WHERE id='$section[id]'"; 

if(!mysql_query($sql)){
	include ("function/admin_menu.inc");
	echo "I have some problems with database<br>\n".mysql_error();	
	echo(" try it again..."); 
	include ("function/footer.inc");
}else{
	header("Location: index.php?op=article&subop=updatesect_ok");
}
}


function section_del($id){

$sql = "DELETE FROM article_section WHERE id=$id";
$sql1 = "DELETE FROM articles WHERE section_id=$id";  

if(!mysql_query($sql)||!mysql_query($sql1)){
	include ("function/admin_menu.inc");
	echo "I have some problems with database<br>\n".mysql_error();	
	echo(" try it again..."); 
	include ("function/footer.inc");
}else{
	header("Location: index.php?op=article&subop=delsec_ok");
}
}

function delete_articles($id){
$sql = "DELETE FROM articles WHERE id=$id"; 
$sql1 = "SELECT * FROM articles WHERE id=$id"; 
$result = mysql_query($sql1); 
while ($record = mysql_fetch_array($result)) { 
$sql2 = "DELETE FROM comments WHERE aid=$id";
} 

mysql_query($sql)or die("ERROR, try it again...1"); 
mysql_query($sql2)or die("ERROR, try it again...2"); 

echo "<link rel=\"stylesheet\"  href=\"styles.css\" type=\"text/css\">";
echo "<br><span class=\"text\"><center>"._ARTDELETE.".<br></center></span>"; 
}

switch($subop){
	case "create":
		articles_create($article);
		break;
	case "create_ok":
		link_add(all,_ARTCOMPLETE);
		break;
		
	case "add_section":
		section_create($section);
		break;
	case "add_ok":
		link_add(all,_SECTIONCOMPLETE);
		break;
		
	case "del":
		delete_articles($id);
		break;
	case "del_section":
		section_del($id);
		break;
	case "delsec_ok":
		link_add(all,_SECTIONDELETED);
		break;
		
	case "edit_article":
		link_add(editarticle,FALSE,$id);
		break;
	case "update_article":
		update_article($article);
		break;
	case "update_ok":
		link_add(all,_ARTUPDATED);
		break;
		
	case "edit_section":
		link_add(editsection,FALSE,$id);
		break;
	case "update_section":
		section_update($section);
		break;
	case "updatesect_ok":
		link_add(all,_SECTIONUPDATED);
		break;
		
	default:
		link_add();
		break;
}
?>
