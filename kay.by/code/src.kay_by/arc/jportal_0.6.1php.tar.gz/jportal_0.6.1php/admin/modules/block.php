<?
#################
#    blocks     #
#      by       #
# jow & martin  #
# under GNU/GPL #
#################


function block_add($mess=FALSE,$id=FALSE){
if($mess) 
	echo "<br><span class=\"text\"><center>$mess</center></span><br>";
if($id){
	$query="SELECT * FROM blocks WHERE id=$id";
	$result=mysql_query($query);
	$block=mysql_fetch_array($result);
}
?>
<form action="index.php?op=block&subop=<?echo ($block[id])?"update":"create";?>" method="POST"> 
<input type="hidden" name="block[id]" value="<? echo $block[id];?>" size="20">
<input type="hidden" name="block[type]" value="<? echo $block[type];?>" size="20">
<center><table cellSpacing="0" cellPadding="0" width="546" border="0" height="111"> 
<br><center><span class="velky"><? echo _BLOCK;?></span></center>
<hr align="center" size="1" width="600" color="#FFFFFF" noshade><br>
<tbody> 
<tr> 
<td width="40" height="23"><span class="text" size="2"><? echo _TITLE_B;?></span></td> 
<td width="502" height="33"><input type="text" name="block[title]" value="<? echo $block[title];?>" size="20">
<input type="hidden" name="notext" value="1">
<select name="block[position]">
<option <? if($block[position]=="L") echo "SELECTED";?> value="L"><? echo _LEFT_B;?></option>
<option <? if($block[position]=="P") echo "SELECTED";?> value="P"><? echo _RIGHT_B;?></option>
</select>
</td> 
</tr> 
<tr> 
<td width="40" height="23"><span class="text"><? echo _ROW_B;?></span></td> 
<td width="502" height="33">
<select name="block[row]">
<option <? if($block[row]=="1") echo "SELECTED";?> value="1"><? echo _ONE_B;?></option>
<option <? if($block[row]=="2") echo "SELECTED";?> value="2"><? echo _TWO_B;?></option>
<option <? if($block[row]=="3") echo "SELECTED";?> value="3"><? echo _THREE_B;?></option>
<option <? if($block[row]=="4") echo "SELECTED";?> value="4"><? echo _FOUR_B;?></option>
<option <? if($block[row]=="5") echo "SELECTED";?> value="5"><? echo _FIVE_B;?></option>
<option <? if($block[row]=="6") echo "SELECTED";?> value="6"><? echo _SIX_B;?></option>
<option <? if($block[row]=="7") echo "SELECTED";?> value="7"><? echo _SEVEN_B;?></option>
<option <? if($block[row]=="8") echo "SELECTED";?> value="8"><? echo _EIGHT_B;?></option>
<option <? if($block[row]=="9") echo "SELECTED";?> value="9"><? echo _NINE_B;?></option>
<option <? if($block[row]=="10") echo "SELECTED";?> value="10"><? echo _TEN_B;?></option>
</select>
</td> 
</tr>
<tr> 
<td width="40" height="23"><span class="text"><? echo _TEXT_B;?></span></td> 
<td width="502" height="33">
<textarea name="block[content]" rows="6" cols="60"><? echo $block[content];?></textarea></td> 
</tr> 
<tr> 
<td colSpan="2" width="544" height="46">&nbsp;
        <br><input class="button" type="submit" maxLength="12" size="12" value="<? echo _SEND_B;?>" name="submit"><br><br>
        <hr align="center" size="1" width="600" color="#FFFFFF" noshade>
</td> 
</tr> 
</tbody> 
</form> 
<?
$sql = "SELECT * FROM blocks ORDER by id DESC LIMIT 0, 10"; 
$result = mysql_query($sql); 
while ($record = mysql_fetch_array($result)) { 
echo "<span class=\"text\">".$record["id"].". ".$record["title"].
" |<a href=\"index.php?op=block&subop=del&id=".$record["id"]."\">"._DEL."</a>".
" |<a href=\"index.php?op=block&subop=edit&id=".$record["id"]."\">"._EDIT."</a>".
"</span><br><br>";
}
echo "</table>";
}


function block_create($block){

$sql = "INSERT INTO blocks (id, position, type, title, content) VALUES ('$block[id]', '$block[position]', '$block[type]', '$block[title]', '$block[content]')"; 

mysql_query($sql)or die("ERRO, try it again.."); 

	echo "<link rel=\"stylesheet\"  href=\"styles.css\" type=\"text/css\">";
	echo "<br><span class=\"text\"><center>"._BLOCKCOMPLETE.".<br></center></span>"; 
}

function block_update($block){
$sql = "UPDATE blocks SET position='$block[position]', type='$block[type]', title='$block[title]', content='$block[content]' WHERE id='$block[id]'"; 

if(!mysql_query($sql)){
	include ("function/admin_menu.inc");
	echo "I have some problems with database<br>\n".mysql_error();	
	echo(" try it again..."); 
	include ("function/footer.inc");
}else{
	header("Location: index.php?op=block&subop=update_ok");
}
}



function block_del($id){

$sql = "DELETE FROM blocks WHERE id=$id"; 

mysql_query($sql);
if(mysql_errno()!=0)
	echo mysql_error(); 
else{
	echo "<link rel=\"stylesheet\"  href=\"styles.css\" type=\"text/css\">";
	echo "<br><span class=\"text\"><center>"._BLOCKDELETE.".<br></center></span>"; 
}
}
switch($subop){
	case "create":
		block_create($block);
		break;
	case "create_ok":
		block_add(_BLOCKCOMPLETE);
		break;
	case "del":
		block_del($id);
		break;
	case "edit":
		block_add(FALSE,$id);
		break;
	case "update":
		block_update($block);
		break;
	case "update_ok":
		block_add(_BLOCKUPDATED);
		break;
	default:
		block_add();
		break;

}
?>


