<? 
switch($op) {
    case "read":
    include ("themes/header.php");
    include ("function/articles.inc");
    read_a($id, $section);
    include ("themes/footer.php");
    break;
    
    case "topic_all":
    include ("admin/config.php");
    include ("themes/header.php");
    include ("function/articles.inc");
    topic_a();
    include ("themes/footer.php");
    break;
    
    case "topic":
    include ("admin/config.php");
    include ("themes/header.php");
    include ("function/articles.inc");
    topic($id, $section, $parent);
    include ("themes/footer.php");
    break;
}
?>
