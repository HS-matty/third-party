<?
//footer
include ("admin/config.php");
include ("themes/$theme/footer.php");
?>
