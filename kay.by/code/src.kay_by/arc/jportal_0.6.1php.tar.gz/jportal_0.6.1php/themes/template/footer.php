<?
##center part of page - end###
echo "
</td>
<td width=\"25%\" valign=\"top\">";
news();
Blocks("P");
topic_block();
top_a("R");
echo "
</td>
    </tr>
</table>
    </td>
<tr><td width=\"100%\" align=\"center\">
<span class=\"text\">$footer1<br>$footer2</span></td></tr>
  </tr>
</table>
    </td>
  </tr>
</table>
</span>
</body>
</html>";
?>
