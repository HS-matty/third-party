<?
##copyright###
##(c)2001 by jow&martin
##all rights reserved
##copyright###

##includes - MOST IMPORTANT!!!###
include ("function/function.inc");
include ("themes/$theme/grafix_fc.inc");
##includes - MOST IMPORTANT!!!###


##html header###
echo "
<html>
<head>
<title>$site_name</title>
<meta http-equiv=\"Content-Type\" content=\"text/html\" charset=\"$char_set\">
<meta name=\"description\" content=\"\">
<meta name=\"keywords\" content=\"\">
<link rel=\"StyleSheet\" href=\"themes/$theme/styles.css\" type=\"text/css\">
</head>
<body>
<center>
<span class=\"text\">
<table width=\"700\" border=\"0\">
  <tr align=\"center\">
    <td align=\"center\" valign=\"top\">
<table width=\"100%\" border=\"0\">
  <tr>
    <td>
<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\">
<tr><td align=\"left\">
<span class=\"colorbig\">$site_name</span>
</td><td align=\"right\">
<form action=\"search.php?op=search\" method=\"POST\">
<input type=\"text\" name=\"query[query]\">&nbsp;<select name=\"type[type]\"><option value=\"articles\">"._IN_ARTICLES."</option><option value=\"links\">"._IN_LINKS."</option></select>&nbsp;<input class=\"button\" type=\"submit\" name=\"submit\" value=\""._SEARCH_NOW."\">
</form></td>
<tr><td align=\"left\" colspan=\"3\">"; 
include ("function/menu.inc");
echo "</td></tr>
</table><br>
<table width=\"700\" cellspacing=\"2\" cellpadding=\"0\" border=\"0\">
<td width=\"25%\" align=\"left\" valign=\"top\">";
Blocks("L");
last_file();
last_link();
echo "</td>
<td width=\"50%\" valign=\"top\">";
	##center part of page - article on index###	
?>	
