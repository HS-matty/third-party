<?
//header
include ("function/counter.inc");
include ("admin/config.php");
include ("themes/$theme/header.php");
include ("function/language/lang.$lang");
?>	
