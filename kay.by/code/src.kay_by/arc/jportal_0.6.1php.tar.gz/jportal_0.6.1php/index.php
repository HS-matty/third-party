<? 
include ("admin/config.php");
include ("themes/header.php");
articles_i();
include ("themes/footer.php");

switch($op) {
    case "new":
    include ("function/helpme.inc");
    break;
}
?>
