<?
/**************************************

electrifiedForum
Version 0.99rc3 - November 2, 2001

Copyright 2001- electrifiedpenguin.com

This is free software, please leave all
copyright notices intact, thanks!

This is the misc functions file

MAKE NO CHANGES TO THIS FILE
Customizing options are in the realm files!!!

***************************************/

function lastvisit()
{
	global $forumsess,$realm,$config,$eflastvisit;
	
	if (!session_is_registered("forumsess"))
		session_register("forumsess");
	
	if ($eflastvisit)	
		$forumsess[$realm][lastvisit] = $eflastvisit;
	
	$expire = time() + (60*60*24*365);
	setcookie("eflastvisit", time(), $expire);

	if (!$forumsess[$realm][lastvisit])	
		$forumsess[$realm][lastvisit] = $eflastvisit;
	
}

function printvisit()
{
	global $forumsess,$realm,$config,$lang;
	
	if ($config['24hour'])
	{
		$lastvisit1 = date("n/j/y",$forumsess[$realm][lastvisit]);
		$lastvisit2 = date("H:i",$forumsess[$realm][lastvisit]);
	} 
	else 
	{
		$lastvisit1 = date("n/j/y",$forumsess[$realm][lastvisit]);
		$lastvisit2 = date("h:i A",$forumsess[$realm][lastvisit]);
	}
	
	if ($forumsess[$realm][username])
		print "$lang[wb] ".$forumsess[$realm][username].".<br>";
		
	print "$lang[ylvo] ".$lastvisit1." $lang[at] ".$lastvisit2."<br>";
}

function age_from_bday($birthdate)
{

	$birthyear = substr($birthdate,0,4);
	$birthday = substr($birthdate,4,4);
	$age = date("Y") - $birthyear;
	if (date("md") < $birthday)
		$age = $age - 1;
	return $age;
}

function convert($n) 
{
	if ($n < 10) 
		return "0".$n;
	else
		return $n;
}

function forumtitle($forumname)
{
/* Return the title for a $forumname */
	global $config;
	return db_getvar($config[ftable],"fname='$forumname'",'ftitle');
}

function threadtitle($forumname,$threadid)
{
	global $config;
	return db_getvar($config[mtable],"fname='$forumname' AND threadid='$threadid' AND threadindex='0'",'title');
}

function sql_to_unix_time($timeString) 
{ 
	return mktime(substr($timeString, 8,2), substr($timeString, 10,2), substr($timeString, 12,2), substr($timeString,4,2), substr($timeString, 6,2), substr($timeString, 0,4)); 
}

function forumcount()
{
	global $config;
	return db_numrows_all($config[ftable]);

}

function tmsgcount()
{
	global $config;
	return db_numrows_all($config[mtable]);

}

function usercount()
{
	global $config;
	return db_numrows_all($config[utable]);

}

function verifyforum($forumname)
{
/* verify forum $forumname exists */
	global $config;
	
	if (db_numrows($config[ftable],"fname='$forumname'")>0)
		return TRUE;
	else
		return FALSE;

}

function verifythread($forumname,$threadid)
{
/* verify forum $forumname exists with a thread id od $threadid */
	global $config;
	
	if (db_numrows($config[mtable],"fname='$forumname' AND threadid='$threadid'")>0)
		return TRUE;
	else
		return FALSE;

}

function topiccount($forumname)
{
/* count number of messages in a forum */
	global $config;
	return db_numrows($config[mtable],"fname='$forumname' AND threadindex='0'");
}

function threadcount($forumname,$threadid)
{
/* count number of messages in a thread */
	global $config;
	return db_numrows($config[mtable],"fname='$forumname' AND threadid='$threadid'");
}

function messagecount($forumname)
{
/* count number of messages in a forum */
	global $config;
	return db_numrows($config[mtable],"fname='$forumname'");

}

function usermessagecount($user)
{
/* count number of messages in a forum */
	global $config;
	return db_numrows($config[mtable],"poster='$user'");

}

function ownercheck($mid,$username)
{
	global $config;
	$owner = db_getvar($config[mtable],"id='$mid'","poster");
	
	if ($username == $owner) 
		return TRUE;
	else 
		return FALSE;

}

function admincheck($username)
{
	global $config;
	$level = db_getvar($config[utable],"username='$username'","level");
	
	if ($level == 10) 
		return TRUE;
	else 
		return FALSE;

}

function usercheck($username)
{
	global $config;
	$user = db_getvar($config[utable],"username='$username'","username");
	
	if ($user) 
		return TRUE;
	else 
		return FALSE;

}

function avatar($username)
{
	global $config;
	
	$avatar = db_getvar($config[utable],"username='$username'","avatar");
	
	if ($avatar)
		return "<img src='$config[avatar_dir]$avatar' border=0 alt=''>";
	else
		return "";
}

function is_forum_open($forum)
{
	global $config;
	
	$fopts = db_getvar($config[ftable],"fname='$forum'","options");
	
	if ($fopts & 1)
		return TRUE;
	else
		return FALSE;
}

function is_thread_open($forum,$threadid)
{
	global $config;
	
	$fopts = db_getvar($config[mtable],"fname='$forum' AND threadid='$threadid' AND threadindex='0'","options");
	
	if ($fopts & 1)
		return TRUE;
	else
		return FALSE;
}

function lastthread($forum)
{
/* Return the last used thread id for a given $forum */
/* Will return -1 for no available threadids */
	global $config;
	
	if (db_numrows($config[mtable],"fname='$forum'")>0)
	{
		$result = db_select("SELECT * FROM $config[mtable] WHERE fname='$forum' ORDER BY threadid DESC LIMIT 0,1");
	
		while($row = db_getarray($result))
		{
			$lastid=$row[threadid];
		}
	} 
	else 
	{
		$lastid = -1;
	}

	return $lastid;
}

function lastindex($forum,$threadid)
{
/* Return the last used thread index for a given $forum and $threadid */
/* Will return -1 for no available threadids */
	global $config;
	
	if (db_numrows($config[mtable],"fname='$forum'")>0)
	{
		$result = db_select("SELECT * FROM $config[mtable] WHERE fname='$forum' AND threadid='$threadid' ORDER BY threadindex DESC LIMIT 0,1");
		
		while($row = db_getarray($result))
		{
			$lastid=$row[threadindex];
		}
		
		//print "Debug: Forum: $forum Threadid: $threadid Last ID: $lastid<br>";
	} 
	else 
	{
		$lastid = -1;
	}
	
	return $lastid;
}

function lastthreaddate($forum,$threadid)
{
/* Return the most recent date for a given $forum */
/* Will return -1 for no available threadids */
	global $config;
	
	$result = db_select("SELECT posttime FROM $config[mtable] WHERE fname='$forum' AND threadid='$threadid' ORDER BY posttime DESC LIMIT 0,1");
	
	while($row = db_getarray($result))
	{
		$date=$row[posttime];
	}

	return $date;
}

function lastdate($forum)
{
/* Return the most recent date for a given $forum */
/* Will return -1 for no available threadids */
	global $config;
	
	$result = db_select("SELECT posttime FROM $config[mtable] WHERE fname='$forum' ORDER BY posttime DESC LIMIT 0,1");
	
	while($row = db_getarray($result))
	{
		$date=$row[posttime];
	}

	return $date;
}
?>