<?
/**************************************

electrifiedForum
Version 0.99rc3 - November 2, 2001

Copyright 2001- electrifiedpenguin.com

This is free software, please leave all
copyright notices intact, thanks!

This is the filesystems function file

MAKE NO CHANGES TO THIS FILE
Customizing options are in the realm files!!!

***************************************/

function dir_list($dirname)
{
	$handle=opendir($dirname);
	while ($file = readdir($handle))
	{
   		if($file=='.'||$file=='..'||is_dir($dirname.$file)) continue;
   		$result_array[]=$file;
 	}
 	closedir($handle);
 	return $result_array;
}

?>