<?
$lang[to]					= 'to';
$lang[the]				= 'the';

$lang[index] 			= 'Index';
$lang[forums] 		= 'forums';
$lang[register] 	= 'Register';
$lang[login]			=	'Login';
$lang[search]			=	'Search';

$lang[forum]			= 'Forum';
$lang[description]	= 'Description';
$lang[topics]			= 'Topics';
$lang[msgs]				=	'Msgs';
$lang[mr]					= 'Most Recent';

$lang[ylvo]				= 'You last visited on';
$lang[at]					= 'at';
$lang[legend]			= 'Legend';
$lang[fws]				= 'Forum-wide Stats';
$lang[powby]			= 'Powered By';

$lang[total]			= 'Total';
$lang[message]		= 'Message';
$lang[messages]		=	'Messages';
$lang[users]			=	'Users';
$lang[nm]					= 'New Messages';
$lang[nnm]				=	'No New Messages';

$lang[wb]					= 'Welcome Back';
$lang[ao]					= 'Administrative Options';
$lang[manage]			= 'Manage';

$lang[profile]		= 'Profile';
$lang[logout]			=	'Logout';
$lang[owner]			= 'Owner';	

$lang[member]			= 'Member';
$lang[administrator]	= 'Administrator';
$lang[age]				= 'Age';
$lang[mnyr]				= 'Member not yet rated';
$lang[posted]			= 'Posted';

$lang[title]			= 'Title';
$lang[poster]			= 'Poster';

$lang[gf]					= 'General Forums';
$lang[error]			= 'Error';

$lang[previous]		= 'Previous';
$lang[next]				= 'Next';

$lang[movethread]	= 'Move Thread';
$lang[closethread]=	'Close Thread';
$lang[thread]			= 'Thread';

$lang['new']			=	'New';
$lang[post]				= 'Post';
$lang[icon]				= 'Icon';
$lang[reply]			= 'Reply';
$lang[edit]				= 'Edit';
$lang[options]		= 'Options';
$lang['delete']		= 'Delete';

?>