<?
$lang[to]				= 'naar';
$lang[the]				= 'de';

$lang[index] 			= 'Index';
$lang[forums] 			= 'forums';
$lang[register] 		= 'Aanmelden';
$lang[login]			= 'Login';
$lang[search]			= 'Zoeken';

$lang[forum]			= 'Forum';
$lang[description]		= 'Beschrijving';
$lang[topics]			= 'Topics';
$lang[msgs]				= 'Berichten';
$lang[mr]				= 'Laatste Bericht';

$lang[ylvo]				= 'Uw laatste bezoek was op';
$lang[at]				= '';
$lang[legend]			= 'Legenda';
$lang[fws]				= 'Forum-statistieken';
$lang[powby]			= 'Powered By';

$lang[total]			= 'Totaal';
$lang[message]			= 'Bericht';
$lang[messages]			= 'Berichten';
$lang[users]			= 'Gebruikers';
$lang[nm]				= 'Nieuwe Berichten';
$lang[nnm]				= 'Geen Nieuwe Berichten';

$lang[wb]				= 'Welkom Terug';
$lang[ao]				= 'Administratieve Opties';
$lang[manage]			= 'Beheer';

$lang[profile]			= 'Profiel';
$lang[logout]			= 'Logout';
$lang[owner]			= 'Eigenaar';	

$lang[member]			= 'Lid';
$lang[administrator]	= 'Beheerder';
$lang[age]				= 'Leeftijd';
$lang[mnyr]				= 'Nog geen beoordeling';
$lang[posted]			= 'Gepost';

$lang[title]			= 'Titel';
$lang[poster]			= 'Poster';

$lang[gf]				= 'Algemene Fora';
$lang[error]			= 'Fout';

$lang[previous]			= 'Vorige';
$lang[next]				= 'Volgende';

$lang[movethread]		= 'Verplaats Thread';
$lang[closethread]		= 'Sluit Thread';
$lang[thread]			= 'Thread';

$lang['new']			= 'Nieuw';
$lang[post]				= 'Post';
$lang[icon]				= 'Icon';
$lang[reply]			= 'Beantwoorden';
$lang[edit]				= 'Bewerken';
$lang[options]			= 'Opties';
$lang['delete']			= 'Verwijder';
?>