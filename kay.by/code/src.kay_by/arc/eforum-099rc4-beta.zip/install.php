<?
$version = ".99rc4";

$unwritable_message = "<font style='font-size: 32px; color: red; font-weight: bold;'>Error: The directory electrifiedForum is installed into needs to be CHMOD 777 so it is writable by the PHP process.<br> When you have made this change, reload this page to continue the install process.<br> Once you are done creating realms you should CHMOD 755 this directory.</font>";

if (!$realm)
	$realm = "default";

$config[dbhost]=$dbhost;
$config[dbuser]=$dbuser;
$config[dbpass]=$dbpass;
$config[dbname]=$dbname;

include 'funcs.mysql.php';

htmlstart();

if (!is_writable(getcwd()))
	die($unwritable_message);
if (file_exists("realm.$realm.php"))
	$realm_exists = TRUE;
	
	
function check_table_existence($table)
{
	global $config;
	
	if (db_select("SHOW FIELDS FROM $table"))
	{
		return TRUE;
	}
	else 
	{
		return FALSE;
	}

}

function lang_array(){
	$handle=opendir("lang");
	while ($file = readdir($handle)){
   	if($file=='.'||$file=='..') continue;
   	$files[]=$file;
 	}
 	closedir($handle);
	for($i=0;$i<sizeof($files);$i++){
		if (substr($files[$i],0,4)=="lang"){
			$langs[]=preg_replace("/lang\.(.*?)\.php/si","\\1",$files[$i]);
		}
	}
	return $langs;

}

if ($submit)
{
	
	if (file_exists("realm.$realm.php"))
	{

		die ("Error: Realm $realm already exists!");

	}
	else
	{	
	

		$phpver = phpversion();
		$ext[ldap] = extension_loaded("ldap");
		$ext[mysql] = extension_loaded("mysql");
		$installer[ip] = getenv("REMOTE_ADDR");
		$installer[browser] = getenv("HTTP_USER_AGENT");
		$server[os] = getenv("OSTYPE");
		$server[web] = getenv("SERVER_SOFTWARE");
		$server[host] = getenv("HTTP_HOST");
		if (!db_connect())
		{
			$conn_error = TRUE;
			$errors++;
		}	
		
		if ($ext[mysql] && !$conn_error){
				//db_connect();
				$res_version = mysql_query("SELECT Version() as version");
				$mysql = mysql_fetch_array($res_version);
		}
		
		print "<strong><font size='+2'>Installing electrifiedForum $version</font></strong><br><br>";
		print "<strong>System Information</strong><br>";
		print "PHP Version: $phpver<br>";
		if (floor($phpver)<4)
			print "<font color=red>PHP Version Not 4.0 or Greater</font> You may have problems<br>";
		if ($conn_error)
			print "<font color=red>Unable to connect to MySQL host at $dbhost</font> Please check hostname and permissions for the MySQL database.<br>";
		print "MySQL Version: $mysql[version]<br>";
		if (!strstr($mysql[version],"3.23"))
			print "<font color=red>MySQL Version Not 3.23.x</font> You may have problems<br>";
		print "Server OS: $server[os]<br>";
		print "Web Server Daemon: $server[web]<br>";
		print "Server Hostname: $server[host]<br>";
		
		print "<br>";
		if ($ext[mysql])
			print "MySQL Extension Loaded<Br>";
		if ($ext[ldap])
			print "LDAP Extension Loaded (Not yet used)<Br>";
			
	
		print "<br><hr noshade width=20% align=left>";
		print "Building MySQL Tables in database $config[dbname]...<br><br>";
		
		if ($ext[mysql] && !$conn_error)
		{
			print "Creating forums table...";
			if (!check_table_existence("forums"))
			{
				if (mysql_query("CREATE TABLE forums (
             fname varchar(20) NOT NULL,
             ftitle varchar(30) NOT NULL,
             fdesc varchar(200) NOT NULL,
             cat varchar(40) NOT NULL,
             owner varchar(100) NOT NULL,
             icon varchar(100) NOT NULL,
             options smallint(6) DEFAULT '1' NOT NULL,
						 forumpassword varchar(100) NOT NULL,
             PRIMARY KEY (fname),
             UNIQUE fname (fname),
             KEY fname_2 (fname));"))
					{
					print "Success<br>";
				} 
				else 
				{
					print "<font color=red>Error:</font> ".mysql_error()."<br>";
					$errors++;
				}
			
			mysql_query("INSERT INTO forums VALUES ('chat','Chat','A forum to talk about anything and everything!','General','$adminuser','','1');");
			
			
			} 
			else 
			{
				print "<font color=red>Warning!</font> Forums table Already Exists!<br>";
				$warnings++;
			}
		
			print "Creating users table...";
			if (!check_table_existence("fusers")){
				if (mysql_query("CREATE TABLE fusers (
						 	username varchar(20) NOT NULL,
							password varchar(20) NOT NULL,
							level smallint(6) DEFAULT '0' NOT NULL,
							options tinyint(4) DEFAULT '0' NOT NULL,
             	location varchar(100) NOT NULL,
             	email varchar(100) NOT NULL,
             	homepage varchar(200) NOT NULL,
             	showemail tinyint(4) DEFAULT '0' NOT NULL,
             	icq varchar(20) NOT NULL,
             	showicq tinyint(4) DEFAULT '0' NOT NULL,
             	aim varchar(40) NOT NULL,
             	showaim tinyint(1) DEFAULT '0' NOT NULL,
             	yahoo varchar(80) NOT NULL,
             	showyahoo tinyint(1) DEFAULT '0' NOT NULL,
             	realname varchar(100) NOT NULL,
             	age smallint(6) DEFAULT '0' NOT NULL,
             	birthday varchar(8) NOT NULL,
             	showbirthday tinyint(4) DEFAULT '0' NOT NULL,
             	gender varchar(10) NOT NULL,
             	avatar varchar(60) NOT NULL,
   						sig text NOT NULL,
   						disabled tinyint(1) DEFAULT '0' NOT NULL,
   						rank smallint(6) DEFAULT '0' NOT NULL,
   						votes smallint(6) DEFAULT '0' NOT NULL,
   						PRIMARY KEY (username),
   						UNIQUE username (username),
   						KEY username_2 (username));"))
				{
					print "Success<br>";
				} 
				else 
				{
					print "<font color=red>Error:</font> ".mysql_error()."<br>";
					$errors++;
				}
				if ($pass_encrypt == "mysql")
					mysql_query("INSERT INTO fusers VALUES ( '$adminuser', PASSWORD('$adminpass'), '10', '0', '', '', '', '0', '', '0', '', '0', '', '0', '', '', '', '0', '', '', '', '0', '', '');");
				else
					mysql_query("INSERT INTO fusers VALUES ( '$adminuser', '$adminpass', '10', '0', '', '', '', '0', '', '0', '', '0', '', '0', '', '', '', '0', '', '', '', '0', '', '');");

			} 
			else 
			{
				print "<font color=red>Warning!</font> Users table Already Exists!<br>";
				$warnings++;
			}
			
		
			print "Creating messages table...";
			if (!check_table_existence("messages")){
				if (mysql_query("CREATE TABLE messages (
             id smallint(6) NOT NULL auto_increment,
             fname varchar(20) NOT NULL,
             threadid smallint(6) DEFAULT '0' NOT NULL,
             threadindex smallint(6) DEFAULT '0' NOT NULL,
             poster varchar(100) NOT NULL,
             title varchar(120) NOT NULL,
             content text NOT NULL,
             icon varchar(60) NOT NULL,
             ip varchar(60) NOT NULL,
             posttime timestamp(14),
             options smallint(6) DEFAULT '1' NOT NULL,
             PRIMARY KEY (id),
             UNIQUE id (id),
             KEY forumname (fname));"))
				{
					print "Success<br>";
				} 
				else 
				{
					print "<font color=red>Error:</font> ".mysql_error()."<br>";
					$errors++;
				}
					mysql_query("INSERT INTO messages VALUES ('1','chat','0','0','$adminuser','Welcome to electrifiedForum', 'If you see this message, electrifiedForum is properly installed and configured!!', '', '', now(), '1')");
			} 
			else 
			{
				print "<font color=red>Warning!</font> Messages table Already Exists!<br>";
				$warnings++;
			}
			
			print "Creating private messages table...";
			if (!check_table_existence("pmessages")){
				if (mysql_query("CREATE TABLE pmessages (
         			id smallint(6) NOT NULL auto_increment,
         			mto varchar(20) NOT NULL,
         			mfrom varchar(20) NOT NULL,
         			status smallint(6) DEFAULT '0' NOT NULL,
         			subject varchar(120) NOT NULL,
         			message text NOT NULL,
         			senttime timestamp(14),
         			PRIMARY KEY (id),
         			UNIQUE id (id));"))
				{
					print "Success<br>";
				} 
				else 
				{
					print "<font color=red>Error:</font> ".mysql_error()."<br>";
					$errors++;
				}
			} 
			else 
			{
				print "<font color=red>Warning!</font> Private Messages table Already Exists!<br>";
				$warnings++;
			}
				print "Creating Anonymous User...";
				if (!$config[utable])
					$config[utable] = 'fusers';
				if (mysql_db_query($config[dbname],"INSERT INTO $config[utable] (username, password, level, options, location, email, homepage, showemail, icq, showicq, aim, showaim, yahoo, showyahoo, realname, age, birthday, showbirthday, gender, avatar, sig, disabled, rank, votes) VALUES ('Anonymous', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '1', '', '')"))
					print "Success<br>";
				else 
				{
					print "<font color=red>Error:</font> ".mysql_error()."<br>";
					$errors++;
				}
			
		} 
		else 
		{
			if (!$ext[mysql])
				print "<strong><font color=red>FATAL ERROR</font></strong>: Unable to build MySQL tables: MySQL Support Not Enabled in this version of PHP<br>";
			else
				print "<strong><font color=red>FATAL ERROR</font></strong>: Unable to build MySQL tables: Unable to connect to MySQL host. Please check username/password.<br>";
			$errors++;
		}
		
   	/* Now to open up the template file, parse the vars, and writeout the realm file */
   	if ($ext[mysql] && !$conn_error)
		{
   		$tf = fopen('realmtemplate.txt','r'); 
   		$templa = fread($tf, filesize('realmtemplate.txt'));

			$replacees = array("[%REALM-TITLE%]", "[%DB-HOST%]", "[%DB-USER%]", "[%DB-PASS%]", "[%DB-NAME%]", "[%DESCRIPTION%]", "[%KEYWORDS%]", "[%BGCOLOR%]", "[%TTCOLOR%]", "[%TTTEXTCOLOR%]", "[%TEXTCOLOR%]", "[%LINKCOLOR%]", "[%TBGCOLOR%]", "[%TRCOLORA%]", "[%TRCOLORB%]", "[%SEC_PASS_ENCRYPT%]", "[%LANGUAGE%]", "[%ANON%]", "[%TOPICSPERPAGE%]", "[%POSTSPERPAGE%]");
			
			$replacers = array($title, $dbhost, $dbuser, $dbpass, $dbname, $description, $keywords, $bgcolor, $ttcolor, $tttcolor, $textcolor, $linkcolor, $tbgcolor, "#e5e5e5", "#d7d7d7", $pass_encrypt, $language, $anon, $topics, $posts);
			
   		$data = str_replace($replacees,$replacers,$templa);

   		fclose($tf);
		
			print "Creating realm file realm.$realm.php...";
			if ($rf = @fopen("realm.$realm.php",'w'))
			{
   			print "Success<br>";
			} 
			else 
			{
				print "<font color=red>Error</font><br>";
				$errors++;			
			}
			print "Writing to realm file realm.$realm.php...";
			if (@fwrite($rf,$data)){
				print "Success<br>";
			} else {
				print "<font color=red>Error</font><br>";
				$errors++;			
			}
   		@fclose($rf);
		
			@chmod("realm.$realm.php", 0777);
   	}
		print "<br>";
		if (!$errors && !$warnings)
			print "Install successful, No errors or warnings<br>";
		elseif (!$errors)
			print "Install complete but with warnings<br>";
		else
			print "Errors occurred during Installation.<br><br>To recieve help, please copy this entire page into the support forums at <a href='http://www.electrifiedpenguin.com/forums/'>www.electrifiedpenguin.com</a> or email to <a href='mailto:support@electrifiedpenguin.com'>support@electrifiedpenguin.com</a><br>";
	
		if (substr(str_replace(".","",phpversion()),0,3)>=402)
  		if (strstr("Windows",php_uname()) || getenv("WINDIR"))
  			if (ini_get("session.save_path")=="/tmp")
  			{
  				print "You appear to be running this installer on a windows host. eF uses PHP sessions, and the session.save_path in php.ini is currently incorrect.<br>";
  				print "Please resolve this by editing php.ini and setting session.save_path to a valid temporary directory on your system, such as c:\\temp.<br>";
  			}
	}
		
} 
else 
{
/* Installation Options Form */

$langs =lang_array();
?>
<script>
function setBgSample(){
ble=document.inopts.bgcolor.value;
window.document.all.bgcolorclr.bgColor=ble;
}
function setTcSample(){
ble=document.inopts.textcolor.value;
window.document.all.textcolorclr.bgColor=ble;
}
function setTtSample(){
ble=document.inopts.ttcolor.value;
window.document.all.ttcolorclr.bgColor=ble;
}
function setTttSample(){
ble=document.inopts.tttcolor.value;
window.document.all.tttcolorclr.bgColor=ble;
}
function setLinkSample(){
ble=document.inopts.linkcolor.value;
window.document.all.linkcolorclr.bgColor=ble;
}
function setTbgSample(){
ble=document.inopts.tbgcolor.value;
window.document.all.tbgcolorclr.bgColor=ble;
}
</script>
<form action='install.php' method=post name="inopts">
<table border=0 cellpadding=0 cellspacing=0 width='80%'>
	<TR>
	<td bgcolor="#808080">
	<table border=0 cellspacing=1 cellpadding=4 width='100%'>
	<tr>
	<td colspan=2 bgcolor="#3300ff" class=tabletop>
		<div class="forumtitle">Install electrifiedForum <?=$version?></div>
	</td>
	</tr>
	<tr bgcolor="#e5e5e5">
	<td colspan=2>Please fill out the form below in order to install or create a new realm for electrifiedForum <?=$version?>.<br>
<i>DO NOT run this if you are upgrading from a previous electrifiedForum! Use upgrade.php instead</i><br>
Options selected here can be changed later by directly editing the realm.<i>realmname</i>.php file.</td>
	</tr>
	<tr bgcolor="#d7d7d7">
	<td>
	Realm:<br>
	<font size='-1'>Note: Default will be used if this is the first realm.</font>
	</td>
	<?
	if ($realm_exists)
		print "<td><input type=text name=realm value=''></td>";
	elseif (!file_exists("realm.default.php"))
		print "<td><input type=hidden name=realm value='default'>Default</td>";
	else
		print "<td><input type=text name=realm value='$realm'></td>";
	?>
	</tr>	
	<tr bgcolor="#e5e5e5">
	<td>Administrator User Name:</td><td><input type=text name=adminuser></td>
	</tr>
	<tr bgcolor="#d7d7d7">
	<td>Administrator Password:</td><td><input type=text name=adminpass></td>
	</tr>
	<tr bgcolor="#e5e5e5">
	<td>Title of forums:</td><td><input type="text" name=title></td>
	</tr>
	<tr bgcolor="#d7d7d7">
	<td>MySQL Database Host:</td><td><input type="text" name=dbhost></td>
	</tr>		
	<tr bgcolor="#e5e5e5">
	<td>MySQL Database Username:</td><td><input type="text" name=dbuser></td>
	</tr>
	<tr bgcolor="#d7d7d7">
	<td>MySQL Database Password:</td><td><input type="text" name=dbpass></td>
	</tr>		
	<tr bgcolor="#e5e5e5">
	<td>MySQL Database Name:</td><td><input type="text" name=dbname></td>
	</tr>
	<tr bgcolor="#d7d7d7">
	<td>Meta Description:</td><td><input type="text" name=description></td>
	</tr>		
	<tr bgcolor="#e5e5e5">
	<td>Meta Keywords:</td><td><input type="text" name=keywords></td>
	</tr>
	<tr bgcolor="#d7d7d7">
	<td>Background Color:</td><td><input type="text" name=bgcolor value='#FFFFFF' onchange='javascript:setBgSample();' onblur='javascript:setBgSample();'>
	<?  cShow("bgcolor"); ?> 
	</td>
	</tr>
	<tr bgcolor="#e5e5e5">
	<td colspan=2><? cpicker("bgcolor"); ?></td>
	</tr>
	<tr bgcolor="#d7d7d7">
	<td>Default Text Color:</td><td><input type="text" name=textcolor value='#000000' onchange='javascript:setTcSample();' onblur='javascript:setTcSample();'>
	<?  cShow("textcolor","#000000"); ?>
	</td> 
	</tr>
	<tr bgcolor="#e5e5e5">
	<td colspan=2><? cpicker("textcolor"); ?></td>
	</tr>
	<tr bgcolor="#d7d7d7">
	<td>Default Link Color:</td><td><input type="text" name=linkcolor value='#0000FF' onchange='javascript:setLinkSample();' onblur='javascript:setLinkSample();'>
	<?  cShow("linkcolor","#0000FF"); ?> 
	</td>
	</tr>
	<tr bgcolor="#e5e5e5">
	<td colspan=2><? cpicker("linkcolor"); ?></td>
	</tr>				

	<tr bgcolor="#d7d7d7">
	<td>Table Top Color:</td><td><input type="text" name=ttcolor value='#3300FF' onchange='javascript:setTtSample();' onblur='javascript:setTtSample();'>
	<?  cShow("ttcolor","#3300FF"); ?> 
	</td>
	</tr>
	<tr bgcolor="#e5e5e5">
	<td colspan=2><? cpicker("ttcolor"); ?></td>
	</tr>
	<tr bgcolor="#d7d7d7">
	<td>Table Top Text Color:</td><td><input type="text" name=tttcolor value='#FFFFFF' onchange='javascript:setTttSample();' onblur='javascript:setTttSample();'>
	<?  cShow("tttcolor","#FFFFFF"); ?> 
	</td>
	</tr>
	<tr bgcolor="#e5e5e5">
	<td colspan=2><? cpicker("tttcolor"); ?></td>
	</tr>
	<tr bgcolor="#d7d7d7">
	<td>Table Border Color:</td><td><input type="text" name=tbgcolor value='#808080' onchange='javascript:setTbgSample();' onblur='javascript:setTbgSample();'>
	<?  cShow("tbgcolor","#808080"); ?> 
	</td>
	</tr>
	<tr bgcolor="#e5e5e5">
	<td colspan=2><? cpicker("tbgcolor"); ?></td>
	</tr>
	<tr bgcolor="#d7d7d7">
	<td>Language:</td><td><select name=language><? for($i=0;$i<sizeof($langs);$i++){ print "<option value=$langs[$i]>$langs[$i]"; } ?></select></td>
	</tr>
	<tr bgcolor="#e5e5e5">
	<td>Password Encryption:</td><td><select name=pass_encrypt><option value="mysql">MySQL<option value="">None</select></td>
	</tr>	
	<tr bgcolor="#d7d7d7">
	<td>Allow Anonymous:</td><td><select name=anon><option value=TRUE>Yes<option value=FALSE>No</select></td>
	</tr>
	<tr bgcolor="#e5e5e5">
	<td>Topics Per Page:</td><td><select name=topics><option value="50">50<option value="30" SELECTED>30<option value="20">20</select></td>
	</tr>			
	<tr bgcolor="#d7d7d7">
	<td>Posts Per Page::</td><td><select name=posts><option value="30">30<option value="20" SELECTED>20<option value="10">10</select></td>
	</tr>									
</table>
</td>
</tr>
</table>


<input type=submit name=submit value='Install'>

</form>
<?


}

function htmlstart(){
	?>
	
	<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
		
		<html>
		<head>
		<title>electrifiedForum <?=$version?> Installer</title>
		<style>
			BODY,TD,.content {
				font-family : Verdana, Geneva, Arial, Helvetica, sans-serif;
				font-size : 12px;
			}
			.menu {
				font-size: 11px;
			}
			.rightbox {
				font-size: 11px;
			}
			.large {
				font-size: 36px;
				font-weight: bold;
			}
			A {
				text-decoration: none;
				color: #0000ff;
			}
			.menu A:HOVER {
				text-decoration: none;
				color: white;
				background-color: purple;
			}
			.newsHead {
				color: white;
				font-weight: bold;
				padding-left: 3px;
			}
			.newsContent {
				padding-left: 3px;
			}
			.menu A.heading {
				text-decoration: none;
				color: black;
			}
			.menu A.heading:HOVER {
				text-decoration: underline;
				color: black;
				background-color: white;
			}
			.error {
				color: red;
			}
			.messages {
				font-family : Verdana, Geneva, Arial, Helvetica, sans-serif;
				font-size : 12px;
			}
			.tabletop, .tabletop A {
				color: white;
				font-size: 11px;
				text-decoration: none;
			}
			.ftitle {
				color: white;
				font-size: 12px;
				font-weight: bold;
			}
			.messagebody {
				padding : 4px;
			}
			.messagetitle {
				font-size: 11px;
				padding : 2px;
			}
			.forumtitle {
				font-size: 16px;
				font-weight: bold;
			}
			
		</style>
	</head>
	
	<body bgcolor="#FFFFFF" text="#000000" link="#0000FF" vlink="#0000FF" alink="#0000FF">
	<?

}

function cshow($field,$color="#FFFFFF")
{
?>
<div style="border-color: black; border-style: solid; border-width: 1px; width=100"><table id="<?=$field?>clr" bgcolor=<?=$color?>><tr><td width=100 height=10>&nbsp;</td></tr></table></div>
<?
}

function cpicker($field)
{
/* color picker */
?>

<SCRIPT LANGUAGE="JavaScript">
<!-- ;

function toHex(dec) { //Converts dec to hex
	hexChars="0123456789ABCDEF"
		if (dec > 255) {
			return null
	}
	var i = dec % 16
		var j = (dec - i) / 16
		result = hexChars.charAt(j)
		result += hexChars.charAt(i)
		return result
}
/*########################################################################*/
/*# THIS SCRIPT �1997 RON COSCORROSA (rc@europa.com)                     #*/
/*# IF YOU WANT TO USE THIS CODE YOU MUST INCLUDE THIS COPYRIGHT NOTICE. #*/
/*# http://www.europa.com/~rc/javascript/                                #*/
/*########################################################################*/
function cPicker<?=$field?>(red,green,blue) {
document.inopts.<?=$field?>red.value=red
document.inopts.<?=$field?>green.value=green
document.inopts.<?=$field?>blue.value=blue
brn="#" + toHex(red) + toHex(green) + toHex(blue)
document.inopts.<?=$field?>.value=brn
window.document.all.<?=$field?>clr.bgColor=brn
}
// -->
</SCRIPT>


<SCRIPT LANGUAGE="JavaScript">
<!-- ;

Cstring="<table border=0 cellpadding=0 cellspacing=0><tr>"
	for(i=0;i<=255*6;i+=8) { //lower the increment, the more accurate (and slower)
		if(i > 0 && i <=255 * 1) {
			incColor=i
			Cstring+="<td bgcolor=#" + toHex(255) + toHex(incColor) + toHex(0) + "><a href='javascript:cPicker<?=$field?>(255," + incColor + ",0)'>&nbsp;</a></td>"
		} else {
		if(i>255*1 && i <=255*2) {
			incColor=(255-(i-255))
				Cstring+="<td bgcolor=#" + toHex(incColor) + toHex(255) + toHex(0) + "><a href='javascript:cPicker<?=$field?>(" + incColor + ",255,0)'>&nbsp;</a></td>"
			
			} else {
			if(i>255*2 && i <=255*3) {
				incColor=i-(2*255)
					Cstring+="<td bgcolor=#" + toHex(0) + toHex(255) + toHex(incColor) + "><a href='javascript:cPicker<?=$field?>(0,255," + incColor + ")'>&nbsp;</a></td>"
				
				} else {
				if(i>255*3 && i <=255*4) {
					incColor=255-(i-(3*255))
						Cstring+="<td bgcolor=#" + toHex(0) + toHex(incColor) + toHex(255) + "><a href='javascript:cPicker<?=$field?>(0," + incColor + ",255)'>&nbsp;</a></td>"
					
					} else {
					if(i>255*4 && i <=255*5) {
						incColor=i-(4*255)
							Cstring+="<td bgcolor=#" + toHex(incColor) + toHex(0) + toHex(255) + "><a href='javascript:cPicker<?=$field?>(" + incColor + ",0,255)'>&nbsp;</a></td>"
						
						} else {
						if(i>255*5 && i <255*6) {
							incColor=255-(i-(5*255))
								Cstring+="<td bgcolor=#" + toHex(255) + toHex(0) + toHex(incColor) + "><a href='javascript:cPicker<?=$field?>(255,0," + incColor + ")'>&nbsp;</a></td>"
							
						}
					}
				}
			}
		}
	}
}
Cstring+="</tr></table>"
document.write(Cstring)
b_wString="<table border=0 cellpadding=0 cellspacing=0>"
for(i=0;i<=255;i+=2){
		b_wString+="<td bgcolor=#" + toHex(i) + toHex(i) + toHex(i) + "><a href='javascript:cPicker<?=$field?>(" + i + "," + i + "," + i + ")'>&nbsp;</a></td>"
		if (i==254){
			i=255
			b_wString+="<td bgcolor=#" + toHex(i) + toHex(i) + toHex(i) + "><a href='javascript:cPicker<?=$field?>(" + i + "," + i + "," + i + ")'>&nbsp;</a></td>"
		}
}
b_wString+="</tr></table>"
document.write(b_wString)
// -->
</SCRIPT>

<input type=hidden name="<?=$field?>red" value="0" maxlength=3>
<input type=hidden name="<?=$field?>green" value="0" maxlength=3>
<input type=hidden name="<?=$field?>blue" value="0" maxlength=3>





<?
}
?>




