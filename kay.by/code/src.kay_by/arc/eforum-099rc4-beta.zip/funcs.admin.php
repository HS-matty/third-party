<?
/**************************************

electrifiedForum
Version 0.99rc3 - November 2, 2001

Copyright 2001- electrifiedpenguin.com

This is free software, please leave all
copyright notices intact, thanks!

This is the admin functions file

MAKE NO CHANGES TO THIS FILE
Customizing options are in the realm files!!!

***************************************/

function manageusers()
{
	global $forumsess,$config,$realm,$sortby;

	if (admincheck($forumsess[$realm][username]))
	{
		if (db_numrows_all($config[utable])>0)
		{
			
			if ($sortby)		
				$result = db_select("SELECT * FROM $config[utable] ORDER BY $sortby ASC");
			else 
				$result = db_select("SELECT * FROM $config[utable] ORDER BY username ASC");
				
			print "<table border=0 cellpadding=0 cellspacing=0 width='$config[table_width]'><TR>
			<td bgcolor='$config[tcolor]'>
			<table border=0 cellspacing=1 cellpadding=4 width='100%'>";
			
			print "<tr bgcolor='".$config['color_top']."'>

			<td class=tabletop width=150> <strong><a href='index.php?action=manageusers&realm=$realm&sortby=username'>Username</a></strong> </td>
			<td class=tabletop> <strong><a href='index.php?action=manageusers&realm=$realm&sortby=level'>Level</a></strong> </td>
			<td class=tabletop> <strong>Msgs</strong> </td>
			<td class=tabletop> <strong>Actions</strong> </td>
			</tr>";
			
			$i = 0;
			
			while($row = db_getarray($result))
			{
							
				$i = $i + 1;
		
				if ($i % 2)
					$bgcolor = $config['color_b'];
				else
				  $bgcolor = $config['color_a'];
			
				if ($row[username] == $forumsess[$realm][username])
				{
					$promotetext = "";
					$demotetext = "";
				}
				else
				{
					$promotetext = "&nbsp;&nbsp; <a href='index.php?action=promoteuser&user=$row[username]&realm=$realm&'>Promote</a>";
					$demotetext = "&nbsp;&nbsp; <a href='index.php?action=demoteuser&user=$row[username]&realm=$realm&'>Demote</a>";
				}
			
				if ($row[disabled])
					$disabletext = "<a href='index.php?action=enableuser&user=$row[username]&realm=$realm&'>Enable</a>";
				else
					$disabletext = "<a href='index.php?action=disableuser&user=$row[username]&realm=$realm&'>Disable</a>";	
			
				if ($row[level] == 10)
				{
					$level = "Administrator $demotetext";
					$actions = "";
				}
				else
				{
					$level = "Member $promotetext";
					$actions = "$disabletext";
				}
				
				print "<tr bgcolor='$bgcolor'>

					<td valign=top><a href='index.php?action=userinfo&user=$row[username]&realm=$realm'>".$row[username]."</a></td>
					<td valign=top> $level </td>
					<td valign=top align=center>
					<a href='index.php?action=searchnow&realm=$realm&search%5Bkey%5D=".$row[username]."&search%5Btype%5D=poster'>
					".usermessagecount($row[username])."</a></td>
					<td valign=top>
					$actions
					</td>
					</tr>";
			}
			
			print "</table></td></tr></table>";

			
		}
		else
		{
			print "No users available<br>";
		}
		
	}
	else
	{
		print "You do not have sufficient access to manage users.<br>";
	}
	
}


function manageforums()
{
	global $forumsess,$config,$realm;
	
	if (admincheck($forumsess[$realm][username]))
	{
		
		print "<a href='index.php?action=addforum&realm=$realm'>Add Forum</a><br><br>";
		
		if (db_numrows_all('forums')>0)
		{
				print "<table border=0 cellpadding=0 cellspacing=0 width='$config[table_width]'><TR>
				<td bgcolor='$config[tcolor]'><table border=0 cellspacing=1 cellpadding=4 width='100%'>";
							
			$result = db_select("SELECT cat FROM $config[ftable] GROUP BY cat");
			
			while($cat = db_getarray($result))
			{
			
				$result2 = db_select("SELECT * FROM $config[ftable] WHERE cat='$cat[cat]' ORDER BY ftitle ASC");
				
				if (!$cat[cat])
					$cat[cat] = $lang[gf];
			
			
				print "<tr bgcolor='".$config['color_top']."'>

				<td class=tabletop colspan=5> <strong>$cat[cat]</strong> </td>

				</tr>";
				print "<tr bgcolor='".$config['color_top']."'>
				<td class=tabletop> <b>Status</b> </td>
				<td class=tabletop width=150> <b>Forum</b> </td>
				<td class=tabletop> <b>Topics</b> </td>
				<td class=tabletop> <b>Messages</b> </td>
				<td class=tabletop> <b>Actions</b> </td>
				</tr>";
				
				$i = 0;
				
				while($row = db_getarray($result2)){
								
					$i = $i + 1;
			
					$options = $row[options];
					
					if (!$options & 1)
						$closed = TRUE;
					else
						$closed = FALSE;
					
					if ($options & 2)
						$private = TRUE;
					else
						$private = FALSE;
			
					if ($i % 2)
						$bgcolor = $config['color_b'];
					else
					  $bgcolor = $config['color_a'];
				
				 	/*
					if ($row[icon]) 
						$icon = "<img src='$row[icon]'>";
					else
						$icon = "<img src='$config[forumicon]'>";
					*/
					$status = NULL;
					if ($closed)
						$status = "Closed<br>";
					else
						$status = "Open<br>";
					if ($private)
						$status .= "Private";
					
					print "<tr bgcolor='$bgcolor'>
						<td valign=top>$status</td>
						<td valign=top><a href='index.php?forum=$row[fname]&realm=$realm'>".$row[ftitle]."</a></td>
						<td valign=top>".topiccount($row[fname])."</td>
						<td valign=top>".messagecount($row[fname])."</td>
						<td valign=top>
						<a href='index.php?action=editforum&forum=".$row[fname]."&realm=$realm'>Edit</a>
						<a href='index.php?action=deleteforum&forum=".$row[fname]."&realm=$realm'>Delete</a>
						<a href='index.php?action=deleteforum&forum=".$row[fname]."&delall=1&realm=$realm'>Delete Clean</a>
						</td>
						</tr>";
				}
								
			}
			
			print "</table></td></tr></table>";

			
		} 
		else
		{
			print "No forums available<br>";
		}
				
		
	} 
	else
	{
		print "You do not have sufficient access to manage forums.<br>";
	}

}

function catlist()
{
	global $config;
	
	$result = db_select("SELECT cat FROM $config[ftable] GROUP BY cat");
			
	while($cat = db_getarray($result))
	{
			$c[] = $cat[cat];
	}
	return $c;
}

function addforum()
{
	global $forumsess,$config,$realm;
	
	if (admincheck($forumsess[$realm][username]))
	{
		?>
		
		<form action='index.php?action=saveforum&realm=<?=$realm?>' method=post>
			<table border=0 cellpadding=0 cellspacing=0 width='<?=$config[table_width]?>'><TR>
				<td bgcolor='<?=$config[tcolor]?>'>
			<table border=0 cellspacing=1 cellpadding=4 width='100%'>
			<tr bgcolor='<?=$config[color_top]?>'>
	
				<td class=tabletop colspan=2> <strong>Create New Forum</strong> </td>
	
				</tr>
		<tr  bgcolor="<?=$config['color_a']?>">
			<td valign=top width=120><strong>Forum Name (all lowercase, no spaces)</strong></td>
			<td><input type="text" name="post[fname]" size=30></td>
		</tr>
		<tr  bgcolor="<?=$config['color_b']?>">
			<td valign=top width=120><strong>Forum Title</strong></td>
			<td><input type="text" name="post[ftitle]" size=30></td>
		</tr>
		<tr  bgcolor="<?=$config['color_a']?>">
			<td valign=top width=120><strong>New Category</strong></td>
			<td><input type="text" name="post[newcat]" size=30></td>
		</tr>
			<tr  bgcolor="<?=$config['color_a']?>">
			<td valign=top width=120><strong>or Existing Category</strong></td>
			<td>
			<select name="post[cat]">
			<? 
			$cats = catlist();
			for ($i=0;$i<sizeof($cats);$i++)
			{
				print "<option value='$cats[$i]'>$cats[$i]";
			}
			?>
			</select>
			</td>
		</tr>
		<tr bgcolor="<?=$config['color_b']?>">
			<td valign=top><strong>Description</strong></td>
			<td><textarea cols="30" rows="4" name="post[fdesc]" wrap="soft" style="width: 90%;"></textarea></td>
		</tr>
		<tr bgcolor="<?=$config['color_a']?>">
			<td valign=top><strong>Options</strong></td>
			<td>
			<input type='checkbox' name='post[private]' value='2'> Private (Password Protected)<br>
			&nbsp;&nbsp;&nbsp;&nbsp; Password: <input type='text' name='post[forumpass]'>
			</td>
		</tr>
		<tr bgcolor="<?=$config['color_b']?>">
			<td>&nbsp;</td>
			<td><input type="submit" value="Save!" name="post[submit]"></td>
		</tr>
		</table>
		</td>
		</tr>
		</table>
		</form>
		
		<?
	} 
	else
	{
		print "You do not have sufficient access to add forums.<br>";
	}

}

function makeforum()
{
	global $forumsess,$config,$realm,$post;
	
	if (admincheck($forumsess[$realm][username]))
	{
		$options = 1 + $post[private];	
		$columns = "fname,ftitle,cat,fdesc,owner,options,forumpassword";
		if ($post[newcat])
			$values = "'$post[fname]','$post[ftitle]','$post[newcat]','$post[fdesc]','".$forumsess[$realm][username]."','$options',PASSWORD('$post[forumpass]')";
		else
			$values = "'$post[fname]','$post[ftitle]','$post[cat]','$post[fdesc]','".$forumsess[$realm][username]."','$options',PASSWORD('$post[forumpass]')";
			
		db_insert($config[ftable],$columns,$values);
	
		print "Successfully saved forum $post[ftitle]! ($post[fname])<br><br>";
		
		manageforums();
	}
	else
	{
		print "You do not have sufficient access to add forums.<br>";
	}

}

function editforum($fname)
{
	global $forumsess,$config,$realm;
	
	$row = db_getrow($config[ftable],"fname='$fname'");
	
	if (admincheck($forumsess[$realm][username]))
	{
		?>
		
		<form action='index.php?action=saveforumchange&forum=<?=$fname?>&realm=<?=$realm?>' method=post>
			<table border=0 cellpadding=0 cellspacing=0 width='<?=$config[table_width]?>'><TR>
				<td bgcolor='<?=$config[tcolor]?>'>
			<table border=0 cellspacing=1 cellpadding=4 width='100%'>
			<tr bgcolor='<?=$config[color_top]?>'>
	
				<td class=tabletop colspan=2> <strong>Edit Forum</strong> </td>
	
				</tr>
		<tr  bgcolor="<?=$config['color_a']?>">
			<td valign=top width=120><strong>Forum Name</strong></td>
			<td><?=$fname?></td>
		</tr>
		<tr  bgcolor="<?=$config['color_b']?>">
			<td valign=top width=120><strong>Forum Title</strong></td>
			<td><input type="text" name="post[ftitle]" value='<?=$row[ftitle]?>' size=30></td>
		</tr>
		<tr  bgcolor="<?=$config['color_a']?>">
			<td valign=top width=120><strong>Category</strong></td>
			<td><input type="text" name="post[cat]" value='<?=$row[cat]?>' size=30></td>
		</tr>
		<tr bgcolor="<?=$config['color_b']?>">
			<td valign=top><strong>Description</strong></td>
			<td><textarea cols="30" rows="4" name="post[fdesc]" wrap="soft" style="width: 90%;"><?=$row[fdesc]?></textarea></td>
		</tr>
		<tr bgcolor="<?=$config['color_b']?>">
			<td valign=top><strong>Options</strong></td>
			<td>
			<input type='checkbox' name='post[private]' value='2' <? if ($row[options] &2) print "CHECKED";?>> Private (Password Protected)<br>
			<?
				if ($row[forumpassword])
					print "Password Encrypted. To reset/change, enter a new one below:<br>";
			?>
			&nbsp;&nbsp;&nbsp;&nbsp; Password: <input type='text' name='post[forumpass]'>
			</td>
		</tr>
		<tr bgcolor="<?=$config['color_a']?>">
			<td>&nbsp;</td>
			<td><input type="submit" value="Save!" name="post[submit]"></td>
		</tr>
		</table>
		</td>
		</tr>
		</table>
		</form>
		
		<?
	}
	else 
	{
		print "You do not have sufficient access to edit forums.<br>";
	}

}

function saveforumchanges($fname)
{
	global $forumsess,$config,$realm,$post;
	
	if (admincheck($forumsess[$realm][username]))
	{
	
		$options = 1 + $post[private];	
		//$columns = array("ftitle","cat","fdesc","options","forumpassword");
		//$values = array($post[ftitle],$post[cat],$post[fdesc],$options,);
		if ($post[forumpass] && $post[private])
			$passupdt = ", forumpassword=PASSWORD('$post[forumpass]')";
			
		$sql = "UPDATE $config[ftable] SET ftitle='$post[ftitle]', cat='$post[cat]', fdesc='$post[fdesc]', options='$options'$passupdt WHERE fname='$fname'";
		
		//db_update($config[ftable],"fname='$fname'",$columns,$values);
		if (db_do($sql))		
			print "Successfully saved changes to forum $post[ftitle]! ($fname)<br><br>";
		
		manageforums();
	} 
	else 
	{
		print "You do not have sufficient access to edit forums.<br>";
	}

}

function removeforum($fname)
{
	global $forumsess,$config,$realm,$delall;
	
	if (admincheck($forumsess[$realm][username]))
	{
		
		print "Deleting forum $fname...";
		if (db_remove($config[ftable],"fname='$fname'"))
			print "done.<br>";
		
		if ($delall)
		{
			print "Deleting messages...";
			if (db_remove($config[mtable],"fname='$fname'"))
				print "done.<br>";
		}
		
		manageforums();
	}
	else 
	{
		print "You do not have sufficient access to remove forums.<br>";
	}

}

function userinfo($user)
{
	global $forumsess,$realm,$config;

	if (admincheck($forumsess[$realm][username]))
	{
		
		$row = db_getrow($config[utable],"username='$user'");
		
		$options = $row[options];
		$birthyear = substr($row[birthday],0,4);
		$birthday = substr($row[birthday],6,2);
		$birthmonth = substr($row[birthday],4,2);
	
		?>
		<FORM NAME="editprofile" ACTION="#">
		<table border=0 cellpadding=0 cellspacing=0 width="<?=$config[table_width]?>">
		<TR>
		<td bgcolor="<?=$config['tcolor']?>">
			<table border=0 cellspacing=1 cellpadding=4 width="100%">
					<tr bgcolor='<?=$config[color_top]?>'>
	
				<td class=tabletop colspan=2> <strong>Profile</strong> </td>
	
			</tr>
			<tr>
			<td bgcolor="<?=$config['color_a']?>" colspan=2>
			<FONT SIZE="2" FACE="Verdana, Arial">
			This is <?=$user?>'s Profile<br></FONT>
			</td></tr>

			<tr bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>User Name</B></FONT></TD>
			<TD><?=$row[username]?></TD>
			</TR>
			
			<TR bgcolor="<?=$config['color_a']?>">
				<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Email</B></FONT></TD>
				<TD><?=$row[email]?></TD>
			</TR>
	
			<TR bgcolor="<?=$config['color_b']?>">
				<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>ICQ Number</B></FONT></TD>
				<TD><?=$row[icq]?></TD>
			</tr>
	
			<TR bgcolor="<?=$config['color_a']?>">
				<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>AIM Screen Name</B></FONT></TD>
				<TD><?=$row[aim]?></TD>
			</tr>
			
			<TR bgcolor="<?=$config['color_b']?>">
				<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Yahoo ID</B></FONT></TD>
				<TD><?=$row[yahoo]?></TD>
			</tr>		
			
			<TR bgcolor="<?=$config['color_a']?>">
				<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>City, State, Country</B></FONT></TD>
				<TD><?=$row[location]?></TD>
			</tr>
	
			<TR bgcolor="<?=$config['color_b']?>">
				<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Birthday</B></FONT></TD>
				<TD><? print "$birthmonth-$birthday-$birthyear";?></TD>
			</tr>
			
			<TR bgcolor="<?=$config['color_a']?>">
				<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Gender</B></FONT></TD>
				<TD><?=$row[gender]?></TD>
			</tr>
			
			<TR bgcolor="<?=$config['color_b']?>">
				<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Homepage URL</B></FONT></TD>
				<TD><?=$row[homepage]?></TD>
			</tr>
			
			<TR bgcolor="<?=$config['color_a']?>">
				<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Privacy Options</B></FONT></TD>
				<TD>
				<INPUT TYPE="checkbox" NAME="reg[showemail]" VALUE="1" <? if ($options & 1) print "CHECKED";?>> Display email address<br>
				<INPUT TYPE="checkbox" NAME="reg[showicq]" VALUE="2" <? if ($options & 2) print "CHECKED";?>> Display ICQ Number<br>
				<INPUT TYPE="checkbox" NAME="reg[showaim]" VALUE="4" <? if ($options & 4) print "CHECKED";?>> Display AIM Screen Name<br>
				<INPUT TYPE="checkbox" NAME="reg[showyahoo]" VALUE="8" <? if ($options & 8) print "CHECKED";?>> Display Yahoo ID<br>
				<INPUT TYPE="checkbox" NAME="reg[showbirthday]" VALUE="16" <? if ($options & 16) print "CHECKED";?>> Display Age<br>
				<INPUT TYPE="checkbox" NAME="reg[showhomepage]" VALUE="32" <? if ($options & 32) print "CHECKED";?>> Display Homepage URL
				</TD>
			</TR>
	
			 <TR bgcolor="<?=$config['color_b']?>">
				<TD valign=top><FONT SIZE="2" FACE="Verdana, Arial"><B>Signature</B></font><BR></TD>
				<TD><?=$row[sig]?></TD>
			</tr>
			</TABLE></td></tr></table>
			</form>
		<?
	
	
	} 
	else 
	{
		print "You do not have sufficient access to view user profiles.<br>";
	}
}

function userpromote($user)
{
	global $forumsess,$realm,$config;
	if (admincheck($forumsess[$realm][username]))
	{

		$columns = array("level");
		$values = array('10');
		
		db_update($config[utable],"username='$user'",$columns,$values);

	
		print "Successfully promoted $user to admin status!<br><br>";
		
		manageusers();
	} 
	else 
	{
		print "You do not have sufficient access to promote users.<br>";
	}
}

function userdemote($user)
{
	global $forumsess,$realm,$config;
	if (admincheck($forumsess[$realm][username]))
	{

		$columns = array("level");
		$values = array('1');
		
		db_update($config[utable],"username='$user'",$columns,$values);

	
		print "Successfully demoted $user to member status!<br><br>";
		
		manageusers();
	} 
	else 
	{
		print "You do not have sufficient access to demote users.<br>";
	}
}

function userdisable($user)
{
	global $config,$forumsess,$realm;
	if (admincheck($forumsess[$realm][username]))
	{
		$columns = array('disabled');
		$values = array('1');
		if (db_update($config[utable],"username='$user'",$columns,$values))
			print "User $user Disabled.<br><br>";
		else
			print "Unable to disable user $user.<br><br>";
		manageusers();
	} 
	else 
	{
		print "You do not have sufficient access to disable users.<br>";
	}
	
}

function userenable($user)
{
	global $config,$forumsess,$realm;
	if (admincheck($forumsess[$realm][username]))
	{
		$columns = array('disabled');
		$values = array('0');
		if (db_update($config[utable],"username='$user'",$columns,$values))
			print "User $user Enabled.<br><br>";
		else
			print "Unable to enable user $user.<br><br>";
		manageusers();
	} 
	else 
	{
		print "You do not have sufficient access to enable users.<br>";
	}
	
}

function closethread($forum,$id)
{
	global $config,$forumsess,$realm;
	
	if (admincheck($forumsess[$realm][username]))
	{
		$oldopts = db_getvar($config[mtable],"threadid='$id' AND fname='$forum' AND threadindex='0'","options");
		$oldtime = db_getvar($config[mtable],"threadid='$id' AND fname='$forum' AND threadindex='0'","posttime");
		$columns = array("options","posttime");
		$newopts = $oldopts -1;
		$values = array($newopts,$oldtime);
		db_update($config[mtable],"threadid='$id' AND fname='$forum' AND threadindex='0'",$columns,$values);
		print "Successfully closed thread id $id<br><br>";
	} 
	else 
	{
		print "You do not have sufficient access to close threads.<br>";
	}
}

function movethread($oldforum,$newforum,$threadid)
{
	global $forumsess,$realm,$config;			
				
	if (admincheck($forumsess[$realm][username]))
	{
		$newid = lastthread($newforum) + 1;
		if (db_do("UPDATE $config[mtable] SET threadid='$newid',fname='$newforum',posttime=posttime WHERE threadid='$threadid' AND fname='$oldforum'"))
		{
					print "Successfully moved thread id $threadid from $oldforum to $newforum<br><br>";
		} 
		else 
		{
					print "There was an error.<br><br>";
		}
	} 
	else 
	{
		print "You do not have sufficient access to move threads.<br>";
	}
}

function ConfirmCleanUp()
{
	global $forumsess,$realm,$config;			
				
	if (admincheck($forumsess[$realm][username]))
	{
		print "Are you sure you wish to run cleanup?<br>";
		print "This will check the database for orphaned messages and delete them.<br>";
		print "<br>";
		print "<a href='index.php?action=cleanup&realm=$realm'>Run Cleanup</a> &nbsp; &nbsp; <a href='index.php?realm=$realm'>Cancel Cleanup</a><br>";
	}
	else
	{
		print "You do not have sufficient access to run cleanup!.<br>";
	}
}

function CleanUp()
{
	global $forumsess,$realm,$config;			
				
	if (admincheck($forumsess[$realm][username]))
	{
		
		$forums = forums_array();
		print "Checking for & removing messages without current threads...<br>";
		/* First, Cleanup Current Forums */
		foreach ($forums as $forum)
		{
			$result = db_select("SELECT * FROM $config[mtable] WHERE fname='$forum' AND threadindex=0");
			while($row = db_getarray($result))
			{
				$goodThreads[$forum][] = $row[threadid]; 
			}
			if (sizeof($goodThreads[$forum]) > 0)
			{
				$sql = "SELECT * FROM $config[mtable] WHERE fname='$forum' AND threadid != '".$goodThreads[$forum][0]."'";
				for($i=1;$i<sizeof($goodThreads[$forum]);$i++)
				{
					$sql .= " AND threadid != '".$goodThreads[$forum][$i]."'";
				}
				
				
				
				$re = db_select($sql);
				
				while($ra = db_getarray($re))
				{
					db_remove($config[mtable],"id='$ra[id]'");
					$count++;
				}
			}
			
		}
		print "Checking for & removing messages without current forums...<br>";
		/* Then, We want to find any posts in the database with removed forums */
		
		$fsql = "SELECT * FROM $config[mtable] WHERE fname != '$forums[0]'";
		for($i=1;$i<sizeof($forums);$i++)
		{
			$fsql .= " AND fname != '".$forums[$i]."'";
		}
		
		$re = db_select($fsql);
		while($ra = db_getarray($re))
		{			
			db_remove($config[mtable],"id='$ra[id]'");
			$count++;
		}
		print "Total Deleted Rows: $count<br>";
		//print_r($goodThreads);
		
		
	} 
	else 
	{
		print "You do not have sufficient access to run cleanup!.<br>";
	}
}

?>