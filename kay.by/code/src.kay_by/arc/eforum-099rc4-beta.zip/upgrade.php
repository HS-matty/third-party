<?

$version = ".99rc4";

if (!$realm)
	$realm = "default";

if (($realm)&&(file_exists("realm.$realm.php")))
	include "realm.$realm.php";
else
	include "realm.default.php";

include 'funcs.mysql.php';

if ($submit)
{
	
	if (!file_exists("realm.$realm.php"))
		print "Error: Realm $realm doesnt exist!";
	else
	{	
		$phpver = phpversion();
		$ext[ldap] = extension_loaded("ldap");
		$ext[mysql] = extension_loaded("mysql");
		$installer[ip] = getenv("REMOTE_ADDR");
		$installer[browser] = getenv("HTTP_USER_AGENT");
		$server[os] = getenv("OSTYPE");
		$server[web] = getenv("SERVER_SOFTWARE");
		$server[host] = getenv("HTTP_HOST");
		
		//$ext[mysql] = FALSE;
		//$phpver = "3.0.17";
		//print floor($phpver);
		
		if ($ext[mysql])
		{
			db_connect();
			$res_version = mysql_query("SELECT Version() as version");
			$mysql = mysql_fetch_array($res_version);
		}
		
		print "<strong><font size='+2'>Upgrading electrifiedForum to $version</font></strong><br><br>";
		print "<strong>System Information</strong><br>";
		print "PHP Version: $phpver<br>";
		if (floor($phpver)<4) 
			print "<font color=red>PHP Version Not 4.0 or Greater</font> You may have problems<br>";
		print "MySQL Version: $mysql[version]<br>";
		if (!strstr($mysql[version],"3.23")) 
			print "<font color=red>MySQL Version Not 3.23.x</font> You may have problems<br>";
		print "Server OS: $server[os]<br>";
		print "Web Server Daemon: $server[web]<br>";
		print "Server Hostname: $server[host]<br>";
		
		print "<br>";
		if ($ext[mysql])
			print "MySQL Extension Loaded<Br>";
		if ($ext[ldap])
			print "LDAP Extension Loaded (Not yet used)<Br>";
			
		print "<br><hr noshade width=20% align=left>";
		print "Updating MySQL Tables in database $config[dbname]...<br><br>";
				
		if ($ext[mysql])
		{
			if ($curver == "90")
			{
				print "Updating forums table (options)...";

				if (mysql_db_query($config[dbname],"ALTER TABLE forums ADD options SMALLINT DEFAULT '1' not null"))
					print "Success<br>";
				else 
				{
					print "<font color=red>Error</font>: ".mysql_error()."<br>";
					$errors++;
				}
		
				print "Updating users table (votes)...";

				if (mysql_db_query($config[dbname],"ALTER TABLE fusers ADD votes SMALLINT DEFAULT '0' not null"))
					print "Success<br>";
				else
				{
					print "<font color=red>Error</font>: ".mysql_error()."<br>";
					$errors++;
				}
			
    		print "Updating users table (rank)...";

				if (mysql_db_query($config[dbname],"ALTER TABLE fusers ADD rank SMALLINT DEFAULT '0' not null"))
					print "Success<br>";
				else 
				{
					print "<font color=red>Error</font>: ".mysql_error()."<br>";
					$errors++;
				}
		
				print "Updating messages table (options)...";

				if (mysql_db_query($config[dbname],"ALTER TABLE messages ADD options SMALLINT DEFAULT '1' not null"))
					print "Success<br>";
				else
				{
					print "<font color=red>Error</font>: ".mysql_error()."<br>";
					$errors++;
				}

				print "Creating private messages table...";
				
				if (mysql_db_query($config[dbname],"CREATE TABLE pmessages (
   			id smallint(6) NOT NULL auto_increment,
   			mto varchar(20) NOT NULL,
   			mfrom varchar(20) NOT NULL,
   			status smallint(6) DEFAULT '0' NOT NULL,
   			subject varchar(120) NOT NULL,
   			message text NOT NULL,
   			senttime timestamp(14),
   			PRIMARY KEY (id),
   			UNIQUE id (id),
   			KEY mto (mto, mfrom),
   			KEY status (status)
				);"))
					print "Success<br>";
				else
				{
					print "<font color=red>Error</font>: ".mysql_error()."<br>";
					$errors++;
				}
				print "Creating Anonymous User...";
				if (!$config[utable])
					$config[utable] = 'fusers';
				if (mysql_db_query($config[dbname],"INSERT INTO $config[utable] (username, password, level, options, location, email, homepage, showemail, icq, showicq, aim, showaim, yahoo, showyahoo, realname, age, birthday, showbirthday, gender, avatar, sig, disabled, rank, votes) VALUES ('Anonymous', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '1', '', '')"))
					print "Success<br>";
				else 
				{
					print "<font color=red>Error</font>: ".mysql_error()."<br>";
					$errors++;
				}
				print "Extending Forum Table (forumpassword)...";
				if (!$config[ftable])
					$config[ftable] = 'forums';
				if (mysql_db_query($config[dbname],"ALTER TABLE $config[ftable] ADD forumpassword VARCHAR (100) not null"))
					print "Success<br>";
				else
				{
					print "<font color=red>Error</font>: ".mysql_error()."<br>";
					$errors++;
				}
			}
			elseif ($curver == "95")
			{
				print "Creating private messages table...";
				if (mysql_db_query($config[dbname],"CREATE TABLE pmessages (
   			id smallint(6) NOT NULL auto_increment,
   			mto varchar(20) NOT NULL,
   			mfrom varchar(20) NOT NULL,
   			status smallint(6) DEFAULT '0' NOT NULL,
   			subject varchar(120) NOT NULL,
   			message text NOT NULL,
   			senttime timestamp(14),
   			PRIMARY KEY (id),
   			UNIQUE id (id),
   			KEY mto (mto, mfrom),
   			KEY status (status)
				);"))
					print "Success<br>";
				else 
				{
					print "<font color=red>Error</font>: ".mysql_error()."<br>";
					$errors++;
				}
				print "Creating Anonymous User...";
				if (!$config[utable])
					$config[utable] = 'fusers';
				if (mysql_db_query($config[dbname],"INSERT INTO $config[utable] (username, password, level, options, location, email, homepage, showemail, icq, showicq, aim, showaim, yahoo, showyahoo, realname, age, birthday, showbirthday, gender, avatar, sig, disabled, rank, votes) VALUES ('Anonymous', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '1', '', '')"))
					print "Success<br>";
				else 
				{
					print "<font color=red>Error</font>: ".mysql_error()."<br>";
					$errors++;
				}
				print "Extending Forum Table (forumpassword)...";
				if (!$config[ftable])
					$config[ftable] = 'forums';
				if (mysql_db_query($config[dbname],"ALTER TABLE $config[ftable] ADD forumpassword VARCHAR (100) not null"))
					print "Success<br>";
				else
				{
					print "<font color=red>Error</font>: ".mysql_error()."<br>";
					$errors++;
				}
			}
			elseif ($curver == "99")
			{
				print "Creating Anonymous User...";
				if (!$config[utable])
					$config[utable] = 'fusers';
				if (mysql_db_query($config[dbname],"INSERT INTO $config[utable] (username, password, level, options, location, email, homepage, showemail, icq, showicq, aim, showaim, yahoo, showyahoo, realname, age, birthday, showbirthday, gender, avatar, sig, disabled, rank, votes) VALUES ('Anonymous', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '1', '', '')"))
					print "Success<br>";
				else 
				{
					print "<font color=red>Error</font>: ".mysql_error()."<br>";
					$errors++;
				}
				print "Extending Forum Table (forumpassword)...";
				if (!$config[ftable])
					$config[ftable] = 'forums';
				if (mysql_db_query($config[dbname],"ALTER TABLE $config[ftable] ADD forumpassword VARCHAR (100) not null"))
					print "Success<br>";
				else
				{
					print "<font color=red>Error</font>: ".mysql_error()."<br>";
					$errors++;
				}
			}
			elseif ($curver == "99rc3")
			{
				print "Extending Forum Table (forumpassword)...";
				if (!$config[ftable])
					$config[ftable] = 'forums';
				if (mysql_db_query($config[dbname],"ALTER TABLE $config[ftable] ADD forumpassword VARCHAR (100) not null"))
					print "Success<br>";
				else
				{
					print "<font color=red>Error</font>: ".mysql_error()."<br>";
					$errors++;
				}
			}
			else 
			{
				print "<strong><font color=red>ERROR</font></strong>: Unknown or unsupported version of electrifiedForum<br>";
				$errors++;
			}
		} 
		else 
		{
			print "<strong><font color=red>FATAL ERROR</font></strong>: Unable to update MySQL tables: MySQL Support Not Enabled in this version of PHP<br>";
			$errors++;
		}
		
		print "<br>";
		if (!$errors && !$warnings)
			print "Upgrade successful, No errors or warnings<br>Make sure you modify your realm files according to the readme..<br>";
			
		elseif (!$errors)
			print "Upgrade complete but with warnings<br>Make sure you modify your realm files according to the readme..<br>";
		else
			print "Errors occurred during Installation.<br><a href='http://www.electrifiedpenguin.com/forums/'>Consult the electrifiedpenguin.com forums for help</a><br>";
	
	}
		
} 
else 
{
/* Installation Options Form */

?>

<form action='upgrade.php?realm=<?=$realm?>' method=post>

Note: This upgrade script is only for use with eF versions 0.90 and above.<br>

<br>
<b>IMPORTANT</b> - Please choose your current eF version:
<select name="curver">
<option value="90">0.90
<option value="90">0.91
<option value="90">0.93
<option value="95">0.95
<option value="95">0.96
<option value="99">0.99rc1
<option value="99">0.99rc2
<option value="99rc3">0.99rc3

</select> <br>
<br>
Confirm upgrade to electrifiedForum <?=$version?> for realm: <?=$realm?><br>

<input type=submit name=submit value='UPGRADE NOW'>
</form>

<?

}
?>