<?
/**************************************

electrifiedForum
Version 0.99rc4 - November 8, 2001

Copyright 2001- electrifiedpenguin.com

This is free software, please leave all
copyright notices intact, thanks!

This is the html forms file

MAKE NO CHANGES TO THIS FILE
Customizing options are in the realm files!!!

***************************************/
function moveform($forum,$id)
{
	global $forumsess,$config,$realm,$lang;
		
		$forums = forums_array();
	
		?>
		<FORM NAME="editprofile" METHOD="POST" ACTION="index.php?action=movethreadnow&forum=<?=$forum?>&id=<?=$id?>&realm=<?=$realm?>">
		<table border=0 cellpadding=0 cellspacing=0 width="<?=$config[table_width]?>">
		<TR>
		<td bgcolor="<?=$config['tcolor']?>">
			<table border=0 cellspacing=1 cellpadding=4 width="100%">
					<tr bgcolor='<?=$config[color_top]?>'>
	
				<td class=tabletop colspan=2> <strong><?=$lang[movethread]?></strong> </td>
	
			</tr>
			<tr>
			<td bgcolor="<?=$config['color_a']?>" colspan=2>
			<FONT SIZE="2" FACE="Verdana, Arial">
			You are moving <?=$lang[thread]?> id <?=$id?> from <?=$forum?> to:
			<BR></FONT>
			</td></tr>
	
			<tr bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B><? print "$lang[new] $lang[forum]";?>:</B></FONT></TD>
			<TD>
			<select name='newforum'>
			<?
			for($i=0;$i<sizeof($forums);$i++)
			{
			   print "<option value='$forums[$i]'>$forums[$i]";
			}
			?>
			</select>
			</TD>
			</TR>
	

	
			 </TABLE>
		</td>
		</tr>
		</table>
		<BR><BR>
		<INPUT TYPE="SUBMIT" NAME="Submit" VALUE="Submit Changes">
		</form>
		<?

}

function karmaform($who)
{
/* user ranking form */
	global $forumsess,$config,$realm,$lang;

		?>
		<FORM NAME="editprofile" METHOD="POST" ACTION="index.php?action=karmasave&who=<?=$who?>&realm=<?=$realm?>">
		<table border=0 cellpadding=0 cellspacing=0 width="90%">
		<TR>
		<td bgcolor="<?=$config['tcolor']?>">
			<table border=0 cellspacing=1 cellpadding=4 width="100%">
					<tr bgcolor='<?=$config[color_top]?>'>
	
				<td class=tabletop colspan=2> <strong>Member Karma Ranking</strong> </td>
	
			</tr>
			<tr>
			<td bgcolor="<?=$config['color_a']?>" colspan=2>
			<FONT SIZE="2" FACE="Verdana, Arial">
			You can rate a <?=$lang[member]?> using this form.  
			<BR></FONT>
			</td></tr>
	
			<tr bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>User Name</B></FONT></TD>
			<TD><?=$who?></TD>
			</TR>
	
			<tr bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Vote</B></FONT></TD>
			<TD>
			<select name=vote>
			<option value=5>Excellent
			<option value=4>Good
			<option value=3>Average
			<option value=2>Poor
			<option value=1>Horrible
			</select>
			</TD>
			</TR>
		
			 </TABLE>
		</td>
		</tr>
		</table>
		<BR><BR>
		<INPUT TYPE="SUBMIT" NAME="Submit" VALUE="Submit Changes">
		</form>
		<?

}

function lostpassform()
{
/* change password form */
	global $config,$realm,$lang;

		//$row = db_getrow($config[utable],"username='".$forumsess[$realm][username]."'");
		
	
		?>
		<FORM METHOD="POST" ACTION="index.php?action=resetpassword&realm=<?=$realm?>">
		<table border='0' cellpadding='0' cellspacing='0' width="<?=$config[table_width]?>">
		<TR>
		<td bgcolor="<?=$config['tcolor']?>">
			<table border='0' cellspacing='1' cellpadding='4' width="100%">
					<tr bgcolor='<?=$config[color_top]?>'>
	
				<td class="tabletop" colspan="2"> <b>Reset Password</b> </td>
	
			</tr>
			<tr>
			<td bgcolor="<?=$config['color_a']?>" colspan="2">
			<FONT SIZE="2" FACE="Verdana, Arial">
			You can reset your password using this form.<br />
			You must enter the email used to register.<br />  
			<BR /></FONT>
			</td></tr>
	
			<tr bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Username:</B></FONT></TD>
			<TD><input type="text" name="pass[user]"></TD>
			</TR>
	
			<tr bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Email Address:</B></FONT></TD>
			<TD><input type="text" name="pass[email]"></TD>
			</TR>	
	
			 </TABLE>
		</td>
		</tr>
		</table>
		<BR /><BR />
		<INPUT TYPE="SUBMIT" NAME="Submit" VALUE="Reset Password">
		</form>
		<?
	

}

function passwordform()
{
/* change password form */
	global $forumsess,$config,$realm,$lang;

		$row = db_getrow($config[utable],"username='".$forumsess[$realm][username]."'");
		
	
		?>
		<FORM NAME="editprofile" METHOD="POST" ACTION="index.php?action=passwordsave&realm=<?=$realm?>">
		<table border=0 cellpadding=0 cellspacing=0 width="<?=$config[table_width]?>">
		<TR>
		<td bgcolor="<?=$config['tcolor']?>">
			<table border=0 cellspacing=1 cellpadding=4 width="100%">
					<tr bgcolor='<?=$config[color_top]?>'>
	
				<td class=tabletop colspan=2> <strong>Change Password</strong> </td>
	
			</tr>
			<tr>
			<td bgcolor="<?=$config['color_a']?>" colspan=2>
			<FONT SIZE="2" FACE="Verdana, Arial">
			You can change your password using this form.  
			<BR></FONT>
			</td></tr>
	
			<tr bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>User Name</B></FONT></TD>
			<TD><?=$row[username]?></TD>
			</TR>
	
			<tr bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Old Password</B></FONT></TD>
			<TD><input type="password" name="pass[old]"></TD>
			</TR>
	
			<tr bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>New Password</B></FONT></TD>
			<TD><input type="password" name="pass[new]"></TD>
			</TR>	
	
			 </TABLE>
		</td>
		</tr>
		</table>
		<BR><BR>
		<INPUT TYPE="SUBMIT" NAME="Submit" VALUE="Submit Changes">
		</form>
		<?
	

}


function LoginBox()
{
	global $realm,$config;
	?>
	
<form action=index.php?realm=<?=$realm?> method=post>
<input type=hidden name=action value=login>

		<table border=0 cellpadding=0 cellspacing=0 width='<?=$config[table_width]?>'><TR>
			<td bgcolor='<?=$config[tcolor]?>'>
		<table border=0 cellspacing=1 cellpadding=4 width='100%'>
		<tr bgcolor='<?=$config[color_top]?>'>

			<td class=tabletop colspan=2> <strong>Login</strong> </td>

			</tr>



<tr bgcolor=<?=$config['color_a']?>>
	<td width=120>Username:</td>
	<td width=120><input type="text" name="username"></td>
</tr>
<tr bgcolor=<?=$config['color_b']?>>
	<td>Password:</td>
	<td><input type="password" name="password"><br>
	<a href="index.php?action=lostpassword&realm=<?=$realm?>">Lost Password?</a>
	</td>
</tr>
<tr bgcolor=<?=$config['color_a']?>>
	<td>&nbsp;</td>
	<td align=left><input type="submit" value="Login"></td>
</tr>


</td>
</tr>
</table>

	
</td>
</tr>
</table>
</form>
<?

}

function postform($forum)
{
/* HTML Form for posting a new message */
	global $forumsess,$config,$realm,$lang;
	
	?>
	
	<form action='index.php?action=postsave&forum=<?=$forum?>&realm=<?=$realm?>' method=post>
		<table border=0 cellpadding=0 cellspacing=0 width='<?=$config[table_width]?>'><TR>
			<td bgcolor='<?=$config[tcolor]?>'>
		<table border=0 cellspacing=1 cellpadding=4 width='100%'>
		<tr bgcolor='<?=$config[color_top]?>'>

			<td class=tabletop colspan=2> <strong><? print "$lang[post] $lang[new] $lang[topic]";?></strong> </td>

			</tr>
	<tr  bgcolor="<?=$config['color_a']?>">
		<td valign=top width=120><strong><?=$lang[title]?></strong></td>
		<td><input type="text" name="post[title]" size=30></td>
	</tr>
	<tr bgcolor="<?=$config['color_b']?>">
		<td valign=top><strong>Icon</strong></td>
		<td>
		<? listmsgicons(); ?>
		</td>
	</tr>
	<tr bgcolor="<?=$config['color_a']?>">
		<td valign=top><strong><?=$lang[message]?></strong><br>
		<FONT SIZE="1" FACE="Verdana, Arial"><a href="#" onclick="window.open('efcode.html','efcode','toolbars=no,scrollbars=yes');" >eF Code & Smilies Guide</a></td>
		<td><textarea cols="30" rows="6" name="post[content]" wrap="soft" style="width: 90%;"></textarea></td>
	</tr>
	
	<?
	
	if ((!session_is_registered("forumsess"))||(!isset($forumsess[$realm][username])))
	{
		?>
		<tr bgcolor="<?=$config['color_b']?>">
		<td valign=top><strong>Username</strong></td>
		<td><input type="text" name="post[username]"></td>
		</tr>
		<tr bgcolor="<?=$config['color_a']?>">
		<td valign=top><strong>Password</strong></td>
		<td><input type="password" name="post[password]"></td>
		</tr>
		<?
	}
	if ($config[allow_anon])
	{
		?>
		<tr bgcolor="<?=$config['color_b']?>">
  		<td valign=top><strong>Special Options</strong></td>
  		<td>
  		<input type=checkbox name='post[anon]' value=TRUE> Post Anonymously<br>
  		(Automatic for unregistered users)<br>
  		</td>
  	</tr>
		<?
	}
	?>
	<tr bgcolor="<?=$config['color_a']?>">
		<td>&nbsp;</td>
		<td><input type="submit" value="Save!" name="post[submit]"></td>
	</tr>
	</table>
	</td>
	</tr>
	</table>
	</form>
	
	<?
	
}

function replyform($forum,$threadid)
{
/* HTML Form for posting a new message */
	global $forumsess,$config,$realm,$lang;
	
	$retitle = threadtitle($forum,$threadid);
	?>
	
	<form action='index.php?action=replysave&forum=<?=$forum?>&id=<?=$threadid?>&realm=<?=$realm?>' method=post>
		<table border=0 cellpadding=0 cellspacing=0 width='<?=$config[table_width]?>'><TR>
			<td bgcolor='<?=$config[tcolor]?>'>
		<table border=0 cellspacing=1 cellpadding=4 width='100%'>
		<tr bgcolor='<?=$config[color_top]?>'>

			<td class=tabletop colspan=2> <strong><? print "$lang[reply] $lang[to] $lang[topic]";?>: <?=$retitle?></strong> </td>

			</tr>
	<tr  bgcolor="<?=$config['color_a']?>">
		<td valign=top width=120><strong><?=$lang[title]?></strong></td>
		<td><input type="text" name="post[title]" value="RE: <?=$retitle?>" size=30></td>
	</tr>
	<tr bgcolor="<?=$config['color_b']?>">
		<td valign=top><strong><?=$lang[icon]?></strong></td>
		<td>
		<? listmsgicons(); ?>
		</td>
	</tr>
	<tr bgcolor="<?=$config['color_a']?>">
		<td valign=top><strong><?=$lang[message]?></strong><br>
		<FONT SIZE="1" FACE="Verdana, Arial"><a href="#" onclick="window.open('efcode.html','efcode','toolbars=no,scrollbars=yes');" >eF Code & Smilies Guide</a></td>
		<td><textarea cols="30" rows="6" name="post[content]" wrap="soft" style="width: 90%;"></textarea></td>
	</tr>
	
	<?
	
	if ((!session_is_registered("forumsess"))||(!isset($forumsess[$realm][username])))
	{
		?>
		<tr bgcolor="<?=$config['color_b']?>">
		<td valign=top><strong>Username</strong></td>
		<td><input type="text" name="post[username]"></td>
		</tr>
		<tr bgcolor="<?=$config['color_a']?>">
		<td valign=top><strong>Password</strong></td>
		<td><input type="password" name="post[password]"></td>
		</tr>
		<?
	}
	if ($config[allow_anon])
	{
		?>
		<tr bgcolor="<?=$config['color_b']?>">
  		<td valign=top><strong>Special Options</strong></td>
  		<td>
  		<input type=checkbox name='post[anon]' value=TRUE> Post Anonymously<br>
  		(Automatic for unregistered users)<br>
  		</td>
  	</tr>
		<?
	}
	?>
	
	
	<tr bgcolor="<?=$config['color_a']?>">
		<td>&nbsp;</td>
		<td><input type="submit" value="Save!" name="post[submit]"></td>
	</tr>
	</table>
	</td>
	</tr>
	</table>
	</form>
	<br>
	<?
	
	displaythread($forum,$threadid);
	
}

function replyquote($forum,$mid)
{
/* HTML Form for replying to a message with quote */
	global $forumsess,$config,$realm,$lang;
	
	$threadid = db_getvar($config[mtable],"id='$mid'","threadid");
	
	$retitle = db_getvar($config[mtable],"id='$mid'","title");

	?>
	
	<form action='index.php?action=replysave&forum=<?=$forum?>&id=<?=$threadid?>&realm=<?=$realm?>' method=post>
	<table border=0 cellpadding=0 cellspacing=0 width='<?=$config[table_width]?>'><TR>
	<td bgcolor='<?=$config[tcolor]?>'>
	<table border=0 cellspacing=1 cellpadding=4 width='100%'>
	<tr bgcolor='<?=$config[color_top]?>'>
		<td class=tabletop colspan=2> <strong><? print "$lang[reply] $lang[to] $lang[topic]";?>: <?=$retitle?></strong> </td>
	</tr>
	<tr  bgcolor="<?=$config['color_a']?>">
		<td valign=top width=120><strong><?=$lang[title]?></strong></td>
		<td><input type="text" name="post[title]" value="RE: <?=$retitle?>" size=30></td>
	</tr>
	<tr bgcolor="<?=$config['color_b']?>">
		<td valign=top><strong><?=$lang[icon]?></strong></td>
		<td>
		<? listmsgicons(); ?>
		</td>
	</tr>
	<tr bgcolor="<?=$config['color_a']?>">
		<td valign=top><strong><?=$lang[message]?></strong><br>
		<FONT SIZE="1" FACE="Verdana, Arial"><a href="#" onclick="window.open('efcode.html','efcode','toolbars=no,scrollbars=yes');" >eF Code & Smilies Guide</a></td>
		<td>
<textarea cols="30" rows="6" name="post[content]" wrap="soft" style="width: 90%;">

[quote]
<? print reverse_process(db_getvar($config[mtable],"id='$mid'","content")); ?>
[/quote]
</textarea>	
	
		</td>
	</tr>
	
	<?
	
	if ((!session_is_registered("forumsess"))||(!isset($forumsess[$realm][username])))
	{
		?>
		<tr bgcolor="<?=$config['color_b']?>">
		<td valign=top><strong>Username</strong></td>
		<td><input type="text" name="post[username]"></td>
		</tr>
		<tr bgcolor="<?=$config['color_a']?>">
		<td valign=top><strong>Password</strong></td>
		<td><input type="password" name="post[password]"></td>
		</tr>
		<?
	}
	if ($config[allow_anon])
	{
		?>
		<tr bgcolor="<?=$config['color_b']?>">
  		<td valign=top><strong>Special Options</strong></td>
  		<td>
  		<input type=checkbox name='post[anon]' value=TRUE> Post Anonymously<br>
  		(Automatic for unregistered users)<br>
  		</td>
  	</tr>
		<?
	}
	?>
	
	
	<tr bgcolor="<?=$config['color_a']?>">
		<td>&nbsp;</td>
		<td><input type="submit" value="Save!" name="post[submit]"></td>
	</tr>
	</table>
	</td>
	</tr>
	</table>
	</form>
	<br>
	<?
	displaythread($forum,$threadid);
}

function editmsg($forum,$mid)
{
/* Display a box for editing a message */
	global $forumsess,$config,$realm,$lang;
	
	$threadid = db_getvar($config[mtable],"id='$mid'","threadid");
	
	$title = db_getvar($config[mtable],"id='$mid'","title");

	?>
	
	<form action='index.php?action=editsave&forum=<?=$forum?>&mid=<?=$mid?>&id=<?=$threadid?>&realm=<?=$realm?>' method=post>
			<table border=0 cellpadding=0 cellspacing=0 width='<?=$config[table_width]?>'><TR>
			<td bgcolor='<?=$config[tcolor]?>'>
		<table border=0 cellspacing=1 cellpadding=4 width='100%'>
		<tr bgcolor='<?=$config[color_top]?>'>

			<td class=tabletop colspan=2> <strong><? print "$lang[edit] $lang[message]" ?>: <?=$title?></strong> </td>

			</tr>
	<tr bgcolor="<?=$config['color_a']?>">
		<td valign=top width=120><strong><?=$lang[title]?></strong></td>
		<td><input type="text" name="edit[title]" size=30 value="<?=$title?>"></td>
	</tr>
	<tr bgcolor="<?=$config['color_b']?>">
		<td valign=top><strong><?=$lang[message]?></strong><br>
		<FONT SIZE="1" FACE="Verdana, Arial"><a href="#" onclick="window.open('efcode.html','efcode','toolbars=no,scrollbars=yes');" >eF Code & Smilies Guide</a></td>
		<td><textarea cols="30" rows="6" name="edit[content]" wrap="soft" style="width: 90%;"><? print reverse_process(db_getvar('messages',"id='$mid'","content")); ?></textarea>
		</td>
	</tr>
	<tr bgcolor="<?=$config['color_a']?>">
		<td valign=top><strong><?=$lang[options]?></strong></td>
		<td>
		<input type="checkbox" name="edit[delete]" value="TRUE"> <? print "$lang[delete] $lang[message]"; ?>
		</td>
	</tr>
	<?
	
	if ((!session_is_registered("forumsess"))||(!isset($forumsess[$realm][username])))
	{
		?>
		<tr bgcolor="<?=$config['color_b']?>">
		<td valign=top><strong>Username</strong></td>
		<td><input type="text" name="edit[username]"></td>
		</tr>
		<tr bgcolor="<?=$config['color_a']?>">
		<td valign=top><strong>Password</strong></td>
		<td><input type="password" name="edit[password]"></td>
		</tr>
		<?
	}
	?>
	
	
	<tr bgcolor="<?=$config['color_b']?>">
		<td>&nbsp;</td>
		<td><input type="submit" value="Save!" name="edit[submit]"></td>
	</tr>
	</table>
	</td>
	</tr>
	</table>
	</form>
	
	<?

}

function signup_form()
{
	global $config,$realm,$lang;
	
	if ($config[restrict_new_signups])
	{
		if ($config[restrict_signups_text])
			print $config[restrict_signups_text]."<br>";
		else
			print "The administrator has disabled new signups.<br>";
	} 
	else 
	{
	?>
	<FORM NAME="Register" METHOD="POST" ACTION="index.php?action=savereg&realm=<?=$realm?>">
	<table border=0 cellpadding=0 cellspacing=0 width="<?=$config[table_width]?>">
	<TR>
	<td bgcolor="<?=$config['tcolor']?>">
		<table border=0 cellspacing=1 cellpadding=4 width="100%">
		<tr bgcolor='<?=$config[color_top]?>'>
			<td class=tabletop colspan=2> <strong><?=$lang[register]?></strong> </td>
		</tr>
		<tr>
		<td bgcolor="<?=$config['color_b']?>" colspan=2>
		<FONT SIZE="2" FACE="Verdana, Arial">
		In order to use all features of the <?=$lang[forums]?>, you must <?=$lang[register]?>.  
		<BR><BR>
		Note: Required fields are marked by an asterisk.</FONT>
		</td></tr>
		<tr bgcolor="<?=$config['color_a']?>" valign=top>
		<td height="44">
				<table width="100%" border="0" cellspacing="0" cellpadding="0"><tr valign="top">
					<td>
					<FONT SIZE="2" FACE="Verdana, Arial">
					<B>Avatar</B>
					</FONT><BR>
					<FONT SIZE="1" FACE="Verdana, Arial">Optional image you may use to appear with each of your posts.
					</td>
					<td align="right" width="100">
					<div id="dynamic3"></div>
					</td>
					</tr>
				</table>
				</td>
				<td valign="top">
				
				<? listavatars(""); ?>
				<br>
		</td>
		</tr>
		<tr bgcolor="<?=$config['color_b']?>">
		<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>User Name*</B></FONT></TD>
		<TD><INPUT TYPE="TEXT" NAME="reg[username]" VALUE="" SIZE=18 MAXLENGTH=18></TD>
		</TR>

		<TR bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Password*</B></FONT></TD>
			<TD><INPUT TYPE="password" NAME="reg[password]" VALUE="" SIZE=30 MAXLENGTH=50></TD>
		 </tr>
		
		<TR bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Email*</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[email]" VALUE="" SIZE=30 MAXLENGTH=150></TD>
		</TR>
		
		<TR bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>ICQ Number</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[icq]" VALUE="" SIZE=30 MAXLENGTH=50></TD>
		</tr>

		<TR bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>AIM Screen Name</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[aim]" VALUE="" SIZE=30 MAXLENGTH=50></TD>
		</tr>
		
		<TR bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Yahoo ID</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[yahoo]" VALUE="" SIZE=30 MAXLENGTH=50></TD>
		</tr>		
		
		<TR bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>City, State, Country</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[location]" VALUE="" SIZE=30 MAXLENGTH=50></TD>
		</tr>

		<TR bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Birthday</B></FONT></TD>
			<TD>
			<?
			print "<SELECT name='reg[month]'>";
			for ($i = 1; $i < 13; $i++) 
			{
				$n = convert($i);
				print "<OPTION value=$i>$n</OPTION>";
			}
			print "</SELECT>&nbsp;&nbsp;";
			
			print "<SELECT name='reg[day]'>";
			for ($i = 1; $i < 32; $i++) 
			{
				$n = convert($i);
				print "<OPTION value=$i>$n</OPTION>";
			}
			print "</SELECT>&nbsp;&nbsp;";
			
			print "<SELECT name='reg[year]'>";
			for ($i = 87; $i >= 0; $i--) 
			{
				$n = $i + date("Y")-100;
				print "<OPTION value=$n>$n</OPTION>";
			}
			print "</SELECT>";
			?>		
			
			</TD>
		</tr>
		
		<TR bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Gender</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[gender]" VALUE="" SIZE=30 MAXLENGTH=50></TD>
		</tr>
		
		<TR bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Homepage URL</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[homepage]" VALUE="http://" SIZE=30 MAXLENGTH=100></TD>
		</tr>
		
		<TR bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Privacy Options</B></FONT></TD>
			<TD>
			<INPUT TYPE="checkbox" NAME="reg[showemail]" VALUE="1"> Display email address<br>
			<INPUT TYPE="checkbox" NAME="reg[showicq]" VALUE="2"> Display ICQ Number<br>
			<INPUT TYPE="checkbox" NAME="reg[showaim]" VALUE="4"> Display AIM Screen Name<br>
			<INPUT TYPE="checkbox" NAME="reg[showyahoo]" VALUE="8"> Display Yahoo ID<br>
			<INPUT TYPE="checkbox" NAME="reg[showbirthday]" VALUE="16"> Display Age<br>
			<INPUT TYPE="checkbox" NAME="reg[showhomepage]" VALUE="32"> Display Homepage URL<br>
			<INPUT TYPE="checkbox" NAME="reg[notifications]" VALUE="64"> Send Email Notifications<br>
			(Any topics you post in)
			</TD>
		</TR>
		 <TR bgcolor="<?=$config['color_a']?>">
			<TD valign=top><FONT SIZE="2" FACE="Verdana, Arial"><B>Signature</B></font><BR></TD>
			<TD><TEXTAREA NAME="reg[sig]" ROWS=3 COLS=25 WRAP=soft></TEXTAREA>
		 </TD></tr>
		 </TABLE>
	</td>
	</tr>
	</table>
	<BR><BR>
	<INPUT TYPE="SUBMIT" NAME="Submit" VALUE="Submit Registration">
	</form>
	<?
	}
}

function editprofile()
{
	global $config,$forumsess,$realm,$lang;
	
	$row = db_getrow($config[utable],"username='".$forumsess[$realm][username]."'");
	
	$options = $row[options];
	$birthyear = substr($row[birthday],0,4);
	$birthday = substr($row[birthday],6,2);
	$birthmonth = substr($row[birthday],4,2);

	?>
	<FORM NAME="editprofile" METHOD="POST" ACTION="index.php?action=updateprofile&realm=<?=$realm?>">
	<table border=0 cellpadding=0 cellspacing=0 width="<?=$config[table_width]?>">
	<TR>
	<td bgcolor="<?=$config['tcolor']?>">
		<table border=0 cellspacing=1 cellpadding=4 width="100%">
				<tr bgcolor='<?=$config[color_top]?>'>

			<td class=tabletop colspan=2> <strong><?=$lang[profile]?></strong> </td>

		</tr>
		<tr>
		<td bgcolor="<?=$config['color_b']?>" colspan=2>
		<FONT SIZE="2" FACE="Verdana, Arial">
		You can <?=$lang[edit]?> your <?=$lang[forum]?> <?=$lang[profile]?>.<BR>
		<br>
		To change your password, <a href="index.php?action=changepass&realm=<?=$realm?>">use this form</a>.<br>
		<BR>
		Note: Required fields are marked by an asterisk.</FONT>
		</td></tr>
		<tr bgcolor="<?=$config['color_a']?>" valign=top>
		<td height="44">
				<table width="100%" border="0" cellspacing="0" cellpadding="0"><tr valign="top">
					<td>
					<FONT SIZE="2" FACE="Verdana, Arial">
					<B>Avatar</B>
					</FONT><BR>
					<FONT SIZE="1" FACE="Verdana, Arial">Optional image you may use to appear with each of your posts.
					</td>
					<td align="right" width="100">
					<div id="dynamic3"></div>
					</td>
					</tr>
				</table>
				</td>
				<td valign="top">
				
				<? listavatars($row[avatar]); ?>
				<br>
		</td>
		</tr>
		<tr bgcolor="<?=$config['color_b']?>">
		<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>User Name*</B></FONT></TD>
		<TD><?=$row[username]?></TD>
		</TR>
		
		<TR bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Email*</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[email]" VALUE="<?=$row[email]?>" SIZE=30 MAXLENGTH=150></TD>
		</TR>

		<TR bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>ICQ Number</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[icq]" VALUE="<?=$row[icq]?>" SIZE=30 MAXLENGTH=50></TD>
		</tr>

		<TR bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>AIM Screen Name</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[aim]" VALUE="<?=$row[aim]?>" SIZE=30 MAXLENGTH=50></TD>
		</tr>
		
		<TR bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Yahoo ID</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[yahoo]" VALUE="<?=$row[yahoo]?>" SIZE=30 MAXLENGTH=50></TD>
		</tr>		
		
		<TR bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>City, State, Country</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[location]" VALUE="<?=$row[location]?>" SIZE=30 MAXLENGTH=50></TD>
		</tr>

		<TR bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Birthday</B></FONT></TD>
			<TD>
			<?
			print "<SELECT name='reg[month]'>";
			for ($i = 1; $i < 13; $i++) 
			{
				$n = convert($i);
				if ($n == $birthmonth) 
					$c = "SELECTED";
				else 
					$c = '';
					
				print "<OPTION value=$i $c>$n</OPTION>";
			}
			print "</SELECT>&nbsp;&nbsp;";
			
			print "<SELECT name='reg[day]'>";
			for ($i = 1; $i < 32; $i++) 
			{
				$n = convert($i);
				if ($n == $birthday) 
					$c = "SELECTED";
				else 
					$c = '';
					
				print "<OPTION value=$i $c>$n</OPTION>";
			}
			print "</SELECT>&nbsp;&nbsp;";
			
			print "<SELECT name='reg[year]'>";
			for ($i = 87; $i >= 0; $i--) 
			{
				$n = $i + date("Y")-100;
				if ($n == $birthyear) 
					$c = "SELECTED";
				else 
					$c = '';
					
				print "<OPTION value=$n $c>$n</OPTION>";
			}
			print "</SELECT>";
			?>		
			
			</TD>
		</tr>
		
		<TR bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Gender</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[gender]" VALUE="<?=$row[gender]?>" SIZE=30 MAXLENGTH=50></TD>
		</tr>
		
		<TR bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Homepage URL</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[homepage]" VALUE="<?=$row[homepage]?>" SIZE=30 MAXLENGTH=100></TD>
		</tr>
		
		<TR bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Privacy Options</B></FONT></TD>
			<TD>
			<INPUT TYPE="checkbox" NAME="reg[showemail]" VALUE="1" <? if ($options & 1) print "CHECKED";?>> Display email address<br>
			<INPUT TYPE="checkbox" NAME="reg[showicq]" VALUE="2" <? if ($options & 2) print "CHECKED";?>> Display ICQ Number<br>
			<INPUT TYPE="checkbox" NAME="reg[showaim]" VALUE="4" <? if ($options & 4) print "CHECKED";?>> Display AIM Screen Name<br>
			<INPUT TYPE="checkbox" NAME="reg[showyahoo]" VALUE="8" <? if ($options & 8) print "CHECKED";?>> Display Yahoo ID<br>
			<INPUT TYPE="checkbox" NAME="reg[showbirthday]" VALUE="16" <? if ($options & 16) print "CHECKED";?>> Display Age<br>
			<INPUT TYPE="checkbox" NAME="reg[showhomepage]" VALUE="32" <? if ($options & 32) print "CHECKED";?>> Display Homepage URL<br>
			<INPUT TYPE="checkbox" NAME="reg[notifications]" VALUE="64" <? if ($options & 64) print "CHECKED";?>> Send Email Notifications<br>
			(Any topics you post in)
			</TD>
		</TR>

		 <TR bgcolor="<?=$config['color_b']?>">
			<TD valign=top><FONT SIZE="2" FACE="Verdana, Arial"><B>Signature</B></font><BR></TD>
			<TD><TEXTAREA NAME="reg[sig]" ROWS=3 COLS=25 WRAP=soft><?=$row[sig]?></TEXTAREA>
		 </TD></tr>
		 </TABLE>
	</td>
	</tr>
	</table>
	<BR><BR>
	<INPUT TYPE="SUBMIT" NAME="Submit" VALUE="Submit Changes">
	</form>
	<?


}

function searchform()
{
	global $config,$realm,$lang;
	
	?>
	
	<form action="index.php" method=get>
	<input type=hidden name=action value=searchnow>
	<input type=hidden name=realm value=<?=$realm?>>
	<?=$lang[search]?> for <input type=text name='search[key]'>
	in <select name='search[type]'>
	<option value=any> Any
	<option value=title> <?=$lang[thread]?> <?=$lang[title]?>
	<option value=content> <?=$lang[message]?>
	<option value=poster> <?=$lang[poster]?>
	</select>
	<input type=submit>
	</form>
	
	
	<?
}

?>