<?
/**************************************

electrifiedForum
Version 0.99rc3 - November 2, 2001


Copyright 2001- electrifiedpenguin.com

This is free software, please leave all
copyright notices intact, thanks!

This is the messaging functions file

MAKE NO CHANGES TO THIS FILE
Customizing options are in the realm files!!!

***************************************/

/**************************************

Data Structure For Private Messaging

1 Table: pmessages

id: smallint, auto-increment
mto: varchar(20)
mfrom: varchar(20)
status: smallint [this is an 'options' style field]
subject: varchar(120)
message: text


***************************************/

function new_messages($username)
{
/* Return true if there are unread messages */
	global $config;
	
	if (db_numrows($config[pmtable],"mto='$username' AND status='0'")>0)
		return TRUE;
	else
		return FALSE;
	
}

function list_messages($username)
{
/* Display list of messages in a users messagebox */

	global $realm,$config,$forumsess;
	if ($forumsess[$realm][username])
	{
		if (db_numrows($config[pmtable],"mto='$username'")>0)
		{
			$result = db_select("SELECT * FROM $config[pmtable] WHERE mto='$username' ORDER BY id DESC");
			$i = 0;
			print "<table border=0 cellpadding=0 cellspacing=0 width='$config[table_width]'><TR>
			<td bgcolor='$config[tcolor]'>
			<table border=0 cellspacing=1 cellpadding=4 width='100%'>";
			print "<tr bgcolor='".$config['color_top']."'>
			<td class=tabletop width='50%'> <strong>Subject</strong> </td>
			<td class=tabletop> <strong>Sender</strong> </td>
			
			<td class=tabletop> <strong>Date Time</strong> </td></tr>";
			
			while($row = db_getarray($result))
			{
				
				$i = $i + 1;
		
				if ($i % 2) $bgcolor = $config['color_b'];
				else  $bgcolor = $config['color_a'];
		
		
				if ($row[senttime])
				{
						if ($config['24hour'])
							$format = "m-d-y H:i";
						else
							$format = "m-d-y h:i a";
							
						$datetext = date($format,sql_to_unix_time($row[senttime]));
				} 
				else 
				{
						$datetext = FALSE;
				}
					
				if ($row[status] == '0')
					$titletext = "<b>".$row[subject]."</b>";
				else
					$titletext = $row[subject];
					
				print "<tr bgcolor='$bgcolor' height=20><td><a href='index.php?action=readpm&id=$row[id]&realm=$realm'>$titletext</a></td><td>$row[mfrom]</td><td>$datetext</td></tr>";

			}
			print "</table></td></tr></table>";
		} 
		else 
		{
			print "You have no messages in your Messagebox<br>";
		}
	
	} 
	else 
	{
		print "You are not logged in. You must log in before viewing your inbox.<br>";
	}	


}

function read_message($username,$id)
{
/* Read the selected message */
	global $config,$realm,$forumsess;

	if (!$config[icondir])
		$config[icondir] = "art/icons";
		
		$result = db_select("SELECT p.id AS id, p.message AS message, p.senttime AS senttime, p.status AS status, u.username AS mfrom, u.options AS useropts, u.gender AS gender, u.birthday AS birthday, u.sig AS sig, u.votes AS votes, u.rank AS rank, u.location AS location, p.subject AS subject, u.email AS email, u.homepage AS homepage, u.aim AS aim, u.yahoo AS yahoo, u.icq AS icq FROM $config[pmtable] p, $config[utable] u WHERE p.id='$id' AND u.username=p.mfrom");
		

				
		$i = 0;
			print "<table border=0 cellpadding=0 cellspacing=0 width='$config[table_width]'><TR><td bgcolor='$config[tcolor]'><table border=0 cellspacing=1 cellpadding=4 width='100%'><tr bgcolor='".$config['color_top']."'><td class=tabletop><strong>Sender</strong></td><td class=tabletop><strong>Message</strong></td></tr>";
		
		while($row = db_getarray($result))
		{
			$i = $i + 1;
		
			$options = $row[useropts];
			if ($i % 2) 
				$bgcolor = $config['color_b'];
			else  
				$bgcolor = $config['color_a'];
			
			if ($row[status] == 0)
			{
				$columns = array("status");
				$values = array('1');
				db_update($config[pmtable],"id='$id'",$columns,$values);
			}
			
			if (($row[rank])&&($row[votes]))
			{
				$score = $row[rank]/$row[votes];
				$rank = round($score, 0);
				$score = round($score, 2);
			} 
			else 
			{
				$rank = FALSE;
			}
			
			if ($config['24hour'])
				$format = "l, F j Y H:i";
			else
				$format = "l, F j Y h:i A";
			
			$datetext = date($format,sql_to_unix_time($row[senttime]));
			
			?><tr bgcolor="<?=$bgcolor?>">
			<TD width=18% valign=top rowspan=3>
			<FONT SIZE="2" face="Verdana, Arial">
			<B><?=$row[mfrom]?></B>
			</font>
			<BR>
			<FONT SIZE="1" face="Verdana, Arial">
			<?
			if (admincheck($row[mfrom]))
				print "Administrator<br>";
			else
				print "Member<br>";
			
			if ($options & 16)
			{
				$age = age_from_bday($row[birthday]);				
				print "Age: $age<br>";
			}
			
			if ($row[gender])
				print "$row[gender]<br>";
			
			if ($row[location])
				print "$row[location]<br>";
			
			if ($rank)
			{
				print "<img src='art/ranking/$config[rankcolor]/$rank.gif'><br>";
				print $score."<br>";
			}
			else
			{
				print "Member not yet rated<br>";
			}
			?>		
			</FONT>
			<br>
			<? print avatar($row[mfrom]); ?>
			</td>
			<td class=messagetitle height=20 valign=top>

			<strong><?=$row[subject]?></strong>
			</td>
			</tr>
			<tr bgcolor="<?=$bgcolor?>">
			<TD class=messagebody valign=top height=100%>
			<FONT SIZE="1" face="Verdana, Arial">
			<b>Sent:</b>
			<?=$datetext?>
			&nbsp; &nbsp;
			<A HREF='index.php?action=pmdelete&id=<?=$row[id]?>&realm=<?=$realm?>'>
			Delete</A>
			&nbsp; &nbsp;
			<A HREF='index.php?action=pm&to=<?=$row[mfrom]?>&re=re:+<?=$row[subject]?>&realm=<?=$realm?>'>
			Reply</A>
			<?
			/*
			print "&nbsp;&nbsp;
					<A HREF='index.php?action=pmreplyquote&id=$row[id]&realm=$realm'>
					<IMG SRC='$config[icondir]/quote.gif' align=absmiddle BORDER=0 ALT='Reply w/Quote'></A>";
			*/
			?>

			</FONT>
			<HR noshade size=1 width=100%>
			<FONT SIZE="2" FACE="Verdana, Arial">
			<!-- Message -->
			<? print process($row[message]);?>
			<!-- end message -->
			<!-- sig -->
			<?
			if ($row[sig])
				print "<br><br><hr noshade width=150 size=1 align=left>$row[sig]<br>";
				
			?>
			<!-- end sig -->
			</FONT>
			<p>
			</td>
			</tr>
			<tr bgcolor="<?=$bgcolor?>" height=15>
			<td valign=top>
			<?
			
			print "<a href='#' onclick=\"window.open('index.php?action=karma&who=".$row[poster]."&realm=$realm','karma','toolbars=no,width=300,height=200');\"><IMG SRC='$config[icondir]/karma.gif' BORDER=0 ALT='Rate $row[poster]' align=absmiddle></a>";

			if ($options & 1)
				print "&nbsp;
					<A HREF='mailto:$row[email]'>
					<IMG SRC='$config[icondir]/email.gif' BORDER=0 ALT='Email' align=absmiddle></A>";
			
			if ($options & '32')
				print "&nbsp;
					<a href='$row[homepage]' target='_blank'>
					<img src='$config[icondir]/homepage.gif' alt='Visit $row[poster]`s homepage!' border=0 align=absmiddle></a>";

			if ($options & 4)
				print "&nbsp;
					<A HREF='aim:goim?screenname=$row[aim]&message=Hello'>
					<IMG SRC='$config[icondir]/aim.gif' BORDER=0 ALT='$row[aim]' align=absmiddle></A>";
			
			if ($options & 8)
				print "&nbsp;
					<a href='http://edit.yahoo.com/config/send_webmesg?.target=$row[yahoo]' target='_blank'>
					<img src='$config[icondir]/yahoo.gif' alt='Send a Yahoo! message to $row[yahoo]' border=0 align=absmiddle></a>";
			
			if ($options & 2)
				print "&nbsp;<a href='http://wwp.icq.com/$row[icq]' target='_blank'><IMG SRC='http://wwp.icq.com/scripts/online.dll?icq=$row[icq]&img=5' BORDER=0 ALT='ICQ: $row[icq]' align=absmiddle><img src='$config[icondir]/icq_text.gif' border=0 align=absmiddle></a>";
		

			?>
			&nbsp;
			</td>
			</tr>
			<?
		}
		print "</table></td></tr></table>";

}

function message_form($to,$re)
{
/* Create new private message */
	global $config,$realm,$forumsess;

?>
	
	<form action='index.php?action=sendpm&realm=<?=$realm?>' method=post>
		<table border=0 cellpadding=0 cellspacing=0 width='<?=$config[table_width]?>'><TR>
			<td bgcolor='<?=$config[tcolor]?>'>
		<table border=0 cellspacing=1 cellpadding=4 width='100%'>
		<tr bgcolor='<?=$config[color_top]?>'>

			<td class=tabletop colspan=2> <strong>Send New Private Message</strong> </td>

	</tr>
		<tr  bgcolor="<?=$config['color_a']?>">
		<td valign=top width=120><strong>To</strong></td>
		<td><input type="text" name="to" size=30 value='<?=$to?>'></td>
	</tr>
	<tr  bgcolor="<?=$config['color_b']?>">
		<td valign=top width=120><strong>Subject</strong></td>
		<td><input type="text" name="subj" size=30 value='<?=$re?>'></td>
	</tr>
	<tr bgcolor="<?=$config['color_a']?>">
		<td valign=top><strong>Message</strong><br>
		<FONT SIZE="1" FACE="Verdana, Arial"><a href="#" onclick="window.open('efcode.html','efcode','toolbars=no,scrollbars=yes');" >eF Code & Smilies Guide</a></td>
		<td><textarea cols="30" rows="6" name="message" wrap="soft" style="width: 90%;"></textarea></td>
	</tr>
	
	<?
	
	if ((!session_is_registered("forumsess"))||(!isset($forumsess[$realm][username])))
	{
		?>
		<tr bgcolor="<?=$config['color_b']?>">
		<td valign=top><strong>Username</strong></td>
		<td><input type="text" name="username"></td>
		</tr>
		<tr bgcolor="<?=$config['color_a']?>">
		<td valign=top><strong>Password</strong></td>
		<td><input type="password" name="password"></td>
		</tr>
		<?
	}
	?>
	
	
	<tr bgcolor="<?=$config['color_b']?>">
		<td>&nbsp;</td>
		<td><input type="submit" value="Save!" name="post[submit]"></td>
	</tr>
	</table>
	</td>
	</tr>
	</table>
	</form>
	
	<?

}

function send_message($to,$subj,$message)
{
/* Send a private message */
	global $forumsess,$config,$realm,$HTTP_SERVER_VARS,$username,$password;
	
	if ((session_is_registered("forumsess"))&&($forumsess[$realm][username]))
	{
		if ($subj)
		{		
			$columns = "mto,subject,message,mfrom";
			$values = "'$to','$subj','$message','".$forumsess[$realm][username]."'";
		
			db_insert($config[pmtable],$columns,$values);
		
			print "Successfully sent your message!<br>Now sending you to your inbox...<br>";
		
			print "<META HTTP-EQUIV='refresh' content='2;url=index.php?action=inbox&realm=$realm'>";
			
		} 
		else 
		{
			print "Error - You did not enter a subject for your message. <br>";
		}
	} 
	else 
	{
		if (($username)&&($password))
		{
			if (verifyuser($username,$password))
			{
				if ($subj)
				{		
					$columns = "mto,subject,message,mfrom";
					$values = "'$to','$subj','$message','".$username."'";
		
					db_insert($config[pmtable],$columns,$values);
						
					print "Successfully sent your message!<br>Now sending you to your inbox...<br>";
			
					print "<META HTTP-EQUIV='refresh' content='2;url=index.php?action=inbox&realm=$realm'>";
			
				} 
				else 
				{
					print "Error - You did not enter a subject for your message. <br>";
				}
			} 
			else 
			{
				print "Invalid username or password!<br>";
			}
		}
		else 
		{
			print "Username or password not entered!<br>";
		}
	}
}

function del_message($id)
{
	global $forumsess,$config,$realm;
	if ((session_is_registered("forumsess"))&&($forumsess[$realm][username]))
	{
			db_remove($config[pmtable],"id='$id' AND mto='".$forumsess[$realm][username]."'");
			print "Successfully deleted message id $id<br>Now sending you to your inbox...<br>";
			print "<META HTTP-EQUIV='refresh' content='2;url=index.php?action=inbox&realm=$realm'>";
	}
}

?>