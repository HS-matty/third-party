<?
/**************************************

electrifiedForum
Version 0.99rc4 - November 14, 2001

Copyright 2001- electrifiedpenguin.com

This is free software, please leave all
copyright notices intact, thanks!

This is the main index file

MAKE NO CHANGES TO THIS FILE
Customizing options are in the realm files!!!

***************************************/
$disable = FALSE;

if (!$realm)
	$realm = "default";

function GetMicrotime()
{ 
	list($usec, $sec) = explode(" ",microtime()); 
  return ((float)$usec + (float)$sec); 
} 

// Starttime
$starttime = GetMicrotime();
	
if (($realm)&&(file_exists("realm.$realm.php")))
	include "realm.$realm.php";
else
	include "realm.default.php";

if ($config[language] && file_exists("lang/lang.$config[language].php"))
	include "lang/lang.$config[language].php";
elseif ($language && file_exists("lang/lang.$language.php"))
	include "lang/lang.$language.php";
else 
	include "lang/lang.english.php";
	
include "funcs.layout.php";
include "funcs.forum.php";
include "funcs.mysql.php";
include "funcs.files.php";
include "funcs.small.php";
include "funcs.forms.php";
include "funcs.admin.php";
include "funcs.messaging.php";
include "funcs.user.php";

if ($disable) shut_down();

session_start("forums");

db_connect();


if (!$forumsess[$realm][lastvisit])
	lastvisit();
	
	
if ($action == "login") login($username,$password);
else if ($action == "logout") logout();
elseif ($action == "verifyforumpassword")	ForumAuth();

if ($action == "displaythread") htmlstart(forumtitle($forum));
elseif ($forum) htmlstart(forumtitle($forum));
else htmlstart("Main Forums");


/* New Karma (Ranking) Actions */
if (!$config[disable_karma])
{
  if ($action == "karma")
	{
  	karmaform($who);
  	exit;
  }
	elseif ($action == "karmasave")
	{
  	karmasave($who,$vote);
  	exit;
  }
}

@mainblock();

if ($config[req_auth] && !$forumsess[$realm][username])
{
	if ($action == "register")					
		signup_form();
	elseif ($action == "savereg") 			
		saveuser("new");
	else 
	{
		authreq_box();
		loginbox2();
	}
} 
else 
{
	if (($action == "movethreadnow")&&($forumsess[$realm]["admin"]))	 	movethread($forum,$newforum,$id);

	if ($autherror)
	{
		print "<div class=error>Authentication Error: $autherror</div>";
		$action = "loginbox";
	}

	forumheader();

	if ($action == "loginbox") 				loginbox();
	elseif ($action == "register") 			signup_form();
	elseif ($action == "profile") 			editprofile();
	elseif ($action == "savereg") 			saveuser("new");
	elseif ($action == "updateprofile") 	saveuser("edit");
	elseif ($action == "post")				postform($forum);
	elseif ($action == "postsave") 			postsave($forum);
	elseif ($action == "reply") 			replyform($forum,$id);
	elseif ($action == "replyquote") 		replyquote($forum,$mid);
	elseif ($action == "editmsg") 			editmsg($forum,$mid);
	elseif ($action == "editsave") 			editsave($forum,$mid);
	elseif ($action == "replysave") 		replysave($forum,$id);
	elseif ($action == "displaythread") 	displaythread($forum,$id);
	elseif ($action == "search") 			searchform();
	elseif ($action == "searchnow")			search();
		
	elseif ($action == "changepass")		passwordform();
	elseif ($action == "passwordsave")		savepass();
	elseif ($action == "lostpassword")		lostpassform();
	elseif ($action == "resetpassword")		passwordreset();
	
	elseif ($action == "inbox" && $config[messaging])			list_messages($forumsess[$realm]["username"]);
	elseif ($action == "readpm" && $config[messaging])			read_message($forumsess[$realm]["username"],$id);
	elseif ($action == "pm" && $config[messaging])					message_form($to,$re);
	elseif ($action == "sendpm" && $config[messaging])			send_message($to,$subj,$message);
	elseif ($action == "pmdelete" && $config[messaging])				del_message($id);

	elseif (($action == "manageusers")&&($forumsess[$realm]["admin"]))	manageusers();
	elseif (($action == "manageforums")&&($forumsess[$realm]["admin"]))	manageforums();
	elseif (($action == "editforum")&&($forumsess[$realm]["admin"]))	editforum($forum);
	elseif (($action == "deleteforum")&&($forumsess[$realm]["admin"]))	removeforum($forum);
	elseif (($action == "addforum")&&($forumsess[$realm]["admin"]))		addforum();
	elseif (($action == "saveforum")&&($forumsess[$realm]["admin"]))		makeforum();
	elseif (($action == "saveforumchange")&&($forumsess[$realm]["admin"]))	saveforumchanges($forum);
	elseif (($action == "userinfo")&&($forumsess[$realm]["admin"]))			userinfo($user);
	elseif (($action == "promoteuser")&&($forumsess[$realm]["admin"]))		userpromote($user);
	elseif (($action == "demoteuser")&&($forumsess[$realm]["admin"]))		userdemote($user);
	elseif (($action == "disableuser")&&($forumsess[$realm]["admin"]))		userdisable($user);
	elseif (($action == "enableuser")&&($forumsess[$realm]["admin"]))		userenable($user);
	elseif (($action == "closethread")&&($forumsess[$realm]["admin"]))	 	closethread($forum,$id);
	elseif (($action == "movethread")&&($forumsess[$realm]["admin"]))	 	moveform($forum,$id);
	elseif (($action == "confirmcleanup")&&($forumsess[$realm]["admin"]))	 	ConfirmCleanUp();
	
	elseif (($action == "cleanup")&&($forumsess[$realm]["admin"]))	 	CleanUp();
	
	elseif ($forum) 						displayforum($forum);

	else mainforums();

	forumfooter();
}
	
mainend();
htmlend();

db_disconnect();
?>