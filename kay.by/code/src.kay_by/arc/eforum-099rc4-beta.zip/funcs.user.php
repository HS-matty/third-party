<?
/**************************************

electrifiedForum
Version 0.99rc4 - November 20, 2001

Copyright 2001- electrifiedpenguin.com

This is free software, please leave all
copyright notices intact, thanks!

This is the user functions file

MAKE NO CHANGES TO THIS FILE
Customizing options are in the realm files!!!

***************************************/

function login($username,$password)
{
	global $config,$forumsess,$autherror,$realm;
	
	if ($config['pass_encrypt'] == "mysql")
		$vsql = "username='$username' AND password=PASSWORD('$password')";
	else
		$vsql = "username='$username' AND password='$password'";

	if (db_numrows($config[utable],"username='$username'")==1)
	{
		if (db_numrows($config[utable],$vsql)==1)
		{
			$disable = db_getvar($config[utable],"username='$username'","disabled");
			if (!$disable)
			{
				if (!session_is_registered("forumsess"))
					session_register("forumsess");
			
				$forumsess[$realm][username] = $username;
			
				if (db_getvar($config[utable],"username='$username'","level")==10)
					$forumsess[$realm][admin] = TRUE;
				
				return TRUE;
			}
			else
			{
				$autherror = "Account Disabled";
				return FALSE;
			}
		}
		else
		{
			$autherror = "Bad Password";
			return FALSE;
		}
	} 
	else
	{
		$autherror = "Bad Username";
		return FALSE;
	}
}

function verifyuser($username,$password)
{
/*synonymous with login()*/
	return login($username,$password);
}

function logout()
{
	global $config,$forumsess,$realm;
	
	unset($forumsess[$realm][username]);
	if ($forumsess[$realm][admin])
		unset($forumsess[$realm][admin]);
	if ($forumsess[$realm][verified])
		unset($forumsess[$realm][verified]);

}

function saveuser($method)
{
	global $config,$forumsess,$realm,$reg,$lang;
	
	if ($config[restrict_new_signups]&& $method == "new") 
	{
		if ($config[restrict_signups_text])
			print $config[restrict_signups_text]."<br>";
		else
			print "The administrator has disabled new signups.<br>";
	} 
	else 
	{
		$options = $reg[showemail] + $reg[showicq] + $reg[showaim] + $reg[showyahoo] + $reg[showbirthday] + $reg[showhomepage] + $reg[notification];
		$birthday = $reg[year].convert($reg[month]).convert($reg[day]);
	
		if ($method == "new")
		{
			if (!$reg[email])
				$regerror .= "You did not enter an email address.<br>";
			else
			{
  			$existinguser = db_numrows_sql("SELECT * FROM $config[utable] WHERE email='$reg[email]'");
  			if ($existinguser > 0 && !$config[allow_multiple_accts])
  				$regerror .= "The email adress you entered has already been used.";
			}
			
			if (!$reg[username])
				$regerror .= "You did not enter a username.<br>";
			if (!$reg[password])
				$regerror .= "You did not enter a password.<br>";
			
			if ($regerror)
			{
				print "<b style='color: red;'>Registration errors have occured:</b><br>$regerror<br>";
				signup_form();
				return;
			}
			
			$columns = "username,password,location,email,avatar,sig,icq,aim,yahoo,birthday,gender,homepage,options";
			
			if ($config['pass_encrypt'] == "mysql")
				$values = "'$reg[username]', PASSWORD('$reg[password]'), '$reg[location]', '$reg[email]', '$reg[avatar]', '$reg[sig]', '$reg[icq]', '$reg[aim]', '$reg[yahoo]', '$birthday', '$reg[gender]', '$reg[homepage]', '$options'";
			else
				$values = "'$reg[username]', '$reg[password]', '$reg[location]', '$reg[email]', '$reg[avatar]', '$reg[sig]', '$reg[icq]', '$reg[aim]', '$reg[yahoo]', '$birthday', '$reg[gender]', '$reg[homepage]', '$options'";

			if (db_insert($config[utable],$columns,$values))
			{
				if (!session_is_registered("forumsess"))
					session_register("forumsess");
		
				$forumsess[$realm]["username"] = $reg[username];
	
				print "Successfully saved your registration!<br><br>";
			
			} 
			else 
			{
				print "There was an $lang[error] with your registration!<br><br>";
			}
		
		} 
		elseif ($method == "edit") 
		{
			$columns = array("location","email","avatar","sig","icq","aim","yahoo","gender","birthday","homepage","options");
			$values = array($reg[location],$reg[email],$reg[avatar],$reg[sig],$reg[icq],$reg[aim],$reg[yahoo],$reg[gender],$birthday,$reg[homepage],$options);
		
			db_update($config[utable],"username='".$forumsess[$realm][username]."'",$columns,$values);
			print "Successfully edited your $lang[profile]!<br><br>";
	
		} 
		else 
		{
			print "An $lang[error] has occured.<br><br>";
		}
	
		print "<META HTTP-EQUIV='refresh' content='2;url=index.php?realm=$realm'>";

	}
}

function savepass()
{
	global $config,$forumsess,$realm,$pass,$lang;
	//$row = db_getrow($config[utable],"username='".$forumsess[$realm][username]."'");
	//if ($pass[old]==$row[password]){
	
	if ($config['pass_encrypt'] == "mysql")
	{
		if (db_numrows($config[utable],"username='".$forumsess[$realm][username]."' AND password=PASSWORD('$pass[old]')")==1)
		{
			//$columns = array("password");
		
			//$values = array("PASSWORD(".$pass['new'].")");
		
			$sql = "UPDATE $config[utable] SET password=PASSWORD('$pass[new]') WHERE username='".$forumsess[$realm][username]."'";
			//db_update($config[utable],"username='".$forumsess[$realm][username]."'",$columns,$values);
			if (db_do($sql))
				print "Successfully saved your new password!<br><br>";
			else 
				print "An $lang[error] has occured while attempting to update your password.<br><br>";
				
			mainforums();
		}
		else
		{
			print "$lang[error] You have entered an incorrect password!<br><br>";
			passwordform();
		}
	}
	else
	{
		$row = db_getrow($config[utable],"username='".$forumsess[$realm][username]."'");
		if ($pass[old]==$row[password])
		{
			$columns = array("password");
		
			$values = array($pass['new']);
		
			
			db_update($config[utable],"username='".$forumsess[$realm][username]."'",$columns,$values);
			
			print "Successfully saved your new password!<br><br>";
			mainforums();
		}
		else
		{
			print "$lang[error] You have entered an incorrect password!<br><br>";
			passwordform();
		}
	}	
}

function listavatars($currav)
{
	global $config;
	
	$avatars = dir_list($config['avatar_dir']);

	?>
	<script>
	/*
	Dynamic Image selector Script- � Dynamic Drive (www.dynamicdrive.com)
	*/
	
	function generateimage(which){
	if (document.all){
		if(which!=''){
			dynamic3.innerHTML='<center>Loading image...</center>'
			dynamic3.innerHTML='<img src="<?=$config[avatar_dir]?>'+which+'">'
		} else {
			dynamic3.innerHTML='&nbsp;'
		}
	}
	/*else if (document.layers){
		if(which!=''){
			document.dynamic1.document.dynamic2.document.write('<img src="<?=$config[avatar_dir]?>'+which+'">')
		} else {
			document.dynamic1.document.dynamic2.document.write('&nbsp;')
		}
		document.dynamic1.document.dynamic2.document.close()
	}
	else
	alert('You need IE 4+ to preview the images!')*/
	
	
	}
	</script>
	<select name="reg[avatar]" onChange="generateimage(this.options[this.selectedIndex].value)">
	<option value="" Selected>None
	<?
		
	for ($i=0;$i<sizeof($avatars);$i++)
	{
		if ($avatars[$i] == $currav)
			print "<option value='$avatars[$i]' SELECTED>$avatars[$i]</option>";
		else
			print "<option value='$avatars[$i]'>$avatars[$i]</option>";
	}
	
	?>
	
	</select>
	<?
}

function PasswordReset()
{
	// Will reset the password and email the user
	global $config,$realm,$pass,$lang;
	
	$newpass = substr(md5(microtime()),0,5);
	
	if ($config['pass_encrypt'] == "mysql")
	{
		if (db_numrows($config[utable],"username='$pass[user]' AND email='$pass[email]'")==1)
		{

			$sql = "UPDATE $config[utable] SET password=PASSWORD('$newpass') WHERE username='$pass[user]' AND email='$pass[email]'";

			if (db_do($sql))
			{
				SendPasswordEmail($pass[email],$pass[user],$newpass);
				print "An email has been sent containing your new password.<br>";
				print "Please login using this new password and change it ASAP.<br><br>";
			}
			else 
				print "An $lang[error] has occured while attempting to reset your password.<br><br>";
				
			mainforums();
		}
		else
		{
			print "$lang[error] The entered email address is not associated with any users in our database.<br><br>";
			passwordform();
		}
	}
	else
	{
		if (db_numrows($config[utable],"username='$pass[user]' AND email='$pass[email]'")==1)
		{
			
			$sql = "UPDATE $config[utable] SET password='$newpass' WHERE username='$pass[user]' AND email='$pass[email]'";
			
			if (db_do($sql))
			{
				SendPasswordEmail($pass[email],$pass[user],$newpass);
				print "An email has been sent containing your new password.<br>";
				print "Please login using this new password and change it ASAP.<br><br>";
			}
			else 
				print "An $lang[error] has occured while attempting to reset your password.<br><br>";
				
			mainforums();
		}
		else
		{
			print "$lang[error] The entered email address is not associated with any users in our database.<br><br>";
			passwordform();
		}
	}	

}

function SendPasswordEmail($to, $username, $newpass)
{
	global $config,$PHP_SELF,$HTTP_SERVER_VARS,$realm;
	$subj = "Password reset from $config[title]";
	$from = "<eF Password Reset>";
	$msg = "This is an automatic email from electrifiedForum at http://$HTTP_SERVER_VARS[HTTP_HOST]$PHP_SELF?realm=$realm\n";
	$msg .= "\n\n";
	$msg .= "Your information to login to $config[title] at\n";
	$msg .= "http://$HTTP_SERVER_VARS[HTTP_HOST]$PHP_SELF?realm=$realm\n";
	$msg .= "\n";
	$msg .= "Username: $username\n";
	$msg .= "New Password: $newpass\n";
	$msg .= "";
	
	if (mail($to, $subj, $msg, "From: $from\n"))
		return TRUE;
	else
		return FALSE;
}

?>