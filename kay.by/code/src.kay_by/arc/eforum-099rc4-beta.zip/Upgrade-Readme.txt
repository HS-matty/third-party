electrifiedForum v.99 (Beta) UPGRADE README File
###############################


This is still a beta release of electrifiedForum, and havent had time to write really good documentation, but here is a quick rundown of how to install and setup.

NOTE: This readme only covers upgrading from previous (.90+) versions of electrifiedForum.

Step 1: Copy files to web server.

Using the same directories as in the zip file, copy all files from this zip file to the location of the existing eF. Overwrite exisiting files where necessary.

Step 2: Run Upgrader

Go to the upgrader in your web browser, by going to the address www.yourdomain.com/efdirectory/upgrade.php where yourdomain is the host of your pages, and efdirectory is the directory/path where ef resides.

click upgrade to confirm upgrading eF.

If you recieve any errors during upgrade, please cut and paste them into a post on our support forums, http://www.electrifiedpenguin.com/forums/

If all went well, DELETE upgrade.php and install.php

THIS IS VERY IMPORTANT!!!!


Step 3: Update realm file.

If upgrading from 0.90,0.91, or 0.93,
Add the following lines to realm.default.php (within the main area at the top): 

$config['filtering']		=	FALSE;		// Word Filtering On?
$config['efcode']		=   	TRUE;

$config['forumiconnew']		=	'art/blue_folder.gif';	
$config['rankcolor']		= 	'blue';
	
$config['badwords']		=	array("badword1","badword2");

If upgrading from 0.95 or .96, please confirm the above vars.

All upgrades you should add these lines to the realm files:

$config['table_width']		= 	'90%';			// Width of tables
$config['icondir'] 		= 	'art/icons';		// Directory containing the posting icons (edit, quote, aim, etc...)
								// Currently we include icons and icons-white (for dark backgrounds)
								// You can create your own icons and dir and specify it here...
$config['24hour']		= 	FALSE;			// Use 24 hour time instead of 1-12 AM/PM format?


If upgrading from 0.99rc1 or rc2, please confirm the above vars.

All upgrades you should add these lines to the realm files:

$config['topics_per_page']= 30;			// Number of topics shown per forum page
$config['posts_per_page'] = 20;			// Number of posts shown per thread page

$config['allow_anon']	  = 'FALSE';		// Allow anonymous (auth or not) posting?

Step 4: Test!

To test the forums, go to the forum directory in your web browser. If you see no errors, and 1 forum 'chat', then everything is good to go.








###############

Common Issues:

If you get errors such as 'call to undefined function mysql_connect', then MySQL support is not enabled or compiled into PHP.

If you get a unable to save session file error on a windows server, its usually because php.ini has not been configured properly.

If images are not showing up properly, see step 3. There are some lines related to graphics that must be in the realm files.

###############

If you need assistance, feel free to contact us via email at support@electrifiedpenguin.com or through our forums at http://www.electrifiedpenguin.com/forums/





Thanks!
-Skot
Friday, November 2, 2001							

