<?

/**************************************

electrifiedForum
Version 0.99rc4 - November 14, 2001

Copyright 2001- electrifiedpenguin.com

This is free software, please leave all
copyright notices intact, thanks!

This is the main functions file

MAKE NO CHANGES TO THIS FILE
Customizing options are in the realm files!!!

***************************************/

$ef[ver] = '.99rc4';

if (!$config['table_width'])
	$config['table_width'] = '90%';
	
	
function forummenu()
{
/* print a menu of basic forum functions, based on being logged in or not */
	global $forumsess,$realm,$config,$lang;
	
	if ($forumsess[$realm][username])
		print "<a href='index.php?action=profile&realm=$realm'>$lang[profile]</a> | <a href='index.php?action=logout&realm=$realm'>$lang[logout]</a> | <a href='index.php?action=search&realm=$realm'>$lang[search]</a>";
		
	else
		print "<a href='index.php?action=register&realm=$realm'>$lang[register]</a> | <a href='index.php?action=loginbox&realm=$realm'>$lang[login]</a> | <a href='index.php?action=search&realm=$realm'>$lang[search]</a>";

}

function forumheader()
{
/* Create a table for the top of the forum... */
	global $config,$forum,$id,$realm,$HTTP_SERVER_VARS,$action,$lang,$forumsess;
	
	if ($forum && verifyforum($forum))
	{
		$finfo = db_getrow($config[ftable],"fname='$forum'");
	}
		
	?>
	<table border=0 cellpadding=0 cellspacing=0 width='<?=$config[table_width]?>'>
	<TR>
	<td bgcolor="<?=$config[tcolor]?>">
	<table border=0 cellspacing=1 cellpadding=4 width='100%'>
	<tr>
	<td colspan=2 bgcolor="<?=$config['color_top']?>" class=tabletop>
		<div class="forumtitle"><? print stripslashes($config[title])?></div>
	</td>
	<td width=160 align=center bgcolor="<?=$config['color_top']?>" class=tabletop>
	<!-- Register / Login / Etc -->
		<? forummenu(); ?>
	</td>
	</tr>
	<tr>
	<td colspan=2 bgcolor="<?=$config['color_a']?>">
	<!-- Navigation -->
		<a href="index.php?realm=<?=$realm?>"><?=$lang[index]?></a>
		<?
		if ($config[messaging])
		{
			if ($action=="inbox")
			{
				print ": Private Message Inbox";
				$mm = 1;
			}
		}
		?>
		<? if ($finfo && !$mm) print " <font style='font-size: 9px;'>&gt;&gt;</font> <a href='index.php?forum=$forum&realm=$realm'>".forumtitle($forum)."</a>"; ?>
		<? if (isset($id) && !$mm) print ":<br> ".threadtitle($forum,$id); ?>
	</td>
	<td width=160 align=right bgcolor="<?=$config['color_a']?>">
	<!-- Post / Reply Button -->
		&nbsp;
		<? postbutton(); ?>
	</td>
	</tr>
	<?
	if ($finfo) {
		?>
		<tr>
		<td colspan=2 bgcolor="<?=$config['color_a']?>">
			<?=$finfo[fdesc]?>
		</td>
		<td width=160 align=center bgcolor="<?=$config['color_a']?>">
			<? print $lang[owner].": ".$finfo[owner];?>
		</td>
		</tr>
		<?
	}
	
	if ($config[messaging] && $forumsess[$realm][username]) 
	{
		?>
		<tr>
		<td colspan=3 bgcolor="<?=$config['color_a']?>">
			Message Center:
			<a href="index.php?action=inbox&realm=<?=$realm?>">
			<?
			if (new_messages($forumsess[$realm][username])) print "<b>New Messages</b>";
			else print "Inbox";
			?>
			</a>
			- <a href="index.php?action=pm&realm=<?=$realm?>">Compose</a>
		</td>
		</tr>
		<?
	}
		
	?>
	</table>
	</td>
	</tr>
	</table>
	<br>
	<?
}

function postbutton()
{
	global $config,$forum,$id,$realm,$action;
	if ($config['use_buttons'])
	{
			if ((isset($id))&&(is_thread_open($forum,$id))) 
				print "<a href='index.php?action=reply&forum=$forum&id=$id&realm=$realm'><img src='$config[reply_butn]' border=0 alt='Post Reply'></a><br>";
			elseif ($forum && is_forum_open($forum) && !isset($id))
				print "<a href='index.php?action=post&forum=$forum&realm=$realm'><img src='$config[post_butn]' border=0 alt='Post New Message'></a><br>";
	} 
	else 
	{		
			if ((isset($id))&&(is_thread_open($forum,$id))) 
				print "<a href='index.php?action=reply&forum=$forum&id=$id&realm=$realm'>Post Reply</a><br>";
			elseif ($forum && is_forum_open($forum) && !isset($id))
				print "<a href='index.php?action=post&forum=$forum&realm=$realm'>Post Message</a><br>";
	}
}



function forumfooter()
{
/* Create a table for the bottom of the forum... */
	global $forumsess,$realm,$id,$forum,$config,$ef,$lang,$starttime;
	?>
	<br>
	<table border=0 cellpadding=0 cellspacing=0 width='<?=$config[table_width]?>'>
	<TR>
	<td bgcolor="<?=$config[tcolor]?>">
	<table border=0 cellspacing=1 cellpadding=4 width='100%'>
	<tr>
	<td colspan=2 bgcolor="<?=$config['color_a']?>">
	<!-- Last Visit Text -->
		<?
		if ($forumsess[$realm][lastvisit])
			printvisit();
		?>
	</td>
	<td width=33% align=right bgcolor="<?=$config['color_a']?>">
	<!-- Post / Reply Button -->
		&nbsp;
		<? postbutton(); ?>
	</td>
	</tr>
	
	<?
	if ($forumsess[$realm][admin])
	{
		?>
			<tr>
			<td width=33% align=left bgcolor="<?=$config['color_b']?>">
			<?=$lang[ao]?>
			</td>
			<td colspan=2 align="right" bgcolor="<?=$config['color_b']?>">
			<?	if (isset($id))
				print "<a href='index.php?action=closethread&forum=$forum&id=$id&realm=$realm'>Close Thread</a> | <a href='index.php?action=movethread&forum=$forum&id=$id&realm=$realm'>Move Thread</a><br>";
			?>
			<a href='index.php?action=manageusers&realm=<?=$realm?>'><?print $lang[manage]." ".$lang[users];?></a> | <a href='index.php?action=manageforums&realm=<?=$realm?>'><?print $lang[manage]." ".$lang[forums];?></a> | <a href='index.php?action=confirmcleanup&realm=<?=$realm?>'>CleanUp</a>
			</td>
			</tr>
		<?
	}
	?>
	
	<tr>
	<td width=33% bgcolor="<?=$config['color_a']?>" valign=top>
	<!-- Legend -->
		<u><?=$lang[legend]?></u><br>
		<br>
		<img src='<?=$config[forumiconnew]?>'> <?=$lang[nm]?><br>
		<img src='<?=$config[forumicon]?>'> <?=$lang[nnm]?><br>
	</td>
	<td width=33% bgcolor="<?=$config['color_a']?>" valign=top>
	<!-- Stats -->
		<u><?=$lang[fws]?></u><br>
		<br>
		<? print $lang[total]." ".$lang[forums].": ".forumcount(); ?><br>
		<? print $lang[total]." ".$lang[messages].": ".tmsgcount(); ?><br>
		<? print $lang[total]." ".$lang[users].": ".usercount(); ?><br>
	</td>
	<td width=33% bgcolor="<?=$config['color_a']?>" valign=top>
	<!-- Copyright -->
		<u><?=$lang[powby]?></u><br>
		<br>
		
		electrifiedForum v<?=$ef[ver]?><br>
		Copyright &copy; 2001 <a href="http://www.electrifiedpenguin.com">electrifiedpenguin.com</a>

	</td>
	</tr>
	</table>
	</td>
	</tr>
	</table>
	<?
	$endtime = GetMicrotime();
	$totaltime = round($endtime-$starttime,5);
	print "<div align=center style='font-size: 10px;'>This page was generated in $totaltime seconds.</div>";
}


function authreq_box()
{
/* Create a table for the top of the forum... */
	global $config,$realm,$lang;
	
	?>
	<table border=0 cellpadding=0 cellspacing=0 width='<?=$config[table_width]?>'>
	<TR>
	<td bgcolor="<?=$config[tcolor]?>">
	<table border=0 cellspacing=1 cellpadding=4 width='100%'>
	<tr>
	<td colspan=2 bgcolor="<?=$config['color_top']?>" class=tabletop>
		<div class="forumtitle"><?=$config[title]?></div>
	</td>
	<td width=160 align=center bgcolor="<?=$config['color_top']?>" class=tabletop>
	<!-- Register / Login -->
		<? print "<a href='index.php?action=register&realm=$realm'>$lang[register]</a> | <a href='index.php?action=loginbox&realm=$realm'>$lang[login]</a>"?>
	</td>
	</tr>
	<tr>
	<td colspan=3 bgcolor="<?=$config['color_a']?>">
	<?
	if ($config[auth_req_text])
		print $config[auth_req_text];
	else 
		print "Access to these forums is restricted to members only.";
	?>
	<br><br>
	Please <a href="index.php?action=loginbox&realm=<?=$realm?>">login</a> or <a href="index.php?action=register&realm=<?=$realm?>">register</a><br>
		
	</td>

	</tr>
	<?
	if ($finfo) 
	{
		?>
		<tr>
		<td colspan=2 bgcolor="<?=$config['color_a']?>">
			<?=$finfo[fdesc]?>
		</td>
		<td width=160 align=center bgcolor="<?=$config['color_a']?>">
			<? print $lang[owner].": ".$finfo[owner];?>
		</td>
		</tr>
		<?
	}
	
	if ($config[messaging] && $forumsess[$realm][username]) 
	{
		?>
		<tr>
		<td colspan=3 bgcolor="<?=$config['color_a']?>">
			Message Center:
			<a href="index.php?action=inbox&realm=<?=$realm?>">
			<?
			if (new_messages($forumsess[$realm][username])) 
				print "<b>New Messages</b>";
			else 
				print "Inbox";
			?>
			</a>
			- <a href="index.php?action=pm&realm=<?=$realm?>">Compose</a>
		</td>
		</tr>
		<?
	}
		
	?>
	</table>
	</td>
	</tr>
	</table>
	<br>
	<?
}

?>