<?
/**************************************

electrifiedForum
Version 0.99rc4 - November 12, 2001


Copyright 2001- electrifiedpenguin.com

This is free software, please leave all
copyright notices intact, thanks!

This is the main functions file

MAKE NO CHANGES TO THIS FILE
Customizing options are in the realm files!!!

***************************************/

/* Setup default vars for tables */
if (!$config[utable])
	$config[utable] = 'fusers';
if (!$config[mtable])
	$config[mtable] = 'messages';
if (!$config[ftable])
	$config[ftable] = 'forums';
if (!$config[pmtable])
	$config[pmtable] = 'pmessages';

	
function MailNotification($forum, $thread, $poster)
{
	global $config,$PHP_SELF,$HTTP_SERVER_VARS,$realm;
	
	$result = db_select("SELECT u.* FROM $config[mtable] AS m, $config[utable] AS u WHERE m.fname = '$forum' AND m.threadid = '$thread' AND u.username = m.poster AND u.options & 64 GROUP BY u.username");

	while($row = db_getarray($result))
	{
		if ($row[username] != $poster)
			$users[] = $row;
	}
	
	$topicname = threadtitle($forum,$thread);
	
	$subj = "Reply to Topic $topicname at $config[title]";

	$from = "<eF Email Notifications>";
	
	$msg = "This is an automatic email from electrifiedForum at http://$HTTP_SERVER_VARS[HTTP_HOST]$PHP_SELF?realm=$realm\n";
	$msg .= "\n\n";
	$msg .= "A new reply has been posted to the $topicname at $config[title]\n";
	$msg .= "You can view the topic at:\n";
	$msg .= "http://$HTTP_SERVER_VARS[HTTP_HOST]$PHP_SELF?action=displaythread&forum=$forum&id=$thread&realm=$realm";
	
	$msg .= "You requested email notifications be sent for replies to topics you post in on the forums at\n";
	$msg .= "http://$HTTP_SERVER_VARS[HTTP_HOST]$PHP_SELF?realm=$realm\n";
	$msg .= "\n";
	$msg .= "To turn off email notifications, log in to the forums above, click profile, and uncheck the email notifications option box.\n";
	$msg .= "\n";
	
	if (is_array($users))
		foreach ($users as $user)
			if ($user[email])
				mail($user[email], $subj, $msg, "From: $from\n");
		
}

function ForumAuth()
{
	/* Need to take current user, entered password, verify, and if verified, allow access to this forum for duration of session */
	global $forumsess,$forumpass,$forum,$realm,$config;
	
	if (db_numrows_sql("SELECT * FROM $config[ftable] WHERE fname='$forum' AND forumpassword=PASSWORD('$forumpass')") == 1)
		$forumsess[$realm][verified][$forum] = TRUE;
	else
		$verifyerror = "&verifyerror=1";
	header("Location: index.php?action=displayforum&forum=$forum&realm=$realm$verifyerror");
}

function forums_array()
{
	/* return an array of forum names */
	global $config;
	
	$result = db_select("SELECT fname FROM $config[ftable] ORDER BY fname ASC");
	
	while($row = db_getarray($result))
	{
		$forums[] = $row[fname];
	}
	
	return $forums;
	
}

function filter($data)
{
	global $config;
	$repchar = '*';
	
	for($i=0;$i<sizeof($config[badwords]);$i++)
	{
		$rep = '';
		$ltrs = strlen($config[badwords][$i])-1;
		for ($n=0;$n<$ltrs;$n++)
		{
			$rep .= $repchar;
		}
		$replacement = substr($config[badwords][$i],0,1).$rep;
		
		$data = eregi_replace($config[badwords][$i],$replacement,$data);
	
	}

	return $data;
}

function mainforums()
{
/* Display all known forums in a nice table */
	global $config,$realm,$forumsess,$lang;
			
		if (db_numrows_all($config[ftable])>0)
		{
		
			print "<table border=0 cellpadding=0 cellspacing=0 width='$config[table_width]'><TR>
				<td bgcolor='$config[tcolor]'>
				<table border=0 cellspacing=1 cellpadding=4 width='100%'>";
							
			$result = db_select("SELECT cat FROM $config[ftable] GROUP BY cat");
			
			while($cat = db_getarray($result))
			{
			
				$result2 = db_select("SELECT * FROM $config[ftable] WHERE cat='$cat[cat]' ORDER BY ftitle ASC");
				
				if (!$cat[cat])
					$cat[cat] = $lang[gf];
				
				print "<tr bgcolor='".$config['color_top']."'>

				<td class=ftitle colspan=6> <strong>$cat[cat]</strong> </td>

				</tr>";
				print "<tr bgcolor='".$config['color_top']."'>
				<td>&nbsp;</td>
				<td class=tabletop width=150> <strong>$lang[forum]</strong> </td>
				<td class=tabletop> <strong>$lang[description]</strong> </td>
				<td class=tabletop> <strong>$lang[topics]</strong> </td>
				<td class=tabletop> <strong>$lang[msgs]</strong> </td>
				<td class=tabletop> <strong>$lang[mr]</strong> </td>
				</tr>";
				
				$i = 0;
				
				while($row = db_getarray($result2))
				{
								
					$i = $i + 1;
			
					if ($i % 2) $bgcolor = $config['color_b'];
					else  $bgcolor = $config['color_a'];
					
					$date[$i] = lastdate($row[fname]);
					
					if ($date[$i])
					{
						if ($config['24hour'])
							$format = "l, F j H:i";
						else
							$format = "l, F j h:i a";
						$datetext = date($format,sql_to_unix_time($date[$i]));
					} 
					else 
					{
						$datetext = "&nbsp;";
					}
					
					if (sql_to_unix_time($date[$i]) > $forumsess[$realm][lastvisit])
					{
						$icon = "<img src='$config[forumiconnew]'>";
						$titletext = $row[ftitle];
					} 
					else 
					{
						$titletext = $row[ftitle];
						$icon = "<img src='$config[forumicon]'>";
					}
					
					print "<tr bgcolor='$bgcolor'>
						<td valign=top>$icon</td>
						<td valign=top><a href='index.php?forum=$row[fname]&realm=$realm'>".$titletext."</a></td>
						<td valign=top>".$row[fdesc]."</td>
						<td valign=top align=center>".topiccount($row[fname])."</td>
						<td valign=top align=center>".messagecount($row[fname])."</td>
						<td valign=top>".$datetext."</td>
						</tr>";
				}
								
			}
			
			print "</table></td></tr></table>";
		} 
		else 
		{
			print "No forums available<br>";
		}
		
}

function DisplayForum($forumname)
{
/* Take forumname, and get all threadnames for it... */
	global $realm,$config,$forumsess,$lang,$startat,$verifyerror;
	if (!$startat)
		$startat = 0;
	if (!$config['topics_per_page'])
		$config['topics_per_page'] = 30;
	$foruminfo = db_getrow($config[ftable], "fname='$forumname'");
	
	if ($foruminfo)
	{
		if ($foruminfo[options] & 2 && !$forumsess[$realm][verified][$forumname])
		{
			/* Private forum */
			print "<form action='index.php?action=verifyforumpassword&forum=$forumname&realm=$realm' method='post'>";
			print "This forum is marked as private and requires a password to login.<br />";
			print "Enter the password in the box below, and click verify to login.<br />";
			if ($verifyerror)
			{
				print "<br /><font color=red>Entered Password was not correct.</font><br />";
			}
			
			print "<br />";
			print "Forum Password: <input type='password' name='forumpass'> ";
			print "<input type='submit' name='submit' value=' Verify '><br />";
			print "</form>";		
		}
		else
		{
  		$sql = "SELECT m.*, MAX(d.posttime) AS ptime FROM $config[mtable] m, $config[mtable] d WHERE m.fname='$forumname' AND d.fname='$forumname' AND d.threadid=m.threadid AND m.threadindex='0' GROUP BY m.threadid ORDER BY ptime DESC";
  		$totalnum = db_numrows_sql($sql);
  		if ($totalnum>0)
  		{
  			$result = db_select($sql." LIMIT $startat,$config[topics_per_page]");
  			$totalhits = db_numrows_result($result);
  			$i = 0;
  			$start = $startat+1;
  			$end = $startat+$totalhits;
  			$backto = $startat-$config['topics_per_page'];
  			
  			//print $totalnum."<br>";
  			$remaining = $totalnum - ($startat+$config['topics_per_page']);
  			$totalpages = ceil($totalnum / $config['topics_per_page']);
  			$lastpagestart = ($totalpages-1) * $config['topics_per_page'];
  
  			if ($remaining > $config['topics_per_page'])
  				$remaining = $config['topics_per_page'];
  			
  			if ($startat > 0)
  			{
  				$backtext = "<a href='index.php?action=displayforum&realm=$realm&forum=$forumname&startat=$backto'>&lt;&lt; $lang[previous] $config[topics_per_page]</a>";
  				$starttext = "<a href='index.php?action=displayforum&realm=$realm&forum=$forumname&startat=0'>&lt;&lt;&lt; First Page</a>";
  			}
  			if ($totalnum > ($startat+$config['topics_per_page']))
  			{
  				$nexttext = "<a href='index.php?action=displayforum&realm=$realm&forum=$forumname&startat=$end'>$lang[next] $remaining &gt;&gt;</a>"; 
  				$endtext = "<a href='index.php?action=displayforum&realm=$realm&forum=$forumname&startat=$lastpagestart'>Last Page &gt;&gt;&gt;</a>"; 
  			}		
  		
  		print "<table border=0 cellpadding=0 cellspacing=0 width='$config[table_width]'><TR><td bgcolor='$config[tcolor]'>
        		<table border=0 cellspacing=1 cellpadding=4 width='100%'>
        		<tr bgcolor='".$config['color_top']."'>
        		<td class=tabletop width='33%' align=left> <strong>$backtext<br>$starttext</strong> </td>
        		<td class=tabletop width='33%' align=center>
        			<strong>Showing topics $start to $end</strong><br>
        			Total Topics: $totalnum Pages: $totalpages
        		</td>
        		<td class=tabletop width='33%' align=right> <strong>$nexttext<br>$endtext</strong> </td>
        		</tr>
        		</table></td></tr>		
      			<TR>
      			<td bgcolor='$config[tcolor]'>
      			<table border=0 cellspacing=1 cellpadding=4 width='100%'>";
      			print "<tr bgcolor='".$config['color_top']."'>
      			<td class=tabletop> &nbsp; </td>
      			<td class=tabletop width='50%'> <strong>$lang[title]</strong> </td>
      			<td class=tabletop> <strong>$lang[poster]</strong> </td>
      			<td class=tabletop> <strong>$lang[msgs]</strong> </td>
      			<td class=tabletop> <strong>$lang[mr]</strong> </td></tr>";
  			
  			while($row = db_getarray($result))
  			{
  				
  				$i = $i + 1;
  		
  				if ($i % 2) $bgcolor = $config['color_b'];
  				else  $bgcolor = $config['color_a'];
  		
  		
  				if ($row[icon]) 
  					$icon = "<img src='$config[msgicons_dir]$row[icon]'>";
  				else
  					$icon = "<img src='$config[msgicons_dir]$config[msgicon]'>";
  		
  				$date[$i] = lastthreaddate($forumname,$row[threadid]);
  				
  					if ($date[$i])
  					{
  						if ($config['24hour'])
  							$format = "m-d-y H:i";
  						else
  							$format = "m-d-y h:i a";
  						$datetext = date($format,sql_to_unix_time($date[$i]));
  					} 
  					else 
  					{
  						$datetext = FALSE;
  					}
  					
  				if (sql_to_unix_time($date[$i]) > $forumsess[$realm][lastvisit])
  					$titletext = "<b>".$row[title]."</b>";
  				else
  					$titletext = $row[title];
  					
  		print "<tr bgcolor='$bgcolor' height=20>
        		<td width=20 align=center valign=top height=20>$icon</td>
        		<td><a href='index.php?action=displaythread&forum=$forumname&id=$row[threadid]&realm=$realm'>$titletext</a></td>
        		<td>$row[poster]</td>
        		<td align=center>".threadcount($forumname,$row[threadid])."</td>
        		<td>$datetext</td>
        		</tr>";
  
  			}
  			print "</table>
      				<table border=0 cellspacing=1 cellpadding=4 width='100%'>
      				<tr bgcolor='".$config['color_top']."'>
      				<td class=tabletop width='33%' align=left> <strong>$backtext<br>$starttext</strong> </td>
      				<td class=tabletop width='33%' align=center>
    					<strong>Showing topics $start to $end</strong><br>
    					Total Topics: $totalnum Pages: $totalpages
      				</td>
      				<td class=tabletop width='33%' align=right> <strong>$nexttext<br>$endtext</strong> </td>
      				</tr>
      				</table>";
  			print "</td></tr></table>";
  		} 
  		else 
  		{
  			print "No messages available for this forum. <a href='index.php?action=post&forum=$forumname&realm=$realm'>Post one!</a><br>";
  		}
  		
  		print "</div>";
  	}

	} 
	else
	{
	
		print "$lang[error]- No forum with id of $forumname available<br>";

	}

}

function DisplayThread($forumname,$threadid)
{
	global $config,$realm,$forumsess,$lang,$startat;
	
	if (!$startat)
		$startat = 0;
	
	if (!$config['posts_per_page'])
		$config['posts_per_page'] = 30;
		
	if (!$config[icondir])
		$config[icondir] = "art/icons";
		
	$open = is_thread_open($forumname,$threadid);
	$sql = "SELECT p.id AS id, p.posttime AS posttime, p.content AS content, u.username AS poster, u.options AS useropts, u.gender AS gender, u.birthday AS birthday, u.sig AS sig, u.votes AS votes, u.rank AS rank, u.location AS location, p.icon AS icon, p.title AS title, p.ip AS ip, u.email AS email, u.homepage AS homepage, u.aim AS aim, u.yahoo AS yahoo, u.icq AS icq FROM $config[mtable] p, $config[utable] u WHERE p.fname='$forumname' AND p.threadid='$threadid' AND u.username=p.poster ORDER BY p.threadindex ASC";
	if (verifythread($forumname,$threadid))
	{
		$totalnum = db_numrows_sql($sql);

  	$result = db_select($sql." LIMIT $startat,$config[posts_per_page]");
  	$totalhits = db_numrows_result($result);
  	$i = 0;
  	$start = $startat+1;
  	$end = $startat+$totalhits;
  	$backto = $startat-$config['posts_per_page'];
  	
  	//print $totalnum."<br>";
  	$remaining = $totalnum - ($startat+$config['posts_per_page']);
  	$totalpages = ceil($totalnum / $config['posts_per_page']);
  	$lastpagestart = ($totalpages-1) * $config['posts_per_page'];
  
  	if ($remaining > $config['posts_per_page'])
  		$remaining = $config['posts_per_page'];
  	
  	if ($startat > 0)
  	{
  		$backtext = "<a href='index.php?action=displaythread&realm=$realm&forum=$forumname&id=$threadid&startat=$backto'>&lt;&lt; $lang[previous] $config[topics_per_page]</a>";
  		$starttext = "<a href='index.php?action=displaythread&realm=$realm&forum=$forumname&id=$threadid&startat=0'>&lt;&lt;&lt; First Page</a>";
  	}
  	if ($totalnum > ($startat+$config['posts_per_page']))
  	{
  		$nexttext = "<a href='index.php?action=displaythread&realm=$realm&forum=$forumname&id=$threadid&startat=$end'>$lang[next] $remaining &gt;&gt;</a>"; 
  		$endtext = "<a href='index.php?action=displaythread&realm=$realm&forum=$forumname&id=$threadid&startat=$lastpagestart'>Last Page &gt;&gt;&gt;</a>"; 
  	}		
  
  
  	print "<table border=0 cellpadding=0 cellspacing=0 width='$config[table_width]'><TR><td bgcolor='$config[tcolor]'>
		<table border=0 cellspacing=1 cellpadding=4 width='100%'>
		<tr bgcolor='".$config['color_top']."'>
		<td class=tabletop width='33%' align=left> <strong>$backtext<br>$starttext</strong> </td>
		<td class=tabletop width='33%' align=center>
			<strong>Showing posts $start to $end</strong><br>
			Total Posts: $totalnum Pages: $totalpages
		</td>
		<td class=tabletop width='33%' align=right> <strong>$nexttext<br>$endtext</strong> </td>
		</tr>
		</table></td></tr>
		</table>
		<br>";
		print "<table border=0 cellpadding=0 cellspacing=0 width='$config[table_width]'>
			<TR>
			<td bgcolor='$config[tcolor]'>
			<table border=0 cellspacing=1 cellpadding=4 width='100%'>
			<tr bgcolor='".$config['color_top']."'>
			<td class=tabletop><strong>Poster</strong></td>
			<td class=tabletop><strong>Topic</strong></td>
			</tr>";
		while($row = db_getarray($result))
		{
			$i = $i + 1;
		
			$options = $row[useropts];
			if ($i % 2) $bgcolor = $config['color_b'];
			else  $bgcolor = $config['color_a'];
			
			if (($row[rank])&&($row[votes]))
			{
				$score = $row[rank]/$row[votes];
				$rank = round($score, 0);
				$score = round($score, 2);
			} 
			else 
			{
				$rank = FALSE;
			}
			
			if ($config['24hour'])
				$format = "l, F j Y H:i";
			else
				$format = "l, F j Y h:i A";
			
			$datetext = date($format,sql_to_unix_time($row[posttime]));
			
			?><tr bgcolor="<?=$bgcolor?>">
			<TD width=18% valign=top rowspan=3>
			<FONT SIZE="2" face="Verdana, Arial">
			<B><?=$row[poster]?></B>
			</font>
			<BR>
			<FONT SIZE="1" face="Verdana, Arial">
			<?
			if (admincheck($row[poster]))
				print $lang[administrator]."<br>";
			elseif ($row[poster]=="Anonymous")
				print "";
			else
				print $lang[member]."<br>";
				
			
			if ($options & 16){
				$age = age_from_bday($row[birthday]);				
				print $lang[age].": $age<br />";
			}
			
			if ($row[gender])
				print "$row[gender]<br />";
			
			if ($row[location])
				print "$row[location]<br />";
			
			if (!$config[disable_karma])
			{
  			if ($rank)
  			{
  				print "<img src='art/ranking/$config[rankcolor]/$rank.gif' /><br />";
  				print $score."<br>";
  			}
  			elseif ($row[poster]=="Anonymous")
  				print "";
  			else
  				print $lang[mnyr]."<br />";
			}
			?>		
			</FONT>
			<br>
			<? print avatar($row[poster]); ?>
			</td>
			<td class=messagetitle height=20 valign=top>
			<?
			if ($row[icon]) 
				print "<img src='$config[msgicons_dir]$row[icon]'>";
			else
				print "<img src='$config[msgicons_dir]$config[msgicon]'>";
			?>
			<strong><?=$row[title]?></strong>
			</td>
			</tr>
			<tr bgcolor="<?=$bgcolor?>">
			<TD class=messagebody valign=top height=100%>
			<FONT SIZE="1" face="Verdana, Arial">
			<b><?=$lang[posted]?>:</b>
			<?=$datetext?>
			&nbsp; &nbsp;
			<A HREF='index.php?action=editmsg&forum=<?=$forumname?>&mid=<?=$row[id]?>&realm=<?=$realm?>'>
			<IMG SRC="<?=$config[icondir]?>/edit.gif"  align=absmiddle BORDER=0 ALT="Edit/Delete Message"></A>
			<?
			if ($open)
				print "&nbsp;&nbsp;
					<A HREF='index.php?action=replyquote&forum=$forumname&mid=$row[id]&realm=$realm'>
					<IMG SRC='$config[icondir]/quote.gif' align=absmiddle BORDER=0 ALT='Reply w/Quote'></A>";
			?>

			</FONT>
			<HR noshade size=1 width=100%>
			<FONT SIZE="2" FACE="Verdana, Arial">
			<!-- Message -->
			<?
			$content = $row[content];
			if (ereg("^##EFCODE##.*",$content))
			{
				$content = str_replace("##EFCODE##","",$content);
				print process($content);
			}
			else
				print $content;
			?>
			<!-- end message -->
			<!-- sig -->
			<?
			if ($row[sig])
				print "<br><br><hr noshade width=150 size=1 align=left>$row[sig]<br>";
				
			?>
			<!-- end sig -->
			</FONT>
			<p>
			</td>
			</tr>
			<tr bgcolor="<?=$bgcolor?>" height=15>
			<td valign=top>
			<?
			if (($row[poster] != "Anonymous") && (!$config[disable_karma]))
				print "<a href='#' onclick=\"window.open('index.php?action=karma&who=".$row[poster]."&realm=$realm','karma','toolbars=no,width=300,height=200');\"><IMG SRC='$config[icondir]/karma.gif' BORDER=0 ALT='Rate $row[poster]' align=absmiddle></a>&nbsp;";

			if ($config[messaging] && $row[poster] != "Anonymous")
				print "
					<A HREF='index.php?action=pm&to=$row[poster]&re=re:+$row[title]&realm=$realm'>
					<IMG SRC='$config[icondir]/pm.gif' BORDER=0 ALT='Send a private message to $row[poster]' align=absmiddle></A>";

			if ($options & 1)
				print "&nbsp;
					<A HREF='mailto:$row[email]'>
					<IMG SRC='$config[icondir]/email.gif' BORDER=0 ALT='Email' align=absmiddle></A>";
			
			if ($options & '32')
				print "&nbsp;
					<a href='$row[homepage]' target='_blank'>
					<img src='$config[icondir]/homepage.gif' alt='Visit $row[poster]`s homepage!' border=0 align=absmiddle></a>";

			if ($options & 4)
				print "&nbsp;
					<A HREF='aim:goim?screenname=$row[aim]&message=Hello'>
					<IMG SRC='$config[icondir]/aim.gif' BORDER=0 ALT='$row[aim]' align=absmiddle></A>";
			
			if ($options & 8)
				print "&nbsp;
					<a href='http://edit.yahoo.com/config/send_webmesg?.target=$row[yahoo]' target='_blank'>
					<img src='$config[icondir]/yahoo.gif' alt='Send a Yahoo! message to $row[yahoo]' border=0 align=absmiddle></a>";
			
			if ($options & 2)
				print "&nbsp;<a href='http://wwp.icq.com/$row[icq]' target='_blank'><IMG SRC='http://wwp.icq.com/scripts/online.dll?icq=$row[icq]&img=5' BORDER=0 ALT='ICQ: $row[icq]' align=absmiddle><img src='$config[icondir]/icq_text.gif' border=0 align=absmiddle></a>";

			
			if ($forumsess[$realm][admin])
				print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<FONT SIZE=1><IMG SRC='$config[icondir]/ip.gif' BORDER=0 align=absmiddle> $row[ip]</font>";
			?>
			&nbsp;
			</td>
			</tr>
			<?
		}
		print "</table></td></tr></table><br>";
  	print "<table border=0 cellpadding=0 cellspacing=0 width='$config[table_width]'><TR><td bgcolor='$config[tcolor]'>
		<table border=0 cellspacing=1 cellpadding=4 width='100%'>
		<tr bgcolor='".$config['color_top']."'>
		<td class=tabletop width='33%' align=left> <strong>$backtext<br>$starttext</strong> </td>
		<td class=tabletop width='33%' align=center>
			<strong>Showing posts $start to $end</strong><br>
			Total Posts: $totalnum Pages: $totalpages
		</td>
		<td class=tabletop width='33%' align=right> <strong>$nexttext<br>$endtext</strong> </td>
		</tr>
		</table></td></tr>
		</table>";
	} 
	else 
	{
	
		print "$lang[error]- No thread with id of $threadid available<br>";

	}

}


function process($data)
{
/* Process message data with various conversions/filters */
/* Currently, we are dumb and process this before sticking in the database */
/* Someday my master will change me so that I only process data at viewing time */

	global $config;
	
	if ($config[efcode])
		$data = nl2br(htmlentities($data));
	else
		$data = nl2br($data);
	
	if ($config[filtering])
		$data = filter($data);
		
	$data = str_replace("\n","",$data);
	$data = str_replace("\r","",$data);
	
	if ($config[efcode])
	{
		$data = str_replace(":)","<IMG src=\"art/smileys/smile.gif\">",$data);
		$data = str_replace(":D","<IMG src=\"art/smileys/biggrin.gif\">",$data);
		$data = str_replace(":P","<IMG src=\"art/smileys/tongue.gif\">",$data);
		$data = str_replace(":?:","<IMG src=\"art/smileys/confused.gif\">",$data);
		$data = str_replace(":wink:","<IMG src=\"art/smileys/wink.gif\">",$data);
		$data = str_replace(":angry:","<IMG src=\"art/smileys/angry.gif\">",$data);
		$data = str_replace(":rolleyes:","<IMG src=\"art/smileys/rolleyes.gif\">",$data);
		$data = str_replace(":(","<IMG src=\"art/smileys/sad.gif\">",$data);
		$data = str_replace(":laugh:","<IMG src=\"art/smileys/laugh.gif\">",$data);
		$data = str_replace(":grrr:","<IMG src=\"art/smileys/grrr.gif\">",$data);
		$data = str_replace(":eek:","<IMG src=\"art/smileys/eek.gif\">",$data);
		$data = str_replace(":uhoh:","<IMG src=\"art/smileys/uhoh.gif\">",$data);
		
		//$data = preg_replace("/\[quote\](.*?)\[\/quote]/si", "<br><TABLE border=0 align=center width=85% cellpadding=0><TR><TD>
		//<font style=\"font-size: 11px;\">Quote</font>
		//<HR noshade size=1></TD></TR><TR><TD>\\1</TD></TR><TR><TD><HR noshade size=1></TD></TR></TABLE>", $data);
		
		$data = preg_replace("/\[quote\]/si", "<br><TABLE border=0 align=center width=85% cellpadding=0><TR><TD>
		<font style=\"font-size: 11px;\">Quote</font>
		<HR noshade size=1></TD></TR><TR><TD>",$data);
		$data = preg_replace("/\[\/quote]/si", "</TD></TR><TR><TD><HR noshade size=1></TD></TR></TABLE>", $data);
		$data = preg_replace("/\[b\](.*?)\[\/b\]/si", "<B>\\1</B>", $data);
		$data = preg_replace("/\[i\](.*?)\[\/i\]/si", "<I>\\1</I>", $data);
		$data = preg_replace("/\[u\](.*?)\[\/u\]/si", "<U>\\1</U>", $data);
		$data = preg_replace("/\[url\](http:\/\/)?(.*?)\[\/url\]/si", "<A HREF=\"http://\\2\" TARGET=\"_blank\">\\2</A>", $data);
		$data = preg_replace("/\[url=(http:\/\/)?(.*?)\](.*?)\[\/url\]/si", "<A HREF=\"http://\\2\" TARGET=\"_blank\">\\3</A>", $data);
		$data = preg_replace("/\[email\](.*?)\[\/email\]/si", "<A HREF=\"mailto:\\1\">\\1</A>", $data);
		$data = preg_replace("/\[img\](.*?)\[\/img\]/si", "<IMG SRC=\"\\1\">", $data);
		$data = preg_replace("/\[code\](.*?)\[\/code\]/si", "<p><blockquote><font size=1>code:</font><HR noshade size=1><pre>\\1<br></pre><HR noshade size=1></blockquote><p>", $data);	
		/* adding a space to beginning */
		$data = " ".$data;
	
		$data = preg_replace("#([\n ])([a-z]+?)://([^, \n\r]+)#i", "\\1<a href=\"\\2://\\3\" target=\"_blank\">\\2://\\3</a>", $data);
	
		$data = preg_replace("#([\n ])www\.([a-z0-9\-]+)\.([a-z0-9\-.\~]+)((?:/[^, \n\r]*)?)#i", "\\1<a href=\"http://www.\\2.\\3\\4\" target=\"_blank\">www.\\2.\\3\\4</a>", $data);
	
		$data = preg_replace("#([\n ])([a-z0-9\-_.]+?)@([^, \n\r]+)#i", "\\1<a href=\"mailto:\\2@\\3\">\\2@\\3</a>", $data);
	
		/* Remove space */
		$data = substr($data, 1);

	}
	
	return $data;

}

function reverse_process($data)
{
	global $config;
/* reverse Process message data with various conversions/filters */

	//$data = nl2br(htmlentities($data,ENT_QUOTES));
	
	//$data = str_replace("\r","",$data);

	if (ereg("^##EFCODE##.*",$data))
	{
		$data = str_replace("##EFCODE##","",$data);
	}
	else
	{
	
		if ($config[efcode])
		{
			$data = str_replace("<IMG src=\"art/smileys/smile.gif\">",":)",$data);
			$data = str_replace("<IMG src=\"art/smileys/biggrin.gif\">",":D",$data);
			$data = str_replace("<IMG src=\"art/smileys/tongue.gif\">",":P",$data);
			$data = str_replace("<IMG src=\"art/smileys/tongue.gif\">",":p",$data);
			$data = str_replace("<IMG src=\"art/smileys/confused.gif\">",":?:",$data);
			$data = str_replace("<IMG src=\"art/smileys/wink.gif\">",":wink:",$data);
			$data = str_replace("<IMG src=\"art/smileys/angry.gif\">",":angry:",$data);
			$data = str_replace("<IMG src=\"art/smileys/rolleyes.gif\">",":rolleyes:",$data);
			$data = str_replace("<IMG src=\"art/smileys/sad.gif\">",":(",$data);
			$data = str_replace("<IMG src=\"art/smileys/laugh.gif\">",":laugh:",$data);
			$data = str_replace("<IMG src=\"art/smileys/grrr.gif\">",":grrr:",$data);
			$data = str_replace("<IMG src=\"art/smileys/eek.gif\">",":eek:",$data);
			$data = str_replace("<IMG src=\"art/smileys/uhoh.gif\">",":uhoh:",$data);
		
			$data = preg_replace("/<TABLE border=0 align=center width=85% cellpadding=0><TR><TD>
			<font style=\"font-size: 11px;\">Quote<\/font>
			<HR noshade size=1><\/TD><\/TR><TR><TD>(.*?)<\/TD><\/TR><TR><TD><HR noshade size=1><\/TD><\/TR><\/TABLE>/si","[quote]\\1[/quote]", $data);
			$data = preg_replace("/<TABLE border=0 align=center width=85% cellpadding=0><TR><TD>
			<font style=\"font-size: 11px;\">Quote<\/font>
			<HR noshade size=1><\/TD><\/TR><TR><TD>/si", "[quote]", $data);
			$data = preg_replace("/<\/TD><\/TR><TR><TD><HR noshade size=1><\/TD><\/TR><\/TABLE>/si", "[/quote]", $data);
			$data = preg_replace("/<B>(.*?)<\/B>/si", "[B]\\1[/B]", $data);
			$data = preg_replace("/<I>(.*?)<\/I>/si", "[I]\\1[/I]", $data);
			$data = preg_replace("/<U>(.*?)<\/U>/si", "[U]\\1[/U]", $data);
			$data = preg_replace("/<p><blockquote><font size=1>code:<\/font><HR noshade size=1><pre>(.*?)<br><\/pre><HR noshade size=1><\/blockquote><p>/si", "[code]\\1[/code]", $data);
			$data = preg_replace("/\<A HREF=\"(http:\/\/)?(.*?)\" TARGET=\"_blank\"\>(.*?)\<\/A\>/si", "[url=http://\\2]\\3[/url]", $data);
			$data = preg_replace("/\<A HREF=\"mailto:(.*?)\">(.*?)<\/A>/si", "[email]\\1[/email]", $data);
			$data = preg_replace("/\<IMG SRC=\"(.*?)\">/si", "[img]\\1[/img]", $data);
		}
	
		$data = str_replace("<br>","\n",$data);
		$data = str_replace("<br />","\n",$data);
	}
	return $data;

}

function postsave($forum)
{
/* Process a submitted post */
	global $forumsess,$config,$post,$realm,$HTTP_SERVER_VARS,$lang;
	

	$content = "##EFCODE##".$post[content];
	if ((session_is_registered("forumsess"))&&($forumsess[$realm][username]))
	{
		if ($post[title])
		{
			$threadid = lastthread($forum) + 1;
					if ($post['anon'] && $config['allow_anon'])
					{
						$columns = "fname,threadid,threadindex,title,content,poster,ip,icon";
						$values = "'$forum', '$threadid', '$threadindex', '$post[title]', '$content', 'Anonymous', '$HTTP_SERVER_VARS[REMOTE_ADDR]', '$post[icon]'";
					}
					else
					{
						$columns = "fname,threadid,threadindex,title,content,poster,ip,icon";
						$values = "'$forum', '$threadid', '$threadindex', '$post[title]', '$content', '".$forumsess[$realm][username]."', '$HTTP_SERVER_VARS[REMOTE_ADDR]', '$post[icon]'";
					}	
		
			db_insert($config[mtable],$columns,$values);
		
			print "Successfully saved your post!<br>Now redirecting you to the thread...<br>";
		
			print "<META HTTP-EQUIV='refresh' content='2;url=index.php?action=displaythread&forum=$forum&id=$threadid&realm=$realm'>";
			
		} 
		else 
		{
			print "$lang[error] - You did not use a title for your post. <br>";
		}
	}
	elseif ($config['allow_anon'] && !$post[username])
	{
		if ($post[title])
		{
			$threadid = lastthread($forum) + 1;
			$columns = "fname,threadid,threadindex,title,content,poster,ip,icon";
			$values = "'$forum', '$threadid', '$threadindex', '$post[title]', '$content', 'Anonymous', '$HTTP_SERVER_VARS[REMOTE_ADDR]', '$post[icon]'";
			db_insert($config[mtable],$columns,$values);
		
			print "Successfully saved your post!<br>Now redirecting you to the thread...<br>";
		
			print "<META HTTP-EQUIV='refresh' content='2;url=index.php?action=displaythread&forum=$forum&id=$threadid&realm=$realm'>";
			
		} 
		else 
		{
			print "$lang[error] - You did not use a title for your post. <br>";
		}
	}
	else 
	{
		if (($post[username])&&($post[password]))
		{
			if (verifyuser($post[username],$post[password]))
			{
				if ($post[title])
				{
					$threadid = lastthread($forum) + 1;
					if ($post['anon'] && $config['allow_anon'])
					{
						$columns = "fname,threadid,threadindex,title,content,poster,ip,icon";
						$values = "'$forum', '$threadid', '$threadindex', '$post[title]', '$content', 'Anonymous', '$HTTP_SERVER_VARS[REMOTE_ADDR]', '$post[icon]'";
					}
					else
					{
						$columns = "fname,threadid,threadindex,title,content,poster,ip,icon";
						$values = "'$forum', '$threadid', '$threadindex', '$post[title]', '$content', '".$forumsess[$realm][username]."', '$HTTP_SERVER_VARS[REMOTE_ADDR]', '$post[icon]'";
					}	
						
					db_insert($config[mtable],$columns,$values);
						
					print "Successfully saved your post!<br>Now redirecting you to the thread...<br>";
						

					print "<META HTTP-EQUIV='refresh' content='2;url=index.php?action=displaythread&forum=$forum&id=$threadid&realm=$realm'>";
				} 
				else 
				{
					print "$lang[error] - You did not enter a $lang[title] for your post. <br>";
				}
			} 
			else 
			{
				print "$lang[error] - Invalid username or password!<br>";
			}
		} 
		else 
		{
			print "$lang[error] - Username or password not entered!<br>";
		}
	}
}

function replysave($forum,$threadid)
{
/* Process a submitted post */
	global $forumsess,$config,$post,$realm,$HTTP_SERVER_VARS,$lang;
	
	//$post[content] = process($post[content]);
	$content = "##EFCODE##".$post[content];
	if (is_thread_open($forum,$threadid))
	{
		if ((session_is_registered("forumsess"))&&($forumsess[$realm][username]))
		{
			$threadindex = lastindex($forum,$threadid) + 1;
					if ($post['anon'] && $config['allow_anon'])
					{
						$columns = "fname,threadid,threadindex,title,content,poster,ip,icon";
						$values = "'$forum', '$threadid', '$threadindex', '$post[title]', '$content', 'Anonymous', '$HTTP_SERVER_VARS[REMOTE_ADDR]', '$post[icon]'";
					}
					else
					{
						$columns = "fname,threadid,threadindex,title,content,poster,ip,icon";
						$values = "'$forum', '$threadid', '$threadindex', '$post[title]', '$content', '".$forumsess[$realm][username]."', '$HTTP_SERVER_VARS[REMOTE_ADDR]', '$post[icon]'";
					}	
		
			db_insert($config[mtable],$columns,$values);
		
			MailNotification($forum, $threadid, $forumsess[$realm][username]);
			print "Successfully saved your post!<br>Now redirecting you to the thread...<br>";
			print "<META HTTP-EQUIV='refresh' content='2;url=index.php?action=displaythread&forum=$forum&id=$threadid&realm=$realm'>";
		}
		elseif ($config['allow_anon'] && !$post[username])
		{
			$threadindex = lastindex($forum,$threadid) + 1;
			$columns = "fname,threadid,threadindex,title,content,poster,ip,icon";
			$values = "'$forum', '$threadid', '$threadindex', '$post[title]', '$content', 'Anonymous', '$HTTP_SERVER_VARS[REMOTE_ADDR]', '$post[icon]'";
			db_insert($config[mtable],$columns,$values);
		
			MailNotification($forum, $threadid, $forumsess[$realm][username]);
			print "Successfully saved your post!<br>Now redirecting you to the thread...<br>";
			print "<META HTTP-EQUIV='refresh' content='2;url=index.php?action=displaythread&forum=$forum&id=$threadid&realm=$realm'>";
			
  	}
		else 
		{
			if (($post[username])&&($post[password]))
			{
				if (verifyuser($post[username],$post[password]))
				{
					$threadindex = lastindex($forum,$threadid) + 1;
					if ($post['anon'] && $config['allow_anon'])
					{
						$columns = "fname,threadid,threadindex,title,content,poster,ip,icon";
						$values = "'$forum', '$threadid', '$threadindex', '$post[title]', '$content', 'Anonymous', '$HTTP_SERVER_VARS[REMOTE_ADDR]', '$post[icon]'";
					}
					else
					{
						$columns = "fname,threadid,threadindex,title,content,poster,ip,icon";
						$values = "'$forum', '$threadid', '$threadindex', '$post[title]', '$content', '".$forumsess[$realm][username]."', '$HTTP_SERVER_VARS[REMOTE_ADDR]', '$post[icon]'";
					}	
					db_insert($config[mtable],$columns,$values);
					
					MailNotification($forum, $threadid, $forumsess[$realm][username]);	
					print "Successfully saved your post!<br>Now redirecting you to the thread...<br>";
					print "<META HTTP-EQUIV='refresh' content='2;url=index.php?action=displaythread&forum=$forum&id=$threadid&realm=$realm'>";
					
				} 
				else 
				{
					print "$lang[error] - Invalid username or password!<br>";
					// something should be put here to redisplay the form //
				}
			} 
			else 
			{
				print "$lang[error] - Username or password not entered!<br>";
				// something should be put here to redisplay the form //
			}
		}
	} 
	else 
	{
		print "Sorry, the specified thread is closed for new posting.<br>";
		displaythread($forum,$threadid);
	}
}


function editsave($forum,$mid)
{
/* Save an edited message */
	global $forumsess,$config,$edit,$realm,$lang;
	$threadid = db_getvar($config[mtable],"id='$mid'","threadid");
	//$edit[content] = process($edit[content]);
	$content = "##EFCODE##".$edit[content];
	if ((session_is_registered("forumsess"))&&($forumsess[$realm][username]))
	{
		if ((ownercheck($mid,$forumsess[$realm][username]))||($forumsess[$realm][admin]))
		{
			if ($edit[delete])
			{
				db_remove($config[mtable],"id='$mid'");
				print "Successfully deleted post id $mid<br><br>";
			} 
			else 
			{	
				$columns = array("title","content");
				$values = array($edit[title],$content);
				db_update($config[mtable],"id='$mid'",$columns,$values);
				print "Successfully edited post id $mid<br><br>";
			}
		} 
		else 
		{
			print "$lang[error] - You do not have permission to edit this message!<br>";
		}
		
		if ($edit[delete])
			displayforum($forum);
		else
			displaythread($forum,$threadid);
	} 
	else 
	{
		if (($edit[username])&&($edit[password]))
		{
			if (verifyuser($edit[username],$edit[password]))
			{
				if ((ownercheck($mid,$forumsess[$realm][username]))||($forumsess[$realm][admin]))
				{
					if ($edit[delete])
					{
						db_remove($config[mtable],"id='$mid'");
						print "Successfully deleted post id $mid<br><br>";
					} 
					else 
					{	
						$columns = array("title","content");
						$values = array($edit[title],$edit[content]);
						db_update($config[mtable],"id='$mid'",$columns,$values);
						print "Successfully edited post id $mid<br><br>";
					}
					if ($edit[delete])
						displayforum($forum);
					else
						displaythread($forum,$threadid);
				} 
				else 
				{
					print "$lang[error] - You do not have permission to edit this message!<br>";
				}
			} 
			else 
			{
				print "$lang[error] - Invalid username or password!<br>";
			}
		} 
		else 
		{
			print "$lang[error] - Username or password not entered!<br>";
		}
	}
}







function listmsgicons()
{
	global $config;
	
	$icons = dir_list($config['msgicons_dir']);

	for ($i=0;$i<sizeof($icons);$i++)
	{
			print "<input type=radio name='post[icon]' value='$icons[$i]'><img src='$config[msgicons_dir]$icons[$i]'>";
		$c = $i+1;
		if ($c%6==0) 
			print "<br>";
	}
	
	?>
	
	</select>
	<?
}



function search()
{
	global $config,$realm,$search,$startat,$lang;
	
	if (!$startat)
		$startat = 0;
	
	if ($search[type] == "any")
		$ss = "poster RLIKE '$search[key]' OR content RLIKE '$search[key]' OR title RLIKE '$search[key]' ORDER BY id DESC LIMIT $startat,30";
	else
		$ss = "$search[type] RLIKE '$search[key]' ORDER BY id DESC LIMIT $startat,30";
	

			
	$totalhits = db_numrows($config[mtable],$ss);
	if ($totalhits>0)
	{
		$result = db_select("SELECT * FROM $config[mtable] WHERE $ss");
		$i = 0;

		$start = $startat+1;
		$end = $startat+$totalhits;
		$backto = $startat-30;
		if ($startat > 0)
			$backtext = "<a href='index.php?action=searchnow&realm=$realm&search%5Bkey%5D=$search[key]&search%5Btype%5D=$search[type]&startat=$backto'>&lt;&lt; $lang[previous] 30</a>";	
		if ($totalhits >= 30)
			$nexttext = "<a href='index.php?action=searchnow&realm=$realm&search%5Bkey%5D=$search[key]&search%5Btype%5D=$search[type]&startat=$end'>$lang[next] 30 &gt;&gt;</a>"; 
		
		
		print "<table border=0 cellpadding=0 cellspacing=0 width='$config[table_width]'><TR><td bgcolor='$config[tcolor]'>
		<table border=0 cellspacing=1 cellpadding=4 width='100%'>
		<tr bgcolor='".$config['color_top']."'>
		<td class=tabletop width='33%' align=left> <strong>$backtext</strong> </td>
		<td class=tabletop width='33%' align=center> <strong>Showing hits $start to $end</strong> </td>
		<td class=tabletop width='33%' align=right> <strong>$nexttext</strong> </td>
		</tr>
		</table>		
		<table border=0 cellspacing=1 cellpadding=4 width='100%'>
		<tr bgcolor='".$config['color_top']."'>
		<td class=tabletop> <strong>$lang[forum]</strong> </td>
		<td class=tabletop> <strong>$lang[title]</strong> </td>
		<td class=tabletop> <strong>$lang[poster]</strong> </td>
		<td class=tabletop> <strong>$lang[messages]</strong> </td></tr>";
		
		while($row = db_getarray($result))
		{
			
			$i = $i + 1;
	
			$forumname = $row[fname];
			$forum = db_getrow('forums',"fname='$forumname'");
	
			if (!$forum)
				$forum[ftitle] = "<i>Old/Removed $lang[forum]</i>";
			
			if ($i % 2) 
				$bgcolor = $config['color_b'];
			else
			  $bgcolor = $config['color_a'];
	
			if ($row[icon]) 
				$icon = "<img src='$config[msgicons_dir]$row[icon]'>";
			else
				$icon = "<img src='$config[msgicons_dir]$config[msgicon]'>";
				
			print "<tr bgcolor='$bgcolor'>
				<td>$forum[ftitle]</td>
				<td>$icon <a href='index.php?action=displaythread&forum=$forumname&id=$row[threadid]&realm=$realm'>$row[title]</a></td>
				<td>$row[poster]</td>
				<td>".threadcount($forumname,$row[threadid])."</td>
				</tr>";

		}

		print "</table>
		<table border=0 cellspacing=1 cellpadding=4 width='100%'>
		<tr bgcolor='".$config['color_top']."'>
		<td class=tabletop width='33%' align=left> <strong>$backtext</strong> </td>
		<td class=tabletop width='33%' align=center> <strong>Showing hits $start to $end</strong> </td>
		<td class=tabletop width='33%' align=right> <strong>$nexttext</strong> </td>
		</tr>
		</table>		
		</td></tr></table>";
		
	} 
	else 
	{
		print "No $lang[messages] found matching your $lang[search]<br>";
	}
		
		searchform();
	print "</div>";
	
}

function karmasave($who,$vote)
{
	global $config,$lang;
	
		$oldrank = db_getvar($config[utable],"username='$who'","rank");
		$oldvotes = db_getvar($config[utable],"username='$who'","votes");
		$newvote=$oldvotes+1;
		$newrank=$oldrank+$vote;
		$columns = array("rank","votes");
		$values = array($newrank,$newvote);
		
		if (db_update($config[utable],"username='$who'",$columns,$values))
			print "Successfully saved your vote!";
		else
			print "there was an $lang[error] processing your vote";
		
}

?>
