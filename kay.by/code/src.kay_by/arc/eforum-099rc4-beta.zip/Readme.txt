electrifiedForum v.99 (Beta)
README File
###############################


This is still a beta release of electrifiedForum, and havent had time to write really good documentation, but here is a quick rundown of how to install and setup.

NOTE: This package is designed for new installs of electrifiedForum as well as upgrades. Upgrade instructions can be found in upgrade-readme.txt.

Step 1: Copy files to web server.

Using the same directories as in the zip file, copy all files from this zip file to somewhere on your server, a subdirectory like 'forum' will be sufficient.

Step 2: Run Installer

If you are installing this onto a Unix/Linux webserver, and the webserver daemon doesnt run as root, you will need to CHMOD the eF directory to 777. You only will need to do this to run the installer. Once you have installed it, you can CHMOD it back to whatever you want. 

Go to the installer in your web browser, by going to the address www.yourdomain.com/efdirectory/install.php where yourdomain is the host of your pages, and efdirectory is the directory/path where ef resides.

Fill out the information, and click submit.

If you recieve any errors during install, please cut and paste them into a post on our support forums, http://www.electrifiedpenguin.com/forums/

If all went well, you should DELETE install.php and upgrade.php from your webserver. You can later upload and run install.php as needed to create new realms, just be sure to delete it after your done for security.




Step 3: Test!

To test the forums, go to the forum directory in your web browser. If you see no errors, and 1 forum 'chat', then everything is good to go.

There is a sample message in the messages table, and an admin with the username/password you picked in step 2 has been created.


Optionals:

Adding forums:

That can now be done through a web interface. Login with an admistrator level account, then click on the 'Manage Forums' link under administrative tools, and create/edit forums as necessary.

Adding custom HTML:

To add custom HTML to the top/bottom of the forums, and/or change the colors used with electrifiedForum, open the default realm file, realm.default.php (or a custom realm file), and there are three sets of things that can be changed:


Variables:
-----------
$config['filtering']			=	FALSE;			// Word Filtering On?
$config['efcode']			=	TRUE;			// Enable eF Code?
$config['use_buttons'] 			=	TRUE;			// Use Graphical post/reply buttons ?
$config['reply_butn']			=	'art/grayreply.gif';	// Button to use for reply
$config['post_butn']			=	'art/graypost.gif';	// Button to use for new post
$config['avatar_dir']			=	'art/avatars/';		// Directory to get avatars from
$config['msgicons_dir']			=	'art/msgicons/';	// Directory of icons that can be used to identify a post
$config['msgicon']			=	'icon1.gif';		// Default Icon for messages
$config['forumicon']			=	'art/grey_folder.gif';	// Forum Icon (No new messages)
$config['forumiconnew']			=	'art/blue_folder.gif';	// Forum Icon (New messages)
$config['rankcolor']			= 	'blue';			// Directory name for ranking icons (usually by color...)
$config['table_width'] 			= 	'90%';			// Width of tables
$config['icondir'] 			= 	'art/icons';		// Directory containing the posting icons (edit, quote, aim, etc...)
									// Currently we include icons and icons-white (for dark backgrounds)
									// You can create your own icons and dir and specify it here...
$config['24hour']			= 	FALSE;			// Use 24 hour time instead of 1-12 AM/PM format?

$config['color_top']			=	'#3300ff';		// Color of the table top rows
$config['color_top_font']		=	'#ffffff';		// Color of top font (The headers on tables)
$config['color_a']			=	'#e5e5e5';		// Primary table row color
$config['color_b']			=	'#d7d7d7';		// Color of alternate table rows
$config['tcolor']			=	'#808080';		// Color of the background table (the borders)
$config['badwords']			=	array("badword1","badword2"); // Array of words to be filtered. Set this up if enabling word filtering

function htmlstart()
-----------

You can modify the stylesheet within this function to match colors, fonts, etc, but DO NOT add or remove HTML code here

function mainblock()
-----------

You can place custom header html within the ?> and the <?

function mainend()
-----------

You can place custom footer html within the ?> and the <?



###############

Common Issues:

If you get errors such as 'call to undefined function mysql_connect', then MySQL support is not enabled or compiled into PHP.

If you get a unable to save session file error on a windows server, its usually because php.ini has not been configured properly.

If you see the code in the web browser instead of the actual application running, either PHP is not running properly with the webserver, or mime type for .php has not been setup.

###############

If you need assistance, feel free to contact me via email at lordvolt@electrifiedpenguin.com or through our forums at http://www.electrifiedpenguin.com/forums/





Thanks!
-Skot

Friday, November 2, 2001							

