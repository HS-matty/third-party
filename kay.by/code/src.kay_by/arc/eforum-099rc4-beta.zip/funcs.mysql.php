<?

function db_connect()
{
	global $config;
	return mysql_connect($config[dbhost],$config[dbuser],$config[dbpass]);
}

function db_disconnect()
{
	global $config;
	@mysql_close();
	return;
}

function db_select($sql)
{
	global $config;
	$result = mysql_db_query($config[dbname],$sql);
	return $result;
}

function db_do($sql)
{
	global $config;
	$result = mysql_db_query($config[dbname],$sql);
	return $result;
}

function db_getarray($result)
{
	global $config;
	$arr = @mysql_fetch_array($result);
	return $arr;
}

function db_getvar($table,$condition,$column)
{
	global $config;
	$result = mysql_db_query($config[dbname],"SELECT $column FROM $table WHERE $condition LIMIT 0,1");
	if ($result)
	{
		while ($row = mysql_fetch_array($result))
			$tvar = $row[$column];
		return $tvar;	
	}
	else
		return FALSE;
}

function db_getrow($table,$condition)
{
	global $config;
	$result = mysql_db_query($config[dbname],"SELECT * FROM $table WHERE $condition LIMIT 0,1");
	if ($result)
		while ($row = mysql_fetch_array($result))
			return $row;
	else
		return FALSE;
	
}

function db_insert($table,$columns,$values)
{
	global $config,$lastid;
	if (mysql_db_query($config[dbname],"INSERT INTO $table ($columns) values($values)"))
	{
		$lastid = mysql_insert_id();
		return TRUE;
	} 
	else
		return FALSE;
}

function db_update($table,$condition,$columns,$values)
{
	global $config;
	$set = "";
	for ($i = 0;$i < sizeof($columns);$i++)
	{
		$set .= "$columns[$i]='$values[$i]'";
		if (!(($i+1)==sizeof($columns))){ $set .= ","; }
	}
	$result = mysql_db_query($config[dbname],"UPDATE $table SET $set WHERE $condition");
	return TRUE;
}

function db_numrows($table,$condition)
{
	global $config;
	$result = @mysql_db_query($config[dbname],"SELECT * FROM $table WHERE $condition");
	$rows = @mysql_num_rows($result);
	return $rows;
}

function db_numrows_result($result)
{
	$rows = @mysql_num_rows($result);
	return $rows;
}


function db_numrows_sql($sql)
{
	global $config;
	$result = @mysql_db_query($config[dbname],$sql);
	$rows = @mysql_num_rows($result);
	return $rows;
}

function db_numrows_all($table)
{
	global $config;
	$result = @mysql_db_query($config[dbname],"SELECT * FROM $table");
	$rows = @mysql_num_rows($result);
	return $rows;
}

function db_remove($table,$condition)
{
	global $config;
	if ($result = mysql_db_query($config[dbname],"DELETE FROM $table WHERE $condition"))
		return TRUE;
	else
		return FALSE;
}
?>