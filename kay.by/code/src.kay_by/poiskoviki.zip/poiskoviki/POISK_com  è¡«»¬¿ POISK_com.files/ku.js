function extractCookieValue(val)
{
 if ((endOfCookie = document.cookie.indexOf(";", val)) == -1)
  {
   endOfCookie = document.cookie.length;
  }
 return unescape(document.cookie.substring(val, endOfCookie));
}

function ReadCookie(cookiename)
{
 var numOfCookies = document.cookie.length;
 var nameOfCookie = cookiename + "=";
 var cookieLen = nameOfCookie.length;
 var x = 0;
 while (x <= numOfCookies)
 {
  var y = (x + cookieLen);
  if (document.cookie.substring(x, y) == nameOfCookie)
  return(extractCookieValue(y));
  x = document.cookie.indexOf(" ", x) + 1;
  if (x == 0) return('empty');
 }
 return '';
}


function fload()
{
if (ReadCookie('ps1') != 'empty')
   document.gensearch.ps.value = ReadCookie('ps1');

if (ReadCookie('o1') != 'empty')
   document.gensearch.o.value = ReadCookie('o1');
return true;
}
 
function fgclick() 
{ 
  document.gensearch.submit();
} 
