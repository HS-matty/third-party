<?php

/************************************************************************/
/* PHP-NUKE: Web Portal System                                          */
/* ===========================                                          */
/*                                                                      */
/* Copyright (c) 2001 by Francisco Burzi (fbc@mandrakesoft.com)         */
/* http://phpnuke.org                                                   */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/

if (!eregi("admin.php", $PHP_SELF)) { die ("Access Denied"); }

switch($op) {

    case "RemoveComment":
    include("admin/modules/comments.php");
    break;

    case "removeSubComments":
    include("admin/modules/comments.php");
    break;

    case "removePollSubComments":
    include("admin/modules/comments.php");
    break;

    case "RemovePollComment":
    include("admin/modules/comments.php");
    break;

}

?>