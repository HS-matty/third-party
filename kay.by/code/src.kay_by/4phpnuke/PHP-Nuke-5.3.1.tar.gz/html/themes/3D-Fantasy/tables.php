<?php

function OpenTable() {
    echo "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\"><tr>
    <td width=\"15\" height=\"15\"><img src=\"themes/3D-Fantasy/images/up-left2.gif\" alt=\"\" border=\"0\"></td>
    <td background=\"themes/3D-Fantasy/images/up2.gif\" align=\"center\" width=\"100%\" height=\"15\">&nbsp;</td>
    <td><img src=\"themes/3D-Fantasy/images/up-right2.gif\" width=\"15\" height=\"15\" alt=\"\" border=\"0\"></td></tr>
    <tr>
    <td background=\"themes/3D-Fantasy/images/left2.gif\" width=\"15\">&nbsp;</td>
    <td bgcolor=\"ffffff\" width=\"100%\">";
}

function OpenTable2() {

    echo "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\"><tr>
    <td width=\"15\" height=\"15\"><img src=\"themes/3D-Fantasy/images/up-left2.gif\" alt=\"\" border=\"0\"></td>
    <td background=\"themes/3D-Fantasy/images/up2.gif\" align=\"center\" height=\"15\">&nbsp;</td>
    <td><img src=\"themes/3D-Fantasy/images/up-right2.gif\" width=\"15\" height=\"15\" alt=\"\" border=\"0\"></td></tr>
    <tr>
    <td background=\"themes/3D-Fantasy/images/left2.gif\" width=\"15\">&nbsp;</td>
    <td bgcolor=\"ffffff\">";
}
    
function CloseTable() {
    echo "</td>
    <td background=\"themes/3D-Fantasy/images/right2.gif\">&nbsp;</td></tr>
    <tr>
    <td width=\"15\" height=\"15\"><img src=\"themes/3D-Fantasy/images/down-left2.gif\" alt=\"\" border=\"0\"></td>
    <td background=\"themes/3D-Fantasy/images/down2.gif\" align=\"center\" height=\"15\">&nbsp;</td>
    <td><img src=\"themes/3D-Fantasy/images/down-right2.gif\" width=\"15\" height=\"15\" alt=\"\" border=\"0\"></td></tr>
    </td></tr></table>
    <br>";
}

function CloseTable2() {
    echo "</td>
    <td background=\"themes/3D-Fantasy/images/right2.gif\">&nbsp;</td></tr>
    <tr>
    <td width=\"15\" height=\"15\"><img src=\"themes/3D-Fantasy/images/down-left2.gif\" alt=\"\" border=\"0\"></td>
    <td background=\"themes/3D-Fantasy/images/down2.gif\" align=\"center\" height=\"15\">&nbsp;</td>
    <td><img src=\"themes/3D-Fantasy/images/down-right2.gif\" width=\"15\" height=\"15\" alt=\"\" border=\"0\"></td></tr>
    </td></tr></table>
    <br>";
}

?>